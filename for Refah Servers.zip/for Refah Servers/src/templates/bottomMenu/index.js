import activeHome from 'assets/icons/mobile/activeHome.svg';
import home from 'assets/icons/mobile/home.svg';
import activeProfile from 'assets/icons/mobile/activeProfile.svg';
import Wallet from 'assets/icons/mobile/wallet.svg';
import activeWallet from 'assets/icons/mobile/activeWallet.svg';
import transactionReport from 'assets/icons/mobile/transactionReport.svg';
import transactionFill from "assets/icons/mobile/transactionFill.svg"
import selectedBorder from 'assets/icons/mobile/selectedArrow.svg';
import Profile from 'assets/icons/mobile/profile.svg';
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const BottomMenu = () => {
  
  const { pathname } = useLocation();
  const navigate = useNavigate();
  
  const [ urlPath, setUrlPath ] = useState(); // set url path from url path in browser
  
  useEffect(() => {
    setUrlPath(() => {
      const path = pathname?.split('/').filter(Boolean);
      
      return path[path?.length - 1];
    });
  }, [ pathname ]);
  
  const menuItems = [
    {
      title: 'صفحه اصلی',
      icon: home,
      activeIcon:activeHome,
      key: 'merchantProfile',
      link: 'merchantProfile'
    }, {
      title: 'کیف پول',
      icon: Wallet,
      activeIcon:activeWallet,
      key: 'wallet',
      link: 'merchantProfile/wallet'
    }, {
      title: 'گزارش تراکنش',
      icon: transactionReport,
      activeIcon:transactionFill,
      key: 'depositReport',
      link: 'merchantProfile/depositReport'
    }, {
      title: 'پروفایل',
      icon: Profile,
      activeIcon:activeProfile,
      key: 'editProfile',
      link: 'merchantProfile/editProfile'
    },
  ];
  
  return (
    <div className={ 'flex w-full pb-[10px] justify-between gap-3 bg-white shadow-6 items-center text-center fixed bottom-0 lg:!hidden' }>
      {
        menuItems.map((item) => {
          const isActive = urlPath === item?.key;
          
          return(
            <div className={ 'text-[11.776px] w-1/4 text-center items-center' } onClick={() => navigate(item?.link)}>
              <div className={" drop-shadow-2xl"}>
                {
                  isActive? <img src={selectedBorder} className={" w-[45px] top-[-15px] mb-2 mx-auto drop-shadow-icon"}/>:""
                }
              </div>

              {
                isActive?<img src={ item?.activeIcon } className='inline '/>: <img src={ item?.icon } className='inline mt-[14px]'/>
              }

              <div className={isActive ? 'text-title pt-[4px]': 'pt-[8px]' }>
                { item?.title }
              </div>
            </div>
          )
        })
      }
    </div>
  );
};

export default BottomMenu;
