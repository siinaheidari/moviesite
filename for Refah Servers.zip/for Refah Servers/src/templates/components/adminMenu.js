import { Link } from 'react-router-dom';
import SvgIcon from 'templates/components/SvgIcon';

export const adminMenu = [
    {
        key: 'home',
        label: <SvgIcon icon={ 'boxes' } height={ 20 } width={ 20 }/>,
        children: [
            {
                key: 'dashboard',
                label: <Link to={ 'home/dashboard' }>داشبورد</Link>,
            },
            {
                key: 'supportAndTickets',
                label: <Link to={ 'home/supportAndTickets' }>لیست تیکت ها</Link>,
            },
            {
                key: 'submitComplaint',
                label: <Link to={ 'home/submitComplaint' }>لیست شکایات و پیشنهادات</Link>,
            },
        ],
    },
    {
        key: 'managements',
        label: <SvgIcon icon={ 'cog' } height={ 20 } width={ 20 }/>,
        children: [
            {
                key: 'merchants',
                label: <Link to={ 'managements/merchants' }>مدیریت پذیرندگان</Link>,
            },
            {
                key: 'transactions',
                label: <Link to={ 'managements/transactions' }>لیست تراکنش ها</Link>,
            },
            {
                key: 'operators',
                label: <Link to={ 'managements/operators' }>مدیریت اپراتورها</Link>,
            },
            {
                key: 'branches',
                label: <Link to={ 'managements/branches' }>مدیریت شعبه ها</Link>,
            },
            {
                key: 'PSP',
                label: <Link to={ 'managements/PSP' }>مدیریت PSP ها</Link>,
            },
            {
                key: 'projects',
                label: <Link to={ 'managements/projects' }>مدیریت طرح ها</Link>,
            },
            {
                key: 'clientLabel',
                label: <Link to={ 'managements/clientLabel' }>مدیریت برچسب مشتری</Link>,
            },
            {
                key: 'clientLevel',
                label: <Link to={ 'managements/clientLevel' }>مدیریت سطوح مشتری</Link>,
            },
            {
                key: 'systemCard',
                label: <Link to={ 'managements/systemCard' }>مدیریت کارت سامانه</Link>,
            },
            {
                key: 'requests-list',
                label: <Link to={ 'managements/requests-list' }>نمایش درخواست ها</Link>,
            },
            {
                key: 'terminalsList',
                label: <Link to={ 'managements/terminalsList' }>مشاهده ترمینال ها</Link>,
            },
            {
                key: 'survey',
                label: <Link to={ 'managements/survey' }>مدیریت نظرسنجی</Link>,
            },
            {
                key: 'Faq',
                label: <Link to={ 'managements/Faq' }>سوالات متداول</Link>,
            },
            {
                key: 'news',
                label: <Link to={ 'managements/news' }>مدیریت اخبار</Link>,
            },
            {
                key: 'scoreCalculation',
                label: <Link to={ 'managements/scoreCalculation' }>مدیریت محاسبه امتیاز</Link>,
            },
            {
                key: 'race',
                label: <Link to={ 'managements/race' }>مدیریت مسابقه</Link>,
            },
            {
                key: 'gallery',
                label: <Link to={ 'managements/gallery' }>مدیریت گالری</Link>,
            },
            {
                key: 'businessPartners',
                label: <Link to={ 'managements/businessPartners' }>مدیریت شرکای تجاری</Link>,
            },
        ],
    },
    {
        key: 'reports',
        label: <SvgIcon icon={ 'statisticsBold' } height={ 20 } width={ 20 }/>,
        children: [
            {
                key: 'walletDetail',
                label: <Link to={ 'reports/walletDetail' }>گزارش کیف پول</Link>,
            },
        ],
    },
];