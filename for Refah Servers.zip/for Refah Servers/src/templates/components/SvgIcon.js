import PropTypes from 'prop-types';
import { memo } from 'react';
import styled from 'styled-components';

const Icon = styled.span`
    -webkit-mask-size: cover;
    mask-size: cover;
    -webkit-mask-image: url(${ props => props?.requireIcon });
    mask-image: url(${ p => p.requireIcon });
    background-color: ${ p => p.color };
    width: ${ p => p.width ? `${ p.width }px` : 'auto' };
    height: ${ p => p.height }px;
    display: block;
  `;

const SvgIcon = (props) => {
  
  const { icon, color, width, height, style, ...reset } = props;
  
  const requireIcon = require(`assets/icons/${ icon }.svg`);
  
  return <Icon
    requireIcon={ requireIcon }
    color={ color }
    width={ width }
    height={ height }
    className={ `--svgIcon ${ !!reset?.className ? reset?.className : '' }` }
    style={ style }
  />;
};

SvgIcon.propTypes = {
  icon: PropTypes.string.isRequired,
  color: PropTypes.string,
  width: PropTypes.number,
  height: PropTypes.number?.isRequired,
  style: PropTypes.object
};

SvgIcon.defaultProps = {
  color: '#4D4D4D',
  height: 24
};

export default memo(SvgIcon);
