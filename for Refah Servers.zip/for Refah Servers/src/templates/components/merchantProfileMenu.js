import React from 'react';
import { Link } from 'react-router-dom';
import SvgIcon from 'templates/components/SvgIcon';


export const merchantProfileMenu = [

    {
        key: 'merchantProfile',
        label: <Link to={ '/merchantProfile' }>صفحه اصلی</Link>,
        icon: <SvgIcon icon={ 'home' } height={ 14 }/>,
    },
    {
        key: 'requests',
        label: 'ثبت درخواست',
        icon: <SvgIcon icon={ 'saveForLater' } height={ 14 }/>,
        children: [
            {
                key: 'posAndIPGRequest',
                label: <Link to={ '/merchantProfile/requests/posAndIPGRequest' }>{ 'درخواست پوز' } <span
                    className="--byDollarCoin"/></Link>,
            },
            // {
            //   key: 'profile2',
            //   label: <Link to={ 'requests/merchantProfile' }>{ 'بیمه' } <span className='--byDollarCoin'/></Link>
            // },
            // {
            //   key: 'profile3',
            //   label: <Link to={ 'requests/merchantProfile' }>{ 'مالیات' } <span className='--byDollarCoin'/></Link>
            // },
            {
                key: 'RequestPaperRoll',
                label: <Link to={ '/merchantProfile/requests/RequestPaperRoll' }>{ 'درخواست رول کاغذی' } <span
                    className="--byDollarCoin"/></Link>,
            },
            {
                key: 'ChangeTerminal',
                label: <Link to={ '/merchantProfile/requests/ChangeTerminal' }>{ 'درخواست تعویض پایانه' } <span
                    className="--byDollarCoin"/></Link>,
            },
            {
                key: 'lostTerminal',
                label: <Link to={ '/merchantProfile/requests/lostTerminal' }>{ 'درخواست اعلام مفقودی پایانه' } <span
                    className="--byDollarCoin"/></Link>,
            },
            {
                key: 'ChangeTerminalAddress',
                label: <Link to={ '/merchantProfile/requests/ChangeTerminalAddress' }>{ 'درخواست تغییر IP' } <span
                    className="--byDollarCoin"/></Link>,
            },
            {
                key: 'disposeTerminal',
                label: <Link to={ '/merchantProfile/requests/disposeTerminal' }>{ 'درخواست جمع آوری پایانه' } <span
                    className="--byDollarCoin"/></Link>,
            },
        ],
    },
    {
        key: 'pursueRequests',
        label: <Link to={ 'pursueRequests' }>پیگیری درخواستهای من</Link>,
        icon: <SvgIcon icon={ 'home' } height={ 14 }/>,
    },

    {
        key: 'terminals',
        label: <Link to={ 'terminals' }>دستگاه ها و درگاه های من</Link>,
        icon: <SvgIcon icon={ 'list' } height={ 8 }/>,
    },
    {
        key: 'myBankAccounts',
        label: <Link to={ 'myBankAccounts' }>نمایش اطلاعات بانکی من</Link>,
        icon: <SvgIcon icon={ 'contactlessCard' } height={ 10 }/>,
    },
    {
        key: 'facilitiesGrants',
        label: <Link to={ 'facilitiesGrants' }>نمایش میزان تسهیلات قابل اعطا</Link>,
        icon: <SvgIcon icon={ 'ranking' } height={ 10 }/>,
    },
    {
        key: 'depositReport',
        label: <Link to={ 'depositReport' }>گزارش ریز تراکنش های من</Link>,
        icon: <SvgIcon icon={ 'saveForLater' } height={ 14 }/>,
    },
    {
        key: 'tournament',
        label: <Link to={ 'tournament' }>شرکت در مسابقه</Link>,
        icon: <SvgIcon icon={ 'blockchain' } height={ 15 } width={ 15 }/>,
    },
    {
        key: 'discountCodes',
        label: <Link to={ 'discountCodes' }>کدهای تخفیف</Link>,
        icon: <SvgIcon icon={ 'discount' } height={ 14 }/>,
    },
    {
        key: 'businessPartners',
        label: <Link to={ 'businessPartners' }>شرکای تجاری</Link>,
        icon: <SvgIcon icon={ 'webHyperlink' } height={ 14 }/>,
    },
    {
        key: 'plansAndCampaigns',
        label: <Link to={ 'plansAndCampaigns' }>طرح ها و کمپین ها</Link>,
        icon: <SvgIcon icon={ 'campaign' } height={ 14 }/>,
    },
    {
        key: 'support',
        label: 'پشتیبانی',
        icon: <SvgIcon icon={ 'saveForLater' } height={ 14 }/>,
        children: [
            {
                key: 'support1',
                label: <Link to={ '/merchantProfile/support/offersComplain' }>{ 'ثبت شکایات و پیشنهادات' } <span
                    className="--byDollarCoin"/></Link>,
            },
            {
                key: 'sendTicket',
                label: <Link to={ '/merchantProfile/support/sendTicket' }>{ 'ارسال تیکت' } <span
                    className="--byDollarCoin"/></Link>,
            },

        ],
    },
    {
        key: 'survey',
        label: <Link to={ 'survey' }>شرکت در نظرسنجی</Link>,
        icon: <SvgIcon icon={ 'comments' } height={ 15 } width={ 15 }/>,
    },
];