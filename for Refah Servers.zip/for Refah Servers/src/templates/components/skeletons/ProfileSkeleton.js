import { Col, Row } from 'antd';
import { SquareSkeleton } from 'templates/Ui';
import {MatchBreakpoint} from "react-hook-breakpoints";
import HomeMobile from "../../../pages/profile/merchantProfile/home/screens/Home.Mobile";
import HomeDesktop from "../../../pages/profile/merchantProfile/home/screens/Home.desktop";

const ProfileSkeleton = () => {
  return (
    <>

    <MatchBreakpoint max="md">
        <Row gutter={ [0,40] }>
            <Col span={ 24 }>
                <SquareSkeleton count={ { row: 1, col: 1 } }  height={ 200 } radius={ 5 }/>
            </Col>

            <Col span={ 24 }>
                <SquareSkeleton count={ {row:4, col: 4 } } width={'100%'} height={100 }  radius={ 50}/>
            </Col>

            <Col span={ 24 }>
                <SquareSkeleton count={ { row: 1, col: 1 } } height={ 120 } radius={ 10 }/>
            </Col>

        </Row>
    </MatchBreakpoint>

    <MatchBreakpoint min="lg">
        <Row gutter={ [0, 40] }>
            <Col span={ 24 }>
                <SquareSkeleton count={ { row: 1, col: 1 } } height={ 40 } radius={ 5 }/>
            </Col>

            <Col span={ 24 }>
                <SquareSkeleton count={ { col: 4 } } height={ 80 } radius={ 10 }/>
            </Col>

            <Col span={ 24 }>
                <SquareSkeleton count={ { row: 2, col: 1 } } height={ 300 } radius={ 10 }/>
            </Col>
        </Row>
    </MatchBreakpoint>
    </>
  );
};

export default ProfileSkeleton;
