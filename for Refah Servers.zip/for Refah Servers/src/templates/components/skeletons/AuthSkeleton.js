import { SquareSkeleton } from 'templates/Ui';
import styled from 'styled-components';
import { MatchBreakpoint } from 'react-hook-breakpoints';
import { Col, Row } from 'antd';

const SkeletonContent = styled.div`
  margin-top: 28px;
`;

const AuthSkeleton = () => {
  return (
      <>

          <MatchBreakpoint max="md">
              <SquareSkeleton count={ { row: 1, col: 1 } } height={ '70.3vh' } radius={ 5 }/>
          </MatchBreakpoint>


          <SkeletonContent min="lg">
              <SquareSkeleton count={ { row: 1, col: 2 } } height={ '75.3vh' } radius={ 5 }/>
          </SkeletonContent>
      </>

  );
};

export default AuthSkeleton;
