import PropTypes from 'prop-types';
import styled from 'styled-components';

const ListCircleContainer = styled.span`
  display: inline-block;
  width: ${ props => props?.width }px;
  height: ${ props => props?.height }px;
  background: ${ props => props?.linear ? "linear-gradient(180deg, #F61982 0%, #21409A 100%)" : props?.color };
  border-radius: 50%;
  vertical-align: middle;
  margin-inline-end: ${ props => props?.space }px;
`;

const ListCircle = (props) => <ListCircleContainer { ...props }/>;

ListCircle.propTypes = {
  width: PropTypes.number,
  height: PropTypes.number,
  color: PropTypes.string,
  space: PropTypes.number,
  linear: PropTypes.bool
};

ListCircle.defaultProps = {
  width: 8,
  height: 8,
  color: '#1447A0',
  linear: false,
  space: 10
};

export default ListCircle;
