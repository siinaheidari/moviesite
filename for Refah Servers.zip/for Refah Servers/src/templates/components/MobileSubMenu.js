import {Row, Col, Space} from 'antd';
import {Link, useLocation} from "react-router-dom";
import { merchantProfileMenu } from 'templates/components/merchantProfileMenu';
import {TransitionsPage} from "../Ui";
import rightArrow from "../../assets/icons/mobile/rightArrow.svg";
import circle from "../../assets/icons/mobile/circle.svg";
import blueCircle from "../../assets/icons/mobile/blueCircle.svg";
import React from "react";

const MobileSubMenu = () => {

    const location = useLocation();
    const menuKey = location?.state?.menuKey || '';
    const subMenuTitle = location?.state?.subMenuTitle || '';

    const menuItems = menuKey ? merchantProfileMenu?.find(item => item?.key === menuKey)?.children : [];

    return (
        <TransitionsPage coordinates={'x'} className={"lg:hidden"}>
            <Col span={ 24 } className={ 'mb-[13px] lg:hidden' }>
                <Link to={ "/merchantProfile" } className={ '' }> <img src={ rightArrow }/></Link>
            </Col>
            <div className={ 'flex mb-[27px] lg:hidden justify-between items-center' }>
                <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                    <img src={ circle }/>
                    {subMenuTitle}
                </Space>
            </div>
            <Row gutter={[0,20]}>
                {menuItems?.map(item => (
                    <Col span={24}>
                        <Row className={"text-[#4D4D4D] bg-white px-[19px] drop-shadow-md rounded-[7px]"} gutter={8} align={'middle'}>
                            <Col>
                                <img src={blueCircle}/>
                            </Col>
                            <Col flex='1 1' className='[&>a]:!block [&>a]:py-[19px]'>
                                {item?.label}
                            </Col>
                        </Row>
                        <div className={"border-b-[3.8px] border-b-[#2857BD] w-[99%] mx-auto rounded-b-[30px]"}></div>
                    </Col>
                ))}
            </Row>
        </TransitionsPage>

    );
};

export default MobileSubMenu;
