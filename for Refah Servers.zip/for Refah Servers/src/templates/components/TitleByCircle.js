import { Space } from 'antd';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const TitleByCircleContainer = styled(Space)`
  .--circle {
    width: 12px;
    height: 12px;
    border-radius: 100%;
    background: linear-gradient(180deg, #F61982 0%, #21409A 100%);
  }

  .--path {
    color: #4D4D4D;
    font-size: .875rem;
  }
`;

const TitleByCircle = props => {
  
  const { text, space } = props;
  
  return (
    <TitleByCircleContainer size={ space }>
      <div className='--circle'/>
      
      <div className='--title'>{ text }</div>
    </TitleByCircleContainer>
  );
};

TitleByCircle.propTypes = {
  text: PropTypes.any.isRequired,
  space: PropTypes.number
};

TitleByCircle.defaultProps = {
  space: 16
};

export default TitleByCircle;
