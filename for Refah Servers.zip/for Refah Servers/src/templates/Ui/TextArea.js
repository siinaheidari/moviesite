import { Form, Input } from 'antd';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import tw from 'twin.macro';

const InputContainer = styled(Form.Item)`
  line-height: 0;
  .ant-form-item-label {
    padding-bottom: 6px;
    text-align: start;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    ${ tw`max-lg:!text-[12px]` }
    label {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;
      ${tw`max-lg:!text-[12px]`}

      &.ant-form-item-required {
        /*&:after {
          display: inline-block;
          margin-left: 4px;
          margin-top: -5px;
          color: #FF0000;
          font-size: .875rem;
          font-family: SimSun, sans-serif;
          font-weight: bolder;
          line-height: 1;
          content: '*';
        }*/

        &:before {
          margin-top: -5px;
        }
      }
    }
  }

  .ant-input-affix-wrapper {
    &:not(.ant-input-affix-wrapper-status-error) {
      .ant-input {
        border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
        box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
        border-radius: 5px;
        overflow: hidden;
      }
    }

    .ant-input {
      color: #4D4D4D;

      &::placeholder {
        color: rgba(112, 112, 112, 0.64);
        font-weight: 400;
      }
    }

    .anticon {
      font-size: 17px;
      color: #12489f;
      font-weight: 600;
    }

    &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless),
    &.ant-input-status-error:not(.ant-input-disabled):not(.ant-input-borderless).ant-input,
    &.ant-input-status-error:not(.ant-input-disabled):not(.ant-input-borderless).ant-input:hover,
    &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless):hover {
      border-color: #ff4d4f !important;
    }

    &.ant-input-affix-wrapper-rtl {
      .anticon {
        right: unset;
      }

  }
`;

const TextArea = (props) => {
  
  const { TextArea: AntdTextArea } = Input;
  
  const {
    label,
    placeholder,
    name,
    rows,
    labelCol,
    extra,
    initialValue,
    rules,
    onBlur,
    bordered,
    wrapperStyle,
    inputStyle,
    hidden,
    initialValues,
    ltr,
    allowClear,
    ...reset
  } = props;
  
  return (
    <InputContainer
      label={ label }
      name={ name }
      initialValue={ initialValue }
      extra={ extra }
      rules={ rules }
      bordered={ +bordered }
      hidden={ hidden }
      ltr={ +ltr }
      style={ wrapperStyle }
      labelCol={ labelCol }
    >
      <AntdTextArea
        placeholder={ placeholder || label }
        initialValues={ initialValues }
        allowClear={ allowClear }
        onBlur={ onBlur }
        style={ inputStyle }
        rows={ rows }
        { ...reset }
      />
    </InputContainer>
  );
};

TextArea.propTypes = {
  label: PropTypes.string,
  placeholder: PropTypes.string,
  name: PropTypes.any,
  rows: PropTypes.number,
  extra: PropTypes.any,
  initialValue: PropTypes.any,
  rules: PropTypes.array,
  onBlur: PropTypes.func,
  bordered: PropTypes.bool,
  allowClear: PropTypes.bool,
  ltr: PropTypes.bool,
  hidden: PropTypes.bool,
  wrapperStyle: PropTypes.object,
  inputStyle: PropTypes.object,
  labelCol: PropTypes.object,
  ref: PropTypes.any
};

TextArea.defaultProps = {
  bordered: true,
  ltr: false,
  hidden: false,
  allowClear: true,
  rows: 4
};

export { TextArea };
