import { Form, Radio as AntdRadio } from 'antd';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components';
import tw from 'twin.macro';

const { Group } = AntdRadio;

const GroupContainer = styled(Group)`
  ${ props => !!props?.block &&
    css`
      position: relative;
      display: flex;
      align-items: stretch;
      justify-items: flex-start;
      width: 100%;

      > label {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    `
  }
`;

const InputContainer = styled(Form.Item)`
  line-height: 0;
  ${ tw`max-lg:!mb-[10px]` }
  
  .ant-form-item-label {
    padding-bottom: 4px;
    text-align: start;

    label {
      color: #000000;
      font-size: .875rem;
      font-weight: 400;
      ${tw`max-md:!text-[12px]`};

      &.ant-form-item-required {
        &:after {
          display: inline-block;
          margin-left: 4px;
          margin-top: -5px;
          color: #FF0000;
          font-size: .875rem;
          ${tw`max-lg:!text-[12px]`};
          font-family: SimSun, sans-serif;
          font-weight: bolder;
          line-height: 1;
          content: '*';
        }

        &:before {
          display: none !important;
        }
      }
    }
  }

  &.ant-form-item-has-error {
    .ant-radio-inner {
      border-color: #ff4d4f !important;
    }
  }
`;

const RadioInput = styled(AntdRadio)`
  .ant-radio {
    .ant-radio-input {
      width: 16px !important;
      height: 16px !important;
    }

    .ant-radio-inner {
      width: 16px !important;
      height: 16px !important;
      border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      background-color: #FFFFFF;

      &:after {
        transform: scale(.6) !important;
      }
    }

    &.ant-radio-checked {
      .ant-radio-inner {
        &:after {
          background-color: #F61982;
        }
      }
    }

    &.ant-radio-disabled + span {
      color: rgba(77, 77, 77, 0.6) !important;
      cursor: not-allowed !important;
    }
  }

  span + span {
    color: #4D4D4D;
    font-size: .875rem;
    font-weight: 400;
    ${tw`max-lg:!text-[12px]`};
  }
`;

const RadioButtonInput = styled(AntdRadio.Button)`
  border-color: ${ props => props?.bordered ? props?.theme?.inputsBorderColor : 'unset' } !important;
  height: 42px;
  line-height: 42px;
  text-align: center;

  ${ props => props?.theme?.isAdmin &&
    css`
      :not(:last-child) {
        border-inline-end: none !important;
      }
    `
  }
  span + span {
    color: #4D4D4D;
    font-size: .875rem;
    font-weight: 400;
  }

  &.ant-radio-button-wrapper-checked {
    background-color: ${ props => props?.theme?.radioGroupBgColor } !important;
    border-color: ${ props => props?.theme?.radioGroupBgColor } !important;

    span + span {
      color: #FFFFFF;
      font-weight: 500;
    }
  }
`;

const RadioGroup = (props) => {
  
  const { block, value, children, ...reset } = props;
  
  return (
    <GroupContainer block={ block } value={ value } { ...reset }>
      { children }
    </GroupContainer>
  );
};

const RadioFormItem = (props) => {
  
  const { label, name, rules, wrapperStyle, children, ...reset } = props;
  
  return (
    <InputContainer
      label={ label }
      name={ name }
      rules={ rules }
      style={ wrapperStyle }
      { ...reset }
    >
      { children }
    </InputContainer>
  );
};

const Radio = (props) => {
  
  const { value, children, bordered, ...reset } = props;
  
  return (
    <RadioInput value={ value } bordered={ +bordered } { ...reset }>
      { children }
    </RadioInput>
  );
};

const RadioButton = props => {
  const { value, children, bordered, ...reset } = props;
  
  return (
    <RadioButtonInput value={ value } bordered={ +bordered } { ...reset }>
      { children }
    </RadioButtonInput>
  );
};

RadioGroup.propTypes = {
  block: PropTypes.bool,
  value: PropTypes.string,
  children: PropTypes.node
};

RadioGroup.defaultProps = {
  block: false
};

RadioFormItem.propTypes = {
  label: PropTypes.string,
  name: PropTypes.string,
  rules: PropTypes.array,
  wrapperStyle: PropTypes.object,
  children: PropTypes.node
};

Radio.propTypes = {
  value: PropTypes.string,
  children: PropTypes.node
};

Radio.defaultProps = {
  bordered: true
};

RadioButton.propTypes = {
  value: PropTypes.any,
  bordered: PropTypes.bool
};

RadioButton.defaultProps = {
  bordered: true
};

export { RadioFormItem, Radio, RadioButton, RadioGroup };
