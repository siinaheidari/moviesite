import { Button as AntdButton } from 'antd';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components';
import { isNumber } from 'utils/helper';
import tw from "twin.macro";

const ButtonContainer = styled(AntdButton)`
  // min-width: ${ ({ btnwidth }) => isNumber(btnwidth) ? `${ btnwidth }px` : btnwidth };
  height: ${ ({ btnheight, textwrap }) => textwrap ? 'auto' : btnheight + 'px' };
  border-radius: ${ props => props?.radius }px;
  padding: ${ ({ textwrap }) => textwrap ? '5px' : 0 } 5px;
  line-height: ${ ({ btnheight, textwrap }) => textwrap ? 1.7 : btnheight + 'px' };
  white-space: ${ ({ textwrap }) => textwrap ? 'normal' : 'nowrap' };
  margin: 0;

  &[disabled] {
    background: rgba(85, 126, 255, .4) !important;
    border: unset !important;

    span {
      color: rgba(255, 255, 255, 1) !important;
    }

    &:hover {
      background: rgba(85, 126, 255, .5) !important;
    }
  }

  /***** FOR PRIMARY BTN *****/
  ${ props => props?.type === 'primary' &&
  css`
      background: linear-gradient(90deg, #F61982 0%, #1447A0 100%);
      box-shadow: 0 4px 10px rgba(255, 0, 0, 0.05);
      color: #FFFFFF;
    ${tw`max-lg:text-[12px] max-lg:!font-[400]`}
      span {
        color: #FFFFFF;
      }

      &:hover,
      &:focus {
        background: linear-gradient(90deg, #b6075a 0%, #0d316f 100%);
      }
    ` };
  /***** /FOR PRIMARY BTN *****/

  /***** FOR SECONDARY BTN *****/
  ${ props => props?.type === 'secondary' &&
  css`
      border: 1px solid #1447A0;
      background-color: #1447A0;
      box-shadow: 0 3px 6px rgba(85, 126, 255, 0.1);
${tw`max-lg:text-[12px] max-lg:!font-[400]`}
      span {
        color: #FFFFFF;
      }

      &:hover,
      &:focus {
        background-color: #0d316f;
        border-color: #0d316f;
      }
    ` };
  /***** /FOR SECONDARY BTN *****/

  /***** FOR DEFAULT BTN *****/
  ${ props => props?.type === 'default' &&
  css`
      background-color: transparent;
      border: 1px solid #1447A0;
    ${tw`max-lg:text-[12px] max-lg:!font-[400]`}
      span {
        color: #1447A0;
      }

      &:hover,
      &:focus {
        border-color: #0d316f;
      }
    ` };
  /***** /FOR DEFAULT BTN *****/

  /***** FOR DASHED BTN *****/
  ${ props => props?.type === 'dashed' &&
  css`
      border-style: dashed !important;
      border-color: #1447A0 !important;
    ${tw`max-lg:text-[12px] max-lg:!font-[400]`}
      span {
        color: #1447A0;
      }

      &:hover,
      &:focus {
        border-color: #0d316f;
      }
    ` };
  /***** /FOR DASHED BTN *****/

  /***** FOR transparent BTN *****/
  ${ props => props?.type === 'transparent' &&
  css`
      background-color: transparent !important;
      border-style: none !important;
      border-color: unset !important;

      span {
        color: #0d316f;
      }
    ` };
  /***** /FOR transparent BTN *****/

  /***** FOR icon align BTN *****/
  ${ props => props?.iconalign === 'end' &&
  css`
      display: flex;
      flex-flow: row-reverse;
      align-items: center;
      justify-content: center;

      > span + span {
        margin: 0;
        margin-inline-end: 9px;
      }
    `
}
  /***** /FOR icon align BTN *****/
`;

const Button = (props) => {
  
  const { type, width, height, block, textWrap, disabled, children, radius, iconAlign, ...reset } = props;
  
  return (
    <ButtonContainer
      type={ type }
      btnwidth={ width }
      btnheight={ height }
      block={ block }
      disabled={ disabled }
      textwrap={ +textWrap }
      radius={ radius }
      iconalign={ iconAlign }
      { ...reset }
    >
      { children }
    </ButtonContainer>
  );
};

Button.propTypes = {
  type: PropTypes.oneOf(['default', 'primary', 'secondary', 'dashed', 'transparent']),
  shape: PropTypes.oneOf(['default', 'circle', 'round']),
  iconAlign: PropTypes.oneOf(['start', 'end']),
  width: PropTypes.any,
  height: PropTypes.number,
  radius: PropTypes.number,
  disabled: PropTypes.bool,
  textWrap: PropTypes.bool,
  loading: PropTypes.bool,
  block: PropTypes.bool,
  htmlType: PropTypes.oneOf(['submit', 'button', 'reset']),
  onClick: PropTypes.func,
  children: PropTypes.node
};

Button.defaultProps = {
  type: 'primary',
  shape: 'default',
  iconAlign: 'start',
  width: 169,
  height: 38,
  radius: 5,
  disabled: false,
  block: false,
  textWrap: false,
  loading: false
};

export { Button };
