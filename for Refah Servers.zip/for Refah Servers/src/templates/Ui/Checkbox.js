import { Checkbox as AntdCheckbox, Form } from 'antd';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import tw from 'twin.macro';

const InputContainer = styled(Form.Item)`
  .ant-checkbox-wrapper {
    .ant-checkbox {
      .ant-checkbox-inner {
        border: ${ props => props?.bordered ? '1px solid #C6D4FF' : 'unset' };
        border-radius: 2px;
      }

      &.ant-checkbox-checked {
        .ant-checkbox-inner {
          background-color: #F61982 !important;
          border-color: #F61982 !important;
          box-shadow: none !important;
        }
      }
    }

    span + span {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;
    }

    :hover .ant-checkbox-checked:not(.ant-checkbox-disabled)::after {
      border: none !important;
    }
  }

  &.ant-form-item-has-error {
    .ant-checkbox {
      .ant-checkbox-inner {
        border: 1px solid #ff4d4f;
    
      }
    }
  }
  .ant-form-item-explain-error{
    ${tw`max-md:!text-[12px]`};
  }
`;

const InputContainerAsDiv = styled.div`
  .ant-checkbox-wrapper {
    .ant-checkbox {
      .ant-checkbox-inner {
        border: ${ props => props?.bordered ? '1px solid #C6D4FF' : 'unset' };
        border-radius: 2px;
      }

      &.ant-checkbox-checked {
        .ant-checkbox-inner {
          background-color: #F61982;
          border-color: #F61982;
        }
      }
    }

    span + span {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;
    }

    :hover {
      .ant-checkbox-inner {
        display: none;
        background-color: #F61982 !important;
        border-color: #F61982 !important;
      }
    }
  }
`;

const Checkbox = (props) => {
  
  const { label, name, wrapperStyle, bordered, initialValue, rules, children, withoutForm, ...reset } = props;
  
  if (withoutForm) {
    return (
      <InputContainerAsDiv
        style={ wrapperStyle }
        bordered={ +bordered }
      >
        <AntdCheckbox { ...reset }>
          { children }
        </AntdCheckbox>
      </InputContainerAsDiv>
    );
  }
  
  return (
    <InputContainer
      label={ label }
      name={ name }
      rules={ rules }
      valuePropName='checked'
      style={ wrapperStyle }
      initialValue={ initialValue }
      bordered={ +bordered }
    >
      <AntdCheckbox { ...reset }>
        { children }
      </AntdCheckbox>
    </InputContainer>
  );
};

Checkbox.propTypes = {
  label: PropTypes.string,
  name: PropTypes.any,
  rules: PropTypes.array,
  children: PropTypes.node,
  initialValue: PropTypes.any,
  withoutForm: PropTypes.bool,
  bordered: PropTypes.bool,
  wrapperStyle: PropTypes.object
};

Checkbox.defaultProps = {
  withoutForm: false,
  bordered: true
};

export { Checkbox };
