import { Modal as AntdModal } from 'antd';
import styled, { css } from 'styled-components';
import { useBreakpoints } from 'react-hook-breakpoints';
import PropTypes from 'prop-types';

const ModalContainer = styled(AntdModal)`
  max-width: 100%;

  ${ props => {
    if (props?.width) {
      return css`
        width: ${ props?.width } !important;
      `;
    }
    return css`
      width: ${ props?.widthbybreakpoints[ props?.currentbreakpoint ] }% !important;
    `;
  } }
  
  .ant-modal-content {
    background-color: #FFF;
    box-shadow: 0 3px 15px 1px rgba(0, 0, 0, 0.15);
    border-radius: 15px;
    overflow: hidden;
    padding: 0;

    .ant-modal-header {
      padding: 16px 10%;
    }

    .ant-modal-body {
      padding: 35px 6%;
    }
  }
`;

const Modal = (props) => {
  const { currentBreakpoint } = useBreakpoints();
  
  const { footer, closable, maskClosable, destroyOnClose, size, children, className, ...reset } = props;
  
  const widthByBreakPoints = {
    xs: size?.xs,
    sm: size?.sm,
    md: size?.md,
    lg: size?.lg,
    xl: size?.xl,
    xxl: size?.xxl
  };
  
  return (
    <ModalContainer
      footer={ footer }
      destroyOnClose={ destroyOnClose }
      width={ reset?.width }
      currentbreakpoint={ currentBreakpoint }
      widthbybreakpoints={ widthByBreakPoints }
      closable={closable}
      maskClosable={maskClosable}
      className={className}
      { ...reset }
    >
      { children }
    </ModalContainer>
  );
};

Modal.propTypes = {
  open: PropTypes.bool,
  onCancel: PropTypes.func,
  title: PropTypes.string,
  className: PropTypes.string,
  footer: PropTypes.any,
  destroyOnClose: PropTypes.bool,
  closable: PropTypes.bool,
  maskClosable: PropTypes.bool,
  size: PropTypes.shape({
    xs: PropTypes.number,
    sm: PropTypes.number,
    md: PropTypes.number,
    lg: PropTypes.number,
    xl: PropTypes.number,
    xxl: PropTypes.number
  })
};

Modal.defaultProps = {
  footer: null,
  destroyOnClose: true,
  closable: true,
  maskClosable: true,
  size: {
    xs: 90,
    sm: 85,
    md: 70,
    lg: 66.66666667,
    xl: 50,
    xxl: 40
  }
};

export { Modal };
