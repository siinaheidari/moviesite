import { Dropdown as AntdDropdown } from 'antd';
import { CaretDownOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import { useState } from 'react';
import { motion } from 'framer-motion';
import styled from 'styled-components';

const DropdownContainer = styled(AntdDropdown)`
  cursor: pointer;
  color: #407BFF;
  font-size: .75rem;
  font-weight: 400;

  .anticon {
    margin-inline-start: ${ props => props?.iconSpace }px;
    vertical-align: middle;

    svg {
      color: #407BFF;
      transition: all 0.3s;
    }
  }
`;

const DropdownV2 = props => {
  const [open, setOpen] = useState(false);
  
  const { menu, title, ...reset } = props;
  
  return (
    <DropdownContainer
      open={ open }
      onOpenChange={ setOpen }
      overlayClassName={ '--dropdownContent' }
      menu={ {
        items: menu,
        onClick: () => setOpen(false)
      } }
      { ...reset }
    >
      <motion.div whileTap={ { scale: 0.95 } }>
        { title }
        
        <CaretDownOutlined rotate={ open ? 180 : 0 }/>
      </motion.div>
    </DropdownContainer>
  );
};

DropdownV2.propTypes = {
  menu: PropTypes.array.isRequired,
  trigger: PropTypes.array,
  title: PropTypes.string,
  placement: PropTypes.oneOf(['bottom', 'bottomLeft', 'bottomRight', 'top', 'topLeft', 'topRight']),
  iconSpace: PropTypes.number
};

DropdownV2.defaultProps = {
  trigger: ['click'],
  iconSpace: 5
};

export { DropdownV2 };
