import { MinusOutlined, PlusOutlined } from '@ant-design/icons';
import { Form, InputNumber as AntdInputNumber } from 'antd';
import PropTypes from 'prop-types';
import starkString from 'starkstring';
import styled from 'styled-components';
import tw from 'twin.macro';

const InputContainer = styled(Form.Item)`
  line-height: 0;
  
  
  ${ tw`max-lg:!mb-[4px]` }
  
  .ant-form-item-label {
    padding-bottom: 4px;
    text-align: start;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    ${tw`max-lg:pb-[1px]`};

    label {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;
      ${tw`max-lg:!text-[12px]`};
      &.ant-form-item-required {
        /*&:after {
          display: inline-block;
          margin-left: 4px;
          margin-top: -5px;
          color: #FF0000;
          font-size: .875rem;
          font-family: SimSun, sans-serif;
          font-weight: bolder;
          line-height: 1;
          content: '*';
        }*/

        &:before {
          margin-top: -5px;
        }
      }
    }
  }

  .ant-form-item-control-input-content {
    .ant-input-number {
      direction: ltr !important;
      width: 100%;
      border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
      border-radius: 5px;
      overflow: hidden;
      background-color: #FFFFFF !important;
      height: 42px;
      padding: 0 11px;

      &.ant-input-number-focused {
        border-color: #40a9ff !important;
      }

      .ant-input-number-handler-wrap {
        width: 30px;
        display: ${ props => props?.isControl ? 'block' : 'none' };
        right: 0;
        left: unset;

        .anticon {
          color: #1CC500;
          font-size: 9.5px;
          margin-top: 3px;
        }
      }

      .ant-input-number-input-wrap {
        &,
        .ant-input-number-input {
          text-align: left;
          height: 42px;
        }
      }

      &,
      &.ant-input-number-status-error:not(.ant-input-number-disabled):not(.ant-input-number-borderless).ant-input-number, .ant-input-number-status-error:not(.ant-input-number-disabled):not(.ant-input-number-borderless).ant-input-number:hover,
      .ant-input-number-handler-wrap {
        background-color: #F1F5F9;
      }

      .ant-input-number-handler-wrap {
        height: 46px;
      }

      &.ant-input-number-status-error:not(.ant-input-number-disabled):not(.ant-input-number-borderless).ant-input-number, .ant-input-number-status-error:not(.ant-input-number-disabled):not(.ant-input-number-borderless).ant-input-number:hover {
        border: 1px solid #ff4d4f;
      }

      .ant-input-number-input {
        color: #4D4D4D;

        ::placeholder {
          color: rgba(112, 112, 112, 0.64);
          font-weight: 400;
          text-align: ${ ({ placeholderAlign }) => placeholderAlign };
        }
      }

      ${ ({ inputStyle }) => inputStyle };
    }
  }

  .ant-input-number-group {
    &.ant-input-number-group-rtl {
      direction: ltr;
    }

    .ant-input-number-group-addon {
      border: none;
      border-radius: unset;
      box-shadow: unset;
      background-color: transparent;
      font-size: .8125rem;
      color: rgba(112, 112, 112, 0.64);
    }
  }
`;

const InputNumber = (props) => {
  
  const {
    label,
    placeholder,
    placeholderAlign,
    noPlaceHolder,
    name,
    initialValue,
    rules,
    onBlur,
    bordered,
    isControl,
    labelCol,
    formItemReset,
    amountMode,
    wrapperStyle,
    inputStyle,
    extra,
    ...reset
  } = props;
  
  const amountModeConfig = amountMode ?
    {
      formatter: value => value && starkString(value).parseNumber().englishNumber().toCurrency()
    } :
    {};
  
  return (
    <InputContainer
      label={ label }
      name={ name }
      initialValue={ initialValue }
      rules={ rules }
      bordered={ +bordered }
      isControl={ isControl }
      style={ wrapperStyle }
      inputStyle={ inputStyle }
      extra={ extra }
      labelCol={ labelCol }
      placeholderAlign={ placeholderAlign }
      { ...formItemReset }
    >
      <AntdInputNumber
          placeholder={ !noPlaceHolder ? (placeholder || label) : null }
        onBlur={ onBlur }
        controls={ {
          upIcon: <PlusOutlined/>,
          downIcon: <MinusOutlined/>
        } }
        { ...reset }
        { ...amountModeConfig }
      />
    </InputContainer>
  );
};

InputNumber.propTypes = {
  label: PropTypes.string,
  placeholder: PropTypes.string,
  placeholderAlign: PropTypes.oneOf(['right', 'left', 'start', 'end']),
  noPlaceHolder: PropTypes.bool,
  name: PropTypes.any,
  initialValue: PropTypes.any,
  labelCol: PropTypes.array,
  formItemReset: PropTypes.any,
  rules: PropTypes.array,
  onBlur: PropTypes.func,
  bordered: PropTypes.bool,
  isControl: PropTypes.bool,
  wrapperStyle: PropTypes.object,
  inputStyle: PropTypes.object,
  amountMode: PropTypes.bool,
  extra: PropTypes.node
};

InputNumber.defaultProps = {
  bordered: true,
  isControl: true,
  amountMode: false,
  placeholderAlign: 'start',
  noPlaceHolder: false,
};

export { InputNumber };
