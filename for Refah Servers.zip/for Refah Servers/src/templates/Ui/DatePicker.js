import { Form }                                        from 'antd';
import SvgIcon                                         from '../components/SvgIcon';
import { Input }                                       from 'templates/Ui/Input';
import styled, {css} from 'styled-components';
import PropTypes                                       from 'prop-types';
import MultiDatePicker, { DateObject }                 from 'react-multi-date-picker';
import persian                                         from 'react-date-object/calendars/persian';
import persian_fa                                      from 'react-date-object/locales/persian_fa';
import transition                                      from 'react-element-popper/animations/transition';
import opacity                                         from 'react-element-popper/animations/opacity';
import 'react-multi-date-picker/styles/layouts/mobile.css';
import { convertDatePicker, inputRule, useWindowSize } from '../../utils/helper';
import tw from 'twin.macro';

const InputContainer = styled(Form.Item)`
  line-height: 0;
  ${ tw`max-lg:!mb-[4px]` }
  .ant-input-affix-wrapper,
  .ant-input {
    direction: ${ props => props?.ltr && 'ltr' };
  }

  .ant-form-item-row {
    &.ant-row-rtl {
      .ant-form-item-explain {
        direction: rtl;
        ${tw`max-md:!text-[12px]`};
      }
    }
  }

  .ant-form-item-label {
    padding-bottom: 4px;
    text-align: ${ props => props?.labelAlign };
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: ${props => props?.hiddenlabel ? 'hidden' : 'block'};

    label {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;
      ${tw`max-md:!text-[12px]`};

      &.ant-form-item-required {
        /*&:after {
          display: inline-block;
          margin-left: 4px;
          margin-top: -5px;
          color: #FF0000;
          font-size: .875rem;
          font-family: SimSun, sans-serif;
          font-weight: bolder;
          line-height: 1;
          content: '*';
        }*/

        &:before {
          margin-top: -5px;
        }
      }
    }
  }

  .ant-form-item-control-input {
    .ant-input-wrapper,
    .ant-input-affix-wrapper {
      border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
      border-radius: 5px;
      height: 42px;
      overflow: hidden;
      padding: 0 11px;

      .ant-input {
        border: none !important;
        height: 100% !important;
        box-shadow: none !important;
        border-radius: unset !important;
      }

      ${ props => !!props?.isaddonafter &&
          css`
          border-inline-end: unset !important;
          border-start-end-radius: 0;
          border-end-end-radius: 0;
        `
      }
    }

    .ant-input-suffix {
      .ant-input-clear-icon {
        width: 17px;
        height: 17px;

        .anticon {
          font-size: 17px;
          color: #12489f;
          font-weight: 600;
        }
      }
    }

    &,
    .ant-input,
    &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper, .ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper:hover {
      background-color: #FFFFFF;
    }

    .ant-input-status-error:not(.ant-input-disabled):not(.ant-input-borderless).ant-input:hover,
    &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper,
    .ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper:hover {
      border: 1px solid #ff4d4f;
    }

    .ant-input {
      text-align: ${ ({ center }) => center && 'center' };
      border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
      border-radius: 5px;
      min-height: 42px;
      color: #4D4D4D;

      &::placeholder {
        color: rgba(112, 112, 112, 0.64);
        font-weight: 400;
        text-align: ${ props => props?.placeholderalign };
      }
    }

    .ant-input-group-addon {
      background-color: transparent;
      cursor: pointer;
      border-radius: 0;
      border-start-end-radius: 5px;
      border-end-end-radius: 5px;
      border-top: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      border-bottom: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      border-inline-end: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      border-inline-start: unset !important;
    }
  }
`;

const DatePicker = (props) => {
  const { width } = useWindowSize();
  
  const {
    name,
    listName,
    label,
    labelColor,
    hiddenLabel,
    labelAlign,
    placeholder,
    noPlaceHolder,
    extra,
    extraColor,
    placeholderAlign,
    initialValue,
    validateFirst,
    rules,
    labelCol,
    formItemReset,
    onBlur,
    bordered,
    wrapperStyle,
    inputStyle,
    hidden,
    ltr,
    dateFormat,
    maxDate,
    minDate,
    /*formRef,*/
    ...reset
  } = props;
  
  const formRef = Form.useFormInstance();
  
  let maxDateConfig = {};
  let minDateConfig = {};
  
  const currentData = new DateObject({ calendar: persian });
  
  const currentDataForMax = new DateObject({ calendar: persian });
  
  let inputNameByListName = name;
  
  if (listName) {
    inputNameByListName = [listName, ...inputNameByListName];
  }
  
  const inputWatch = Form.useWatch(inputNameByListName, formRef);
  
  if (maxDate) {
    if (typeof maxDate === 'boolean') {
      maxDateConfig = {
        maxDate: currentDataForMax.subtract(7, 'year'),
        currentDate: ( !reset?.value && !inputWatch ) && currentData.subtract(7, 'year')
      };
    }
    else {
      maxDateConfig = {
        maxDate: new DateObject({ date: maxDate, calendar: persian })
      };
    }
  }
  
  if (minDate) {
    if (typeof minDate === 'boolean') {
      minDateConfig = {
        minDate: new DateObject({ calendar: persian })
      };
    }
    else {
      minDateConfig = {
        minDate: new DateObject({ date: minDate, calendar: persian }),
        currentDate: new DateObject({ date: minDate, calendar: persian })
      };
    }
  }
  
  const CustomDatePickerInput = ({ openCalendar, value, handleValueChange, ...reset }) => {
    return (
      <Input
        placeholder={ !noPlaceHolder ? ( placeholder || label ) : null }
        onFocus={ openCalendar }
        onClick={ openCalendar }
        value={ value }
        onChange={ handleValueChange }
        allowClear={ false }
        suffix={ <SvgIcon icon={ 'calendar' } width={ 19 } height={ 20 } color={ '#434343' }/> }
        withoutForm
        {...reset}
      />
    );
  };
  
  const handleOnChangeDatePicker = value => {
    if (value) {
      formRef.setFields([
        {
          name: inputNameByListName,
          value: convertDatePicker(value, dateFormat),
          errors: []
        }
      ]);
    }
    else {
      formRef.setFields([
        {
          name: inputNameByListName,
          value: '',
          errors: [inputRule('required selectBox', { name: placeholder || label })]
        }
      ]);
    }
    
    return true;
  };
  
  return (
    <InputContainer
      label={ label }
      labelcolor={ labelColor }
      hiddenlabel={hiddenLabel}
      name={ name }
      initialValue={ initialValue }
      labelCol={ labelCol }
      labelalign={ labelAlign }
      placeholderalign={ placeholderAlign }
      extra={ extra }
      extracolor={ extraColor }
      rules={ rules }
      bordered={ +bordered }
      hidden={ hidden }
      ltr={ +ltr }
      style={ wrapperStyle }
      isaddonafter={ +( !!reset?.addonAfter ) }
      validateFirst={ validateFirst }
      { ...formItemReset }
    >
      <MultiDatePicker
        className={ width <= 767 ? 'rmdp-mobile' : '' }
        render={ <CustomDatePickerInput disabled={reset?.disabled}/> }
        onChange={ handleOnChangeDatePicker }
        locale={ persian_fa }
        calendar={ persian }
        format={ dateFormat }
        zIndex={ 9999 }
        animations={ [
          opacity(),
          transition({
            from: 40,
            transition: 'all 400ms cubic-bezier(0.335, 0.010, 0.030, 1.360)'
          })
        ] }
        containerStyle={ { width: '100%' } }
        hideOnScroll
        mobi
        portal
        { ...reset }
        { ...maxDateConfig }
        { ...minDateConfig }
      />
    </InputContainer>
  );
};

DatePicker.propTypes = {
  // input name: (send in form data)
  name: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  // if input in Form.List tag set name
  listName: PropTypes.string,
  label: PropTypes.any,
  hiddenLabel: PropTypes.bool,
  // label color (default: #868786)
  labelColor: PropTypes?.string,
  placeholder: PropTypes.string,
  noPlaceHolder: PropTypes.bool,
  labelAlign: PropTypes.oneOf(['right', 'left', 'start', 'end', 'center']),
  placeholderAlign: PropTypes.oneOf(['right', 'left', 'start', 'end', 'center']),
  extra: PropTypes.any,
  initialValue: PropTypes.any,
  formItemReset: PropTypes.any,
  rules: PropTypes.array,
  labelCol: PropTypes.array,
  onBlur: PropTypes.func,
  bordered: PropTypes.bool,
  ltr: PropTypes.bool,
  hidden: PropTypes.bool,
  validateFirst: PropTypes.bool,
  wrapperStyle: PropTypes.object,
  inputStyle: PropTypes.object,
  dateFormat: PropTypes.string,
  maxDate: PropTypes.bool,
  minDate: PropTypes.bool,
  formRef: PropTypes.any,
  ref: PropTypes.any
};

DatePicker.defaultProps = {
  labelColor: '#868786',
  hiddenLabel: false,
  extraColor: 'rgba(0, 0, 0, .45)',
  bordered: true,
  noPlaceHolder: false,
  ltr: false,
  hidden: false,
  validateFirst: true,
  maxDate: false,
  minDate: false,
  dateFormat: 'YYYY/MM/DD',
  labelAlign: 'start',
  placeholderAlign: 'start'
};

export { DatePicker };
