import { Form, Input as AntdInput } from 'antd';
import PropTypes from 'prop-types';
import {forwardRef, useEffect, useRef} from 'react';
import starkString from 'starkstring';
import styled, { css } from 'styled-components';
import { inputRule, isValidEmail } from 'utils/helper';
import tw from 'twin.macro';

const InputContainer = styled(Form.Item)`
  line-height: 0;


  ${tw`max-lg:!mb-[4px]`}
  .ant-input-affix-wrapper,
  .ant-input {
    direction: ${props => props?.ltr && 'ltr'};
    border-radius: 5px!important;
  }

  .ant-form-item-row {
    &.ant-row-rtl {
      .ant-form-item-explain {
        direction: rtl;
        ${tw`max-lg:!text-[12px]`};
      }
    }
  }

  .ant-form-item-label {
    padding-bottom: 4px;
    ${tw`max-lg:pb-[1px]`};
    text-align: ${props => props?.labelAlign};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

    label {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;
      ${tw`max-lg:!text-[12px]`};

      &.ant-form-item-required {
        /*&:after {
          display: inline-block;
          margin-left: 4px;
          margin-top: -5px;
          color: #FF0000;
          font-size: .875rem;
          font-family: SimSun, sans-serif;
          font-weight: bolder;
          line-height: 1;
          content: '*';
        }*/

        &:before {
          margin-top: -5px;
        }
      }
    }
  }

  .ant-form-item-control-input {
    .ant-input-suffix {
      position: absolute;
      inset-inline-end: 6px;
      inset-block-start: calc(50% - 8px);


      .ant-input-clear-icon {
        width: 17px;
        height: 17px;

        .anticon {
          font-size: 17px;
          color: ${props => props?.theme?.inputPrimaryColor};
          font-weight: 600;
        }
      }
    }

    .ant-input {
      text-align: ${({center}) => center && 'center'};
      color: #4D4D4D;
      height: 33px !important;
      border-radius: 5px;
      
      &::placeholder {
        font-weight: 400;
        font-size: 0.875rem !important;
        text-align: ${props => props?.ltr ? 'end' : props?.placeholderalign};
      }

      &.ant-input-disabled {
        color: rgba(0, 0, 0, 0.25);
      }

      ::-webkit-outer-spin-button,
      ::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      &[type=number] {
        -moz-appearance: textfield;
      }
    }

    .ant-input-group-addon {
      background-color: transparent;
      cursor: pointer;
      border-radius: 0;
      border-start-end-radius: 5px;
      border-end-end-radius: 5px;
      border-top: ${props => props?.bordered ? `1px solid ${props?.theme?.textColorGray2}` : 'unset'} !important;
      border-bottom: ${props => props?.bordered ? `1px solid ${props?.theme?.textColorGray2}` : 'unset'} !important;
      border-inline-end: ${props => props?.bordered ? `1px solid ${props?.theme?.textColorGray2}` :
              'unset'} !important;
      border-inline-start: unset !important;
    }

    .ant-input-prefix {
      margin-inline-end: 5px;
    }
  }
`;

const WithoutFormInput = styled(AntdInput)`
  direction: ${ props => props?.ltr && 'ltr' };
  border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
  box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
  border-radius: 5px;
  min-height: 43px;

  ${ props => !!props?.isaddonafter &&
    css`
      border-inline-end: unset !important;
      border-start-end-radius: 0;
      border-end-end-radius: 0;
    `
  }
  > input.ant-input {
    border: none !important;
    min-height: unset !important;
    box-shadow: none !important;
    border-radius: unset !important;
  }

  .ant-input-suffix {
    .ant-input-clear-icon {
      width: 17px;
      height: 17px;

      .anticon {
        font-size: 17px;
        color: #12489f;
        font-weight: 600;
      }
    }
  }

  &,
  .ant-input,
  &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper, .ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper:hover {
    background-color: #FFFFFF;
  }

  .ant-input-status-error:not(.ant-input-disabled):not(.ant-input-borderless).ant-input:hover,
  &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper,
  .ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper:hover {
    border: 1px solid #ff4d4f;
  }

  .ant-input {
    text-align: ${ ({ center }) => center && 'center' };
    border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
    box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
    border-radius: 5px;
    min-height: 50px;
    color: #4D4D4D;

    &::placeholder {
      color: rgba(112, 112, 112, 0.64);
      font-weight: 400;
      text-align: ${ props => props?.placeholderalign };
    }
  }

  .ant-input-group-addon {
    cursor: pointer;
    border-radius: 0;
    border-start-end-radius: 5px;
    border-end-end-radius: 5px;
    border-top: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
    border-bottom: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` :
      'unset' } !important;
    border-inline-end: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` :
      'unset' } !important;
  }
`;

const SearchContainer = styled(Form.Item)`
  line-height: 0;

  .ant-input-wrapper,
  .ant-input {
    direction: ${ props => props?.ltr && 'ltr' };
  }

  .ant-form-item-row {
    &.ant-row-rtl {
      .ant-form-item-explain {
        direction: rtl;
        ${ tw`max-md:!text-[12px]` };
      }
    }
  }

  .ant-form-item-label {
    padding-bottom: 4px;
    text-align: ${ props => props?.labelAlign };

    label {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;

      &.ant-form-item-required {
        &:after {
          display: inline-block;
          margin-left: 4px;
          margin-top: -5px;
          color: #FF0000;
          font-size: .875rem;
          font-family: SimSun, sans-serif;
          font-weight: bolder;
          line-height: 1;
          content: '*';
        }

        &:before {
          display: none !important;
        }
      }
    }
  }

  .ant-form-item-control-input {
    .ant-input-wrapper {
      border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
      border-radius: 5px;
      height: 33px!important;
      overflow: hidden;
      padding: 0 11px;

      > input.ant-input {
        border: none !important;
        min-height: 33px !important;
        box-shadow: none !important;
        border-radius: unset !important;
        padding: 0;
      }
    }

    &,
    .ant-input,
    &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper, .ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper:hover {
      background-color: #FFFFFF;
    }

    .ant-input-status-error:not(.ant-input-disabled):not(.ant-input-borderless).ant-input:hover,
    &.ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper,
    .ant-input-affix-wrapper-status-error:not(.ant-input-affix-wrapper-disabled):not(.ant-input-affix-wrapper-borderless).ant-input-affix-wrapper:hover {
      border: 1px solid #ff4d4f;
    }

    .ant-input {
      text-align: ${ ({ center }) => center && 'center' };
      border: ${ props => props?.bordered ? `1px solid ${ props?.theme?.inputsBorderColor }` : 'unset' } !important;
      box-shadow: ${ props => props?.bordered ? '0 4px 4px rgba(0, 0, 0, 0.05)' : 'unset' } !important;
      border-radius: 5px;
      min-height: 33px;
      color: #4D4D4D;

      &::placeholder {
        color: rgba(112, 112, 112, 0.64);
        font-weight: 400;
        text-align: ${ props => props?.placeholderalign };
      }
    }

    .ant-input-group-addon {
      .ant-btn {
        box-shadow: none;
        border: none;
        height: 32px;

        .anticon {
          margin-top: 6px;
          color: rgba(77, 77, 77, 0.44);
        }
      }
    }
  }
`;

const Input = forwardRef((props, ref) => {

  const {
    label,
    placeholder,
    noPlaceHolder,
    name,
    placeholderAlign,
    extra,
    initialValue,
    validateType,
    validateFirst,
    rules,
    labelCol,
    labelAlign,
    formItemReset,
    onBlur,
    bordered,
    wrapperStyle,
    inputStyle,
    hidden,
    ltr,
    center,
    allowClear,
    withoutForm,
    justNumber,
    justEnglish,
    formRef,
    focus,
    ...reset
  } = props;

  const inputWatch = Form.useWatch(name, formRef);

  const focusConfig = focus ? {
        ref,
      } :
      {};


  const forJustNumber = justNumber ?
      {
        onChange: e => {
          const { value: inputValue } = e.target;
          formRef.setFields([
            {
              name: name,
              // value: toEnDigit(inputValue)?.replace(/\D/g, ''),
              value: inputValue?.length ? starkString(inputValue)
                  .parseNumber()
                  .englishNumber()
                  .toString() : null,
            },
          ]);
        },
      } :
      {};

  const forJustEnglish = justEnglish ?
      {
        onChange: e => {
          const { value: inputValue } = e.target;

          if (inputValue.match(/^[a-zA-Z1-9.?!:;\- ]+$/g) === null) {
            formRef.setFields([
              {
                name: name,
                value: '',
              },
            ]);
          }
          else {
            formRef.setFields([
              {
                name: name,
                value: inputValue,
              },
            ]);
          }
        },
      } :
      {};

  // Validate Email
  const handleOnBlurEmail = () => {
    if (inputWatch?.length && !isValidEmail(inputWatch)) {
      formRef?.setFields([
        {
          name: name,
          errors: [ inputRule('validate email') ],
        },
      ]);
    }
  };

  // for show min and max error (mobile)
  const handleOnBlurMobile = () => {
    if (inputWatch?.length && inputWatch?.length < 11) {
      formRef?.setFields([
        {
          name: name,
          errors: [ inputRule('minLength input', {
            inputName: label || placeholder,
            length: reset?.maxLength,
          }) ],
        },
      ]);
    }
  };

  let validateByOnBlur = {};

  if (validateType === 'email') {
    rules.push({
      pattern: new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/),
      message: inputRule('validate email'),
      validateTrigger: 'onBlur',
    });

    validateByOnBlur = {
      onBlur: handleOnBlurEmail,
    };
  }

  if (validateType === 'mobile') {
    rules.push({
      pattern: new RegExp(/^[0-9]+$/),
      message: inputRule('must be number input', { inputName: label || placeholder }),
    });

    rules.push({
      min: reset.maxLength,
      message: inputRule('minLength input', {
        inputName: label || placeholder,
        length: reset.maxLength,
      }),
      validateTrigger: 'onBlur',
    });

    rules.push({
      max: reset.maxLength,
      message: inputRule('maxLength input', {
        inputName: label || placeholder,
        length: reset.maxLength,
      }),
    });

    validateByOnBlur = {
      onBlur: handleOnBlurMobile,
    };
  }

  useEffect(() => {
    if (focus && ref?.current) {
      ref?.current.focus({
        cursor: 'end',
      });
    }
  }, [ focus, ref ]);

  if (withoutForm) {
    return (
        <WithoutFormInput
            ref={ ref }
            placeholder={ !noPlaceHolder ? (placeholder || label) : null }
            allowClear={ allowClear }
            onBlur={ onBlur }
            style={ inputStyle }
            ltr={ +ltr }
            center={ +center }
            placeholderalign={ placeholderAlign }
            bordered={ +bordered }
             className={ props?.className }
            { ...validateByOnBlur }
            { ...forJustNumber }
            { ...forJustEnglish }
            { ...reset }
            { ...focusConfig }
        />
    );
  }

  return (
      <InputContainer
          label={ label }
          name={ name }
          initialValue={ initialValue }
          labelCol={ labelCol }
          labelAlign={ labelAlign }
          extra={ extra }
          rules={ rules }
          bordered={ +bordered }
          hidden={ hidden }
          ltr={ +ltr }
          center={ +center }
          placeholderalign={ placeholderAlign }
          style={ wrapperStyle }
          isaddonafter={ +(!!reset?.addonAfter) }
          validateFirst
         className={ reset?.className }
          { ...formItemReset }
      >
        <AntdInput
            ref={ ref }
            placeholder={ !noPlaceHolder ? (placeholder || label) : null }
            allowClear={ allowClear }
            style={ inputStyle }
            onBlur={ onBlur }
            { ...validateByOnBlur }
            { ...forJustNumber }
            { ...forJustEnglish }
            { ...reset }
            { ...focusConfig }
            className={ reset?.inputClassName }
        />
      </InputContainer>
  );
});

const Search = props => {
  
  const {
    label,
    placeholder,
    noPlaceHolder,
    name,
    placeholderAlign,
    extra,
    initialValue,
    validateFirst,
    rules,
    labelCol,
    labelAlign,
    formItemReset,
    onBlur,
    bordered,
    wrapperStyle,
    inputStyle,
    hidden,
    ltr,
    center,
    allowClear,
    withoutForm,
    justNumber,
    justEnglish,
    formRef,
    setRef,
    focus,
    onSearch,
    ...reset
  } = props;
  
  return (
    <SearchContainer
      label={ label }
      name={ name }
      initialValue={ initialValue }
      labelCol={ labelCol }
      labelAlign={ labelAlign }
      extra={ extra }
      rules={ rules }
      bordered={ +bordered }
      hidden={ hidden }
      ltr={ +ltr }
      center={ +center }
      placeholderalign={ placeholderAlign }
      style={ wrapperStyle }
      isaddonafter={ +(!!reset?.addonAfter) }
      validateFirst={ validateFirst }
      { ...formItemReset }
    >
      <AntdInput.Search
        placeholder={ !noPlaceHolder ? (placeholder || label) : null }
        onSearch={ onSearch }
        { ...reset }
      />
    </SearchContainer>
  );
};

Input.propTypes = {
  label: PropTypes.string,
  placeholder: PropTypes.string,
  noPlaceHolder: PropTypes.bool,
  name: PropTypes.any,
  placeholderAlign: PropTypes.oneOf([ 'right', 'left', 'start', 'end', 'center' ]),
  validateType: PropTypes.oneOf([ 'email', 'mobile' ]),
  labelAlign: PropTypes.oneOf([ 'right', 'left', 'start', 'end', 'center' ]),
  extra: PropTypes.any,
  initialValue: PropTypes.any,
  formItemReset: PropTypes.any,
  rules: PropTypes.array,
  labelCol: PropTypes.array,
  onBlur: PropTypes.func,
  bordered: PropTypes.bool,
  allowClear: PropTypes.bool,
  ltr: PropTypes.bool,
  center: PropTypes.bool,
  hidden: PropTypes.bool,
  validateFirst: PropTypes.bool,
  wrapperStyle: PropTypes.object,
  inputStyle: PropTypes.object,
  setRef: PropTypes.any,
  formRef: PropTypes.any,
  withoutForm: PropTypes.bool,
  justNumber: PropTypes.bool,
  justEnglish: PropTypes.bool,
  maxLength: PropTypes.number,
  focus: PropTypes.bool,
};

Input.defaultProps = {
  bordered: true,
  noPlaceHolder: false,
  ltr: false,
  center: false,
  hidden: false,
  withoutForm: false,
  allowClear: true,
  validateFirst: true,
  justNumber: false,
  justEnglish: false,
  focus: false,
  setRef: null,
  placeholderAlign: 'start',
  labelAlign: 'start',
  rules: [],
};

export { Input, Search };
