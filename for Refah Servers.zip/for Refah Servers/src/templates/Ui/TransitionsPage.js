import { AnimatePresence, motion } from 'framer-motion';
import PropTypes                   from 'prop-types';

const TransitionsPage = props => {
  const { id, mode, coordinates, size, duration, style, children, ...reset } = props;
  
  return (
    <AnimatePresence mode={ mode }>
      <motion.div
        key={ id || 'initialPage' }
        initial={ { [ coordinates ]: size * -1, opacity: 0 } }
        animate={ { [ coordinates ]: 0, opacity: 1 } }
        exit={ { [ coordinates ]: size, opacity: 0 } }
        transition={ { duration } }
        style={ style }
        { ...reset }
      >
        { children }
      </motion.div>
    </AnimatePresence>
  );
};

TransitionsPage.propTypes = {
  // page id (required) (default: initialPage)
  id: PropTypes.any.isRequired,
  // animation mode (default: wait)
  mode: PropTypes?.oneOf(['wait', 'sync', 'popLayout']),
  // animation coordinates "x OR y" (default: y)
  coordinates: PropTypes.oneOf(['x', 'y']),
  // animation size (default: 35)
  size: PropTypes.number,
  // animation duration time (default: .4)
  duration: PropTypes.number,
  // wrapper styles
  style: PropTypes.object
};

TransitionsPage.defaultProps = {
  id: 'initialPage',
  mode: 'wait',
  coordinates: 'y',
  duration: .34,
  size: 35,
  style: {}
};

export { TransitionsPage };
