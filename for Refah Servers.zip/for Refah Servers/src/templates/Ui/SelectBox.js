import { Form, Select } from 'antd';
import styled, {css} from 'styled-components';
import PropTypes from 'prop-types';
import tw from 'twin.macro';
import { forwardRef } from 'react';


const InputContainer = styled(Form.Item)`

  ${({readOnly}) => readOnly &&
          css`
            pointer-events: none;
          `
  }
  .ant-select-selector {
    border-radius: 5px;
    min-height: 41px;
    padding: 0 11px;
    padding-top: 0.3rem !important;
    ${tw`max-lg:!text-[12px]`};
  }

  .ant-form-item-row {
    &.ant-row-rtl {
      .ant-form-item-explain {
        direction: rtl;
        ${tw`max-lg:!text-[12px]`};
      }
    }
  }
  
  .ant-form-item-label {

    text-align: start;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

    label {
      color: ${props => props?.labelcolor || props?.theme?.textColorGray2} !important;
      font-size: 0.875rem !important;
      font-weight: 400;
      ${tw`max-lg:!text-[12px]`};
    }
  }

  .ant-select {
    direction: ${props => props?.ltr ? 'ltr' : 'rtl'};
    &.ant-select-multiple {
      .ant-select-selector {
        .ant-select-selection-item {
          line-height: 24px;

        }
      }
    }

    .ant-select-arrow,
    .ant-select-clear {
      width: 14px;
      height: 14px;
      top: 50%;
      inset-inline-end: 14px;

      .anticon {
        font-size: 14px;
        color: ${props => props?.theme?.primaryColorForText} !important;
        font-weight: 600;
      }
    }

    .ant-select-clear {
      top: 45%;

      .anticon {
        font-size: 15px;
        color: ${props => props?.theme?.primaryColorForText};
      }
    }
  }
`;

const WithoutFormSelect = styled(Select)`
  &.ant-select-multiple {
    .ant-select-selector {
      .ant-select-selection-item {
        line-height: 20px;
      }
    }
  }

  .ant-select-arrow,
  .ant-select-clear {
    width: 14px;
    height: 14px;
    top: 50%;
    inset-inline-end: 14px;

    .anticon {
      font-size: 14px;
      color: ${ props => props?.theme?.primaryColorForText } !important;
      font-weight: 600;
    }
  }

  .ant-select-clear {
    top: 45%;

    .anticon {
      font-size: 15px;
    }
  }
`;

const SelectBox = forwardRef((props, ref) => {

  const {
    label,
    placeholder,
    withoutForm,
    showSearch,
    allowClear,
    name,
    loading,
    filterOption,
    initialValue,
    initialValues,
    rules,
    formItemReset,
    labelCol,
    bordered,
    wrapperStyle,
    noStyle,
    selectBoxStyle,
    hidden,
    ltr,
    children,
    ...reset
  } = props;

  if (withoutForm) {
    return (
        <WithoutFormSelect
            virtual={ false }
            initialValues={ initialValues }
            loading={ loading }
            placeholder={ placeholder || label }
            optionFilterProp='children'
            filterOption={ filterOption }
            style={ selectBoxStyle }
            showSearch={ showSearch }
            allowClear={ allowClear }
            bordered={ +bordered }
            ref={ref}
            { ...reset }
        >
          { children }
        </WithoutFormSelect>
    );
  }

  return (
      <InputContainer
          label={ label }
          name={ name }
          initialValue={ initialValue }
          rules={ rules }
          bordered={ +bordered }
          hidden={ hidden }
          ltr={ +ltr }
          style={ wrapperStyle }
          labelCol={ labelCol }
          { ...formItemReset }
      >
        <Select
            virtual={ false }
            loading={ loading }
            initialValues={ initialValues }
            placeholder={ placeholder || label }
            optionFilterProp='children'
            filterOption={ filterOption }
            style={ selectBoxStyle }
            showSearch={ showSearch }
            allowClear={ allowClear }
            ref={ref}
            { ...reset }
        >
          { children }
        </Select>
      </InputContainer>
  );
});

SelectBox.propTypes = {
  label: PropTypes.string,
  placeholder: PropTypes.string,
  name: PropTypes.any,
  loading: PropTypes.bool,
  withoutForm: PropTypes.bool,
  showSearch: PropTypes.bool,
  allowClear: PropTypes.bool,
  filterOption: PropTypes.func,
  initialValue: PropTypes.any,
  initialValues: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  rules: PropTypes.array,
  labelCol: PropTypes.array,
  formItemReset: PropTypes.any,
  bordered: PropTypes.bool,
  ltr: PropTypes.bool,
  hidden: PropTypes.bool,
  wrapperStyle: PropTypes.object,
  selectBoxStyle: PropTypes.object,
  children: PropTypes.node
};

SelectBox.defaultProps = {
  bordered: true,
  showSearch: true,
  allowClear: true,
  ltr: false,
  withoutForm: false,
  hidden: false,
  loading: false,
  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase())
};

export { SelectBox };
