import { Col, Row, Skeleton } from 'antd';
import styled from 'styled-components';
import { isNumber } from 'utils/helper';
import PropTypes from 'prop-types';
import tw from 'twin.macro';

const SquareContainer = styled(Row)`
  height: ${ props => isNumber(props?.wrapperheight) ? `${ props?.wrapperheight }px` : props?.wrapperheight };
`;

const SquareContent = styled(Col)`
  text-align: center;

  .ant-skeleton {
    width: ${ ({ width }) => isNumber(width) ? `${ width }px` : width };
  }

  .ant-skeleton,
  .ant-skeleton-input {
    min-width: ${ ({ width }) => width ? (isNumber(width) ? `${ width }px` : width) : '100%' } !important;
    width: ${ ({ width }) => width ? (isNumber(width) ? `${ width }px` : width) : '100%' } !important;
    height: ${ ({ height }) => isNumber(height) ? `${ height }px` : height } !important;
   
  }

  .ant-skeleton-input {
    width: 100%;
    border-radius: ${ ({ radius }) => radius };
  }

`;

const SquareSkeleton = (props) => {

    const {
        count,
        gutter,
        wrapperHeight,
        width,
        height,
        radius,
    } = props;

    const {
        row = 1,
        col = 1,
    } = count;

    const arrayLength = row * col;

    const ColSpan = 24 / col;

    const [ widthGutter, heightGutter ] = gutter;

    const borderRadius = radius ? (isNumber(radius) ? `${ radius }px` : radius) : 'unset';

    return (
        <SquareContainer gutter={ [ widthGutter, heightGutter ] } wrapperheight={ wrapperHeight }>
            { Array.from({ length: arrayLength })?.map((_, i) => {
                return (
                    <SquareContent span={ ColSpan } key={ `squareSkeleton_${ i + 1 }` } width={ width }
                                   height={ height } radius={ borderRadius }>
                        <Skeleton.Input active/>
                    </SquareContent>
                );
            }) }
        </SquareContainer>
    );
};

SquareSkeleton.propTypes = {
    count: PropTypes.object,
    gutter: PropTypes.array,
    wrapperHeight: PropTypes.any,
    width: PropTypes.any,
    height: PropTypes.any,
    radius: PropTypes.number,
};

SquareSkeleton.defaultProps = {
    count: {
        row: 1,
        col: 1,
    },
    gutter: [ 16, 16 ],
    radius: 0,
    wrapperHeight: '100%',
};

export { SquareSkeleton };
