import { Table as AntdTable } from 'antd';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { convertColor } from 'utils/helper';

const TableContainer = styled(AntdTable)`
  .ant-table-container {
    border: unset !important;
  }

  .ant-table-thead,
  .ant-table-tbody {
    * {
      border-color: #FFFFFF !important;
    }

    .ant-table-cell {
      color: #4D4D4D;
      font-size: .75rem;
      border-inline-end: none !important;
      border-bottom: ${ props => props?.theme?.isAdmin ? '1px solid #F0F0F0' : 'unset' } !important;
    }
  }

  .ant-table-thead {
    .ant-table-cell {
      font-weight: 500;
      background-color: ${ props => props?.theme?.tableHeaderBgColor };
      border-radius: 0 !important;
    }
  }

  .ant-table-tbody {
    .ant-table-row {
      .ant-table-cell {
        font-weight: 400;
      }

      &.--statusTrue {
        .ant-table-cell {
          background-color: #C9FFD8;
        }
      }

      &.--statusFalse {
        .ant-table-cell {
          background-color: #FFE8E4;
        }
      }

      :hover {
        > td,
        td.ant-table-cell-row-hover {
          background: ${ props => convertColor(props?.theme?.tableHeaderBgColor, 4) } !important;
        }

        &.--statusTrue {
          .ant-table-cell {
            background-color: #d3ffdf !important;
          }
        }

        &.--statusFalse {
          .ant-table-cell {
            background-color: #feece9 !important;
          }
        }
      }
    }
  }

  .ant-pagination {
    padding-inline-end: 32px;
  }
`;

const Table = props => {
  return (
    <TableContainer { ...props }/>
  );
};

Table.propTypes = {
  columns: PropTypes.array.isRequired,
  dataSource: PropTypes.array.isRequired,
  bordered: PropTypes.bool,
  loading: PropTypes.bool,
  tableLayout: PropTypes.oneOf(['fixed', 'auto']),
  pagination: PropTypes.object,
  rowClassName: PropTypes.func
};

export { Table };
