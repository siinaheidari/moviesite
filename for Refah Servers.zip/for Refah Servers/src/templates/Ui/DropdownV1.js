import { ReactComponent as CaretDown } from 'assets/icons/caretDown.svg';
import { motion } from 'framer-motion';
import PropTypes from 'prop-types';
import { useState } from 'react';

import OutsideClickHandler from 'react-outside-click-handler';
import styled from 'styled-components';

const ProfileContainer = styled(motion.nav)`
  display: block;
  height: ${ props => props?.height }px;

  .--trigger {
    .__toggleIcon {
      svg {
        width: 11px;
      }
    }

    .__text {
      margin-inline-start: -11px;
    }
  }
`;

const Trigger = styled(motion.div)`
  direction: ltr;
  height: 100%;
  margin-bottom: 10px;
  display: flex;
  justify-content: center;
  gap: 20px;
  align-items: center;
  cursor: pointer;

  &,
  &:hover {
    color: #FFFFFF;
  }

  svg {
    vertical-align: middle;

    path {
      fill: #fff;
    }
  }
`;

const MenuContainer = styled(motion.ul)`
  z-index: 999;
  position: relative;
  margin: 0;
  padding: 0;
  list-style-type: none;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #EEEEEE;
  border-radius: 5px;
  outline: none;
  box-shadow: 0 3px 6px -4px rgba(0, 0, 0, 0.12), 0 6px 16px 0 rgba(0, 0, 0, 0.08), 0 9px 28px 8px rgba(0, 0, 0, 0.05);
  direction: rtl;
  text-align: right;
  min-height: 76px;

  .--menuItem {
    padding: 0;
    clear: both;
    margin: 0;
    line-height: 22px;
    cursor: pointer;
    transition: all 0.3s;
    position: relative;
    display: flex;
    align-items: center;

    :hover,
    &.__active {
      background: linear-gradient(80.52deg, rgba(246, 25, 130, 0.14) 0%, rgba(33, 64, 154, 0.2) 100%);

      .__title {
        > span,
        > a {
          font-weight: 500;
        }
      }
    }

    &.__logOut {
      color: #FF0000;
    }

    .__title {
      flex: auto;
      line-height: 22px;
      cursor: pointer;

      > span,
      > div,
      > a {
        display: block !important;
        color: #4D4D4D !important;
        font-weight: 400;
        font-size: .875rem !important;
        padding: 8px 13px;
      }
    }
  }
`;

const itemVariants = {
  open: {
    opacity: 1,
    y: 0,
    transition: { type: 'spring', stiffness: 300, damping: 24 }
  },
  closed: { opacity: 0, y: 20, transition: { duration: 0.3 } }
};

const DropdownV1 = (props) => {
  
  const { title, menu, height, selectedKey } = props;
  
  const [dropDownOpen, setDropDownOpen] = useState(false);
  
  const handleCloseDropdown = () => setDropDownOpen(current => current === true ? false : current);
  
  const handleClickDropDownItem = () => {
    const closeTimeOut = setTimeout(() => setDropDownOpen(false), 500);
    
    return () => clearTimeout(closeTimeOut);
  };
  
  return (
    <OutsideClickHandler onOutsideClick={ handleCloseDropdown }>
      <ProfileContainer
        initial={ false }
        animate={ dropDownOpen ? 'open' : 'closed' }
        height={ height }
        className='Dropdown'
      >
        <Trigger
          whileTap={ { scale: 0.97 } }
          onClick={ () => setDropDownOpen(current => !current) }
          className='--trigger'
        >
          <motion.div
            variants={ {
              open: { rotate: 180 },
              closed: { rotate: 0 }
            } }
            transition={ { duration: 0.2 } }
            style={ { originY: 0.55 } }
            className='__toggleIcon'
          >
            <CaretDown/>
          </motion.div>
          
          <div className='__text'>
            { title }
          </div>
        </Trigger>
        
        <MenuContainer
          variants={ {
            open: {
              clipPath: 'inset(0% 0% 0% 0% round 10px)',
              y: 0,
              transition: {
                type: 'spring',
                bounce: 0,
                duration: 0.5,
                delayChildren: 0.2,
                staggerChildren: 0.05
              }
            },
            closed: {
              clipPath: 'inset(10% 50% 90% 50% round 10px)',
              y: -20,
              transition: {
                type: 'spring',
                bounce: 0,
                duration: 0.5
              }
            }
          } }
          style={ { pointerEvents: dropDownOpen ? 'auto' : 'none', display: dropDownOpen ? 'block' : 'none' } }
        >
          { menu?.map((item, i) => {
            if (item?.type === 'divider') {
              return <li className='ant-dropdown-menu-item-divider' key={ `menuDivider_${ i }` }/>;
            }
            
            return (
              <motion.li
                onClick={ handleClickDropDownItem }
                key={ `menuItem_${ item?.key }` }
                className={ `--menuItem ${ item?.key === 'log-out' ? '__logOut' : '' } ${ item?.key === selectedKey ? '__active ' : '' }` }
                variants={ itemVariants }
              >
                <div className='__title'>
                  { item?.label }
                </div>
              </motion.li>
            );
          }) }
        </MenuContainer>
      </ProfileContainer>
    </OutsideClickHandler>
  );
};

DropdownV1.propTypes = {
  title: PropTypes.node,
  menu: PropTypes.array,
  height: PropTypes.number,
  selectedKey: PropTypes.string
};

DropdownV1.defaultProps = {
  height: 23
};

export { DropdownV1 };
