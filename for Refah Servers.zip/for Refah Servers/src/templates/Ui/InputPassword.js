import { Form, Input as AntdInput } from 'antd';
import PropTypes from 'prop-types';
import { useEffect, useRef } from 'react';
import styled from 'styled-components';
import { inputRule } from 'utils/helper';
import tw from 'twin.macro';

const InputContainer = styled(Form.Item)`
  line-height: 0;

  ${tw`max-lg:!mb-[4px]`}
  .ant-input-affix-wrapper,
  .ant-input {
    direction: ${props => props?.ltr && 'ltr'};
    border-radius: 5px!important;
  }

  .ant-form-item-row {
    &.ant-row-rtl {
      .ant-form-item-explain {
        direction: rtl;
        ${tw`max-md:!text-[12px]`};
      }
    }
  }

  .ant-form-item-label {
    padding-bottom: 4px;
    ${tw`max-md:pb-[1px]`};
    text-align: ${props => props?.labelAlign};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

    label {
      color: #4D4D4D;
      font-size: .875rem;
      font-weight: 400;
      ${tw`max-md:!text-[12px]`};

      &.ant-form-item-required {
        /*&:after {
          display: inline-block;
          margin-left: 4px;
          margin-top: -5px;
          color: #FF0000;
          font-size: .875rem;
          font-family: SimSun, sans-serif;
          font-weight: bolder;
          line-height: 1;
          content: '*';
        }*/

        &:before {
          margin-top: -5px;
        }
      }
    }
  }

  .ant-form-item-control-input {
    .ant-input-suffix {
      position: absolute;
      inset-inline-end: 6px;
      inset-block-start: calc(50% - 8px);


      .ant-input-clear-icon {
        width: 17px;
        height: 17px;

        .anticon {
          font-size: 17px;
          color: ${props => props?.theme?.inputPrimaryColor};
          font-weight: 600;
        }
      }
    }

    .ant-input {
      text-align: ${({center}) => center && 'center'};
      color: #4D4D4D;
      height: 33px !important;
      border-radius: 5px;

      &::placeholder {
        font-weight: 400;
        font-size: 0.875rem !important;
        text-align: ${props => props?.ltr ? 'end' : props?.placeholderalign};
      }

      &.ant-input-disabled {
        color: rgba(0, 0, 0, 0.25);
      }

      ::-webkit-outer-spin-button,
      ::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      &[type=number] {
        -moz-appearance: textfield;
      }
    }

    .ant-input-group-addon {
      background-color: transparent;
      cursor: pointer;
      border-radius: 0;
      border-start-end-radius: 5px;
      border-end-end-radius: 5px;
      border-top: ${props => props?.bordered ? `1px solid ${props?.theme?.textColorGray2}` : 'unset'} !important;
      border-bottom: ${props => props?.bordered ? `1px solid ${props?.theme?.textColorGray2}` : 'unset'} !important;
      border-inline-end: ${props => props?.bordered ? `1px solid ${props?.theme?.textColorGray2}` :
          'unset'} !important;
      border-inline-start: unset !important;
    }

    .ant-input-prefix {
      margin-inline-end: 5px;
    }
  }
`;

const InputPassword = (props) => {
  
  const inputRef = useRef(null);
  
  const {
    label,
    placeholder,
    noPlaceHolder,
    ltr,
    name,
    bordered,
    dependencies,
    rules,
    allowclear,
    onBlur,
    placeholderAlign,
    labelAlign,
    wrapperStyle,
    inputStyle,
    extra,
    formRef,
    focus,
    ...reset
  } = props;
  
  const focusConfig = focus ? {
      ref: inputRef
    } :
    {};
  
  const inputWatch = Form.useWatch(name, formRef);
  
  const handleMinPasswordValidate = () => {
    if (inputWatch?.length && inputWatch?.length < reset?.min) {
      formRef?.setFields([
        {
          name: name,
          errors: [inputRule('minLength input', { inputName: label || placeholder, length: reset?.min })]
        }
      ]);
    }
  };
  
  let validateByOnBlur = {};
  
  if (!!reset?.min) {
    rules.push({
      min: reset?.min,
      message: inputRule('minLength input', { inputName: label || placeholder, length: reset?.min }),
      validateTrigger: 'onBlur'
    });
    
    validateByOnBlur = {
      onBlur: handleMinPasswordValidate
    };
  }
  
  useEffect(() => {
    if (focus && inputRef.current) {
      inputRef.current.focus({
        cursor: 'end'
      });
    }
  }, [focus, inputRef]);
  
  return (
    <InputContainer
      label={ label }
      name={ name }
      rules={ rules }
      placeholderalign={ placeholderAlign }
      labelalign={ labelAlign }
      ltr={ +ltr }
      bordered={ +bordered }
      extra={ extra }
      dependencies={ dependencies }
      style={ wrapperStyle }
      validateFirst
    >
      <AntdInput.Password
        placeholder={ !noPlaceHolder ? ( placeholder || label ) : null }
        allowClear={ allowclear }
        style={ inputStyle }
        onBlur={ onBlur }
        { ...validateByOnBlur }
        { ...reset }
        { ...focusConfig }
      />
    </InputContainer>
  );
};

InputPassword.propTypes = {
  label: PropTypes.string,
  placeholder: PropTypes.string,
  name: PropTypes.string,
  rules: PropTypes.array,
  dependencies: PropTypes.array,
  allowClear: PropTypes.bool,
  noPlaceHolder: PropTypes.bool,
  bordered: PropTypes.bool,
  focus: PropTypes.bool,
  ltr: PropTypes.bool,
  onBlur: PropTypes.func,
  placeholderAlign: PropTypes.oneOf(['right', 'left', 'start', 'end']),
  labelAlign: PropTypes.oneOf(['right', 'left', 'start', 'end']),
  wrapperStyle: PropTypes.object,
  inputStyle: PropTypes.object,
  extra: PropTypes.node,
  min: PropTypes.number,
  formRef: PropTypes.any
};

InputPassword.defaultProps = {
  bordered: true,
  focus: false,
  allowClear: false,
  noPlaceHolder: false,
  ltr: false,
  placeholderAlign: 'start',
  labelAlign: 'start'
};

export { InputPassword };
