import 'antd/dist/reset.css';
import iRANSansFaNumWeb from 'assets/webfonts/IRANSansFaNumWeb.ttf';
import iRANSansFaNumWebBold from 'assets/webfonts/IRANSansFaNumWeb_Bold.ttf';
import iRANSansFaNumWebLight from 'assets/webfonts/IRANSansFaNumWeb_Light.ttf';
import iRANSansFaNumWebMedium from 'assets/webfonts/IRANSansFaNumWeb_Medium.ttf';

import iRANSansDastNevis from 'assets/webfonts/titles/IranSans-dastNevis.ttf';
import { createGlobalStyle } from 'styled-components';
import tw from 'twin.macro';

const GlobalStyles = createGlobalStyle`
  @font-face {
    font-family: IRANSansFaNum;
    font-style: normal;
    font-weight: 600;
    src: url(${iRANSansFaNumWebBold}) format("truetype")
  }

  @font-face {
    font-family: IRANSansFaNum;
    font-style: normal;
    font-weight: 500;
    src: url(${iRANSansFaNumWebMedium}) format("truetype")
  }

  @font-face {
    font-family: IRANSansFaNum;
    font-style: normal;
    font-weight: 400;
    src: url(${iRANSansFaNumWeb}) format("truetype")
  }

  @font-face {
    font-family: IRANSansFaNum;
    font-style: normal;
    font-weight: 300;
    src: url(${iRANSansFaNumWebLight}) format("truetype")
  }

  @font-face {
    font-family: IRANSansDastNevis;
    font-style: normal;
    src: url(${iRANSansDastNevis}) format("truetype")
  }

  :root {
    --textGradientFirstPercent: 20%;
    --textGradientSecoundtPercent: 80%;

    --textGradientReverseFirstPercent: 0%;
    --textGradientReverseSecoundtPercent: 100%;
  }

  html * :not(i) {
    font-family: IRANSansFaNum !important;
    font-weight: 500;
  }

  .title__dastNevis {
    font-family: IRANSansDastNevis !important;
    font-weight: 700;
  }

  html {
    overflow: hidden;
  }


  body {
    font-size: 100% !important;
    overflow: auto;
  }

  #application {
    &,
    .spinner--container,
    .ant-spin-container {
      height: 100%;
    }

    .ant-layout {
      min-height: 100%;
    }

    .__appContent {
      padding: 0 8vw;
      ${tw`px-[19px]`};

      & > div > *:last-child {
        margin-bottom: 75px;
      }
    }

    a {
      display: inline-block;
      color: #21409A;
      font-size: .875rem;

      :hover {
        color: #122354;
      }
    }

  }

  @media (max-width: 992px) {
    a {
      font-size: 12px !important;
          font-weight: 500;
          color: #4D4D4D !important;
    }
  }

  .__currentTransaction {
    .ant-popover-inner {
      padding: 8px 12px;

      .ant-popover-inner-content {
        font-size: .75rem;
        font-weight: 500;
        color: #232429;
      }
    }
  }

  .--gradientText {
    background: linear-gradient(269.4deg, #21409A var(--textGradientFirstPercent), #F61982 var(--textGradientSecoundtPercent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-fill-color: transparent;
  }

  .--gradientTextReverse {
    background: linear-gradient(269.4deg, #F61982 var(--textGradientReverseFirstPercent), #21409A var(--textGradientReverseSecoundtPercent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-fill-color: transparent;
  }

  .--dropdownContent {
    .ant-dropdown-menu {
      box-shadow: 0 3px 6px -4px rgba(0, 0, 0, 0.12), 0 6px 16px 0 rgba(0, 0, 0, 0.08), 0 9px 28px 8px rgba(0, 0, 0, 0.05) !important;
      border: 1px solid #EEEEEE !important;
      border-radius: 5px !important;
      padding: 0 !important;
      overflow: hidden;

      .ant-dropdown-menu-item {
        line-height: 22px;
        transition: all 0.3s;
        border-radius: unset;
        padding: 0;

        .ant-dropdown-menu-title-content {
          > div,
          > span,
          > a {
            font-weight: 400;
            font-size: .75rem;
            color: #4D4D4D;
            padding: 8px 13px;
          }
        }

        :hover {
          background: linear-gradient(80.52deg, rgba(246, 25, 130, 0.14) 0%, rgba(33, 64, 154, 0.2) 100%);

          .ant-dropdown-menu-title-content * {
            font-weight: 500;
          }
        }
      }
    }
  }

  .ant-form {
    .ant-form-item-label {
      padding-bottom: 4px;
      text-align: start;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;

      label {
        color: #4D4D4D;
        font-size: .875rem;
        font-weight: 400;

        &.ant-form-item-required {
          /*&:after {
            display: inline-block;
            margin-left: 4px;
            margin-top: -5px;
            color: #FF0000;
            font-size: .875rem;
            font-family: SimSun, sans-serif;
            font-weight: bolder;
            line-height: 1;
            content: '*';
          }*/

          &:before {
            margin-top: -5px;
          }
        }
      }
    }
  }

  .h-25 {
    height: 25% !important;
  }

  .h-50 {
    height: 50% !important;
  }

  .h-75 {
    height: 75% !important;
  }

  .h-100 {
    height: 100% !important;
  }

  .h-auto {
    height: auto !important;
  }

  .text-lowercase {
    text-transform: lowercase !important;
  }

  .text-uppercase {
    text-transform: uppercase !important;
  }

  .text-capitalize {
    text-transform: capitalize !important;
  }

  .text-left {
    text-align: left !important;
  }

  .text-right {
    text-align: right !important;
  }

  .text-end {
    text-align: end !important;
  }

  .text-start {
    text-align: start !important;
  }

  .text-center {
    text-align: center !important;
  }

  .text-truncate {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .align-baseline {
    vertical-align: baseline !important;
  }

  .align-top {
    vertical-align: top !important;
  }

  .align-middle {
    vertical-align: middle !important;
  }

  .align-bottom {
    vertical-align: bottom !important;
  }

  .align-text-bottom {
    vertical-align: text-bottom !important;
  }

  .align-text-top {
    vertical-align: text-top !important;
  }

  .align-items-start {
    align-items: flex-start !important;
  }

  .align-items-end {
    align-items: flex-end !important;
  }

  .align-items-center {
    align-items: center !important;
  }

  .align-items-baseline {
    align-items: baseline !important;
  }

  .align-items-stretch {
    align-items: stretch !important;
  }

  .justify-content-start {
    justify-content: flex-start !important;
  }

  .justify-content-end {
    justify-content: flex-end !important;
  }

  .justify-content-center {
    justify-content: center !important;
  }

  .justify-content-between {
    justify-content: space-between !important;
  }

  .justify-content-around {
    justify-content: space-around !important;
  }

  .justify-content-evenly {
    justify-content: space-evenly !important;
  }

  .align-content-start {
    align-content: flex-start !important;
  }

  .align-content-end {
    align-content: flex-end !important;
  }

  .align-content-center {
    align-content: center !important;
  }

  .align-content-between {
    align-content: space-between !important;
  }

  .align-content-around {
    align-content: space-around !important;
  }

  .align-content-stretch {
    align-content: stretch !important;
  }

  .align-self-auto {
    align-self: auto !important;
  }

  .align-self-start {
    align-self: flex-start !important;
  }

  .align-self-end {
    align-self: flex-end !important;
  }

  .align-self-center {
    align-self: center !important;
  }

  .align-self-baseline {
    align-self: baseline !important;
  }

  .align-self-stretch {
    align-self: stretch !important;
  }

  .row-cols-auto > * {
    flex: 0 0 auto;
    width: auto;
  }

  .row-cols-1 > * {
    flex: 0 0 auto;
    width: 100%;
  }

  .row-cols-2 > * {
    flex: 0 0 auto;
    width: 50%;
  }

  .row-cols-3 > * {
    flex: 0 0 auto;
    width: 33.3333333333%;
  }

  .row-cols-4 > * {
    flex: 0 0 auto;
    width: 25%;
  }

  .row-cols-5 > * {
    flex: 0 0 auto;
    width: 20%;
  }

  .row-cols-6 > * {
    flex: 0 0 auto;
    width: 16.6666666667%;
  }

  .row-cols-7 > * {
    flex: 0 0 auto;
    width: 14.285714286%;
  }

  .row-cols-8 > * {
    flex: 0 0 auto;
    width: 12.5%;
  }

  @media (min-width: 576px) {

    .row-cols-sm-auto > * {
      flex: 0 0 auto;
      width: auto;
    }

    .row-cols-sm-1 > * {
      flex: 0 0 auto;
      width: 100%;
    }

    .row-cols-sm-2 > * {
      flex: 0 0 auto;
      width: 50%;
    }

    .row-cols-sm-3 > * {
      flex: 0 0 auto;
      width: 33.3333333333%;
    }

    .row-cols-sm-4 > * {
      flex: 0 0 auto;
      width: 25%;
    }

    .row-cols-sm-5 > * {
      flex: 0 0 auto;
      width: 20%;
    }

    .row-cols-sm-6 > * {
      flex: 0 0 auto;
      width: 16.6666666667%;
    }

    .text-sm-left {
      text-align: left !important;
    }

    .text-sm-right {
      text-align: right !important;
    }

    .text-sm-center {
      text-align: center !important;
    }

    .align-self-sm-auto {
      align-self: auto !important;
    }

    .align-self-sm-start {
      align-self: flex-start !important;
    }

    .align-self-sm-end {
      align-self: flex-end !important;
    }

    .align-self-sm-center {
      align-self: center !important;
    }

    .align-self-sm-baseline {
      align-self: baseline !important;
    }

    .align-self-sm-stretch {
      align-self: stretch !important;
    }

    .align-content-sm-start {
      align-content: flex-start !important;
    }

    .align-content-sm-end {
      align-content: flex-end !important;
    }

    .align-content-sm-center {
      align-content: center !important;
    }

    .align-content-sm-between {
      align-content: space-between !important;
    }

    .align-content-sm-around {
      align-content: space-around !important;
    }

    .align-content-sm-stretch {
      align-content: stretch !important;
    }

    .justify-content-sm-start {
      justify-content: flex-start !important;
    }

    .justify-content-sm-end {
      justify-content: flex-end !important;
    }

    .justify-content-sm-center {
      justify-content: center !important;
    }

    .justify-content-sm-between {
      justify-content: space-between !important;
    }

    .justify-content-sm-around {
      justify-content: space-around !important;
    }

    .justify-content-sm-evenly {
      justify-content: space-evenly !important;
    }

    .align-items-sm-start {
      align-items: flex-start !important;
    }

    .align-items-sm-end {
      align-items: flex-end !important;
    }

    .align-items-sm-center {
      align-items: center !important;
    }

    .align-items-sm-baseline {
      align-items: baseline !important;
    }

    .align-items-sm-stretch {
      align-items: stretch !important;
    }
  }

  @media (min-width: 768px) {

    .row-cols-md-auto > * {
      flex: 0 0 auto;
      width: auto;
    }

    .row-cols-md-1 > * {
      flex: 0 0 auto;
      width: 100%;
    }

    .row-cols-md-2 > * {
      flex: 0 0 auto;
      width: 50%;
    }

    .row-cols-md-3 > * {
      flex: 0 0 auto;
      width: 33.3333333333%;
    }

    .row-cols-md-4 > * {
      flex: 0 0 auto;
      width: 25%;
    }

    .row-cols-md-5 > * {
      flex: 0 0 auto;
      width: 20%;
    }

    .row-cols-md-6 > * {
      flex: 0 0 auto;
      width: 16.6666666667%;
    }

    .text-md-left {
      text-align: left !important;
    }

    .text-md-right {
      text-align: right !important;
    }

    .text-md-center {
      text-align: center !important;
    }

    .align-self-md-auto {
      align-self: auto !important;
    }

    .align-self-md-start {
      align-self: flex-start !important;
    }

    .align-self-md-end {
      align-self: flex-end !important;
    }

    .align-self-md-center {
      align-self: center !important;
    }

    .align-self-md-baseline {
      align-self: baseline !important;
    }

    .align-self-md-stretch {
      align-self: stretch !important;
    }

    .align-content-md-start {
      align-content: flex-start !important;
    }

    .align-content-md-end {
      align-content: flex-end !important;
    }

    .align-content-md-center {
      align-content: center !important;
    }

    .align-content-md-between {
      align-content: space-between !important;
    }

    .align-content-md-around {
      align-content: space-around !important;
    }

    .align-content-md-stretch {
      align-content: stretch !important;
    }

    .justify-content-md-start {
      justify-content: flex-start !important;
    }

    .justify-content-md-end {
      justify-content: flex-end !important;
    }

    .justify-content-md-center {
      justify-content: center !important;
    }

    .justify-content-md-between {
      justify-content: space-between !important;
    }

    .justify-content-md-around {
      justify-content: space-around !important;
    }

    .justify-content-md-evenly {
      justify-content: space-evenly !important;
    }

    .align-items-md-start {
      align-items: flex-start !important;
    }

    .align-items-md-end {
      align-items: flex-end !important;
    }

    .align-items-md-center {
      align-items: center !important;
    }

    .align-items-md-baseline {
      align-items: baseline !important;
    }

    .align-items-md-stretch {
      align-items: stretch !important;
    }
  }

  @media (min-width: 992px) {

    .row-cols-lg-auto > * {
      flex: 0 0 auto;
      width: auto;
    }

    .row-cols-lg-1 > * {
      flex: 0 0 auto;
      width: 100%;
    }

    .row-cols-lg-2 > * {
      flex: 0 0 auto;
      width: 50%;
    }

    .row-cols-lg-3 > * {
      flex: 0 0 auto;
      width: 33.3333333333%;
    }

    .row-cols-lg-4 > * {
      flex: 0 0 auto;
      width: 25%;
    }

    .row-cols-lg-5 > * {
      flex: 0 0 auto;
      width: 20%;
    }

    .row-cols-lg-6 > * {
      flex: 0 0 auto;
      width: 16.6666666667%;
    }

    .text-lg-left {
      text-align: left !important;
    }

    .text-lg-right {
      text-align: right !important;
    }

    .text-lg-start {
      text-align: start !important;
    }

    .text-lg-end {
      text-align: end !important;
    }

    .text-lg-center {
      text-align: center !important;
    }

    .align-self-lg-auto {
      align-self: auto !important;
    }

    .align-self-lg-start {
      align-self: flex-start !important;
    }

    .align-self-lg-end {
      align-self: flex-end !important;
    }

    .align-self-lg-center {
      align-self: center !important;
    }

    .align-self-lg-baseline {
      align-self: baseline !important;
    }

    .align-self-lg-stretch {
      align-self: stretch !important;
    }

    .align-content-lg-start {
      align-content: flex-start !important;
    }

    .align-content-lg-end {
      align-content: flex-end !important;
    }

    .align-content-lg-center {
      align-content: center !important;
    }

    .align-content-lg-between {
      align-content: space-between !important;
    }

    .align-content-lg-around {
      align-content: space-around !important;
    }

    .align-content-lg-stretch {
      align-content: stretch !important;
    }

    .justify-content-lg-start {
      justify-content: flex-start !important;
    }

    .justify-content-lg-end {
      justify-content: flex-end !important;
    }

    .justify-content-lg-center {
      justify-content: center !important;
    }

    .justify-content-lg-between {
      justify-content: space-between !important;
    }

    .justify-content-lg-around {
      justify-content: space-around !important;
    }

    .justify-content-lg-evenly {
      justify-content: space-evenly !important;
    }

    .align-items-lg-start {
      align-items: flex-start !important;
    }

    .align-items-lg-end {
      align-items: flex-end !important;
    }

    .align-items-lg-center {
      align-items: center !important;
    }

    .align-items-lg-baseline {
      align-items: baseline !important;
    }

    .align-items-lg-stretch {
      align-items: stretch !important;
    }
  }

  @media (min-width: 1200px) {

    .row-cols-xl-auto > * {
      flex: 0 0 auto;
      width: auto;
    }

    .row-cols-xl-1 > * {
      flex: 0 0 auto;
      width: 100%;
    }

    .row-cols-xl-2 > * {
      flex: 0 0 auto;
      width: 50%;
    }

    .row-cols-xl-3 > * {
      flex: 0 0 auto;
      width: 33.3333333333%;
    }

    .row-cols-xl-4 > * {
      flex: 0 0 auto;
      width: 25%;
    }

    .row-cols-xl-5 > * {
      flex: 0 0 auto;
      width: 20%;
    }

    .row-cols-xl-6 > * {
      flex: 0 0 auto;
      width: 16.6666666667%;
    }

    .text-xl-left {
      text-align: left !important;
    }

    .text-xl-right {
      text-align: right !important;
    }

    .text-xl-start {
      text-align: start !important;
    }

    .text-xl-end {
      text-align: end !important;
    }

    .text-xl-center {
      text-align: center !important;
    }

    .align-self-xl-auto {
      align-self: auto !important;
    }

    .align-self-xl-start {
      align-self: flex-start !important;
    }

    .align-self-xl-end {
      align-self: flex-end !important;
    }

    .align-self-xl-center {
      align-self: center !important;
    }

    .align-self-xl-baseline {
      align-self: baseline !important;
    }

    .align-self-xl-stretch {
      align-self: stretch !important;
    }

    .align-content-xl-start {
      align-content: flex-start !important;
    }

    .align-content-xl-end {
      align-content: flex-end !important;
    }

    .align-content-xl-center {
      align-content: center !important;
    }

    .align-content-xl-between {
      align-content: space-between !important;
    }

    .align-content-xl-around {
      align-content: space-around !important;
    }

    .align-content-xl-stretch {
      align-content: stretch !important;
    }

    .justify-content-xl-start {
      justify-content: flex-start !important;
    }

    .justify-content-xl-end {
      justify-content: flex-end !important;
    }

    .justify-content-xl-center {
      justify-content: center !important;
    }

    .justify-content-xl-between {
      justify-content: space-between !important;
    }

    .justify-content-xl-around {
      justify-content: space-around !important;
    }

    .justify-content-xl-evenly {
      justify-content: space-evenly !important;
    }

    .align-items-xl-start {
      align-items: flex-start !important;
    }

    .align-items-xl-end {
      align-items: flex-end !important;
    }

    .align-items-xl-center {
      align-items: center !important;
    }

    .align-items-xl-baseline {
      align-items: baseline !important;
    }

    .align-items-xl-stretch {
      align-items: stretch !important;
    }
  }

  @media (min-width: 1600px) {
    .row-cols-xxl-auto > * {
      flex: 0 0 auto;
      width: auto;
    }

    .row-cols-xxl-1 > * {
      flex: 0 0 auto;
      width: 100%;
    }

    .row-cols-xxl-2 > * {
      flex: 0 0 auto;
      width: 50%;
    }

    .row-cols-xxl-3 > * {
      flex: 0 0 auto;
      width: 33.3333333333%;
    }

    .row-cols-xxl-4 > * {
      flex: 0 0 auto;
      width: 25%;
    }

    .row-cols-xxl-5 > * {
      flex: 0 0 auto;
      width: 20%;
    }

    .row-cols-xxl-6 > * {
      flex: 0 0 auto;
      width: 16.6666666667%;
    }

    .text-xxl-left {
      text-align: left !important;
    }

    .text-xxl-right {
      text-align: right !important;
    }

    .text-xxl-start {
      text-align: start !important;
    }

    .text-xxl-end {
      text-align: end !important;
    }

    .text-xxl-center {
      text-align: center !important;
    }

    .align-self-xxl-auto {
      align-self: auto !important;
    }

    .align-self-xxl-start {
      align-self: flex-start !important;
    }

    .align-self-xxl-end {
      align-self: flex-end !important;
    }

    .align-self-xxl-center {
      align-self: center !important;
    }

    .align-self-xxl-baseline {
      align-self: baseline !important;
    }

    .align-self-xxl-stretch {
      align-self: stretch !important;
    }

    .align-content-xxl-start {
      align-content: flex-start !important;
    }

    .align-content-xxl-end {
      align-content: flex-end !important;
    }

    .align-content-xxl-center {
      align-content: center !important;
    }

    .align-content-xxl-between {
      align-content: space-between !important;
    }

    .align-content-xxl-around {
      align-content: space-around !important;
    }

    .align-content-xxl-stretch {
      align-content: stretch !important;
    }

    .justify-content-xxl-start {
      justify-content: flex-start !important;
    }

    .justify-content-xxl-end {
      justify-content: flex-end !important;
    }

    .justify-content-xxl-center {
      justify-content: center !important;
    }

    .justify-content-xxl-between {
      justify-content: space-between !important;
    }

    .justify-content-xxl-around {
      justify-content: space-around !important;
    }

    .justify-content-xxl-evenly {
      justify-content: space-evenly !important;
    }

    .align-items-xxl-start {
      align-items: flex-start !important;
    }

    .align-items-xxl-end {
      align-items: flex-end !important;
    }

    .align-items-xxl-center {
      align-items: center !important;
    }

    .align-items-xxl-baseline {
      align-items: baseline !important;
    }

    .align-items-xxl-stretch {
      align-items: stretch !important;
    }
  }
`;

export default GlobalStyles;