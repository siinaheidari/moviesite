import { Col, Row } from 'antd';
import styled from 'styled-components';

const FooterContainer = styled(Row)`
  background: linear-gradient(270deg, #D11575 0%, #1447A0 100%);
  padding: 10px;

  .--text {
    text-align: center;
    color: #FFFFFF;
    font-weight: 400;
    font-size: .875rem;
  }
`;

const Footer = () => {
  return (
    <FooterContainer className={"max-lg:hidden"}>
      <Col span={ 24 } className='--text'>
        تمامی حقوق مادی و معنوی این سایت متعلق به بانک رفاه کارگران می باشد
      </Col>
    </FooterContainer>
  );
};

export default Footer;
