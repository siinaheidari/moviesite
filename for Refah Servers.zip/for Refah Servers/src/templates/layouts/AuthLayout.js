// antd layout component
import { useEffect } from 'react';
import { Layout } from 'antd';
import { useTheme } from 'contexts/theme/ThemeContext';
import {Navigate, Outlet} from 'react-router-dom';
import styled from 'styled-components';
import Footer from '../footer';
import Header from 'templates/header/main';
import {useAuth} from "../../contexts/auth/AuthContext";

const { Content, Header: AntdHeader, Footer: AntdFooter } = Layout;

const HeaderContainer = styled(AntdHeader)`
  height: auto !important;
  padding: 0 !important;
  margin: 0 !important;
  background-color: transparent !important;
  line-height: 0 !important;
`;

const FooterContainer = styled(AntdFooter)`
  padding: 0 !important;
  background-color: transparent !important;
`;

const AuthLayout = () => {
  const { handleChangeTheme } = useTheme();
  const { isLoggedIn } = useAuth();

  useEffect(() => {
    handleChangeTheme('main');
  }, []);

  if (isLoggedIn) return <Navigate to='/'/>;

  return (
    <Layout className='mainLayout--container'>
      <HeaderContainer>
        <Header/>
      </HeaderContainer>

      <Content className='__appContent'>
        <Layout>
          <Outlet/>
        </Layout>
      </Content>

      <FooterContainer>
        <Footer/>
      </FooterContainer>
    </Layout>
  );
};

export default AuthLayout;
