import { useEffect, useState } from 'react';
import { Col, Layout, Row } from 'antd';
import { useTheme } from 'contexts/theme/ThemeContext';
import { useAuth } from 'contexts/auth/AuthContext';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import styled from 'styled-components';
import { adminMenu } from 'templates/components/adminMenu';

// component
import TopPanel from 'templates/topPanel/admin';
import { TransitionsPage } from 'templates/Ui';
import Sidebar from './components/Sidebar';

const { Content, Header: AntdHeader } = Layout;

const AdminLayoutContainer = styled(Layout)`
  .__topPanel {
    height: auto !important;
    padding: 0 !important;
    margin: 0 !important;
    background-color: transparent !important;
    line-height: 0 !important;
  }

  .__adminContent {
    padding: 0 2vw;
    margin-top: 20px;

    > .ant-layout {
      flex-direction: column;
    }

    .--content {
      padding-inline-start: 16px;
    }
  }
`;

const AdminLayout = () => {
  const { isLoggedIn, auth } = useAuth();
  const { handleChangeTheme } = useTheme();
  
  const { pathname } = useLocation();
  
  const [urlPath, setUrlPath] = useState([]); // set url path from url path in browser
  
  useEffect(() => {
    handleChangeTheme('admin');
  }, []);
  
  useEffect(() => {
    setUrlPath(() => {
      const path = pathname?.split('/').filter(Boolean);
      path.shift();
      
      return path;
    });
  }, [pathname]);
  
  if (!isLoggedIn) return <Navigate to='/auth'/>;
  
  if (auth?.userRole !== 1) return <Navigate to='/'/>;
  
  return (
    <AdminLayoutContainer className='adminLayout--container'>
      <AntdHeader className='__topPanel'>
        <TopPanel/>
      </AntdHeader>
      
      <Content className='__adminContent'>
        <Layout>
          <Row>
            <Col span={ 5 } className='--sideBar'>
              <Sidebar menu={ adminMenu } selectedKeys={ urlPath }/>
            </Col>
            
            <Col span={ 19 } className='--content'>
              <TransitionsPage name={ urlPath }>
                <Outlet/>
              </TransitionsPage>
            </Col>
          </Row>
        </Layout>
      </Content>
    </AdminLayoutContainer>
  );
};

export default AdminLayout;
