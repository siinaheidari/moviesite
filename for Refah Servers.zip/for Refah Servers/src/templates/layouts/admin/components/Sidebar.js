import { Col, Row } from 'antd';
import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import styled from 'styled-components';
import { convertColor } from 'utils/helper';

const SidebarContainer = styled(Row)`
  background: #7258DB;
  border-start-Start-radius: 15px;
  border-start-end-radius: 15px;
  padding-block-start: 31px;
  overflow: hidden;

  .--topSection {
    color: #FFFFFF;
    font-size: .875rem;
    font-weight: 500;
    text-align: center;
    padding-block-end: 24px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.5);
  }

  .--bottomSection {
    padding-inline: 20px;
    height: calc(100vh - 144px);
    overflow-y: auto;

    scroll-behavior: smooth;
    -webkit-overflow-scrolling: touch;

    scrollbar-color: ${ convertColor('#7258DB', -50) } transparent;


    ::-webkit-scrollbar {
      width: 6px;
    }

    /* Track */

    ::-webkit-scrollbar-track {
      //box-shadow: inset 0 0 5px grey;
    }

    /* Handle */

    ::-webkit-scrollbar-thumb {
      background: ${ convertColor('#7258DB', -50) };
      border-radius: 10px;
    }

    /* Handle on hover */

    ::-webkit-scrollbar-thumb:hover {
      background: ${ convertColor('#7258DB', -70) };
    }

    > .ant-row {
      height: 100%;
    }

    .__menuItems,
    .__menuItemsChild {
      padding-block-start: 30px;
      padding-block-end: 35px;
    }

    .__menuItems {
      border-inline-end: 1px solid rgba(255, 255, 255, 0.5);
      padding-inline-end: 24px;

      .--menuItemParent {
        cursor: pointer;

        .--svgIcon {
          background-color: #FFFFFF;
        }

        &.--active,
        :hover {
          .--svgIcon {
            background-color: #F61982;
          }
        }
      }
    }

    .__menuItemsChild {
      padding-inline-start: 13px;

      .--menuItemChildren {
        a {
          color: #FFFFFF !important;
          font-size: .875rem !important;
          font-weight: 400 !important;
          padding: 9px 24px;
        }

        &.--active,
        :hover {
          a {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
          }
        }

        &.--active {
          a {
            :before {
              content: '';
              display: inline-block;
              width: 4px;
              height: 4px;
              background-color: #FFFFFF;
              border-radius: 50%;
              margin-inline-end: 9px;
            }
          }
        }
      }
    }
  }
`;

const Sidebar = ({ menu, selectedKeys }) => {
  
  const newMenu = menu?.filter(item => item?.key !== 'divider');
  
  const [selectedMenuParent, setSelectedMenuParent] = useState(selectedKeys[ 0 ]);
  const [selectedMenuChildren, setSelectedMenuChildren] = useState(selectedKeys[ 1 ]);
  
  useEffect(() => {
    setSelectedMenuParent(selectedKeys[ 0 ]);
    
    setSelectedMenuChildren(selectedKeys[ 1 ]);
  }, [selectedKeys]);
  
  const selectedMenu = newMenu?.find(item => selectedMenuParent === item?.key)?.children;
  
  const handleClickMenuParent = key => setSelectedMenuParent(key);
  
  return (
    <SidebarContainer>
      <Col span={ 24 } className='--topSection'>
        سامانه مدیریت باشگاه پذیرندگان بانک رفاه
      </Col>
      
      <Col span={ 24 } className='--bottomSection'>
        <Row>
          <Col flex='20px' className='__menuItems'>
            <Row gutter={ [0, 30] }>
              { newMenu?.map(item => {
                return (
                  <Col
                    span={ 24 }
                    key={ `adminMenuParent_${ item.key }` }
                    className={ `--menuItemParent ${ selectedMenuParent === item?.key ? '--active' : '' }` }
                    onClick={ () => handleClickMenuParent(item.key) }
                  >
                    { item?.label }
                  </Col>
                );
              }) }
            </Row>
          </Col>
          
          <Col flex='1 1' className='__menuItemsChild'>
            <AnimatePresence mode={ 'popLayout' }>
              <motion.div
                key={ selectedMenuParent || 'empty' }
                initial={ { x: 24, opacity: 0 } }
                animate={ { x: 0, opacity: 1 } }
                exit={ { x: -24, opacity: 0 } }
                transition={ { duration: 0.2 } }
              >
                <Row gutter={ [0, 7] }>
                  { selectedMenu?.map(children => {
                    return (
                      <Col span={ 24 } key={ `adminMenuParent_${ children.key }` }
                           className={ `--menuItemChildren ${ selectedMenuChildren === children?.key ? '--active' : '' }` }>
                        { children?.label }
                      </Col>
                    );
                  }) }
                </Row>
              </motion.div>
            </AnimatePresence>
          </Col>
        </Row>
      </Col>
    </SidebarContainer>
  );
};

export default Sidebar;
