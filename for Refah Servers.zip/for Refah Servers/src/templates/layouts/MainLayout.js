// antd layout component
import { useEffect, useState } from 'react';
import { Layout } from 'antd';
import { useTheme } from 'contexts/theme/ThemeContext';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import styled from 'styled-components';
import Footer from '../footer';
import Header from 'templates/header/main';
import {useAuth} from "../../contexts/auth/AuthContext";
import BottomMenu from '../bottomMenu';
import { useBottomMenu } from '../../contexts/bottomMenu/BottomMenuContext';

const { Content, Header: AntdHeader, Footer: AntdFooter } = Layout;

const HeaderContainer = styled(AntdHeader)`
  height: auto !important;
  padding: 0 !important;
  margin: 0 !important;
  background-color: transparent !important;
  line-height: 0 !important;
`;

const FooterContainer = styled(AntdFooter)`
  padding: 0 !important;
  background-color: transparent !important;
`;

const MainLayout = () => {
  const { handleChangeTheme } = useTheme();
  const { isLoggedIn, auth } = useAuth();
  const { bottomMenuIsVisible, handleChangeBottomMenuVisible } = useBottomMenu();
  const { pathname } = useLocation();



  // TODO: add another
  const dontShowBottomMenu = ['home', 'pursueRequests',"survey","discountCodes","myBankAccounts","tournament","sendTicket","subMenu","posAndIPGRequest","disposeTerminal","ChangeTerminalAddress","terminals",'increase-money',"sendTicket","ChangeTerminal","offersComplain",'use-money','transport-money',"RequestPaperRoll", 'buy-from-merchant','increase-money','cash-flow','add-cart-bank','buy-charge','buy-net', 'pay-bill'];
  
  useEffect(() => {
    let path = pathname?.split('/').filter(Boolean);

    if (!path?.length) {
      path = [ 'home' ];
    }
    
    if (dontShowBottomMenu?.includes(path[path.length - 1])) {
      handleChangeBottomMenuVisible(false);
    }
    
    return () => {
      handleChangeBottomMenuVisible(true);
    };
    
  }, [ pathname ]);
  
  useEffect(() => {
    handleChangeTheme('main');
  }, []);

  if (!isLoggedIn) return <Navigate to='/auth'/>;
  
  return (
    <Layout className='mainLayout--container'>
      <HeaderContainer>
        <Header/>
      </HeaderContainer>
      
      <Content className='__appContent'>
        <Layout>
          <Outlet/>
        </Layout>
      </Content>
      
      { bottomMenuIsVisible &&
        <div className="__bottomMenu">
          <BottomMenu/>
        </div>
      }
      
      <FooterContainer>
        <Footer/>
      </FooterContainer>
    </Layout>
  );
};

export default MainLayout;
