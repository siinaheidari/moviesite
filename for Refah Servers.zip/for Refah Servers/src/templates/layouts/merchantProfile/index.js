import {Col, Row, Tooltip} from 'antd';
import {useAuth} from 'contexts/auth/AuthContext';
import {useEffect, useState} from 'react';
import {Link, Navigate, Outlet, useLocation, useNavigate} from 'react-router-dom';
import styled, {css} from 'styled-components';
import {Modal, TransitionsPage} from 'templates/Ui';
import { formatNumber, useWindowSize } from 'utils/helper';
import {useRequest} from "../../../utils/useRequest";

// components
import {merchantProfileMenu} from 'templates/components/merchantProfileMenu';
import TitleByCircle from 'templates/components/TitleByCircle';
import SideBar from './components/SideBar';
import UserDetails from './components/UserDetails';

// images
import dollarCoins from 'assets/icons/dollarCoins.svg';
import heart from 'assets/icons/heart.svg';
import wallet from 'assets/icons/wallet.svg';
import checkSquare from 'assets/icons/checkSquare.svg';
import {MatchBreakpoint} from "react-hook-breakpoints";


const ProfileLayoutContainer = styled(Row)`
  padding: 33px 0;

  .--content {
    ${props => props?.breadcrumbpath &&
      css`
        background-color: #FFFFFF;
        border: 1px solid #FFFFFF;
        box-shadow: 0 4px 4px rgba(122, 122, 122, 0.05);
        border-radius: 10px;
        padding: 26px 0;
      `
    }
    .--breadcrumb {
      padding: 0 23px;
    }
`;

const StatsBoxContainer = styled(Row)`
  background: #FFFFFF;
  box-shadow: 0 4px 10px rgba(122, 122, 122, 0.1);
  border-radius: 10px;
  overflow: hidden;
  padding: 17px 10%;
  height: 100%;
  cursor: pointer;

  .--icon {
    img {
      height: 24px;
    }
  }

  .--title {
    font-size: .875rem;
    color: #4D4D4D;
  }

  .--value {
    text-align: center;
    font-size: .875rem;
    font-weight: 400;
    color: #21409A;
  }
`;

const ProfileLayout = () => {
  const {isLoggedIn, auth} = useAuth();

  const {width} = useWindowSize();

  const {pathname} = useLocation();
  const navigate = useNavigate();

  const [urlPath, setUrlPath] = useState([]); // set url path from url path in browser

  const [pathForBreadcrumb, setPathForBreadcrumb] = useState([]); // set path for use in breadcrumb


  const {
    isLoading: walletInventoryIsLoading,
    data: walletInventory,

  } = useRequest({
    path: '/wallet/inventory',
    key: ["walletInventoryRequest", auth?.walletIdentifier],
    params: {
      walletIdentifier: auth.walletIdentifier || null,
    },
    options: {
      enabled: !!auth?.walletIdentifier,
      cacheTime: 0,
    },

  });

  const response = walletInventory || {}

  useEffect(() => {
    setUrlPath(() => {
      const path = pathname?.split('/').filter(Boolean);
      if (path?.length > 1) {
        path.shift();
      }

      return path;
    });

    setPathForBreadcrumb(() => {
      let draftPath = pathname?.split('/').filter(Boolean);
      draftPath.shift();

      if (draftPath?.length > 1) {
        draftPath.shift();
      }

      return draftPath;
    });
  }, [pathname]);

  let selectedMenuItemUseInFunction = {};

  const handleBreadcrumb = (menu) => {

    menu?.map(item => {
      if (pathForBreadcrumb.includes(item?.key)) {
        return selectedMenuItemUseInFunction = item;
      } else {
        if (item?.children?.length) {
          return handleBreadcrumb(item?.children);
        }
      }
    });

    return selectedMenuItemUseInFunction;
  };



  const breadcrumbPath = handleBreadcrumb(merchantProfileMenu);

  if (!isLoggedIn) return <Navigate to='/auth'/>;

  // if (auth?.userRole !== 9) return <Navigate to='/'/>;

  const notCustomPage = !!(breadcrumbPath?.key && !['discountCodes', 'posAndIPGRequest', 'businessPartners', 'plansAndCampaigns', 'myBankAccounts', 'facilitiesGrants', 'tournament'].includes(breadcrumbPath?.key));




  return (
    <ProfileLayoutContainer gutter={[0, 30]} breadcrumbpath={+notCustomPage && width > 991}>
      <MatchBreakpoint max="md">
        <Col span={24}>
          <TransitionsPage name={breadcrumbPath?.key || 'initial'} size={25} className='--content'>
            <Outlet context={breadcrumbPath}/>
          </TransitionsPage>
        </Col>
      </MatchBreakpoint>
      
      <MatchBreakpoint min="lg">
        <Col span={24} className='--userDetailBox'>
          <UserDetails urlPath={urlPath}/>
        </Col>
        
        <Col span={24}>
          <Row gutter={16}>
            <Col span={6} className='--sideBar'>
              <SideBar selectedKeys={urlPath} menu={merchantProfileMenu}/>
            </Col>
            
            <Col span={18}>
              <Row gutter={[0, 32]}>
                <Col span={24}>
                  <Row gutter={[12, 12]} align={'stretch'}>
                    <Col span={6}>
                      <StatsBox
                        icon={dollarCoins}
                        title={'امتیازات من:'}
                        value={1200}
                      />
                    </Col>
                    
                    
                    <Col span={6}>
                      <StatsBox
                        icon={wallet}
                        title={'کیف پول من:'}
                        value={`${formatNumber(response?.balance || 0)} ریال`}
                        onClick={() => navigate("/merchantProfile/wallet")}
                      />
                    </Col>
                    
                    <Col span={6}>
                      <StatsBox
                        icon={heart}
                        title={'امکانات رفاهی:'}
                        value={'تخفیفات، انواع وام، قرعه کشی، لورم، لورم۲'}
                      />
                    </Col>
                    
                    <Col span={6}>
                      <StatsBox
                        icon={checkSquare}
                        title={'خدمات بانکداری:'}
                        value={'بانکداری باز، دولت الکترونیک، پرداخت قبوض'}
                      />
                    </Col>
                  </Row>
                </Col>
                
                <Col span={24}>
                  <TransitionsPage name={breadcrumbPath?.key || 'initial'} size={25} className='--content'>
                    {notCustomPage ?
                      (
                        <Row gutter={[0, 20]}>
                          <Col span={24} className='--breadcrumb'>
                            <TitleByCircle text={breadcrumbPath?.label || ''}/>
                          </Col>
                          
                          <Col span={24}>
                            <Outlet context={breadcrumbPath}/>
                          </Col>
                        </Row>
                      ) :
                      <Outlet context={breadcrumbPath}/>
                    }
                  </TransitionsPage>
                </Col>
              </Row>
            </Col>
          </Row>
        </Col>
      </MatchBreakpoint>
    </ProfileLayoutContainer>
  );
};

const StatsBox = ({icon, title, value, ...reset}) => {
  return (
    <StatsBoxContainer gutter={[0, 13]} align={'top'} {...reset}>
      <Col span={24} className='align-self-start'>
        <Row gutter={8} align={'middle'} justify={'center'}>
          <Col className='--icon'>
            <img className={"w-full max-w-[25px] "} src={icon}/>
          </Col>

          <Col className='--title'>
            {title}
          </Col>
        </Row>
      </Col>

      <Col span={24} className='align-self-end --value'>
        <Tooltip title={value}>
          <div className='text-truncate'>
            {value}
          </div>
        </Tooltip>
      </Col>
    </StatsBoxContainer>
  );
};

export default ProfileLayout;
