import { Layout, Menu } from 'antd';
import { useEffect, useState } from 'react';
import styled from 'styled-components';

import dollarCoin from 'assets/icons/dollarCoin.svg';
import { merchantProfileMenu } from 'templates/components/merchantProfileMenu';

const { Sider } = Layout;

const SiderContainer = styled(Sider)`
  background: #FFFFFF !important;
  overflow: hidden;
  min-width: 100% !important;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;

  @media (min-width: 992px) {
    border-radius: 10px;
  }

  .ant-layout-sider-children {
    position: relative;

    .--menu {
      border: none !important;
      background-color: transparent;
      
      .ant-menu-item {
        margin: 0 !important;
        height: 58px;
        line-height: 58px;
        width: 100%;
        border-radius: 0;
        transition: none !important;
        padding: 0 24px;

        .ant-menu-title-content {
          &,
          a {
            color: #4D4D4D !important;
            font-weight: 400;
          }
        }

        :hover,
        &.ant-menu-item-selected {
          background: linear-gradient(267.05deg, rgba(246, 25, 130, 0.22) 5.14%, rgba(33, 64, 154, 0.03) 100.27%);

          .ant-menu-item-icon {
            background-color: #21409A;
          }

          .ant-menu-title-content {
            &,
            a {
              color: #21409A !important;
              font-weight: 500;
            }
          }
        }

        &.ant-menu-item-selected {
          position: relative;

          :before {
            content: '';
            background: linear-gradient(267.05deg, #F61982 5.14%, #21409A 100.27%);
            height: 5px;
            position: absolute;
            top: 0;
            right: 0;
            left: 0;
            z-index: 22;
          }
        }

        :not(:last-child) {
          border-bottom: 1px solid #EEEEEE !important;
        }
      }

      .ant-menu-submenu {
        .ant-menu-submenu-title {
          margin: 0;
          height: 58px;
          line-height: 58px;
          width: 100%;
          border-radius: 0;
          transition: none !important;
          border: 1px solid #EEEEEE !important;

          .ant-menu-title-content {
            &,
            a {
              color: #4D4D4D !important;
              font-weight: 400;
            }
          }

          :hover {
            background: linear-gradient(267.05deg, rgba(246, 25, 130, 0.22) 5.14%, rgba(33, 64, 154, 0.03) 100.27%);

            .ant-menu-item-icon {
              background-color: #21409A;
            }

            .ant-menu-title-content {
              &,
              a {
                color: #21409A !important;
                font-weight: 500;
              }
            }
          }
        }

        &.ant-menu-submenu-selected {
          > .ant-menu-submenu-title {
            .ant-menu-item-icon {
              background-color: #21409A;
            }

            .ant-menu-title-content {
              &,
              a {
                color: #21409A !important;
                font-weight: 500;
              }
            }
          }
        }

        .ant-menu {
          background-color: #F9F9F9;
        }
      }

      /******************************** global for inline and sub ***********************************/

      .ant-menu-title-content {
        .--byDollarCoin {
          background: url(${ dollarCoin }) no-repeat;
          position: absolute;
          left: 16px;
          top: 20px;
          width: 17px;
          height: 17px;
        }
      }
    }
  }
`;

const SideBar = ({ menu, selectedKeys }) => {
  const newMenu = menu?.filter(item => item?.key !== 'divider');
  
  const [openKeys, setOpenKeys] = useState(selectedKeys);
  
  useEffect(() => setOpenKeys(selectedKeys), [selectedKeys]);
  
  let rootSubmenuKeys = [];
  
  merchantProfileMenu?.map(item => {
    rootSubmenuKeys.push(item.key);
  });
  
  const onOpenChange = keys => {
    const latestOpenKey = keys.find(key => openKeys.indexOf(key) === -1);
    if (rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
      setOpenKeys(keys);
    }
    else {
      setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
    }
  };

  
  return (
    <SiderContainer
      breakpoint='lg'
      collapsedWidth='0'
      className='--side__lg'
      theme='light'
    >
      <Menu
        className='--menu'
        onOpenChange={ onOpenChange }
        openKeys={ openKeys }
        defaultOpenKeys={ openKeys }
        selectedKeys={ selectedKeys }
        items={ newMenu }
        mode='inline'
      />
    </SiderContainer>
  );
};

export default SideBar;
