import { Avatar, Badge, Col, Progress, Row, Space } from 'antd';
import { ReactComponent as VIPStar } from 'assets/icons/vipStar.svg';
import user from 'assets/images/user.png';
import { useAuth } from 'contexts/auth/AuthContext';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { DropdownV1 } from 'templates/Ui';
import {convertDatePicker} from "../../../../utils/helper";
import {DateObject} from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";

const UserDetailsContainer = styled(Row)`
  background: linear-gradient(270deg, #1447A0 0%, #D11575 100%);
  border-radius: 10px;
  padding: 17px 5%;

  .--firstSection,
  .--secondSection {
    .__divider {
      border-inline-end: 1px solid #FFFFFF;
      height: 18px;
      margin-inline: 5px;
    }

    .__membershipCode,
    .__lastLogin {
      &,
      .ant-space-item div {
        font-size: 1rem;
        font-weight: 500;
        color: #FFFFFF;
      }
    }
  }

  .--firstSection {
    .__dropDownContainer {
      .ant-badge {
        .ant-progress {
          position: relative;
          z-index: 1;
        }

        .ant-avatar {
          position: absolute;
          right: 0;
          z-index: 0;
        }

        .ant-badge-count {
          width: 23px;
          height: 23px;
          background: #F61982;
          border: 2px solid #EEEEEE;
          border-radius: 50%;
          box-shadow: 0 4px 4px rgba(0, 0, 0, 0.15), inset 0 2px 1px rgba(0, 0, 0, 0.15);
          font-size: .625rem;
          font-weight: 500;
          /*top: 4px;
          transform: translate(65%, -50%);*/
          z-index: 2;
        }
      }

      .--trigger {
        margin-bottom: 17px;

        .__text {
          span {
            font-size: 1rem;
            font-weight: 500;
          }
        }
      }
    }

    .__vipStarIcon {
      svg {
        width: 50px;
      }
    }
  }

  .--secondSection {
    text-align: end;

    .__icons {
      margin-inline-start: 10px;

      i {
        font-size: 35px;
        color: #FFFFFF;
        filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, .25));
        cursor: pointer;
        -webkit-transition: ease all .5s;
        -moz-transition: ease all .5s;
        -o-transition: ease all .5s;
        transition: ease all .5s;
        -webkit-transform: scale(1);
        -moz-transform: scale(1);
        -o-transform: scale(1);
        transform: scale(1);

        :hover {
          -webkit-transform: scale(1.1);
          -moz-transform: scale(1.1);
          -ms-transform: scale(1.1);
          -o-transform: scale(1.1);
          transform: scale(1.1);
        }
      }

      .ant-badge {
        .ant-badge-count {
          width: 23px;
          height: 23px;
          background: #FE2301;
          border-radius: 50%;
          font-size: .875rem;
          font-weight: 400;
          z-index: 2;
          box-shadow: none;
          border: none;
        }
      }
    }
  }
`;

const UserDetails = ({ urlPath }) => {
  const { handleLogout, auth } = useAuth();

  let objectForDate = { date: auth?.lastLogin, format: 'YYYY/MM/DD', calendar: persian };

  const lastLoginDate = new DateObject(objectForDate).format();

  let objectForTime = { date: auth?.lastLogin, format: 'HH:mm', calendar: persian };

  const lastLoginTime = new DateObject(objectForTime).format();
  
  return (
    <UserDetailsContainer gutter={ 16 } justify={ 'space-between' } align={ 'middle' } >
      <Col span={ 14 } className='--firstSection'>
        <Space size={ 16 }>
          <div className='__dropDownContainer'>
            <DropdownV1
              title={
                <Space size={ 15 }>
                  <Badge
                    count={ 5 }
                    offset={ ['1', 7] }
                  >
                    <Progress
                      type='circle'
                      percent={ 80 }
                      width={ 50 }
                      trailColor={ '#CCCCCC' }
                      strokeColor={ '#1CC500' }
                      strokeWidth={ 10 }
                      showInfo={ false }
                    />
                    <Avatar
                      shape='circle'
                      size={ 50 }
                      src={ user }
                    />
                  </Badge>
                  
                  <span>
                    {`${auth.firstNameFa} ${auth.lastNameFa} خوش آمدید`}
                </span>
                </Space>
              }
              selectedKey={ urlPath[0] }
              menu={ [
                {
                  label: <Link to='editProfile'>تکمیل و ویرایش اطلاعات</Link>,
                  key: 'editProfile'
                }
              ] }
              height={ 50 }
            />
          </div>
          
          <div className='__divider'/>
          
          <div className='__membershipCode'>
            <Space>
              <div>کد عضویت:</div>
              
              <div>5125801153</div>
            </Space>
          </div>
          
          <div className='__vipStarIcon'>
            <VIPStar/>
          </div>
        </Space>
      </Col>
      
      <Col span={ 10 } className='--secondSection'>
        <Space size={ 14 }>
          <div className='__lastLogin'>
            <Space>
              <div>آخرین ورود:</div>

              <div>{lastLoginDate}</div>
            </Space>
          </div>
          
          <div className='__divider'/>
          
          <div className='__lastLogin'>
            {lastLoginTime}
          </div>
          
          <div className='__icons'>
            <Space>
              <Badge
                count={ 3 }
                offset={ [11, 4] }
              >
                <i className='icon-bellCircle'/>
              </Badge>
              
              <i
                className='icon-powerOffCircle --logOut'
                title='خروج'
                onClick={ handleLogout }
              />
            </Space>
          </div>
        </Space>
      </Col>
    </UserDetailsContainer>
  );
};

export default UserDetails;
