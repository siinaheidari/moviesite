import { Col, Divider, Row, Space } from 'antd';
import { useAuth } from 'contexts/auth/AuthContext';
import styled from 'styled-components';

import { ReactComponent as BellIcon } from 'assets/icons/bell.svg';
import { ReactComponent as CogIcon } from 'assets/icons/cog.svg';
import { ReactComponent as PowerOffIcon } from 'assets/icons/powerOff.svg';

const TopPanelContainer = styled(Row)`
  background: #28353D;
  padding: 0 3vw;
  height: 52px;

  .--startSection {
    color: #FFFFFF;

    .__divider {
      border-color: #FFFFFF;
      margin: 0;
    }
  }

  .--endSection {
    text-align: end;

    svg {
      height: 28px;
      cursor: pointer;
      -webkit-transition: ease all .5s;
      -moz-transition: ease all .5s;
      -o-transition: ease all .5s;
      transition: ease all .5s;
      -webkit-transform: scale(1);
      -moz-transform: scale(1);
      -o-transform: scale(1);
      transform: scale(1);

      :hover {
        -webkit-transform: scale(1.1);
        -moz-transform: scale(1.1);
        -ms-transform: scale(1.1);
        -o-transform: scale(1.1);
        transform: scale(1.1);
      }
    }
  }
`;

const TopPanel = () => {
  const {auth, handleLogout } = useAuth();
  console.log(auth);


  return (
    <TopPanelContainer align={ 'middle' } justify={ 'space-between' }>
      <Col span={ 10 } className='--startSection'>
        <Space size={ 30 }>
          <div>
            ادمین عزیز : {auth?.firstNameFa} {auth?.lastNameFa}
          </div>
          
          <div>
            <Space size={ 8 } split={ <Divider className='__divider' type={ 'vertical' }/> }>
              <div>
                1401/09/22
              </div>
              
              <div>
                09:15
              </div>
            </Space>
          </div>
        </Space>
      </Col>
      
      <Col span={ 8 } className='--endSection'>
        <Space size={ 30 }>
          <BellIcon/>
          <CogIcon/>
          <PowerOffIcon onClick={ handleLogout }/>
        </Space>
      </Col>
    </TopPanelContainer>
  );
};

export default TopPanel;
