import { Col, Row } from 'antd';
import { ReactComponent as RefahLogo } from 'assets/icons/refahLogo.svg';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const LogoContainer = styled(Row)`
  .--logo {
    text-align: center;

    svg {
      height: 110px;
    }
  }

  .--title {
    color: #204499;
    font-size: .875rem;
    text-align: center;
  }
`;

const HeaderLogo = () => {
  return (
    <LogoContainer gutter={ [0, 7] }>
      <Col span={ 24 } className='--logo'>
        <Link to={ '/' }>
          <RefahLogo/>
        </Link>
      </Col>
      
      <Col span={ 24 } className='--title'>
        باشگاه پذیرندگان
      </Col>
    </LogoContainer>
  );
};

export default HeaderLogo;
