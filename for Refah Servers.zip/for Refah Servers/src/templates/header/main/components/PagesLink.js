import { Col, Row } from 'antd';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { useAuth } from 'contexts/auth/AuthContext';

const PagesLinkContainer = styled(Row)`
  a {
    color: #787878;
    font-weight: 400;
    font-size: .875rem;

    :hover {
      color: #3c3c3c;
    }
  }
`;

const PagesLink = () => {
  const {auth} = useAuth();
  
  const profileLink = auth?.roll === 'merchant' ? 'merchantProfile' : auth?.roll === 'PSP' ? 'pspProfile' : auth?.roll;
  
  return (
    <PagesLinkContainer gutter={ 30 }>
      <Col>
        <PageLink
          // link={ '/'+ profileLink }
          label={ 'اخبار' }
        />
      </Col>
      
      <Col>
        <PageLink
          link={ '' }
          label={ 'شرکت در نظرسنجی' }
        />
      </Col>
      
      <Col>
        <PageLink
          link={ '' }
          label={ 'راهنما' }
        />
      </Col>
      
      <Col>
        <PageLink
          link={ '' }
          label={ 'برندگان قرعه کشی' }
        />
      </Col>
      
      <Col>
        <PageLink
          link={ '/FAQ' }
          label={ 'سوالات متداول' }
        />
      </Col>
    </PagesLinkContainer>
  );
};

const PageLink = ({ label, link }) => {
  return <Link to={ link }>{ label }</Link>;
};

export default PagesLink;
