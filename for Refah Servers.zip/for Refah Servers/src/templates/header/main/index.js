import { Button, Col, Drawer, Row, Space } from 'antd';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import HeaderLogo from 'templates/header/main/components/Logo';
import PagesLink from 'templates/header/main/components/PagesLink';
import { useState } from 'react';
import menu from "../../../assets/icons/menu.svg"
import RefahLogo  from 'assets/icons/smallLogo.png';
import Coin  from 'assets/icons/coin.svg';
import { useAuth } from '../../../contexts/auth/AuthContext';
import profileImage from "../../../assets/images/profileImg.svg"
import { CloseOutlined } from '@ant-design/icons';
import refahLogo from "assets/icons/mobile/refahSmallLogo.svg"

const HeaderContainer = styled(Row)`
  background: #FFFFFF;
  box-shadow: 0 4px 4px rgba(0, 0, 0, 0.05);
  position: relative;

  .--topRibbon {
    width: 100%;
    height: 16px;
    background: #1447A0;
    border-end-start-radius: 10px;
    border-end-end-radius: 10px;
  }

  .--headerContent {
    padding: 5px 7vw 19px;

    .--topSection {
      .__quote {
        > div {
          color: #000000;
          font-size: .875rem;
          position: relative;
          display: inline-block;
   

          .__quoteBottom,
          .__quoteTop {
            display: block;
            font-size: .45rem;
            position: absolute;
            top: -4px;
            z-index: 99;
          }

          .__quoteBottom {
            right: -5px;
            color: #1647A0;
          }

          .__quoteTop {
            left: -5px;
            color: #CF1675;
          }
        }
      }

      .__link {
        a {
          background: linear-gradient(90deg, #F61982 0%, #1447A0 100%);
          box-shadow: 0 4px 10px rgba(255, 0, 0, 0.05);
          color: #FFFFFF !important;
          border-radius: 5px;
          height: 38px;
          width: 100%;
          line-height: 38px;
          font-size: .875rem;
          text-align: center;
          position: relative;
          z-index: 2;
          overflow: hidden;

          :before {
            position: absolute;
            content: "";
            inset: 0; /* same as { top: 0; right: 0; bottom: 0; left: 0; } */
            background: linear-gradient(90deg, #1447A0 100%, #F61982 0%);
            z-index: -1;
            opacity: 0;
            transition: opacity 0.25s linear;
            width: 150%;
          }

          :hover {
            :before {
              opacity: 1;
            }
          }

          &.--transparent {
            :not(:hover) {
              background: #FFFFFF;
              border: 1px solid #B6B6B6;
              box-shadow: 0 4px 10px rgba(182, 182, 182, 0.05);
              color: #555555 !important;
            }
          }
        }
      }
    }

    .--middleSection {
      padding-inline-end: 4px;

      > div {
        border-top: 1px dashed #CACACA;
      }
    }

    .--bottomSection {
      .__socialIcons {
        text-align: end;

        i {
          cursor: pointer;
          font-size: 1.15rem;
          color: #787878;
          -webkit-transition: ease all .5s;
          -moz-transition: ease all .5s;
          -o-transition: ease all .5s;
          transition: ease all .5s;
          -webkit-transform: scale(1);
          -moz-transform: scale(1);
          -o-transform: scale(1);
          transform: scale(1);

          :hover {
            -webkit-transform: scale(1.2);
            -moz-transform: scale(1.2);
            -ms-transform: scale(1.2);
            -o-transform: scale(1.2);
            transform: scale(1.2);
          }
        }
      }

      .__supportNumber {
        color: #787878;
        font-size: .875rem;
      }
    }
  }
`;

const Header = () => {
  const {isLoggedIn, handleLogout, auth } = useAuth();

  const [ drawerOpen, setDrawerOpen ] = useState(false);
  
  return (
    <div>
      <div className={"flex px-[19px] py-[5px] items-center justify-between bg-white lg:hidden"}>
          <img src={menu} onClick={()=>setDrawerOpen(true)}/>
        {isLoggedIn?
          <div className={"flex gap-2 justify-between text-[12px] items-center px-[21px] py-[10px] bg-[#EEE] rounded-[20px]"}>
            <img src={Coin}/>
              امتیازات:
         <span className={"text-title text-[14px]"}>
           1200
         </span>
          
          </div>
          :''}

        <Link to={ "/merchantProfile"}>
          <img src={ RefahLogo }/>
        </Link>
      </div>

    <HeaderContainer className={"max-lg:hidden"}>
      <div className='--topRibbon'/>
      <Col span={ 24 } className='--headerContent'>
        <Row gutter={ 16 }>
          <Col span={ 4 }>
            <HeaderLogo/>
          </Col>
          
          <Col span={ 20 }>
            <Row align={ 'middle' } className='h-100'>
              <Col span={ 24 } className='--topSection'>
                <Row gutter={ 16 } justify={ 'space-between' } align={ 'middle' }>
                  <Col span={ 8 } className='__quote'>
                    <div>
                      <i className='icon-quoteTop __quoteTop'/>
                      <i className='icon-quoteBottom __quoteBottom'/>
                      بانک رفاه، در مسیر نوآوری
                    </div>
                  </Col>
                  
                  <Col lg={ 10 } xl={ 12 } xxl={ 10 }>
                    <Row gutter={ 16 }>
                      <Col span={ 12 } className='__link'>
                        <Link to={ '' } className='--transparent'>
                          خدمات غیر حضوری
                        </Link>
                      </Col>
                      
                      <Col span={ 12 } className='__link'>
                        <Link to={ '' }>
                          اینترنت بانک
                        </Link>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
              
              <Col lg={ 19 } xl={ 18 } xxl={ 19 } className='--middleSection'>
                <div/>
              </Col>
              
              <Col span={ 24 } className='--bottomSection'>
                <Row gutter={ 16 } align={ 'bottom' }>
                  <Col lg={ 19 } xl={ 18 } xxl={ 19 }>
                    <Row justify={ 'space-between' }>
                      <Col flex={ '1 1' }>
                        <PagesLink/>
                      </Col>
                      
                      <Col className='__socialIcons'>
                        <Space size={ 5 } align={ 'center' }>
                          <i className='icon-twitter'/>
                          <i className='icon-facebook'/>
                          <i className='icon-mail'/>
                        </Space>
                      </Col>
                    </Row>
                  </Col>
                  
                  <Col lg={ 5 } xl={ 6 } xxl={ 5 } className='__supportNumber'>
                    <Row gutter={ [16, 5] } justify={ 'space-between' } className={"max-xl:!space-y-3"}>
                      <Col lg={ 24 } xl={ 12 }  className='--text text-center'>
                        شماره پشتیبانی:
                      </Col>
                      
                      <Col lg={ 24 } xl={ 12 } className='--phone text-center text-xxl-end'>
                        021-8525
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
            </Row>
          </Col>
        </Row>
      </Col>
    </HeaderContainer>
      <div>
        <Drawer
          title={ null }
          placement="right"
          onClose={ () => setDrawerOpen(false) }
          bodyStyle={{
            padding:0,
          
          }}
          open={ drawerOpen }
          width={ '75%' }
          closable={ false }
          style={ {
            background:"#fff",
            boxShadow: '0px 0px 6px 6px rgba(0, 0, 0, .10)',
          } }
        >
          <div className={" text-[#787878] text-[12px] font-[400] [&>div:not(:first-child)]:px-[22px]"}>
            <div className={"h-[145px] text-end pt-[40px] px-[16px]"} style={{ backgroundImage:"linear-gradient(226deg, rgba(246, 25, 130, 0.22) 0%, rgba(33, 64, 154, 0.03) 100%)"}}>
              <CloseOutlined style={{ fontSize: '18px' }} className={"text-title"} onClick={()=>setDrawerOpen(false)}/>
              {
                isLoggedIn?"":
                    <div className={"flex justify-center items-center text-center"}>
                      <img src={refahLogo} className={"w-[90px] h-[90px] mb-[60px]"}/>
                    </div>
              }

            </div>
            <div className={isLoggedIn?"relative top-[-50px] space-y-[16px]":"space-y-[16px] mt-[15px]"}>
              {isLoggedIn?
                  <div className={" font-[500] text-title !text-center !items-center "}>
                    <img src={profileImage} className={"inline"}/>
                    <div className={"mb-[6px]"}>
                      { auth?.firstname }
                    </div>
                    <div>
                      0{auth?.mobile}
                    </div>
                  </div>
                  :
         ""
              }

              <div>
                اخبار
              </div>
              <div>
                شرکت در نظرسنجی
              </div>
              <div>
                راهنما
              </div>
              <div>
                برندگان قرعه کشی
              </div>
              <div className={"relative"}>
                سوالات متداول
                <Link to={"/FAQ"} className={"inset-0"}></Link>
              </div>
              <div className={"text-[#F00]"} onClick={handleLogout}>
                خروج
              </div>
            </div>
            </div>
           
        </Drawer>
      </div>

</div>
);
};

export default Header;
