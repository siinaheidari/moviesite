import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { DateObject } from 'react-multi-date-picker';
import baseURI from './axios/baseURI';
import messages from './inputRulesMessage';

export const formatNumber = (number) => Number(number).toLocaleString().split(/\s/).join(',');


export const formatString = (world, suffix = '', sign = '.') => {

  let returnWord = world;

  returnWord = returnWord.toString().trim().toLowerCase()
    .replaceAll('/', '')
    .replaceAll('&', '')
    .replaceAll('(', '')
    .replaceAll(')', '')
    .replaceAll('?', '')
    .replaceAll('!', '')
    .replaceAll('$', '')
    .replaceAll('.', '')
    .replaceAll('\'', '')
    .replaceAll(',', '')
    .replaceAll('’', '')
    .replaceAll('²', '')
    .replaceAll('%', '')
    .replaceAll('-', '')
    .replaceAll(' ', '_')
  ;

  returnWord = suffix ? `${ returnWord }${ sign }${ suffix }` : returnWord;

  return returnWord;

};

export const formatCadNumber = cardNumber => cardNumber?.toString()
    ?.replace(/\d{4}(?=.)/g, '$& - ');

export const formatIBan = iBan => iBan?.replaceAll('IR', '')?.replace(/^/, 'IR')?.replace(/[^\dA-Z]/g, '').replace(/(.{4})/g, '$1 ').trim();

export const formatPhoneNumber = phoneNumber => {
  //Filter only numbers from the input
  let cleaned = ( '' + phoneNumber ).replace(/\D/g, '');

  if (cleaned?.length < 11) {
    cleaned = cleaned?.replace(/^/, '0');
  }
  else if (cleaned?.length > 11) {
    if (cleaned[ 0 ] + cleaned[ 1 ] === '98') {
      cleaned = cleaned?.replace('98', '0');
    }
  }

  //Check if the input is of correct length
  let match = cleaned.match(/^(\d{4})(\d{3})(\d{4})$/);

  if (match) {
    return '(' + match[ 1 ] + ') ' + match[ 2 ] + '-' + match[ 3 ];
  }

  return null;
};

export const formatDate = date => {
  let cleaned = ( '' + date ).replace(/\D/g, '');

  let match = cleaned.match(/^(\d{4})(\d{2})(\d{2})$/);

  return match[ 1 ] + '/' + match[ 2 ] + '/' + match[ 3 ];
};

export const getToday = () => new Date().toISOString().split('T')[ 0 ];

export const changeLocalStorage = async (key, value) => await localStorage.setItem(key, value);

export const fn_deadline = (min) => Date.now() + min * 60000;

export const isJson = str => {
  if (!isNaN(str) || str.toString() == 'true' || str.toString() == 'false') {
    return false;
  }

  try {
    JSON.parse(str);
  }
  catch(e) {
    return false;
  }

  return true;
};

export const toEnDigit = (n) => {
  return n.replace(/[\u0660-\u0669\u06f0-\u06f9]/g,    // Detect all Persian/Arabic Digit in range of their Unicode with a global RegEx character set
    function(a) { return a.charCodeAt(0) & 0xf; }     // Remove the Unicode base(2) range that not match
  );
};

export const isNumber = val => !isNaN(parseFloat(val)) && !isNaN(val - 0);

export const isArray = variable => !!Array.isArray(variable);

const isObject = variable => typeof variable === 'object' && !isArray(variable) && variable !== null;

export const SeoGenerator = (props) => {

  const { title, description, keywords, ogImage, children } = props;

  return (
    <Helmet
      title={ title }
      meta={ [
        {
          name: `description`,
          content: description
        },
        {
          name: `keywords`,
          content: keywords
        },
        {
          itemprop: `name`,
          content: title
        },
        {
          itemprop: `description`,
          content: description
        },
        {
          itemprop: `image`,
          content: ogImage
        },
        {
          property: `og:url`,
          content: window.location.origin + window.location.pathname
        },
        {
          property: `og:type`,
          content: `website`
        },
        {
          property: `og:title`,
          content: title
        },
        {
          property: `og:description`,
          content: description
        },
        {
          property: `og:image`,
          content: ogImage
        }
      ] }
    >
      { children }
    </Helmet>
  );
};

SeoGenerator.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string,
  keywords: PropTypes.string,
  ogImage: PropTypes.string,
  children: PropTypes.node
};

SeoGenerator.defaultProps = {
  title: 'API Management',
  description: 'satPay API Management',
  keywords: 'satPay, API, API Management, API GetWay',
  ogImage: `${ baseURI._base }/logo.png`
};

export const importAll = r => r.keys().map(r);

// scroll to top window
export const scrollTop = () => window.scroll({ top: 0, behavior: 'smooth' });

export const isEven = num => num % 2 === 0;

export const isOdd = num => num % 2 !== 0;

// split array for example: $array=[1,2,3,4,5,6,7] splitArray($array, 2) = [[1,2],[3,4],[5,6],[7]] => 2-item arrays in an array :
export const splitArray = (arr, len) => {
  let chunks = [], i = 0, n = arr.length;
  while (i < n) {
    chunks.push(arr.slice(i, i += len));
  }
  return chunks;
};

splitArray.propTypes = {
  arr: PropTypes.array.isRequired,
  len: PropTypes.number.isRequired
};

export const isEmpty = variable => {
  if (isArray(variable)) {
    return !!!variable?.length;
  }

  else if (isObject(variable)) {
    return !!!Object.keys(variable)?.length;
  }

  return true;
};

export const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
};

export const isValidIp = value => /^(?:(?:^|\.)(?:2(?:5[0-5]|[0-4]\d)|1?\d?\d)){4}$/.test(value);

export const isValidEmail = value => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value);

export const useWindowSize = () => {
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight
  });

  useEffect(() => {
    // Handler to call on window resize
    const handleResize = () => {
      // Set window width/height to state
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };

    // Add event listener
    window.addEventListener('resize', handleResize);

    // Call handler right away so state gets updated with initial window size
    handleResize();

    // Remove event listener on cleanup
    return () => window.removeEventListener('resize', handleResize);
  }, []); // Empty array ensures that effect is only run on mount

  return windowSize;
};

export const inputRule = (text, args) => {
  const argsKeys = args ? Object.keys(args) : [];

  let messageText = messages[ text ];

  if (!!messageText?.length) {
    if (!!argsKeys?.length) {
      Object.entries(args)?.map(([key, val]) => {
        messageText = messageText.replace(`{{${ key }}}`, val || '');
      });
    }
    return messageText;
  }

  return text;
};

export const convertDatePicker = (date, format = 'YYYY/MM/DD') => {
  let object = { date, format };

  const dateConvert = new DateObject(object).format();

  return ( toEnDigit(dateConvert) );
};

export const convertColor = (color, percent) => {
  let R = parseInt(color.substring(1, 3), 16);
  let G = parseInt(color.substring(3, 5), 16);
  let B = parseInt(color.substring(5, 7), 16);

  R = parseInt(R * ( 100 + percent ) / 100);
  G = parseInt(G * ( 100 + percent ) / 100);
  B = parseInt(B * ( 100 + percent ) / 100);

  R = ( R < 255 ) ? R : 255;
  G = ( G < 255 ) ? G : 255;
  B = ( B < 255 ) ? B : 255;

  R = Math.round(R);
  G = Math.round(G);
  B = Math.round(B);

  const RR = ( ( R.toString(16).length === 1 ) ? '0' + R.toString(16) : R.toString(16) ),
    GG = ( ( G.toString(16).length === 1 ) ? '0' + G.toString(16) : G.toString(16) ),
    BB = ( ( B.toString(16).length === 1 ) ? '0' + B.toString(16) : B.toString(16) );

  return '#' + RR + GG + BB;
};


export function checkBanksCard(cardNumber) {
  const bankCards = {
    '603799': 'meli',
    '589210': 'sepah',
    '627961': 'sanatmadan',
    '603770': 'keshavarsi',
    '628023': 'maskan',
    '627760': 'postbank',
    '502908': 'tosehe',
    '627412': 'eghtesad',
    '622106': 'parsian',
    '502229': 'pasargad',
    '627488': 'karafarin',
    '621986': 'saman',
    '639346': 'sina',
    '639607': 'sarmaye',
    '502806': 'shahr',
    '502938': 'day',
    '603769': 'saderat',
    '610433': 'mellat',
    '627353': 'tejarat',
    '589463': 'refah',
    '627381': 'sepah',
    '639370': 'mehreqtesad',
    '639599': 'sepah',
    '504172': 'resalat',
  };

  let number = cardNumber.substring(0, 6);
  return bankCards[ number ] || false;
}


