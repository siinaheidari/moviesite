import { useAxiosClient } from './axios/useAxiosClient';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { requestMessages } from './axios/requestMessages';

// get Data from Api by React query and axios:
export const useRequest = (
    {
        path = '',
        params = {},
        body = {},
        options = {},
        key = [],
        method = 'get',
        isMutation = false, // use useMutation() for send data from post method
        showMessage = true, // show message in mutation request or not (true by default)
        successMessageType = 'success', // mutation request message type (success by default)
        customSuccessMessage = null, // mutation request custom message for success
        errorMessageType = 'error', // mutation request message type (success by default)
        customErrorMessage = null, // mutation request custom message for error
        mutationMethod = 'post',
        justResponse = true, // response data => response.data.response
        formType = 'JSON',
        apiType = 'merchant', // for set bseURI in axios instance
        customRequestHeader = {},
    },
) => {

    const { NODE_ENV } = process.env;

    const client = useAxiosClient(formType, apiType, customRequestHeader);

    const queryClient = useQueryClient();

    const [ mutationRequestIsLoading, setMutationRequestIsLoading ] = useState(false); // state for mutation request is loading

    // async function for get API:
    const callApi = async () => {
        const result = await client.request(
            {
                method: method,
                maxBodyLength: 'Infinity',
                url: path,
                params,
                data: { ...body },
            },
        );

        if (justResponse) { // TODO: FIX AFTER GIVE BASE_URL
            if (apiType === 'club'|| apiType === '"admin"') {
              return result?.data?.output;
            }
            return result?.data?.response;
        }
        return result?.data;

    };

    if (key?.length) {
        key.unshift('request');
    }
    else {
        key = [ 'removingRequest' ];
    }

    const callMutationApi = async (data, params) => {
        if (isMutation) {
            const result = await client.request(
                {
                    method: mutationMethod,
                    url: path,
                    params,
                    data,
                },
            );

            return result?.data;
        }
    };

    // Instead of returning here, just save the result in a variable
    const mutationResult = useMutation({
        mutationFn: (variables) => callMutationApi(variables, params),
        mutationKey: [ 'mutationRequest', path ],
        onMutate: () => setMutationRequestIsLoading(true), // start is loading
        retry: false,
        ...options,
        onSuccess: async (data, variables, context) => {
            await setMutationRequestIsLoading(false); // end is loading

            if (!!showMessage) {
                const findMessage = await requestMessages.find(item => item?.en === data?.message);

                await toast[ successMessageType ](customSuccessMessage || findMessage?.fa || data?.message, {
                    toastId: 'mutationRequest' + '/' + path,
                });
            }

            if (options?.onSuccess) await options?.onSuccess(data, variables, context); // if onSuccess in options
        },
        onError: async (error, variables, context) => {
            await setMutationRequestIsLoading(false); // end is loading

            if (!!showMessage) {
                let findMessage;
                let errorMessage;

                if (apiType === 'wallet') { // TODO FIX AFTER GIV BASE_URL
                    //errorMessage = error?.output;
                    //findMessage = await requestMessages.find(item => item?.en === errorMessage);
                }
                else {
                    errorMessage = error?.message;
                    findMessage = await requestMessages.find(item => item?.en === error?.message);
                }

                await toast[ errorMessageType ](customErrorMessage || findMessage?.fa || errorMessage, {
                    toastId: 'mutationRequest' + '/' + path,
                });
            }

            if (options?.onError) await options?.onError(error, variables, context); // if onError in options
        },
    });

    const query = useQuery(key, callApi, {
        refetchOnWindowFocus: false,
        enabled: (!isMutation && options?.enabled),
        retry: 2,
        ...options,
    });

    // remove mutationRequest query from cache
    useEffect(() => {
        if (isMutation && key.includes('removingRequest')) {
            queryClient.removeQueries([ 'removingRequest' ]);
        }
    }, [ isMutation, key ]);

    // If isMutation is defined, return that result
    if (isMutation) {
        return {
            ...mutationResult,
            isLoading: mutationRequestIsLoading,
        };
    }

    return {
        ...query,
        isLoading: query.isInitialLoading,
    };
};

useRequest.propTypes = {
    path: PropTypes.string,
    params: PropTypes.object,
    body: PropTypes.object,
    key: PropTypes.array,
    options: PropTypes.object,
    method: PropTypes.oneOf([ 'get', 'post' ]),
    isMutation: PropTypes.bool, // use useMutation() for send data from post method
    mutationMethod: PropTypes.oneOf([ 'post', 'put', 'delete', 'patch' ]),
    justResponse: PropTypes.bool, // response data => response.data.response
};
