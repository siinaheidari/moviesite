import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/auth/AuthContext';

const PrivateRoute = ({ component: RouteComponent, roles }) => {
  const { isLoggedIn } = useAuth();
  
  if (!isLoggedIn) {
    return <RouteComponent/>;
  }
  
  return <Navigate to='/'/>;
};

export default PrivateRoute;