import PropTypes from 'prop-types';
import { Children } from 'react';

const typeOfComponent = component =>
  component?.props?.__TYPE ||
  component?.type?.toString().replace('Symbol(react.fragment)', 'react.fragment') ||
  undefined;

const getChildrenByType = (children, types) =>
  Children.toArray(children).filter(child => types.indexOf(typeOfComponent(child)) !== -1);

export const If = ({ condition, children }) => {
  
  const thenComponent = getChildrenByType(children, ['Then']);
  
  const elseComponent = getChildrenByType(children, ['Else']);
  
  if (!!condition) return thenComponent;
  
  else if (elseComponent) return elseComponent;
  
  return <></>;
  
};

export const Then = ({ children }) => children;

export const Else = ({ children }) => children;

If.propTypes = {
  children: PropTypes.node.isRequired,
  condition: PropTypes.bool.isRequired
};

Then.propTypes = {
  children: PropTypes.node,
  __TYPE: PropTypes.string
};

Then.defaultProps = {
  __TYPE: 'Then'
};

Else.propTypes = {
  children: PropTypes.node,
  __TYPE: PropTypes.string
};

Else.defaultProps = {
  __TYPE: 'Else'
};