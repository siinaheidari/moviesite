import { useAuth } from 'contexts/auth/AuthContext';
import { Navigate, Outlet } from 'react-router-dom';

const CheckLoggedIn = () => {
  const { isLoggedIn } = useAuth();
  
  if (!isLoggedIn) {
    return <Outlet/>;
  }
  
  return <Navigate to='/'/>;
};

export default CheckLoggedIn;
