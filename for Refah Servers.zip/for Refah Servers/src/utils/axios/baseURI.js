const { REACT_APP_API_URL, NODE_ENV } = process.env;

const baseURI = {
  _base: {
    admin: NODE_ENV === 'development' ? 'http://192.168.80.63:3000/api/v1' : 'https://clubapi.satpay.ir',
    merchant: NODE_ENV === 'development' ? 'http://192.168.80.61:3010/api/v1' : 'https://wapi.satpay.ir',
    auth: NODE_ENV === 'development' ? 'http://192.168.80.61:3010/api/v1' : 'https://wapi.satpay.ir',
    club: NODE_ENV === 'development' ? 'http://192.168.80.63:3000/api/v1' : 'https://wapi.satpay.ir',
  },
  _serviceURI: {
    admin: NODE_ENV === 'development' ? 'http://192.168.80.63:3000/api/v1' : 'https://clubapi.satpay.ir',
    merchant: NODE_ENV === 'development' ? 'http://192.168.80.61:3010/api/v1' : 'https://wapi.satpay.ir',
    auth: NODE_ENV === 'development' ? 'http://192.168.80.61:3010/api/v1' : 'https://wapi.satpay.ir',
    club: NODE_ENV === 'development' ? 'http://192.168.80.63:3000/api/v1' : 'https://wapi.satpay.ir',
  }
}

export default baseURI;