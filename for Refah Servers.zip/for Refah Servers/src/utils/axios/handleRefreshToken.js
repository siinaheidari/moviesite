import axios from 'axios';
import baseURI from './baseURI';
import {useAuth} from "../../contexts/auth/AuthContext";

const handleRefreshToken = async (apiType = 'merchant') => {
  let baseURL;

  if (apiType === 'merchant') {
    baseURL = baseURI._serviceURI?.auth;
  }
  else {
    baseURL = baseURI._serviceURI?.admin;
  }

  const refreshToken = localStorage.getItem('refreshToken')
  try {
    const result = await axios.post(`${ baseURL }/api/auth/refresh/token`, {
      refreshToken
    });

    localStorage.setItem('accessToken', result?.data?.output?.singleToken);

    return result?.data?.output?.singleToken;
  }
  catch(error) {
    return false;
  }
};
export default handleRefreshToken;
