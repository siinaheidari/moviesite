import axios from 'axios';
import { useAuth } from 'contexts/auth/AuthContext';
import { toast } from 'react-toastify';
import { errorMessages } from 'utils/axios/errorMessages';
import baseURI from './baseURI';
import handleRefreshToken from "./handleRefreshToken";

export const useAxiosClient = (type, apiType = 'merchant', customRequestHeader = {}) => {
  
  const { handleLogout } = useAuth();

  let baseURL;

  if (apiType === 'merchant') {
    baseURL = baseURI._serviceURI?.merchant;
  }
  else if (apiType === 'auth') {
    baseURL = baseURI._serviceURI?.auth;
  }
  else if (apiType === 'club') {
    baseURL = baseURI._serviceURI?.club;
  }
  else {
    baseURL = baseURI._serviceURI?.admin;
  }

  let token = localStorage.getItem('accessToken'); // set token

  // set default header
  const headers = {
    'Content-Type': type === 0 ? 'multipart/form-data' : 'application/json', // content-type default as application/json OR multipart/form-data
    Accept: 'application/json',
    Authorization: 'Bearer '+ token, // set Authorization token
      ...customRequestHeader
  };

  // create axios instance
  const client = axios.create({
    baseURL: baseURL, // default base url
    headers // set headers
  });

  client.interceptors.response.use(
    async (response) => Promise.resolve(response),
    async (error) => {
      // handle custom error
      // TODO: fix error handler after.
      console.log('error in AXIOS ===>', error?.response?.data);

      if (error.response.status === 401) {
        //handleLogout();
        const newAccessToken = await handleRefreshToken(apiType);

        if (newAccessToken) {
          const originalRequest = error.config;
          originalRequest.headers.Authorization = 'Bearer '+ newAccessToken;
          return axios(originalRequest);
        } else {
          handleLogout();
        }
      }


      return Promise.reject(error?.response?.data);
    }
  );

  return client;
};
