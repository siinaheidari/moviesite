export const themes = {
  main: {
    isMain: true,
    inputsBorderColor: '#C6D4FF',
    iconColor: '#1447A0',
    radioGroupBgColor: '#21409A',
    tableHeaderBgColor: '#EEEEEE'
  },
  admin: {
    isAdmin: true,
    inputsBorderColor: '#F0F0F0',
    iconColor: '#F0F0F0',
    radioGroupBgColor: '#7258DB',
    tableHeaderBgColor: '#F0F0F0'
  }
};