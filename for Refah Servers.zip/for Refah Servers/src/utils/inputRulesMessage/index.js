const messages = {
  'required input': 'لطفا {{inputName}} را وارد نمایید',
  'required selectBox': 'لطفا {{inputName}} را انتخاب نمایید',
  'required upload': 'لطفا {{inputName}} را آپلود نمایید',
  'URL invalid': 'لطفا {{inputName}} معتبر وارد نمایید',
  'validate email': 'لطفا یک پست الکترونیک معتبر وارد نمایید',
  'must be number input': 'لطفا {{inputName}} را به صورت عدد وارد نمایید',
  'minLength input': '{{inputName}} نمی تواند کمتر از {{length}} کاراکتر باشد',
  'maxLength input': '{{inputName}} نمی تواند بیشتر از {{length}} کاراکتر باشد',
  'invalidate repeated password': 'رمز های عبور باهم مطابقت ندارند',
  'minLength amount': '{{inputName}} باید حداقل {{length}} باشد',
  'maxLength amount': '{{inputName}} باید حداکثر {{length}} باشد',
  'maxAmount amount': '{{inputName}}  وارد شده باید از موجودی کیف پول شما کمتر باشد ',

};

export default messages;