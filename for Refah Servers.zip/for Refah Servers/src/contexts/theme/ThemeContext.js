import { createContext, useContext, useReducer } from 'react';
import { ThemeProvider as StyledComponentsThemeProvider } from 'styled-components';
import { themes } from 'utils/themes';

// initial state:
const initialState = {
  theme: 'main'
};

// action constant
const CHANGE_THEME = 'CHANGE_THEME';

// action creator function
const changeTheme = data => {
  return {
    type: CHANGE_THEME,
    payload: data
  };
};

// reducer function:
const reducer = (state, { type, payload }) => {
  if (type === CHANGE_THEME) return { theme: payload };
  return state;
};

// Context Create:
const themeContext = createContext({});

export const ThemeProvider = ({ children }) => {
  const [theme, themeDispatch] = useReducer(
    reducer,
    initialState
  );
  
  return (
    <themeContext.Provider value={ { theme, themeDispatch } }>
      <StyledComponentsThemeProvider theme={ { dir: 'rtl', ...themes[ theme?.theme ] } }>
        { children }
      </StyledComponentsThemeProvider>
    </themeContext.Provider>
  );
};

export const useTheme = () => {
  const theme = useContext(themeContext)?.theme?.theme; // data
  const themeDispatch = useContext(themeContext)?.themeDispatch; // dispatch
  const handleChangeTheme = async data => themeDispatch(changeTheme(data)); // handle login or change data user
  
  return { theme, themeDispatch, handleChangeTheme };
};
