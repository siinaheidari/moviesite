import { createContext, useContext, useReducer } from 'react';

const localStorageAuth = localStorage.getItem('auth');

// TODO: remove after connect to AUTH API...
const fakeUserDataForTest = {
  firstName: 'نجمه',
  lastName: 'علوی',
  email: 'najmeh@email.com',
  mobile: '09115236959',
  userName: 'najmeh',
  roll: 'merchant',
}

// initial state:

const initialState = {
  auth: localStorageAuth ? JSON.parse(localStorageAuth) : {},
}
// const initialState = fakeUserDataForTest;

// action constant
const SET_AUTH_DATA = 'SET_AUTH_DATA';
const LOGOUT = 'LOGOUT';

// action creator function
const handleLogin = data => {
  return {
    type: SET_AUTH_DATA,
    payload: data
  };
};

const handleLogoutUser = () => {
  return {
    type: LOGOUT
  };
};

// reducer function:
const reducer = (state, { type, payload }) => {
  const mappedAction = actionMap.get(type);
  
  return mappedAction ? mappedAction(state, payload) : state;
};

const login = (state, payload) => {
  // first save data into local storage
  localStorage.setItem('auth', JSON.stringify(payload));
  
  // save data in state
  return {...state, auth: payload};
};

const logOut = state => {
  // first remove localStorage data (auth and selected app and other)
  localStorage.clear();
  
  // then remove state auth
  return ( { auth: {} } );
};

// action map
const actionMap = new Map([
  [SET_AUTH_DATA, login],
  [LOGOUT, logOut]
]);

// spinner Context Create:
const authDataContext = createContext({});

// create spinner provider:
export const AuthProvider = ({ children }) => {
  
  const [auth, authDispatch] = useReducer(
    reducer,
    initialState
  );
  
  return (
    <authDataContext.Provider value={ { auth, authDispatch } }>
      { children }
    </authDataContext.Provider>
  );
  
};

// get current provider report state and dispatch
export const useAuth = () => {
  const auth = useContext(authDataContext)?.auth?.auth; // data
  const isLoggedIn = Object.keys(auth).length !== 0; // check user logged in or not
  // const isLoggedIn = true; // check user logged in or not
  const authDispatch = useContext(authDataContext)?.authDispatch; // dispatch
  
  const handleChangeUserData = async data => authDispatch(handleLogin(data)); // handle login or change data user
  
  const handleLogout = () => authDispatch(handleLogoutUser()); // handle user log out
  
  return { auth, isLoggedIn, authDispatch, handleLogout, handleChangeUserData };
};
