import { createContext, useContext, useState } from 'react';

// Context Create:
const bottomMenuContext = createContext('');

export const BottomMenuProvider = ({ children }) => {
  const [isVisible, setIsVisible] = useState(true);
  
  return (
    <bottomMenuContext.Provider value={ { isVisible, setIsVisible } }>
      { children }
    </bottomMenuContext.Provider>
  );
};

export const useBottomMenu = () => {
  const bottomMenuIsVisible = useContext(bottomMenuContext)?.isVisible; // get isVisible
  const setBottomMenuIsVisible = useContext(bottomMenuContext)?.setIsVisible; // dispatch
  
  const handleChangeBottomMenuVisible = visible => setBottomMenuIsVisible(visible); // handle change bottom menu visible
  
  return { bottomMenuIsVisible, handleChangeBottomMenuVisible };
};