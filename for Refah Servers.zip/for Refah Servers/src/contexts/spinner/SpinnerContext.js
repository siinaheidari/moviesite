import { Spin } from 'antd';
import { createContext, Suspense, useContext, useReducer } from 'react';

// initial state:
const initialState = {
  isLoading: false
};

// action constant
const CHANGE_IS_LOADING = 'CHANGE_IS_LOADING';

// action creator function
const changeSpinnerIsLoading = type => {
  return {
    type: CHANGE_IS_LOADING,
    payload: type
  };
};

// reducer function:
const reducer = (state, { type, payload }) => {
  if (type === CHANGE_IS_LOADING) return { ...state, isLoading: payload };
  return state;
};

// spinner Context Create:
const spinnerContext = createContext({});

// create spinner provider:
export const SpinnerProvider = ({ children }) => {
  
  const [spinner, spinnerDispatch] = useReducer(
    reducer,
    initialState
  );
  
  return (
    <spinnerContext.Provider value={ { spinner, spinnerDispatch } }>
      <Spin spinning={ spinner.isLoading } size='large' wrapperClassName='spinner--container'>
        <Suspense fallback=''>
          { children }
        </Suspense>
      </Spin>
    </spinnerContext.Provider>
  );
  
};

// get current spinner state and dispatch
export const useSpinnerContext = () => {
  const spinner = useContext(spinnerContext).spinner; // data
  const spinnerDispatch = useContext(spinnerContext).spinnerDispatch; // dispatch
  
  const toggleSpinner = async (toggle) => spinnerDispatch(changeSpinnerIsLoading(toggle));
  return { spinner, spinnerDispatch, toggleSpinner };
};
