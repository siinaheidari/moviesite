import {Col, Empty, Form, Row, Select, Space} from 'antd';
import {ReactComponent as DollarCoin} from 'assets/icons/dollarCoin.svg';
import styled from 'styled-components';
import circle from 'assets/icons/mobile/circle.svg';
import rightArrow from 'assets/icons/mobile/rightArrow.svg';
import {Link} from 'react-router-dom';
import tw from 'twin.macro';
import {Modal, SelectBox, TransitionsPage} from '../../../../../templates/Ui';
import {useRequest} from '../../../../../utils/useRequest';
import {useAuth} from '../../../../../contexts/auth/AuthContext';
import React, {useState} from 'react';
import {DateObject} from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import {convertColor} from '../../../../../utils/helper';


const PursueRequestContainer = styled(Row)`
  padding: 10px 37px;
  ${tw`max-lg:!px-0`}
`;

const RequestBoxContainer = styled(Row)`
  height: 100%;
  border: 1px solid #D4DFFF;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  background-color: #FFF;


  .--topSection {
    align-self: flex-start;
    padding: 19px 12px 0;

    .__requestName {
      text-align: start;
      color: #21409A;
      font-size: .875rem;
      font-weight: 400;
    }

    .__score {
      text-align: end;

      .ant-space {
        .ant-space-item {
          font-size: .625rem;
          font-weight: 400;
          color: #787878;

          svg {
            width: 12.5px;
          }
        }
      }
    }

    .__date {
      .ant-space {
        .ant-space-item {
          color: #4D4D4D;
          font-size: .75rem;
          font-weight: 400;
        }
      }
    }

    .__detailBtn {
      span {
        color: #407BFF;
        font-size: .8rem;
        font-weight: 500;
        cursor: pointer;

        :hover {
          color: ${convertColor('#407BFF', -40)}
        }
      }
    }
  }

  .--bottomSection {
    align-self: flex-end;
    border-top: 1px solid #D4DFFF;
    padding: 17px 20px;

    .__timeLine {
      width: 150%;

      .--timeLineItem {
        position: relative;
        border-block-start: 1px dashed #1CC500;

        .__dot {
          width: 10px;
          height: 10px;
          position: absolute;
          inset-block-start: -5px;
          inset-inline-start: 0;
          z-index: 1;
          background-color: #1CC500;
          border: 1px solid #1CC500;
          border-radius: 50%;
        }

        .__text {
          color: #21409A;
          font-size: .625rem;
          font-weight: 400;
          margin-block-start: 10px;
          text-align: start;
        }

        &.--done {
          border-block-start-style: solid;
        }

        &.--error,
        &.--progress {
          border-block-start-style: dashed;
        }

        &.--error {
          border-block-start-color: #FE2301;

          .__dot {
            background-color: #FE2301;
            border-color: #FE2301;
          }

          .__text {
            color: #FE2301;
          }
        }

        &.--progress {
          .__dot {
            background-color: #FFFFFF;
          }
        }

        &.--progressError {
          border-block-start-color: #FE2301;

          .__dot {
            background-color: #FFFFFF;
            border-color: #FE2301;
          }

          .__text {
            color: #FE2301;
          }
        }

        &:nth-child(2) {
          .__text {
            margin-inline-start: -2%;

          }
        }

        &:first-child,
        &:nth-child(3) {
          .__text {
            margin-inline-start: -10%;
          }
        }

        &:last-child {
          border-block-start: none;

          .__text {
            //margin-inline-start: -10%;
          }
        }
      }
    }
  }

`;

const ModalContainer = styled(Modal)`
`;


const PursueRequest = () => {
    const [filterFormRef] = Form.useForm();
    const [requestTypeId, setRequestTypeId] = useState(51);
    const [detailModal, setDetailModal] = useState({});

    const handleOpenDetailModal = (detailModal) => {
        setDetailModal(detailModal);
    };

    const {auth} = useAuth();


    const {
        isLoading: requestsListIsLoading,
        data: requestsList,
    } = useRequest({
        path: '/setting/list-request-type',
        key: ['myRequests'],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },

    });

    const requestsListRes = requestsList || [];


    const {
        isLoading: myRequestsIsLoading,
        data: myRequests,
    } = useRequest({
        path: '/merchant/request-list',
        key: ['myRequests', requestTypeId],
        apiType: 'club',
        params: {
            requestTypeId: requestTypeId || null,
            personId: auth?.userId,
        },
        options: {
            cacheTime: 0,
        },

    });

    const myRequestsRes = myRequests || [];

    const date = detailModal?.modifyDate?.split('T')[1]?.split(':') || [];


    return (
        <TransitionsPage coordinates={'x'}>
            <div className={'max-lg:!mt-[-13px]'}>
                <Col span={24} className={'mb-[13px] lg:hidden'}>
                    <Link to={-1} className={''}> <img src={rightArrow}/></Link>
                </Col>
                <Col span={24} className={'mb-[17px] lg:hidden'}>
                    <Space align={'center'} className={'text-[12px] font-[500] '}>
                        <img src={circle}/>
                        پیگیری درخواست ها
                    </Space>
                </Col>
                <Form
                    form={filterFormRef}
                    name="indexFrom"
                    autoComplete="off"
                    scrollToFirstError
                    labelCol={{
                        span: 24,
                    }}
                    wrapperCol={{
                        span: 24,
                    }}
                >
                    <Col span={24} className={'items-end flex justify-end lg:px-[37px] max-lg:mb-[-20px]'}>
                        <SelectBox
                            name="price"
                            initialValue={51}
                            allowClear
                            loading={requestsListIsLoading}
                            showSearch={false}
                            className={'max-lg:min-w-[140px] lg:min-w-[250px]'}
                            onChange={val => setRequestTypeId(val)}
                        >

                            {/*<Select.Option value={ 0 }>همه</Select.Option>*/}
                            {
                                requestsListRes?.map(item =>
                                    <Select.Option value={item?.rowId}>{item?.requestTypeDesc}</Select.Option>,
                                )
                            }
                        </SelectBox>
                    </Col>
                </Form>
                <PursueRequestContainer gutter={[16, 25]} align={'stretch'}>

                    {!!Object.keys(myRequestsRes)?.length ? myRequestsRes?.map(item => (
                            <Col xs={24} md={12} lg={8} key={item?.trakingNumber}>
                                <RequestBox
                                    data={item}
                                    detailModal={detailModal}
                                    setDetailModal={setDetailModal}
                                    handleOpenDetailModal={handleOpenDetailModal}
                                />
                            </Col>
                        )) :
                        <Col span={24} className={"text-center item-center"}>
                            <Empty description={'درخواستی یافت نشد'}/>
                        </Col>
                    }
                </PursueRequestContainer>
            </div>

            <Modal
                open={detailModal?.rowId}
                onCancel={() => setDetailModal({})}
                size={{
                    sm: 55,
                    xs: 55,
                    md: 80,
                    lg: 60,
                    xl: 60,
                    xxl: 60,
                }}
                bodyStyle={{
                    padding: 0,

                }}
                style={{
                    top: '25vh',
                }}
            >
                <Col span={24} className={'pb-5 pt-[50px] px-8 space-y-[10px]'}>
                    <div className={"flex justify-between items-center gap-2"}>
                        <Space>
                            <div className={"text-textblue"}>
                                وضعیت درخواست:
                            </div>
                            <div>
                                {
                                    detailModal?.status === 2 ? <div className={"text-[#00b892]"}>تایید شده</div> :
                                        <div className={""}>در انتظار پاسخ ادمین</div>
                                }
                            </div>
                        </Space>
                        <Space size={5}>
                            <div>
                                تاریخ ثبت:
                            </div>
                            {
                                new DateObject({
                                    date: new Date(detailModal?.modifyDate),
                                    calendar: gregorian,
                                }).convert(persian).format(`${date[0]}:${date[1]} - YYYY/MM/DD`)
                            }
                        </Space>
                    </div>
                    <Space size={5}>
                        <div className={"text-textblue"}>
                            توضیحات:
                        </div>
                        {detailModal?.description}
                    </Space>

                    <div className={'text-textblue'}>
                        پاسخ ادمین:
                    </div>
                    <div className={'bg-gray-100 py-3 rounded-[10px] px-[10px]'}>
                        {detailModal?.answered ? <div>{detailModal?.answered}</div> :
                            <div className={"text-[#FE2301]"}>پاسخی داده نشده است</div>}
                    </div>
                </Col>
            </Modal>

        </TransitionsPage>
    );
};

const RequestBox = ({
                        data,
                        detailModal,
                        setDetailModal,
                        handleOpenDetailModal,
                    }) => {

    const date = data?.modifyDate?.split('T')[1]?.split(':');
    return (
        <div>
            {<RequestBoxContainer gutter={[0, 20]}>
                <Col span={24} className="--topSection">
                    <Row gutter={[0, 20]}>
                        <Col span={24}>
                            <Row gutter={16} align={'middle'} justify={'space-between'}>
                                <Col flex="1 1" className="__requestName">
                                    {data?.requestTypeDesc}
                                </Col>

                                <Col flex="100px" className="__score">
                                    <Space size={2}>
                                        امتیاز دریافتی:
                                        <DollarCoin/>
                                        3
                                    </Space>
                                </Col>
                            </Row>
                        </Col>

                        <Col span={24} className="__date flex justify-between items-center">
                            <Space size={9}>
                                <div>
                                    تاریخ ثبت:
                                </div>

                                <div>
                                    {
                                        new DateObject({
                                            date: new Date(data?.modifyDate),
                                            calendar: gregorian,
                                        }).convert(persian).format(`${date[0]}:${date[1]} - YYYY/MM/DD`)
                                    }

                                </div>

                            </Space>

                            <Col className="__detailBtn">
                <span onClick={() => handleOpenDetailModal(data)}
                      className={'text-blue-500 underline cursor-pointer'}>جزئیات</span>
                            </Col>
                        </Col>


                    </Row>
                </Col>


                <div className="flex justify-center gap-1 w-full mb-8 mt-3">
                    <div className={'text-center items-center '}>
                        <div className={'flex justify-center'}>
                            <div className={'border-[5px] border-lime-500 rounded-full w-[15px] h-[15px] '}>
                                <div className={"relative top-[15px] left-[18px] text-[10px] !w-[70px] "}> ثبت درخواست
                                </div>
                            </div>
                            <div className={'text-lime-500 truncate ml-3 '}>
                                --------------------
                            </div>
                        </div>

                    </div>


                    <div className={'flex'}>
                        <div
                            className={data?.status === 1 ? ' border-[5px] border-red-500 rounded-full w-[15px] h-[15px] animate-[ping_1.5s_ease-in-out_infinite]' : 'border-[5px] border-lime-500 rounded-full w-[15px] h-[15px]'}>

                        </div>
                        <div className={"relative top-[20px] text-center left-[16px] text-[10px]"}>PSP</div>
                        <div className={data?.status === 1 ? 'text-red-500 truncate' : 'text-lime-500 truncate'}>
                            --------------------
                        </div>
                    </div>


                    <div className={'text-center items-center'}>
                        <div className={'flex'}>
                            <div
                                className={data?.status === 1 ? 'border-[5px] border-red-500 rounded-full w-[15px] h-[15px]' : 'border-[5px] border-lime-500 rounded-full w-[15px] h-[15px]'}>
                                <div
                                    className={"relative top-[15px] text-center left-[40px] text-[10px] !w-[70px]"}> تایید
                                    نهایی
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </RequestBoxContainer>
            }

        </div>
    );
};

export default PursueRequest;
