import React, {useRef, useState} from 'react';
import {Col, Form, Row, Select, Space, Upload} from 'antd';
import {Button, Input, Modal, SelectBox, Table, TextArea} from 'templates/Ui';
import { inputRule } from 'utils/helper';
import { Link } from 'react-router-dom';
import SvgIcon from 'templates/components/SvgIcon';
import search from "assets/icons/mobile/search.svg"
import upload from "../../../../../../../assets/icons/mobile/upload.svg";
import {LeftOutlined} from "@ant-design/icons";
const DisposeTerminalDesktop = () => {

    const tableRef = useRef();
    const [ TerminalDesktopFormRef ] = Form.useForm();
    const [ terminalDesktopModal, setTerminalDesktopModal ] = useState(false);

    const handleTerminalModal = (type) => {
        setTerminalDesktopModal(type);
    };

    const handleTerminalDesktop = (value) => {
        console.log(value);
    };

    const tableColumns = [
        {
            title: 'شرکت',
            dataIndex: 'inventory',
            key: 'inventory',
            align: 'center'
        },
        {
            title: 'شعبه',
            dataIndex: 'branch',
            key: 'branch',
            align: 'center'
        },
        {
            title: 'کد شعبه',
            dataIndex: 'branchCode',
            key: 'branchCode',
            align: 'center'
        },
        {
            title: 'کد پذیرنده',
            dataIndex: 'memberNumber',
            key: 'memberNumber',
            align: 'center'
        },
        {
            title: 'کد پایانه',
            dataIndex: 'terminal',
            key: 'terminal',
            align: 'center'
        },
        {
            title: 'نام فروشگاه',
            dataIndex: 'branchCode',
            key: 'branchCode',
            align: 'center'
        },
        {
            title: 'استان',
            dataIndex: 'state',
            key: 'state',
            align: 'center'
        },
        {
            title: 'شهر',
            dataIndex: 'city',
            key: 'city',
            align: 'center'
        },
        {
            title: 'نام',
            dataIndex: 'firstName',
            key: 'firstName',
            align: 'center'
        },
        {
            title: 'نام خانوادگی  ',
            dataIndex: 'lastName',
            key: 'lastName',
            align: 'center'
        },
        {
            title: '...',
            dataIndex: 'action',
            key: 'action',
            align: 'center',
            render: (_, {id}) => <div onClick={()=>handleTerminalModal(id)} className={"underline !text-[#407BFF]"}>حذف</div>

        }
    ];



    const Mock = [
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },
        {
            id: 1,
            inventory:"-",
            terminal: 215465,
            terminalType: 'پایانه های بی سیم',
            memberNumber: '0258569',
            firstName: 'نجمه',
            lastName: 'علوی',
            date: '1401-08-02',
            time: '16:21',
            branch: 'ونک',
            branchCode: '035',
            city:"تهران",
            state:"تهران"
        },

    ];


    return (
        <Row>
            <Col span={24} className={'px-[32px] mb-[20px]'}>
                <Row justify={"end"} gutter={14}>
                    <Col span={6}>
                        <Input
                            name={ 'terminal' }
                            placeholder={"جستجو نام درگاه..."}
                            rules={ [
                                {
                                    required: true,
                                    message: inputRule('required input', { inputName: 'کد ملی' })
                                }
                            ]}
                            maxLength={ 10 }
                            justNumber
                            // formRef={ formRef }
                            rtl
                            focus
                            suffix={<img src={search}/> }
                        />
                    </Col>
                    <Col span={3} className='text-end pb-6'>
                        <button className={"bg-backbtn text-white h-[41px] rounded-lg w-full shadow-shadow"}>
                            جستجو
                        </button>
                    </Col>
                </Row>
            </Col>
            <Col span={ 24 } ref={ tableRef }>
                <Table
                    columns={ tableColumns }
                    // loading={isLoading}
                    dataSource={ Mock }
                    // onChange={({current}) => setPage(current)}
                    bordered
                    tableLayout={ 'fixed' }
                    pagination={ {
                        hideOnSinglePage: true,
                        defaultPageSize: 20,
                        total: 200,
                        showSizeChanger: false,
                        responsive: true,
                        position: ['bottomLeft'],
                        nextIcon: <SvgIcon icon={ 'leftCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                                           style={ { margin: '6px auto' } }/>,
                        prevIcon: <SvgIcon icon={ 'rightCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                                           style={ { margin: '6px auto' } }/>,
                        onChange: () => tableRef?.current.scrollIntoView({ behavior: 'smooth' })
                    } }
                />
            </Col>
            <Modal
                open={ terminalDesktopModal }
                onCancel={ () => handleTerminalModal('') }
                header={ false }
                closable={ false }
                bodyStyle={ {
                    padding: 0,
                    backgroundColor: 'white',
                } }
                size={ {
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 60,
                    xl: 60,
                    xxl: 60,
                } }
                style={ {
                    top: '20vh',
                } }

            >
                <div className={ 'px-[17px] pt-[31px] pb-[21px]' }>
                    <Form
                        form={ TerminalDesktopFormRef }
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={ {
                            span: 24,
                        } }
                        wrapperCol={ {
                            span: 24,
                        } }
                        onFinish={ handleTerminalDesktop }
                    >
                        <Col span={24} className={"text-center items-center"}>
                                <Row gutter={24} align={"stretch"}>
                                    <Col span={12}>
                                    <Col span={24}>
                                        <SelectBox
                                            name="Pos"
                                            label={ 'علت جمع آوری' }
                                            initialValue={ 'دستگاه 1' }
                                            showSearch={ false }
                                            rules={ [
                                                {
                                                    required: true,
                                                    message: 'علت جمع آوری را انتخاب نمایید',
                                                },
                                            ] }
                                            allowClear={ false }
                                        >
                                            <Select.Option value={ 1 }>دستگاه 1</Select.Option>
                                            <Select.Option value={ 2 }>دستگاه 2</Select.Option>
                                            <Select.Option value={ 3 }>دستگاه 3</Select.Option>
                                        </SelectBox>
                                    </Col>
                                    <Col span={24}>
                                        <Row>
                                            <Col flex='1 1'>
                                                <Input
                                                    name={'uploadFile'}
                                                    label={'بارگذاری فایل'}
                                                    formRef={TerminalDesktopFormRef}
                                                    className={'!rounded-s-none'}
                                                    placeholder
                                                    rules={[
                                                        {
                                                            required: true,
                                                            message:  'لطفا فایل مورد نظر خود را بارگذاری نمایید.'
                                                        }
                                                    ]}
                                                    ltr
                                                />
                                            </Col>

                                            <Col flex='20%'>
                                                <Button
                                                    type={'secondary'}
                                                    className='!mt-[36px] !rounded-s-none'
                                                    height={42}
                                                    width={'100%'}
                                                >
                                                    <Upload className={''}>
                                                        <img src={upload}/>
                                                    </Upload>

                                                </Button>
                                            </Col>
                                        </Row>
                                    </Col>
                                    </Col>
                                    <Col span={ 12 }>
                                        <TextArea
                                            name={ 'description' }
                                            label={ 'توضیحات' }
                                            rows={ 5 }
                                        />
                                    </Col>
                                </Row>

                        <Col span={ 24 }
                             className=" mt-[65px] pb-[25px]">
                            <Space size={ 14 }>
                                <Button
                                    onClick={ () => setTerminalDesktopModal(false) }
                                    type={ 'default' }
                                    className={ 'max-lg:!min-w-[110px]' }
                                >
                                    انصراف
                                </Button>

                                <Button
                                    type={ 'secondary' }
                                    htmlType={ 'submit' }
                                    iconAlign={ 'end' }
                                    className={ 'max-lg:!min-w-[120px] max-lg:!text-[12px]' }
                                >
                                    <LeftOutlined/>
                                    ارسال درخواست
                                </Button>
                            </Space>
                        </Col>
                        </Col>
                    </Form>
                </div>
            </Modal>
        </Row>
    );
};

export default DisposeTerminalDesktop;
