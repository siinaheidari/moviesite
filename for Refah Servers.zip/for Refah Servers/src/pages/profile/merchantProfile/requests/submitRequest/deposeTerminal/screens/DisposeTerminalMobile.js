import React, { useState } from 'react';
import { Col, Form, Row, Select, Space, Upload } from 'antd';
import { Button, Input, Modal, SelectBox, TextArea, TransitionsPage } from '../../../../../../../templates/Ui';
import { Link } from 'react-router-dom';
import rightArrow from 'assets/icons/mobile/rightArrow.svg';
import circle from 'assets/icons/mobile/circle.svg';
import Arrow from 'assets/icons/mobile/blueArrow.svg';
import upload from 'assets/icons/mobile/upload.svg';
import { LeftOutlined } from '@ant-design/icons';

const DisposeTerminalMobile = () => {

    const [ TerminalMobileFormRef ] = Form.useForm();
    const [ currentTab, setCurrentTab ] = useState('');
    const [ terminalMobileModal, setTerminalMobileModal ] = useState(false);


    const handleTerminalMobile = (value) => {
        console.log(value);
    };

    const handleToggleTab = (type) => {
        setCurrentTab(current => current === type ? '' : type);
    };

    const handleTerminalModal = (type) => {
        setTerminalMobileModal(type);
    };

    return (

        <TransitionsPage coordinates={ 'x' }>
            <Col span={ 24 } className={ 'mb-[13px] lg:hidden' }>
                <Link to={ -1 } className={ '' }> <img src={ rightArrow }/></Link>
            </Col>
            <div className={ ' mb-[17px] lg:hidden justify-between items-center' }>
                <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                    <img src={ circle }/>
                    درخواست جمع آوری پایانه
                </Space>
            </div>

            <Row gutter={ [ 0, 20 ] }>

                <Col span={ 24 }>
                    <div className={ 'py-5 bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('1') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شرکت:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    -
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 ونک
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 123456
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد پذیرنده:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                      123456
                                </span>
                                </Col>
                            </Row>
                        </div>
                        <Row gutter={ [ 5, 13 ] }
                             className={ currentTab === '1' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                کد پایانه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    123456
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام فروشگاه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    رستوران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  سینا
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   حیدری
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  تهران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-[#407BFF] underline' }
                                 onClick={ () => setTerminalMobileModal('1') }>
                                حذف
                            </Col>
                        </Row>

                        <div onClick={ () => handleToggleTab('1') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>
                <Col span={ 24 }>
                    <div className={ 'py-5 bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('2') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شرکت:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    -
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 ونک
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 123456
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد پذیرنده:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                      123456
                                </span>
                                </Col>
                            </Row>
                        </div>
                        <Row gutter={ [ 5, 13 ] }
                             className={ currentTab === '2' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                کد پایانه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    123456
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام فروشگاه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    رستوران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  سینا
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   حیدری
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  تهران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-[#407BFF] underline' }
                                 onClick={ () => setTerminalMobileModal('2') }>
                                حذف
                            </Col>
                        </Row>

                        <div onClick={ () => handleToggleTab('2') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>
                <Col span={ 24 }>
                    <div className={ 'py-5 bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('3') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شرکت:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    -
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 ونک
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 123456
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد پذیرنده:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                      123456
                                </span>
                                </Col>
                            </Row>
                        </div>
                        <Row gutter={ [ 5, 13 ] }
                             className={ currentTab === '3' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                کد پایانه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    123456
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام فروشگاه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    رستوران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  سینا
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   حیدری
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  تهران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-[#407BFF] underline' }
                                 onClick={ () => setTerminalMobileModal('3') }>
                                حذف
                            </Col>
                        </Row>

                        <div onClick={ () => handleToggleTab('3') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>
                <Col span={ 24 }>
                    <div className={ 'py-5 bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('4') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شرکت:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    -
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 ونک
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد شعبه:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 123456
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    کد پذیرنده:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                      123456
                                </span>
                                </Col>
                            </Row>
                        </div>
                        <Row gutter={ [ 5, 13 ] }
                             className={ currentTab === '4' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                کد پایانه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    123456
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام فروشگاه:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    رستوران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  سینا
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   حیدری
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                نام خانوادگی:
                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  تهران
                                </span>
                            </Col>
                            <Col span={ 12 } className={ 'text-[12px] font-[500] text-[#407BFF] underline' }
                                 onClick={ () => setTerminalMobileModal('4') }>
                                حذف
                            </Col>
                        </Row>

                        <div onClick={ () => handleToggleTab('4') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>

            </Row>

            <Modal
                open={ terminalMobileModal }
                onCancel={ () => handleTerminalModal('') }
                header={ false }
                closable={ false }
                bodyStyle={ {
                    padding: 0,
                    backgroundColor: 'white',
                } }
                size={ {
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 40,
                    xl: 40,
                    xxl: 30,
                } }
                style={ {
                    top: '20vh',
                } }

            >
                <div className={ 'px-[17px] pt-[31px] pb-[21px]' }>
                    <Form
                        form={ TerminalMobileFormRef }
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={ {
                            span: 24,
                        } }
                        wrapperCol={ {
                            span: 24,
                        } }
                        onFinish={ handleTerminalMobile }
                    >
                        <Col xs={ 24 } lg={ 5 }>
                            <SelectBox
                                name="Pos"
                                label={ 'علت جمع آوری' }
                                initialValue={ 'دستگاه 1' }
                                showSearch={ false }
                                rules={ [
                                    {
                                        required: true,
                                        message: 'علت جمع آوری را انتخاب نمایید',
                                    },
                                ] }
                                allowClear={ false }
                            >
                                <Select.Option value={ 1 }>دستگاه 1</Select.Option>
                                <Select.Option value={ 2 }>دستگاه 2</Select.Option>
                                <Select.Option value={ 3 }>دستگاه 3</Select.Option>
                            </SelectBox>
                        </Col>
                        <Col span={ 24 }>
                            <Row>
                                <Col flex="1 1">
                                    <Input
                                        name={ 'uploadFile' }
                                        label={ 'بارگذاری فایل' }
                                        formRef={ TerminalMobileFormRef }
                                        className={ '!rounded-s-none' }
                                        placeholder
                                        rules={ [
                                            {
                                                required: true,
                                                message: 'لطفا فایل مورد نظر خود را بارگذاری نمایید.',
                                            },
                                        ] }
                                        ltr
                                    />
                                </Col>

                                <Col flex="20%">
                                    <Button
                                        type={ 'secondary' }
                                        className="!mt-[36px] !rounded-s-none"
                                        height={ 42 }
                                        width={ '100%' }
                                        block
                                    >
                                        <Upload className={ '' }>
                                            <img src={ upload }/>
                                        </Upload>

                                    </Button>
                                </Col>
                            </Row>
                        </Col>
                        <Col span={ 24 }>
                            <TextArea
                                name={ 'description' }
                                label={ 'توضیحات' }
                                rows={ 5 }
                            />
                        </Col>
                        <Col span={ 24 }
                             className="max-lg:!text-center max-lg:!items-center lg:items-end lg:text-end lg:mt-[65px] max-lg:mt-[55px] pb-[25px]">
                            <Row gutter={ 16 } justify={ 'center' }>
                                <Col span={ 12 } sm={ 8 }>
                                    <Button
                                        onClick={ () => setTerminalMobileModal(false) }
                                        type={ 'default' }
                                        className={ 'w-full' }
                                    >
                                        انصراف
                                    </Button>
                                </Col>

                                <Col span={ 12 } sm={ 8 }>
                                    <Button
                                        type={ 'secondary' }
                                        htmlType={ 'submit' }
                                        iconAlign={ 'end' }
                                        className={ 'w-full' }
                                    >
                                        <LeftOutlined/>
                                        ارسال درخواست
                                    </Button>
                                </Col>

                            </Row>
                        </Col>
                    </Form>
                </div>
            </Modal>
        </TransitionsPage>

    );
};

export default DisposeTerminalMobile;
