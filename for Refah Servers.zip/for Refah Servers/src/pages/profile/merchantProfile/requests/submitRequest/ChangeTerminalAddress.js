import React from 'react';
import { Col, Form, Row, Select, Space, Spin } from 'antd';
import { Button, Input, SelectBox, TextArea } from '../../../../../templates/Ui';
import { inputRule } from '../../../../../utils/helper';
import { LeftOutlined, LoadingOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';
import rightArrow from '../../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../../assets/icons/mobile/circle.svg';
import { useRequest } from '../../../../../utils/useRequest';
import { useAuth } from '../../../../../contexts/auth/AuthContext';
import { BeatLoader } from 'react-spinners';
import refahLogo from '../../../../../assets/icons/refahLogo.svg';

const ChangeTerminalAddress = () => {
    const { auth } = useAuth();
    const [ ChangeAddressFormRef ] = Form.useForm();
    const shopWatch = Form.useWatch('shopList', ChangeAddressFormRef);

    const {
        isLoading: paperRollLoading,
        mutateAsync: paperRollRequest,
    } = useRequest({
        path: '/merchant/add-request',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: 'درخواست شما با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleChangeAddress = async () => {
        const values = ChangeAddressFormRef.getFieldsValue([ 'terminal', 'description' ]);
        try {
            await paperRollRequest({
                requestTypeId: '52',
                merchentCode: auth?.userId,
                terminalNumber: values?.terminal,
                description: values.description.trim(),
            });
            await ChangeAddressFormRef.resetFields();

        } catch (err) {
            console.log(err);
        }
    };


    const {
        isLoading: merchantListShopIsLoading,
        data: merchantListShopData,
    } = useRequest({
        path: '/merchant/merchant-list-shop',
        params: {
            rowPage: 100,
            pageNumber: 1,
            personId: auth?.userId,
        },
        key: [ 'merchant-list-shop' ],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const merchantListShopRes = merchantListShopData;


    const {
        isLoading: merchantListTerminalIsLoading,
        data: merchantListTerminalData,
    } = useRequest({
        path: '/merchant/terminal-list',
        params: {
            rowPage: 100,
            pageNumber: 1,
            shopId: shopWatch,
        },
        key: ['terminal-list', shopWatch],
        apiType: 'club',
        options: {
            enabled: !!shopWatch,
            cacheTime: 0,
        },
    });

    const merchantListTerminalRes = merchantListTerminalData;


    return (
        <Row>
            <Spin spinning={ paperRollLoading } className={ 'relative' }
                  indicator={ <LoadingOutlined className={ '!hidden' }/> }
                  tip={ <div>
                      <BeatLoader
                          color={ '#1447a0' }
                          loading={ true }
                          size={ 9 }
                          aria-label="Loading Spinner"
                          data-testid="loader"
                      />
                      <img src={ refahLogo } width={ '90px' } height={ '80px' }
                           className={ 'mx-auto relative top-[-100px]' }/>
                  </div> }>

                <Col span={ 24 } className={ 'mb-[13px] lg:hidden' }>
                    <Link to={ -1 } className={ '' }> <img src={ rightArrow }/></Link>
                </Col>
                <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
                    <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                        <img src={ circle }/>
                        درخواست تغییر IP پایانه
                    </Space>

                </div>
                <Col span={ 24 } className={ ' items-center max-lg:pt-5 lg:px-[30px] max-lg:px-[18px] bg-white rounded-[10px]' }>
                    <Form
                        form={ ChangeAddressFormRef }
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={ {
                            span: 24,
                        } }
                        wrapperCol={ {
                            span: 24,
                        } }
                        onFinish={ handleChangeAddress }
                    >
                        <Row gutter={ 16 } className={ '' }>

                            <Col xs={ 24 } lg={ 12 }>
                                <SelectBox
                                    name="shopList"
                                    label={ 'انتخاب فروشگاه ' }
                                    placeholder={ 'انتخاب کنید' }
                                    showSearch={ false }
                                    loading={ merchantListShopIsLoading }
                                    rules={ [
                                        {
                                            required: true,
                                            message: 'فروشگاه را انتخاب نمایید',
                                        },
                                    ] }
                                    allowClear={ false }
                                    onChange={ val => {
                                        const findShop = merchantListShopRes?.find(item => item?.rowId === val);


                                        ChangeAddressFormRef?.setFields([
                                            {
                                                name: 'postalCode',
                                                value: findShop?.postalCode,
                                            },
                                            {
                                                name: 'address',
                                                value: findShop?.Address,
                                            },
                                        ]);
                                    } }
                                >
                                    {
                                        !!merchantListShopRes ?
                                            merchantListShopRes.map((item) =>
                                                <Select.Option
                                                    value={ item?.rowId }>{ item?.farsiName }</Select.Option>,
                                            ) : '-'
                                    }

                                </SelectBox>
                            </Col>

                            <Col xs={24} lg={12}>
                                <SelectBox
                                    name="terminal"
                                    label={'انتخاب ترمینال'}
                                    placeholder={'انتخاب کنید'}
                                    showSearch={false}
                                    disabled={!shopWatch}
                                    rules={[
                                        {
                                            required: true,
                                            message: 'ترمینال را انتخاب نمایید',
                                        },
                                    ]}
                                    allowClear={false}
                                    loading={merchantListTerminalIsLoading}
                                >
                                    {
                                        !!merchantListTerminalRes ?
                                            merchantListTerminalRes.map((item) =>
                                                <Select.Option
                                                    value={item?.terminalNumber}>{item?.terminalNumber}</Select.Option>,
                                            ) : '-'
                                    }
                                </SelectBox>
                            </Col>
                            {/*<Col xs={ 24 } lg={ 24 }>*/ }
                            {/*    <SelectBox*/ }
                            {/*        name="Pos"*/ }
                            {/*        label={ 'علت تغییر آدرس پایانه' }*/ }
                            {/*        placeholder={ 'انتخاب کنید' }*/ }
                            {/*        showSearch={ false }*/ }
                            {/*        rules={ [*/ }
                            {/*            {*/ }
                            {/*                required: true,*/ }
                            {/*                message: 'دستگاه POS را انتخاب نمایید',*/ }
                            {/*            },*/ }
                            {/*        ] }*/ }
                            {/*        allowClear={ false }*/ }
                            {/*    >*/ }
                            {/*        <Select.Option value={ 1 }>1</Select.Option>*/ }
                            {/*        <Select.Option value={ 2 }>2</Select.Option>*/ }
                            {/*        <Select.Option value={ 3 }>3</Select.Option>*/ }
                            {/*    </SelectBox>*/ }
                            {/*</Col>*/ }


                            <Col xs={ 24 } lg={ 12 }>
                                <Input
                                    name={ 'postalCode' }
                                    label={ 'کد پستی' }
                                    rules={ [
                                        {
                                            required: true,
                                            message: inputRule('required input', { inputName: 'کد پستی' }),
                                        },
                                    ] }

                                    justNumber
                                    formRef={ ChangeAddressFormRef }
                                    disabled
                                    ltr
                                    placeholderAlign={ 'end' }
                                />
                            </Col>

                            <Col xs={ 24 } lg={ 12 }>
                                <Input
                                    name={ 'address' }
                                    label={ 'آدرس' }
                                    rules={ [
                                        {
                                            required: true,
                                            message: inputRule('required input', { inputName: 'آدرس' }),
                                        },
                                    ] }
                                    disabled
                                />
                            </Col>

                            <Col xs={ 24 } lg={ 12 }>
                                <Input
                                    name={ 'oldAddress' }
                                    label={ 'آدرس فعلی' }
                                    // rules={ [
                                    //     {
                                    //         required: true,
                                    //         message: inputRule('required input', { inputName: 'آدرس فعلی' }),
                                    //     },
                                    // ] }
                                    formRef={ ChangeAddressFormRef }
                                    ltr
                                    placeholderAlign={ 'end' }
                                />
                            </Col>
                            <Col xs={ 24 } lg={ 12 }>
                                <Input
                                    name={ 'newAddress' }
                                    label={ 'آدرس جدید' }
                                    // rules={ [
                                    //     {
                                    //         required: true,
                                    //         message: inputRule('required input', { inputName: 'آدرس جدید' }),
                                    //     },
                                    // ] }
                                    formRef={ ChangeAddressFormRef }
                                    ltr
                                    placeholderAlign={ 'end' }
                                />
                            </Col>

                            <Col span={ 24 }>
                                <TextArea
                                    name={ 'description' }
                                    label={ 'توضیحات' }
                                    rows={ 5 }
                                    rules={ [
                                        {
                                            required: true,
                                            message: inputRule('required input', { inputName: 'آدرس' }),
                                        },
                                    ] }
                                />
                            </Col>


                            <Col span={ 24 }
                                 className=" lg:mt-[65px] max-lg:mt-[35px] max-lg:mb-[25px] pb-[25px]">
                                <Row gutter={ 16 } justify={ 'center' }>
                                    <Col sm={ 8 } xs={ 12 }>
                                        <Button
                                            type={ 'default' }
                                            className={ 'w-full' }
                                        >
                                            <Link to={ '/merchantProfile' }>
                                                انصراف
                                            </Link>

                                        </Button>
                                    </Col>

                                    <Col sm={ 8 } xs={ 12 }>
                                        <Button
                                            type={ 'secondary' }
                                            htmlType={ 'submit' }
                                            iconAlign={ 'end' }
                                            className={ 'w-full' }
                                        >
                                            <LeftOutlined/>
                                            ارسال درخواست
                                        </Button>
                                    </Col>
                                </Row>


                            </Col>
                        </Row>
                    </Form>
                </Col>
            </Spin>
        </Row>
    );
};

export default ChangeTerminalAddress;
