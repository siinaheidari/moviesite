import {Col, Form, Row, Space} from 'antd';
import styled from 'styled-components';

import { DropdownV2, RadioButton, RadioFormItem, RadioGroup, Table } from 'templates/Ui';
import ListCircle from '../../../../../templates/components/ListCircle';
import More from "assets/icons/more.svg"
import { useState } from 'react';

const MyBankAccountsContainer = styled(Row)`
  background-color: #FFFFFF;
  box-shadow: 0 4px 10px rgba(122, 122, 122, 0.1);
  border-radius: 10px;
  //padding: 15px 13px 90px;

  .--titleSection {


    .ant-space-item {
      svg {
        vertical-align: middle;
      }

      div {
        color: #FFFFFF;
        font-size: 1rem;
        font-weight: 500;
      }
    }
  }

  .--accountsSection {


    .__clientNumber {
      .ant-space-item {
        div {
          color: #4D4D4D;
          font-size: .875rem;
          font-weight: 400;
        }
      }
    }

    .__table {
      .ant-table-container {
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }

      .ant-table-thead {
        .ant-table-cell {
          :not(:last-child) {
            border-inline-end: 2px solid #FFFFFF !important;
          }

          :first-child {
            border-start-start-radius: 30px;
          }
        }
      }
    }
  }

  .ant-table-row {
    &.--active {
      .ant-table-cell:first-child {
        border-right: 7px solid #1cc500 !important;
      }
    }

    &.--deActive {
      .ant-table-cell:first-child {
        border-right: 7px solid #fe2301 !important;
      }
    }
  }

`;

const BankAccountsDesktop = () => {
    const [requestPaperRollModalVisible, setRequestPaperRollModalVisible] = useState(false);

    const [requestChangeTerminalModalVisible, setRequestChangeTerminalModalVisible] = useState(false);

    const [requestCloseTerminalModalVisible, setRequestCloseTerminalModalVisible] = useState(false);

    const actionMenu = {
        IPG: [
            {
                label: <div>درخواست تغییر IP درگاه پرداخت</div>,
                key: 'change-terminal-ip'
            },
            {
                label: <div>درخواست پشتیبانی</div>,
                key: 'support'
            }
        ],
        POS: [
            {
                label: <div onClick={ () => setRequestPaperRollModalVisible(true) }>درخواست رول کاغذی</div>,
                key: 'paper-roll'
            },
            {
                label: <div onClick={ () => setRequestChangeTerminalModalVisible(true) }>درخواست تعویض پایانه</div>,
                key: 'change-terminal'
            },
            {
                label: <div onClick={ () => setRequestCloseTerminalModalVisible(true) }>درخواست جمع آوری پایانه</div>,
                key: 'close-terminal'
            },
            {
                label: <div>تغییر آدرس پایانه</div>,
                key: 'change-terminal-address'
            },
            {
                label: <div>درخواست پشتیبانی</div>,
                key: 'support'
            }
        ]
    };

    const tableColumns = [
        {
            title: 'نوع حساب',
            dataIndex: 'id',
            key: 'id',
            align: 'center'
        },
        {
            title: 'شماره حساب',
            dataIndex: 'cardNumber',
            key: 'cardNumber',
            align: 'center'
        },
        {
            title: 'شماره شبا',
            dataIndex: 'accountNumber',
            key: 'accountNumber',
            align: 'center'
        },
        {
            title: 'موجودی حساب( ریال)',
            dataIndex: 'iban',
            key: 'iban',
            align: 'center'
        },
        {
            title: 'ترمینال متصل',
            dataIndex: 'connectedTerminal',
            key: 'connectedTerminal',
            align: 'center'
        },
        {
            title: 'تاریخ راه اندازی',
            dataIndex: 'date',
            key: 'date',
            align: 'center'
        },
        {
            title: 'تاریخ جمع آوری ',
            dataIndex: 'date',
            key: 'date',
            align: 'center'
        },
        {
            title: 'عملیات',
            dataIndex: 'action',
            key: 'action',
            align: 'center',
            render: (_, { terminalType }) => {
                terminalType = terminalType === 'POS' ? 'POS' : 'IPG';
                return (
                    <div className='__action'>
                        <DropdownV2
                            menu={ actionMenu[ terminalType ] }
                            title={ 'بیشتر' }
                        />
                    </div>
                );
            }
        }
    ];

    const transactions = [
        {
            id: 1,
            cardNumber: 6037569854123651,
            accountNumber: '0152548754',
            iban: '548525900000000525875',
            date: '1401-08-02',
            connectedTerminal:"156454",
            more: <Space align={"center"} className={"text-textLink"}>
                بیشتر
                <img src={More}/>
            </Space>,
            status: 'active'
        },
        {
            id: 2,
            cardNumber: 6037569854123651,
            accountNumber: '0152548754',
            iban: '548525900000000525875',
            date: '1401-08-02',
            connectedTerminal:"156454",
            more: <Space align={"center"} className={"text-textLink"}>
                بیشتر
                <img src={More}/>
            </Space>,
            status: 'deActive'
        },
        {
            id: 3,
            cardNumber: 6037569854123651,
            accountNumber: '0152548754',
            iban: '548525900000000525875',
            date: '1401-08-02',
            connectedTerminal:"156454",
            more: <Space align={"center"} className={"text-textLink"}>
                بیشتر
                <img src={More}/>
            </Space>,
            status: 'active'
        },
        {
            id: 4,
            cardNumber: 6037569854123651,
            accountNumber: '0152548754',
            iban: '548525900000000525875',
            date: '1401-08-02',
            connectedTerminal:"156454",
            more: <Space align={"center"} className={"text-textLink"}>
                بیشتر
                <img src={More}/>
            </Space>,
            status: 'deActive'
        },
        {
            id: 5,
            cardNumber: 6037569854123651,
            accountNumber: '0152548754',
            iban: '548525900000000525875',
            date: '1401-08-02',
            connectedTerminal:"156454",
            more: <Space align={"center"} className={"text-textLink"}>
                بیشتر
                <img src={More}/>
            </Space>,
            status: 'active'
        },

    ];

    return (

        <Form>

            <MyBankAccountsContainer gutter={ [0, 15] }>
                <Col span={ 24 }>
                    <Space align={"center"} className={"text-[14px] px-[18px] font-[500] text-textblue mt-[15px]"}>
                        <ListCircle width={10} height={10} space={0} linear/>
                        نمایش اطلاعات بانکی
                    </Space>
                </Col>

                <Col span={ 24 } className='--accountsSection'>
                    <Row gutter={ [0, 20] } className={"justify-between px-[20px]"} align={"middle"}>
                        <Col span={ 10 } className='__clientNumber'>
                            <Space size={ 15 }>
                                <div className={"!text-textblue !font-[500] text-[12px]"}>شماره مشتری:</div>
                                <div className={"!text-textblue !font-[500] text-[12px]"}>100254878</div>
                            </Space>
                        </Col>
                        <Col span={10}>
                            <RadioFormItem
                                name={ 'input1' }
                            >
                                <RadioGroup defaultValue={ 'test' } block>
                                    <RadioButton value={ 'test' }>
                                        همه
                                    </RadioButton>

                                    <RadioButton value={ 'test1' }>
                                        فعال
                                    </RadioButton>

                                    <RadioButton value={ 'test2' }>
                                        غیر فعال
                                    </RadioButton>
                                </RadioGroup>
                            </RadioFormItem>
                        </Col>
                    </Row>
                    <Col span={ 24 } className='__table'>
                        <Table
                            columns={ tableColumns }
                            dataSource={ transactions }
                            bordered
                            tableLayout={ 'fixed' }
                            pagination={ false }
                            rowClassName={pageData => {
                                if (pageData?.status === 'active') {
                                    return '--active'
                                }

                                return '--deActive'
                            }}
                        />
                    </Col>

                </Col>
            </MyBankAccountsContainer>
        </Form>
    );
};

export default BankAccountsDesktop;

