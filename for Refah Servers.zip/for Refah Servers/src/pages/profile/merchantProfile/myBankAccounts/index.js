import React from 'react';
import { MatchBreakpoint } from 'react-hook-breakpoints';

import BankAccountsDesktop from './screens/BankAccountsDesktop';
import BankAccountsMobile from './screens/BankAccountsMobile';

const MyBanksAccount = () => {
    return (
        <div>
          <MatchBreakpoint max="md">
            <BankAccountsMobile />
          </MatchBreakpoint>

          <MatchBreakpoint min="lg">
            <BankAccountsDesktop />
          </MatchBreakpoint>
        </div>
    );
};

export default MyBanksAccount;
