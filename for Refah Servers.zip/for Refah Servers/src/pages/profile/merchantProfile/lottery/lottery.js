import {Col, Popover, Row, Space, Statistic} from 'antd';
import styled from 'styled-components';
import {formatNumber} from 'utils/helper';
import React, {useEffect, useState} from 'react';
import {Link} from "react-router-dom";
import rightArrow from "../../../../assets/icons/mobile/rightArrow.svg";
import circle from "../../../../assets/icons/mobile/circle.svg";
import lotteryBanner1 from "assets/images/lotteryBanner1.svg"
import lotteryBanner2 from "assets/images/lotteryBanner2.svg"
import { TransitionsPage} from 'templates/Ui';
const {Countdown} = Statistic;

const LotteryChanceContainer = styled(Row)`

  .--timeLeft,
  .--remainingTransaction {
   

    .__description {
      color: #4D4D4D;
      font-size: .75rem;
      font-weight: 400;
    }
  }

  .--countDown {
    direction: ltr;
  }

  .--timeLeft {
    direction: ltr;

    .__box {
      > div {
        background: linear-gradient(44.14deg, #F61982 2.69%, #21409A 93.25%);
        border-radius: 10px;
        text-align: center;
        padding: 1.6vw 5px;

        .--title,
        .--number {
          color: #FFFFFF;
          font-weight: 400;
          font-size: .625rem;
        }

        .--number {
          font-weight: 500;
          font-size: 14px;
          margin-top: 12px;
        }
      }
    }

    .__box,
    .__description {
      direction: rtl;
        font-size: 12px;
        font-weight: 500;
    }
  }

  .--remainingTransaction {
    > .ant-row {
      //background: #F9F9F9;
      border-radius: 10px;
      padding: 20px 0px;

      .--progress {
        background: #D9D9D9;
        border-radius: 4px;
        overflow: hidden;
        position: relative;
        height: 9px;
        direction: ltr;

        .__tail {
          background: linear-gradient(269.82deg, #21409A 0%, #F61982 100%);
          border-radius: 4px;
          height: 100%;
          cursor: pointer;
        }
      }

      .--amounts {
        margin-top: 10px;
        direction: ltr;

        .__amount {
          direction: rtl;
            display: flex;
            align-items: center;
            gap: 3px;

          > div {
            font-size: .625rem;

            :first-child {
              color: #232429;
              font-weight: 500;
            }

            :last-child {
              color: #7A7A7A;
              font-weight: 400;
              margin-top: 3px;
            }
          }
        }
      }
    }
  }
`;

const Lottery = () => {

    const THREE_DAYS_IN_MS = 3 * 24 * 60 * 60 * 1000;
    const NOW_IN_MS = new Date().getTime();

    const dateTimeAfterThreeDays = NOW_IN_MS + THREE_DAYS_IN_MS;

    const [targetDate, setTargetDate] = useState(new Date(dateTimeAfterThreeDays));

    const [days, hours, minutes, seconds] = useCountdown(targetDate);

    return (
      <TransitionsPage coordinates={ 'x' }>
        
        <LotteryChanceContainer gutter={[0, 10]}>
            <Col span={24} className={' lg:hidden'}>
                <Link to={"/merchantProfile"} className={''}> <img src={rightArrow}/></Link>
            </Col>
            <div className={'flex mb-[20px] lg:hidden justify-between items-center'}>
                <Space align={'center'} className={'text-[12px] font-[500] '}>
                    <img src={circle}/>
                    شرکت در قرعه کشی
                </Space>
            </div>
            <Col span={24}>
                <img src={lotteryBanner1} className={"w-full"}/>
            </Col>
            <Col span={24} className={"mb-[10px]"}>
                <img src={lotteryBanner2} className={"w-full"}/>
            </Col>


            <Col span={24} className='--timeLeft bg-white px-[24px] py-[35px] rounded-[10px] shadow-4'>
                <div className={'pb-[24px] text-end'}>
                    <Space align={'center'} className={'text-[14px] font-[500] '}>
                        <img src={circle}/>
                        شانس شرکت در قرعه کشی
                    </Space>
                </div>
                <Row gutter={[14, 12]}>
                    <Col span={6} className='__box __day'>
                        <TimeLeftBox title={'روز'} number={days}/>
                    </Col>

                    <Col span={6} className='__box __day'>
                        <TimeLeftBox title={'ساعت'} number={hours}/>
                    </Col>

                    <Col span={6} className='__box __day'>
                        <TimeLeftBox title={'دقیقه'} number={minutes}/>
                    </Col>

                    <Col span={6} className='__box __day'>
                        <TimeLeftBox title={'ثانیه'} number={seconds}/>
                    </Col>

                    <Col span={24} className='__description pb-[20px]'>
                        باقیمانده تا زمان قرعه کشی
                    </Col>
                </Row>
            <Col span={24} className='--remainingTransaction bg-white'>
                <Row gutter={[0, 22]}>
                    <Col span={24} className={"text-[12px] font-[400] text-end"}>
                        مقدار تراکنش های  مورد نیاز برای استفاده از این تسهیلات
                    </Col>

                    <Col span={24} className={"bg-[#EEE] p-[18px] rounded-[10px]"}>
                        
                        <Col span={24} className='__description text-center pb-[13px]'>
                            
                            تراکنش های شما
                        </Col>
                        
                        <div className='--progress'>
                            <Popover
                                placement={'bottomRight'}
                                content={`${formatNumber(1500000)} تومان`}
                                overlayClassName='__currentTransaction'
                            >
                                <div className='__tail' style={{width: '52%'}}/>
                            </Popover>
                        </div>

                        <Row gutter={16} justify={'space-between'} className='--amounts'>
                            <Col className='__amount'>
                                <div>{formatNumber(0)}</div>
                                <div>تومان</div>
                            </Col>

                            <Col className='__amount'>
                                <div>{formatNumber(1500000)}</div>
          
                            </Col>
                            <Col className='__amount'>
                                <div>{formatNumber(3000000)}</div>
                                <div>تومان</div>
                            </Col>
                        </Row>
                    </Col>
                </Row>
            </Col>
            </Col>
        </LotteryChanceContainer>
      </TransitionsPage>
    );
};

const TimeLeftBox = ({title, number}) => {
    return (
        <div>
            <div className='--title'>{title}</div>

            <div className='--number'>{number}</div>
        </div>
    );
};

const useCountdown = (targetDate) => {
    const countDownDate = new Date(targetDate).getTime();

    const [countDown, setCountDown] = useState(
        countDownDate - new Date().getTime()
    );

    useEffect(() => {
        const interval = setInterval(() => {
            setCountDown(countDownDate - new Date().getTime());
        }, 1000);

        return () => clearInterval(interval);
    }, [countDownDate]);

    return getReturnValues(countDown);
};

const getReturnValues = (countDown) => {
    // calculate time left
    const days = Math.floor(countDown / (1000 * 60 * 60 * 24));
    const hours = Math.floor(
        (countDown % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
    );
    const minutes = Math.floor((countDown % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((countDown % (1000 * 60)) / 1000);

    return [days, hours, minutes, seconds];
};

export default Lottery;
