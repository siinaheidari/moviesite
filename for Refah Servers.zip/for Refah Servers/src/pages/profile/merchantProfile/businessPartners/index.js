import React, {useState} from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import {Col, Form, Row, Space, Upload} from "antd";
import Slider from "react-slick";
import {ReactComponent as RightArrow} from "assets/icons/rightArrow.svg";
import {ReactComponent as LeftArrow} from "assets/icons/leftArrow.svg";

import iranKhodro from "assets/images/iranKhodro.svg"
import saipa from "assets/images/saipa.svg"
import kermanMotor from "assets/images/kermanMotor.svg"
import bahman from "assets/images/bahman.svg"
import circle from "../../../../assets/icons/mobile/circle.svg";
import {Link} from "react-router-dom";
import rightArrow from "../../../../assets/icons/mobile/rightArrow.svg";
import {Button, Input, Modal, TextArea, TransitionsPage} from "../../../../templates/Ui";
import {LeftOutlined} from "@ant-design/icons";
import {inputRule} from "../../../../utils/helper";
import upload from "../../../../assets/icons/mobile/upload.svg";


const BusinessPartners = () => {

    const [businessPartnersFormRef] = Form.useForm();
    const [businessPartnersModal, setBusinessPartnersModal] = useState(false);

    const handleBusinessPartners = (value) => {
        console.log(value);
    }

    const settings = {

        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 1,

        nextArrow: <RightArrow/>,
        prevArrow: <LeftArrow/>,
        responsive: [
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                },
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                },
            },

        ],
    }


    return (
        <TransitionsPage coordinates={ 'x' }>
            <div>
                <Col span={24} className={'mb-[13px] lg:hidden'}>
                    <Link to={"/merchantProfile"} className={''}> <img src={rightArrow}/></Link>
                </Col>
                <div className={'flex mb-[2px] lg:hidden justify-between items-center'}>
                    <Space align={'center'} className={'text-[12px] font-[500] '}>
                        <img src={circle}/>
                        شرکای تجاری
                    </Space>
                </div>
                <div className={" lg:bg-white lg:px-[27px] lg:py-[31px] rounded-[10px] lg:shadow-6"}>
                    <Space align={'center'} className={'max-lg:hidden text-[14px] font-[500] '}>
                        <img src={circle}/>
                        شرکای تجاری
                    </Space>
                    <div
                        className={"bg-white py-[62px] max-lg:py-[24px] max-lg:mt-[21px]  px-[23px] max-lg:rounded-[10px] max-lg:shadow-4"}>
                        <Slider {...settings}>
                            <div className={" !px-[10px] !mx-[10px] "}>
                                <img src={iranKhodro} className={"aspect-square shadow-8 rounded-[10px]"}/>
                            </div>
                            <div className={"!px-[10px] !mx-[10px] "}>
                                <img src={bahman} className={"aspect-square  shadow-8 rounded-[10px]"}/>
                            </div>
                            <div className={"!px-[10px] !mx-[10px] "}>
                                <img src={saipa} className={"aspect-square  shadow-8 rounded-[10px]"}/>
                            </div>
                            <div className={" !px-[10px] !mx-[10px] "}>
                                <img src={kermanMotor} className={" aspect-square shadow-8 rounded-[10px]"}/>
                            </div>
                            <div className={" !px-[10px] !mx-[10px] "}>
                                <img src={iranKhodro} className={"aspect-square  shadow-8 rounded-[10px]"}/>
                            </div>
                            <div className={" !px-[10px] !mx-[10px] "}>
                                <img src={kermanMotor} className={"aspect-square  shadow-8 rounded-[10px]"}/>
                            </div>

                            <div className={" !px-[10px] !mx-[10px] "}>
                                <img src={saipa} className={"aspect-square shadow-8 rounded-[10px]"}/>
                            </div>
                        </Slider>
                    </div>
                </div>
            </div>
            <Col xs={24} sm={10} lg={7} className={"items-center text-center mt-[50px] mx-auto"}>
                <Button
                    className={"w-full"}
                    onClick={() => setBusinessPartnersModal(true)}
                    type={"secondary"}>
                    فروشنده شوید!
                </Button>
            </Col>

            <Modal
                open={businessPartnersModal}
                onCancel={() => setBusinessPartnersModal(false)}
                header={false}
                closable={false}
                bodyStyle={{
                    padding: 0,
                    backgroundColor: "white"
                }}
                size={{
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 55,
                    xl: 55,
                    xxl: 55,
                }}
                style={{
                    top: "9vh",
                }}
            >
                <div className={"my-[42px]"}>
                    <Col span={24} className={"text-center items-center mb-[49px] max-lg:mb-[29px] text-title"}>
                        افزودن محصول
                    </Col>


                    <Form
                        form={businessPartnersFormRef}
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={{
                            span: 24,
                        }}
                        wrapperCol={{
                            span: 24,
                        }}
                        onFinish={handleBusinessPartners}
                    >


                        <Row gutter={16} className={"lg:px-[91px] max-lg:px-[17px] "}>
                            <Col xs={24} lg={12}>
                                <Input
                                    name={'name'}
                                    label={'نام محصول'}
                                    placeholder={"نام محصول"}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'نام محصول'})
                                        }
                                    ]}
                                />
                            </Col>
                            <Col xs={24} lg={12}>
                                <Input
                                    name={'discount'}
                                    label={'درصد تخفیف '}
                                    placeholder={"درصد تخفیف "}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'درصد تخفیف '})
                                        }
                                    ]}
                                />
                            </Col>

                            <Col xs={24} lg={12}>
                                <Row>
                                    <Col flex='1 1'>
                                        <Input
                                            name={'uploadFile'}
                                            label={'تصویر محصول'}
                                            formRef={businessPartnersFormRef}
                                            className={'!rounded-s-none'}
                                            placeholder
                                            rules={[
                                                {
                                                    required: true,
                                                    message: 'لطفا فایل مورد نظر خود را بارگذاری نمایید.'
                                                }
                                            ]}
                                            ltr
                                        />
                                    </Col>

                                    <Col flex='20%'>
                                        <Button
                                            type={'secondary'}
                                            className='!mt-[36px] !rounded-s-none'
                                            height={42}
                                            width={'100%'}
                                            block
                                        >
                                            <Upload className={''}>
                                                <img src={upload}/>
                                            </Upload>
                                        </Button>
                                    </Col>
                                </Row>
                            </Col>
                            <Col xs={24} lg={12}>
                                <Input
                                    name={'count'}
                                    label={'تعداد اقساط'}
                                    placeholder={"تعداد اقساط"}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'تعداد اقساط'})
                                        }
                                    ]}
                                />
                            </Col>
                            <Col xs={24} lg={12}>
                                <Input
                                    name={'loanAmount'}
                                    label={'مبلغ هر قسط'}
                                    placeholder={"مبلغ هر قسط"}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'مبلغ هر قسط'})
                                        }
                                    ]}
                                />
                            </Col>
                            <Col xs={24} lg={12}>
                                <Input
                                    name={'profit'}
                                    label={'سود سالانه'}
                                    placeholder={"سود سالانه"}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'سود سالانه'})
                                        }
                                    ]}
                                />
                            </Col>
                            <Col xs={24} lg={12} className={"lg:hidden"}>
                                <Input
                                    name={'descriptionMobile'}
                                    label={'توضیحات محصول'}
                                    placeholder={"توضیحات محصول"}
                                />
                            </Col>
                            <Col span={24} className={"max-lg:hidden"}>
                                <TextArea
                                    name={'description'}
                                    label={'توضیحات'}
                                    rows={5}
                                />
                            </Col>
                            <Col span={24} className="text-center items-center mx-auto lg:mt-[65px] max-lg:mt-[35px] lg:pb-[25px] ">
                                <Row gutter={16} justify={"center"}>
                                    <Col xs={12} sm={10} lg={10}>
                                        <Button
                                          onClick={() => setBusinessPartnersModal(false)}
                                          type={'default'}
                                          className={'w-full bg-red-500'}
                                        >
                                            انصراف
                                        </Button>
                                    </Col>
                                    <Col xs={12} sm={10} lg={10}>
                                        <Button
                                          type={'secondary'}
                                          htmlType={'submit'}
                                          iconAlign={'end'}
                                          className={'w-full'}
                                        >
                                            <LeftOutlined/>
                                            ارسال درخواست
                                        </Button>
                                    </Col>
                                </Row>
                  
                        
                            </Col>
                        </Row>
                    </Form>
                </div>
            </Modal>
        </TransitionsPage>
    );
};

export default BusinessPartners;
