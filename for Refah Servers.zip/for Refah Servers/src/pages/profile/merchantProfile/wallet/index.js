import React, {useState} from 'react';
import '../../../../index.scss';
import {TransitionsPage} from '../../../../templates/Ui';
import SvgIcon from '../../../../templates/components/SvgIcon';
import {useAuth} from '../../../../contexts/auth/AuthContext';
import {formatNumber, useWindowSize} from '../../../../utils/helper';
import {Link, Outlet, useLocation} from 'react-router-dom';
import {AnimatePresence, motion} from 'framer-motion';
import {useRequest} from "../../../../utils/useRequest";


const Wallet = () => {
    const {userData, auth} = useAuth();

    console.log(userData);

    const [filterModal, setFilterModal] = useState(false);

    const {width} = useWindowSize();

    const {pathname: draftPathName} = useLocation();

    const pathname = draftPathName?.split('/').filter(Boolean)
    const handleFilterModal = () => {
        setFilterModal(true);
    };

    const {
        isLoading: walletInventoryIsLoading,
        data: walletInventory,

    } = useRequest({
        path: '/wallet/inventory',
        key: ["walletInventoryRequest", auth?.walletIdentifier],
        params: {
            walletIdentifier: auth.walletIdentifier || null,
        },
        options: {
            enabled: !!auth?.walletIdentifier,
            cacheTime: 0,
        },

    });

    const response = walletInventory || {}
    console.log(response)

    return (
        <div>
            <div className={'flex'}>
                <div className={` ${width >= 992 ? 'w-1/3 max-lg:w-full' : 'w-full'} `}>
                    <TransitionsPage coordinates={'x'}>
                        <div className={'backwallet max-lg:!h-[160px] max-lg:text-[12px] !font-[400]'}>
                            <div className={' text-center text-white item-center '}>
                                <div className={'flex gap-5 items-start'}>
                                    <img src={'/images/walleticon.png'} alt={''}/>
                                    <div>
                                        <h1 className={'!font-[400]'}>موجودی کیف پول</h1>
                                        <h1
                                            className={'text-[15px] text-white pt-2 !font-[500]'}>{`${formatNumber(response?.balance || 0)} ریال`}</h1>
                                    </div>
                                </div>
                                <div className={' items-center text-center pt-2 text-[12px]'}>
                                    <h1 className={'!font-[400]  lg:text-[13px]'}>شناسه کیف پول من: </h1>
                                    <h1 className={'pt-1 !font-[400]'}>{auth?.walletIdentifier}</h1>
                                </div>
                            </div>
                        </div>

                        <div
                            className={'flex gap-2 justify-between !font-[400] items-center flex-wrap py-2 border-b-2 max-lg:!text-[12px] max-lg:!font-[500]'}>
                            <div
                                className={`${pathname[pathname?.length - 1] === 'increase-money' ? 'text-blue-800' : ''} relative flex gap-2 items-center text-start py-2 cursor-pointer`}>
                                <img className={'bg-white p-1 py-2 rounded-md border-indigo-400'}
                                     src={'/images/Vector.svg'}/>
                                <h1 className={'m-0 max-lg:!text-[12px] max-lg:!font-[500] font-[400] '}>افزایش
                                    موجودی</h1>
                                <Link to={'/merchantProfile/wallet/increase-money'} className={'absolute inset-0'}/>
                            </div>
                            <div
                                className={`${pathname[pathname?.length - 1] === 'use-money' ? 'text-blue-800' : ''} relative flex gap-2 items-center text-start py-2 cursor-pointer`}>
                                <img className={' bg-white p-1 rounded-md border-indigo-400'}
                                     src={'/images/Group 1042-new.svg'}/>
                                <h1 className={'my-0 max-lg:!text-[12px] max-lg:!font-[500] font-[400]'}>برداشت</h1>
                                <Link to={'/merchantProfile/wallet/use-money'} className={'absolute inset-0'}/>
                            </div>
                            <div
                                className={`${pathname[pathname?.length - 1] === 'transport-money' ? 'text-blue-800' : ''} relative flex gap-2 items-center text-start py-2 cursor-pointer`}>
                                <img className={' bg-white p-1 py-1.5 rounded-md border-indigo-400'}
                                     src={'/images/transport.svg'}/>
                                <h1 className={'m-0 max-lg:!text-[12px] max-lg:!font-[500] font-[400]'}>انتقال</h1>
                                <Link to={'/merchantProfile/wallet/transport-money'} className={'absolute inset-0'}/>
                            </div>
                        </div>

                        <div className={'max-lg:!text-[12px] !font-[400]'}>
                            <button
                                className={`${pathname[pathname?.length - 1] === 'buy-from-merchant' ? 'bg-[#CDDAFF]' : 'bg-white'} relative  w-full focus:bg-cashback focus:text-textblue my-[11px] flex gap-3 items-center justify-center px-2 h-[42px] border border-borderblue rounded-md`}>
                                <div className={'w-full max-w-[170px] flex gap-2 '}>
                                    <img src={'/images/shoppingCart.svg'} className={'w-[17px]'}/>
                                    <h1 className={'m-0 max-lg:!text-[12px] max-lg:!font-[500] font-[400] w-full'}>
                                        خرید از پذیرنده
                                    </h1>
                                </div>
                                <Link to={'/merchantProfile/wallet/buy-from-merchant'} className={'absolute inset-0'}/>

                            </button>
                            <button
                                className={`${pathname[pathname?.length - 1] === 'increase-money' ? 'bg-[#CDDAFF]' : 'bg-white'} relative  w-full focus:bg-cashback focus:text-textblue my-[11px] flex gap-3 items-center justify-center px-2 h-[42px] border border-borderblue rounded-md`}>

                                <div className={'w-full max-w-[170px] flex gap-2'}>
                                    <img src={'/images/Vector (1).svg'} className={'w-[16px]'}/>
                                    <h1 className={'my-0 max-lg:!font-[500] text-center !font-[400] w-full'}>
                                        شارژ خودکار کیف پول
                                    </h1>
                                </div>
                                <Link to={'/merchantProfile/wallet/increase-money'} className={'absolute inset-0'}/>

                            </button>

                            <button
                                className={`${pathname[pathname?.length - 1] === 'cash-flow' ? 'bg-[#CDDAFF]' : 'bg-white'} relative  w-full focus:bg-cashback focus:text-textblue my-[11px] flex gap-3 items-center justify-center px-2 h-[42px] border border-borderblue rounded-md`}>

                                <div className={'w-full max-w-[170px] flex gap-2'}>
                                    <img src={'/images/Group.svg'} className={'w-[18px]'}/>
                                    <h1 className={'my-0 max-lg:!font-[500] text-center !font-[400] w-full'}>
                                        مشاهده گردش کیف پول
                                    </h1>
                                </div>
                                <Link to={'/merchantProfile/wallet/cash-flow'} className={'absolute inset-0'}/>

                            </button>

                            <button
                                className={`${pathname[pathname?.length - 1] === 'add-cart-bank' ? 'bg-[#CDDAFF]' : 'bg-white'} relative w-full focus:bg-cashback focus:text-textblue my-[11px] flex gap-3 items-center justify-center px-2 h-[42px] border border-borderblue rounded-md`}>

                                <div className={'w-full max-w-[170px] flex gap-2'}>
                                    <SvgIcon icon={'plusCircle'} width={20} height={17} color={'#1447A0'}/>
                                    <h1 className={'my-0 max-lg:!font-[500] text-center !font-[400] w-full'}>
                                        اضافه کردن کارت بانکی
                                    </h1>
                                </div>
                                <Link to={'/merchantProfile/wallet/add-cart-bank'} className={'absolute inset-0'}/>
                            </button>
                        </div>
                        <div
                            className={'flex flex-wrap justify-between !font-[400] gap-2 items-center text-center mt-[25px] max-lg:text-[12px]'}>
                            <div className={'cursor-pointer relative'}>
                                <div
                                    className={`${pathname[pathname?.length - 1] === 'pay-bill' ? 'bg-[#CDDAFF]' : 'bg-white'} ' items-center text-center  rounded-md border border-[#C6D4FF] w-[80px] h-[80px] flex justify-center`}>
                                    <img
                                        className={'inline'}
                                        src={'/images/tablet.svg'}/>
                                </div>

                                <p className={'my-3 max-lg:!font-[500] !font-[400]'}>پرداخت قبوض</p>
                                <Link to={'/merchantProfile/wallet/pay-bill'} className={'absolute inset-0'}/>
                            </div>


                            <div
                                className={'relative cursor-pointer'}>

                                <div
                                    className={`${pathname[pathname?.length - 1] === 'buy-net' ? 'bg-[#CDDAFF]' : 'bg-white'} ' items-center text-center  rounded-md border border-[#C6D4FF] w-[80px] h-[80px] flex justify-center`}>
                                    <img
                                        className={'inline'}
                                        src={'/images/network.svg'}/>
                                </div>


                                <p className={'my-3 max-lg:!font-[500] !font-[400]'}>بسته اینترنت</p>
                                <Link to={'/merchantProfile/wallet/buy-net'} className={'absolute inset-0'}/>
                            </div>

                            <div
                                className={'relative cursor-pointer'}>
                                <div
                                    className={`${pathname[pathname?.length - 1] === 'buy-charge' ? 'bg-[#CDDAFF]' : 'bg-white'} ' items-center text-center  rounded-md border border-[#C6D4FF] w-[80px]  h-[80px] flex justify-center`}>
                                    <img
                                        className={'inline'}
                                        src={'/images/sim-card.svg'}/>
                                </div>

                                <p className={'my-3 max-lg:!font-[500] !font-[400]'}>خرید شارژ</p>
                                <Link to={'/merchantProfile/wallet/buy-charge'} className={'absolute inset-0'}/>
                            </div>
                        </div>
                    </TransitionsPage>
                </div>

                {width >= 992 &&
                    <div className={'w-2/3 pr-6 max-lg:w-full max-lg:pr-0 max-lg:!text-[12px]'}>
                        <AnimatePresence mode={'wait'}>
                            <motion.div
                                key={pathname[pathname?.length - 1]}
                                initial={{x: -30, opacity: 0}}
                                animate={{x: 0, opacity: 1}}
                                exit={{x: -30, opacity: 0}}
                                transition={{duration: .34}}
                                className={'bg-white px-[30px] pt-[20px] pb-[40px] rounded-[10px] shadow-4'}
                            >
                                <Outlet/>
                            </motion.div>
                        </AnimatePresence>
                    </div>
                }

            </div>
        </div>
    );
};

export default Wallet;