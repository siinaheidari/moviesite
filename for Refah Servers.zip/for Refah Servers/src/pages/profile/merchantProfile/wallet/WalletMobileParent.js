import React from 'react';
import {Link, Outlet, useLocation} from 'react-router-dom';
import {Col, Space} from 'antd';
import rightArrow from '../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../assets/icons/mobile/circle.svg';
import {formatNumber} from "../../../../utils/helper";
import {useRequest} from "../../../../utils/useRequest";
import {useAuth} from "../../../../contexts/auth/AuthContext";

const WalletMobileParent = () => {
    const {auth} = useAuth()

    const {pathname: draftPathName} = useLocation();

    const pathname = draftPathName?.split('/').filter(Boolean);


    const {
        isLoading: walletInventoryIsLoading,
        data: walletInventory,

    } = useRequest({
        path: '/wallet/inventory',
        key: ["walletInventoryRequest", auth?.walletIdentifier],
        params: {
            walletIdentifier: auth.walletIdentifier || null,
        },
        options: {
            enabled: !!auth?.walletIdentifier,
            cacheTime: 0,
        },

    });

    const mobileWalletResponse = walletInventory || {}


    return (
        <>
            <div className={pathname[pathname?.length - 1] === 'wallet' ? 'hidden' : 'mb-[20px]'}>
                <Col span={24} className={'mb-[7px] mt-[-10px]'}>
                    <Link to={'/merchantProfile/wallet'} className={''}> <img src={rightArrow}/></Link>
                </Col>
                <Space align={'center'} className={'text-[12px] font-[500] '}>
                    <img src={circle}/>
                    {
                        pathname[pathname?.length - 1] === 'increase-money' ? 'افزایش موجودی' :
                            pathname[pathname?.length - 1] === 'use-money' ? 'برداشت' :
                                pathname[pathname?.length - 1] === 'transport-money' ? 'انتقال' :
                                    pathname[pathname?.length - 1] === 'buy-from-merchant' ? 'خرید از پذیرنده' :
                                        pathname[pathname?.length - 1] === 'increase-money' ? 'شارژ خودکار کیف پول' :
                                            pathname[pathname?.length - 1] === 'cash-flow' ? 'مشاهده گردش کیف پول' :
                                                pathname[pathname?.length - 1] === 'add-cart-bank' ? 'اضافه کردن کارت جدید' :
                                                    pathname[pathname?.length - 1] === 'buy-charge' ? 'خرید شارژ' :
                                                        pathname[pathname?.length - 1] === 'buy-net' ? 'بسته اینترنت' :
                                                            pathname[pathname?.length - 1] === 'pay-bill' ? 'پرداخت قبض' : ""

                    }
                </Space>
            </div>

            {
                pathname[pathname?.length - 1] !== 'wallet' && pathname[pathname?.length - 1] !== 'add-cart-bank' ?
                    <div className={'backwallet !h-[95px] !shadow-6 mb-[20px] max-lg:text-[12px] !font-[400]'}>
                        <div className={' text-center text-white item-center '}>
                            <div className={'flex gap-5 items-center'}>
                                <img src={'/images/walleticon.png'} alt={''}/>
                                <div>
                                    <h1 className={'text-[12px] !font-[400]'}>موجودی کیف پول</h1>
                                    <h1
                                        className={'text-[14px] text-white pt-2 !font-[500]'}>{`${formatNumber(mobileWalletResponse?.balance || 0)} ریال`}</h1>
                                </div>
                            </div>
                            {/*<div className={' items-center text-center pt-2 text-[12px]'}>*/}
                            {/*    <h1 className={'!font-[400] text-[10px]'}>شناسه کیف پول من: </h1>*/}
                            {/*    <h1 className={'pt-1 !font-[400] text-[12px]'}>{auth?.walletIdentifier}</h1>*/}
                            {/*</div>*/}
                        </div>
                    </div> : ""
            }


            <div
                className={pathname[pathname?.length - 1] === 'wallet' || pathname[pathname?.length - 1] === 'cash-flow' || pathname[pathname?.length - 1] === 'buy-net' ? '' : 'bg-white  px-[18px] pt-[20px] pb-[50px] rounded-[10px] shadow-6'}>
                <Outlet/>
            </div>
        </>

    );
};

export default WalletMobileParent;
