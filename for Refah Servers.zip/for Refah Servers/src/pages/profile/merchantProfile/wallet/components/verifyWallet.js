import React, {useEffect} from 'react';
import {useNavigate, useParams, useSearchParams} from "react-router-dom";
import {convertDatePicker, formatNumber} from "../../../../../utils/helper";
import {DateObject} from "react-multi-date-picker";
import {useRequest} from "../../../../../utils/useRequest";
import {useAuth} from "../../../../../contexts/auth/AuthContext";
import {Button} from "../../../../../templates/Ui";

const VerifyWallet = () => {
  const {auth, handleChangeUserData} = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const {isLoading: userWalletsIsLoading, data: userWalletsData, isFetched, dataUpdatedAt} = useRequest({
    path: '/api/core/wallet/info',
    key: ['userWalletInfo'],
    options: {
      enabled: searchParams.get('status') === 'true',
      cacheTime: 0,
    }
  });

  useEffect(() => {
    if (searchParams.get('status') === 'true' && isFetched) {
      let draftUserInfo = auth;

      if (userWalletsData?.output) {
        draftUserInfo.walletDetails = userWalletsData?.output
      }
      handleChangeUserData(draftUserInfo);
    }
  }, [searchParams.get('status'), isFetched, dataUpdatedAt])

  return (
    <div className={"bg-white text-center items-center w-full max-w-[650px] m-auto my-10 border rounded-[10px] shadow-shadow px-[78px] py-[39px]"}>
      <div className={"text-textcolor text-[14px]"}>
        <div className={"m-auto text-center items-center pb-8 max-lg:pb-4"}>
          <img className={"inline text-tick pb-5"} src={searchParams.get('status') === 'true' ? "/images/Tick Square.svg" : "/images/Close Square.svg"}/>

          {searchParams.get('status') === 'true' ?
            <h1 className={"text-tick text-[16px] max-lg:!text-[12px]"}>
              پرداخت شما با موفقیت انجام شد
            </h1> :
            <h1 className={"text-error text-[16px] max-lg:!text-[12px]"}>
              پرداخت انجام نشد
            </h1>
          }
        </div>
        <div className={"flex justify-between items-center max-lg:!text-[12px] "}>
          <h1>مبلغ: (ریال)</h1>
          <h1>{formatNumber(searchParams.get('amount'))}</h1>
        </div>
        <div className={"flex justify-between items-center max-lg:!text-[12px] pb-[10px]"}>
          <h1>{searchParams.get('terminalNumber')?"شماره ترمینال":""} </h1>
          <h1>{searchParams.get('terminalNumber')}</h1>
        </div>
        {searchParams.get('status') === 'true' &&
          <div className={"flex justify-between items-center max-lg:!text-[12px] pb-[10px]"}>
            <h1>کد رهگیری:</h1>
            <h1>{searchParams.get('trackingNumber')}</h1>
          </div>
        }

        <div className={"flex justify-between items-center  max-lg:!text-[12px] pb-[43px]"}>
          <h1>تاریخ و ساعت:</h1>
          <h1>{searchParams.get('date')}</h1>
        </div>

        <Button
            type={"default"}
            className={"max-lg:text-[12px] "}
            onClick={() => navigate('/merchantProfile/wallet')}>

        >
          بازگشت به صفحه کیف پول
        </Button>
      </div>
    </div>
  );
};

export default VerifyWallet;
