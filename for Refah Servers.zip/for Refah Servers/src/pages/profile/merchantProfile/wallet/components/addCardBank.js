import {Col, Divider, Form, Space, Spin} from 'antd';
import {useRequest} from "../../../../../utils/useRequest";
import React, {useEffect, useRef, useState} from "react";
import {checkBanksCard} from "../../../../../utils/helper";
import {useAuth} from "../../../../../contexts/auth/AuthContext";
import {Button, Input} from "../../../../../templates/Ui";
import styled from "styled-components";
import addCart from "assets/icons/pluss.svg"
import {LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../assets/icons/refahLogo.svg";
import cardPatternRefah from 'assets/images/refahCardBg.png';

const CardBankContainer = styled.div`
  background: url(${cardPatternRefah}) center;
  background-size: cover;
`;

const ErrorMessage = styled.div`
  color: #c62606;
  margin-top: 8px;
  text-align: center;
  font-size: 12px;
`;

const AddCardBank = () => {

    const {auth} = useAuth();
    const [addCardBankForm] = Form.useForm();
    const cardWatch = Form.useWatch('card', addCardBankForm);
    const inputsRef = useRef([]);
    const [findBankName, setFindBankName] = useState('');
    console.log(cardWatch)

    const [showErrorMessage, setShowErrorMessage] = useState(false);
    const [refahCardError, setRefahCardError] = useState(false);


    useEffect(() => {
        let cardNumber;

        if (cardWatch?.pan1?.length === 4 && cardWatch?.pan2?.length >= 2) {
            cardNumber = cardWatch?.pan1 + cardWatch?.pan2.substring(0, 2);
        }

        if (cardNumber?.length === 6) {
            setFindBankName(checkBanksCard(cardNumber))
        }
    }, [cardWatch])

    const {mutateAsync: addCardBankRequest, isLoading: addCardBankIsLoading} = useRequest({
        path: '/wallet/iban-pan',
        isMutation: true,
    })

    const handleAddCardBank = async () => {
        try {
            await addCardBankForm?.validateFields();

            const values = await addCardBankForm?.getFieldsValue(true);
            const pan = structuredClone(values);
            pan.pan = values?.card?.pan1 + values?.card?.pan2 + values?.card?.pan3 + values?.card?.pan4;
            delete pan.card;

            await addCardBankRequest(pan)
            addCardBankForm.resetFields();
        } catch (error) {
            console.log('error in handleAddCardBank >>>>>', error)

            if (error?.errorFields && error?.errorFields[0]?.errors[0] !== 'refah card error') {
                setShowErrorMessage(true);
            }
        }

    };


    const handleOnKeyDown = (event, index) => {
        if (event.key === 'Backspace' && event.target.value === '') {
            event.preventDefault();
            if (index > 0) {
                inputsRef.current[index - 1].focus();
            }
        }
    };

    const handleOnInput = (event, count, index) => {
        const {value} = event.target;
        if (value.length === count) {
            event.preventDefault();
            if (index < inputsRef.current.length - 1) {
                inputsRef.current[index + 1].focus();
            }
        }
    };


    return (
        <div className={" mx-auto"}>
            <Spin spinning={addCardBankIsLoading} className={"relative"}
                  indicator={<LoadingOutlined className={"!hidden"}/>} tip={<div>
                <BeatLoader
                    color={"#1447a0"}
                    loading={true}
                    size={9}
                    aria-label="Loading Spinner"
                    data-testid="loader"
                />
                <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
            </div>}>

                <Space className={"max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]"}>
                    <img src={addCart}/>
                    اضافه کردن کارت جدید
                </Space>
                <Divider className={"max-lg:hidden !bg-[#C6D4FF] !mt-[9px] !mb-[25px]"}/>
                <Form
                    form={addCardBankForm}
                    name="increaseMoneyForm"
                    autoComplete={'false'}
                >
                    <CardBankContainer
                        className={"p-5 max-lg:px-[18px] w-full max-w-[300px] h-[175px] rounded-md mt-[37px] mx-auto items-center"}>
                        <Space size={5} className={"mt-[50px]"}>
                            <img src={"/images/plusCart.svg"}/>
                            <div className={"text-[12px] text-textblue"}> کارت بانکی خود را اضافه کنید</div>
                        </Space>

                        <div className={"w-full flex gap-3"} style={{direction: 'ltr'}}>

                            <Input
                                name={['card', 'pan1']}
                                formRef={addCardBankForm}
                                className="[&>div>div>div~div]:!hidden [&>div~div]:!hidden !m-0"
                                inputClassName='!text-center'
                                ltr
                                allowClear={false}
                                justNumber
                                type={'tel'}
                                maxLength={4}
                                ref={el => inputsRef.current[1] = el}
                                onInput={(e) => handleOnInput(e, 4, 1)}
                                rules={[
                                    {
                                        required: true
                                    },
                                    {
                                        validator: () => {
                                            const pan = cardWatch?.pan1 + cardWatch?.pan2;

                                            if (pan?.length >= 6) {
                                                const checkPan = checkBanksCard(pan);

                                                if (checkPan !== 'refah') {
                                                    setRefahCardError(true);
                                                    return Promise.reject(new Error('refah card error'));
                                                }
                                            }
                                            setRefahCardError(false);
                                            return Promise.resolve();
                                        }
                                    }
                                ]}
                            />


                            <Input
                                name={['card', 'pan2']}
                                className="[&>div>div>div~div]:!hidden [&>div~div]:!hidden !m-0"
                                inputClassName='!text-center'
                                ltr
                                allowClear={false}
                                formRef={addCardBankForm}
                                maxLength={4}
                                justNumber
                                type={'tel'}
                                id={'pan2'}
                                ref={el => inputsRef.current[2] = el}
                                onInput={(e) => handleOnInput(e, 4, 2)}
                                onKeyDown={(e) => handleOnKeyDown(e, 2)}
                                rules={[
                                    {
                                        required: true
                                    },
                                    {
                                        validator: () => {
                                            const pan = cardWatch?.pan1 + cardWatch?.pan2;

                                            if (pan?.length >= 6) {
                                                const checkPan = checkBanksCard(pan);

                                                if (checkPan !== 'refah') {
                                                    setRefahCardError(true);
                                                    return Promise.reject(new Error('refah card error'));
                                                }
                                            }
                                            setRefahCardError(false);
                                            return Promise.resolve();
                                        }
                                    }
                                ]}

                            />


                            <Input
                                name={['card', 'pan3']}
                                formRef={addCardBankForm}
                                className="[&>div>div>div~div]:!hidden [&>div~div]:!hidden !m-0"
                                inputClassName='!text-center'
                                ltr
                                allowClear={false}
                                maxLength={4}
                                justNumber
                                type={'tel'}
                                id={'pan3'}
                                ref={el => inputsRef.current[3] = el}
                                onInput={(e) => handleOnInput(e, 4, 3)}
                                onKeyDown={(e) => handleOnKeyDown(e, 3)}
                                rules={[
                                    {
                                        required: true
                                    }
                                ]}
                            />


                            <Input
                                name={['card', 'pan4']}
                                formRef={addCardBankForm}
                                className="[&>div>div>div~div]:!hidden [&>div~div]:!hidden !m-0"
                                inputClassName='!text-center'
                                ltr
                                allowClear={false}
                                justNumber
                                type={'tel'}
                                maxLength={4}
                                ref={el => inputsRef.current[4] = el}
                                onKeyDown={(e) => handleOnKeyDown(e, 4)}
                                id={'pan4'}
                                rules={[
                                    {
                                        required: true
                                    },
                                ]}
                            />

                        </div>

                        {(showErrorMessage && !refahCardError) &&
                            <ErrorMessage>
                                لطفا شماره کارت را به صورت کامل وارد نمایید
                            </ErrorMessage>
                        }

                        {refahCardError &&
                            <ErrorMessage>
                                شماره کارت وارد شده مربوط به بانک رفاه نمی‌باشد
                            </ErrorMessage>
                        }
                    </CardBankContainer>


                    <Col xs={24} sm={9} lg={7} className={"lg:mt-[63px] max-lg:mt-[63px] mb-[20px] mx-auto"}>
                        <Button
                            type={"secondary"}
                            className={"w-full"}
                            onClick={handleAddCardBank}

                        >
                            ثبت کارت بانکی
                        </Button>
                    </Col>

                </Form>
            </Spin>
        </div>
    );
}

export default AddCardBank;