import React from 'react';
import {Col, Divider, Empty, Form, Row, Select, Space, Spin} from 'antd';
import {Button, DatePicker, Modal, SelectBox} from '../../../../../../templates/Ui';
import {DateObject} from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import {formatNumber, inputRule} from '../../../../../../utils/helper';
import filter from '../../../../../../assets/icons/mobile/Filter.svg';
import {LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../../assets/icons/refahLogo.svg";

const CashFlowMobile = (
    {
        response,
        statusType,
        currentData,
        lastDayDate,
        handleFilter,
        filterFormRef,
        filterModal,
        setFilterModal,
        isLoading,
    }) => {


    return (
        <Spin spinning={isLoading} className={"relative"} indicator={<LoadingOutlined className={"!hidden"}/>}
              tip={<div>
                  <BeatLoader
                      color={"#1447a0"}
                      loading={true}
                      size={9}
                      aria-label="Loading Spinner"
                      data-testid="loader"
                  />
                  <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
              </div>}>

            <Row gutter={[0, 10]} className={'relative'}>
                <div onClick={() => setFilterModal(true)}
                     className={'absolute drop-shadow-lg !left-0 top-[-5px] p-[7px] mb-[2rem] rounded-[5px] bg-white'}>
                    <img src={filter}/>
                </div>

                <div className={"w-full mt-[3rem]"}>
                    {!!response?.length ?
                        response.map((item) => {
                            console.log('rrrr', item?.transactionDate);

                            const date = item?.transactionDate.split('T')[1]?.split(':');

                            return (
                                <Col xs={24} md={12} key={item?.transactionID}>
                                    <div
                                        className="h-full pt-[14px] bg-white rounded-[5px] mb-[0.7rem] shadow-[0_4px_4px_0_rgba(122,122,122,.05)]">
                                        <div
                                            className="text-[12px] space-y-[12px] px-[15px] border-0 border-b border-solid border-b-[#C6D4FF] pb-[15px]">
                                            <div className={`${item?.status === 0 ? 'bg-[#F9BD15]' :
                                                item?.status === 1 ? 'bg-[#00B892]' :
                                                    'bg-[#FE2301]'}  rounded-[5px] w-[60px] text-center h-[16px] leading-[17px] px-[5px] text-white text-[11px] font-[500] `}>
                                                {statusType[item?.status || 0]}
                                            </div>

                                            <div className="text-[#21409A] text-[12px] font-[500]">
                                                {item?.transactionTypeDesc} {[3, 5].includes(item?.transactionType) ? item?.toWalletName : item?.description}
                                            </div>

                                            <Col span={24}
                                                 className={'flex justify-between text-[12px] font-[500] text-[#4D4D4D]'}>
                                                تاریخ و ساعت:
                                                <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-3'}>
                                 {

                                     new DateObject({
                                         date: new Date(item?.createDate),
                                         calendar: gregorian,
                                     }).convert(persian).format(`${date[0]}:${date[1]} - YYYY/MM/DD`)
                                 }
                                </span>
                                            </Col>


                                            <div>
                                                <div className={"flex justify-between items-center"}>
                                                    <div className="text-textcolor text-[12px] font-[500]">
                                                        مبلغ:
                                                    </div>

                                                    <div className=" text-[12px] font-[400]">
                                                        <Space className={"text-[12px]"}>
                                                            <div
                                                                className={item?.status === 1 ? "text-[#00B892] text-[13px] " :
                                                                    item?.status === 2 ? "text-[#FE2301] text-[13px] " : item?.status === 0 ? "text-[#F9BD15] text-[12px] " : ""}>
                                                                {formatNumber(item?.transactionPrice || 0)}
                                                            </div>
                                                            ریال
                                                        </Space>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="py-[13px] text-center">
                                            <Space size={10} align={'start'}>
                                                <div className="text-textcolor text-[12px] font-[500]">
                                                    موجودی پس از تراکنش:
                                                </div>

                                                <div className="text-textblue text-[12px] font-[400]">
                                                    <Space>
                                                        <div className="text-textblue">
                                                            {formatNumber(item?.balance || 0)}
                                                        </div>
                                                        ریال
                                                    </Space>
                                                </div>
                                            </Space>
                                        </div>
                                    </div>
                                </Col>
                            );
                        })

                        :
                        <Col span={24} className="text-center">
                            <Empty description={'تراکنشی یافت نشد'}/>
                        </Col>
                    }
                </div>


                <Modal
                    open={filterModal}
                    onCancel={() => setFilterModal(false)}
                    header={false}
                    closable={false}
                    bodyStyle={{
                        padding: 0,
                        backgroundColor: 'white',
                    }}
                    size={{
                        xs: 90,
                        sm: 90,
                        md: 90,
                        lg: 40,
                        xl: 40,
                        xxl: 30,
                    }}
                    style={{
                        top: '20vh',
                    }}

                >
                    <Col span={24}>
                        <div className={'--modal text-[12px] text-[#4D4D4D]'}>
                            <Space className={'px-[22px] pt-[16px]'}>
                                <img src={filter}/>
                                فیلترها
                            </Space>
                        </div>
                        <Divider className={'!m-2'}/>
                        <Form
                            form={filterFormRef}
                            name="indexFrom"
                            autoComplete="off"
                            scrollToFirstError
                            labelCol={{
                                span: 24,
                            }}
                            wrapperCol={{
                                span: 24,
                            }}
                            initialValues={{
                                transactionType: 0,
                                status: 3,
                            }}
                            onFinish={handleFilter}
                        >

                            <Row gutter={[13, 10]} className={'pt-[17px] pb-[40px] px-[18px]'}>
                                <Col span={12}>
                                    <DatePicker
                                        name={'startDate'}
                                        placeholder={'از تاریخ'}
                                        hiddenLabel
                                        initialValue={lastDayDate?.format('YYYY-MM-DD')}
                                        rules={[
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', {inputName: 'تاریخ '}),
                                            },
                                        ]}
                                        rtl
                                    />
                                </Col>
                                <Col span={12}>
                                    <DatePicker
                                        name={'endDate'}
                                        placeholder={'تا تاریخ'}
                                        hiddenLabel
                                        initialValue={currentData.format('YYYY-MM-DD')}

                                        rules={[
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', {inputName: 'تاریخ '}),
                                            },
                                        ]}
                                        rtl
                                    />
                                </Col>
                                <Col span={24}>
                                    <SelectBox
                                        name="transactionType"
                                        placeholder="لیست تراکنش ها"
                                        initialValue={0}
                                        showSearch={false}
                                        rules={[
                                            {
                                                required: true,
                                                message: 'نوع تراکنش را انتخاب نمایید',
                                            },
                                        ]}
                                        allowClear={false}
                                    >
                                        <Select.Option value={0}>همه</Select.Option>
                                        <Select.Option value={1}>شارژ کیف پول</Select.Option>
                                        <Select.Option value={2}>برداشت از کیف پول</Select.Option>
                                        <Select.Option value={3}>انتقال از کیف پول</Select.Option>
                                        <Select.Option value={4}>پرداخت بابت خرید</Select.Option>
                                        <Select.Option value={5}>دریافت از کیف پول دیگر</Select.Option>
                                        <Select.Option value={6}>دریافت بابت فروش</Select.Option>
                                        <Select.Option value={7}>پرداخت قبض</Select.Option>
                                    </SelectBox>
                                </Col>
                                <Col span={24} className={"mt-[-17px]"}>
                                    <SelectBox
                                        name="status"
                                        placeholder="وضعیت تراکنش"
                                        showSearch={false}
                                        rules={[
                                            {
                                                required: true,
                                                message: 'وضعیت تراکنش را انتخاب نمایید',
                                            },
                                        ]}
                                        allowClear={false}
                                    >
                                        <Select.Option value={3}>همه</Select.Option>
                                        <Select.Option value={0}>نامعلوم</Select.Option>
                                        <Select.Option value={1}>موفق</Select.Option>
                                        <Select.Option value={2}>ناموفق</Select.Option>
                                    </SelectBox>
                                </Col>
                                <Col span={24} className={'items-center text-center mt-[45px]'}>
                                    <Button
                                        className={'!rounded-[5px] text-[12px] font-[400] w-full'}
                                        onClick={handleFilter}
                                        type={'secondary'}
                                        radius={50}
                                        width={127}
                                    >
                                        اعمال فیلتر
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    </Col>

                </Modal>

            </Row>
        </Spin>
    );
};

export default CashFlowMobile;
