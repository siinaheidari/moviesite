import React, {useState} from 'react';
import styled from 'styled-components';
import vector from 'assets/icons/wallet.svg';
import SendPinReminder from '../SendPinReminder';
import {Col, Form, Row, Space, Spin} from 'antd';
import {Button, Input, Modal, TransitionsPage} from '../../../../../../templates/Ui';
import {formatNumber, inputRule} from '../../../../../../utils/helper';
import {useRequest} from '../../../../../../utils/useRequest';
import {useNavigate} from "react-router-dom";
import {useQueryClient} from "@tanstack/react-query";
import {useAuth} from "../../../../../../contexts/auth/AuthContext";
import {LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../../assets/icons/refahLogo.svg";

const WaterBillInquiryContainer = styled(Row)`
  position: relative;

  .--response {
    & > div:first-child {
      background: ${props => props?.theme?.gradientPrimaryColorLight2};
      border-radius: 10px;
      overflow: hidden;
      padding: 31px 11px;
    }

    & > div:last-child {
      margin-top: 40px;
    }

    .__title {
      color: ${props => props?.theme?.textColorGray};
      font-size: 1.2rem;
      font-weight: 500;
      text-align: start;
    }

    .__value {
      color: #414042;
      font-weight: 400;
      font-size: 1.2rem;
      text-align: end;
    }

    .__payBtn {
      background: ${props => props?.theme?.gradientPrimaryColorLight2};
      border: 1px solid #FFFFFF;
      border-radius: 10px;
      overflow: hidden;
      height: 56px;
      line-height: 56px;
      cursor: pointer;
      text-align: center;
      color: ${props => props?.theme?.textColorGray};
      font-size: 1.2rem;
      font-weight: 500;
      margin-top: 20px;
    }

    .__try {
      margin-top: 15px;
    }
  }

  & > .ant-col {
    position: relative;
    z-index: 99;
  }

  .--vector {
    width: 100%;
    height: 180px;
    background: url(${vector}) no-repeat center;
    background-size: auto 100%;
    position: fixed;
    inset-inline: 0;
    inset-block-end: 22vh;
    z-index: 0;
  }
`;

// Styled component for OTP container
const OtpContainer = styled(Row)`
  .ant-input {
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  .ant-btn {
    border-start-start-radius: 0;
    border-end-start-radius: 0;
    margin-top: 12px;
  }
`;

const WaterBill = ({handleBack}) => {
    const {
        auth,
        handleChangeUserData,
    } = useAuth();

    const [formRef] = Form.useForm();

    const [otpModalVisible, setOtpModalVisible] = useState(false);

    // state for show btn To resend the verification code:
    const [resendCode, setResendCode] = useState(false);

    const navigate = useNavigate()
    const queryClient = useQueryClient();


    let mockResponse = {
        'address': 'ولی عصرجنب قصریخ شهدا1',
        'amount': 14212000,
        'averageConsumption': '0',
        'billId': '9132972104120',
        'billPDFurl': '',
        'customerType': 'حقیقی',
        'currentDate': '02/22/2023 00:00:00',
        'cycle': '12',
        'extraInfo': '{"آمپراژ":"32","کد شرکت توزیع":"41","نام شرکت توزیع":"تهران بزرگ","فاز":"تک فاز","نوع ولتاژ":"ثانویه","قدرت قراردادی":"6.4","نوع تعرفه":"تجاری","نوع مشترک":"حقیقی","بدهی سایر خدمات یا خسارت":"0 ریال","بدهی واگذاری انشعاب برای انشعابات قسط":"0 ریال","محدوده جغرافیایی":"شهری","شماره بدنه":"11154386","تاریخ انقضا پروانه":"1978-06-10T12:00:00Z","شناسه اشتراک":"1279041","رمز رایانه":"13297215","سریال صورت حساب":"143","سال فروش":"1401","دوره فروش":"12","تاریخ صدور صورت حساب":"1401/12/06","مصرف میان باری":"174","مصرف پر باری":"9","مصرف کم باری":"16","مصرف روز جمعه":"0","مصرف راکتیو":"0","دیماند قرائت شده":"0","متوسط مصرف ماهانه انرژی":"0","مبلغ صورت حساب (جمع اجزا صورت حساب به اضافه بدهی قبلی)":"14,212,000 ریال","مبلغ صورت حساب":"921,533 ریال","مبلغ بیمه":"8,333 ریال","مبلغ مالیات (در سهم ارزش افزوده)":"38,411 ریال","مبلغ عوارض (در سهم ارزش افزوده)":"0 ریال","مبلغ عوارض برق":"75,841 ریال","جمع مبلغ انرژی":"758,411 ریال","مبلغ راکتیو":"0 ریال","مبلغ دیماند":"0 ریال","مبلغ آبونمان":"9,808 ریال","مبلغ پیک فصل":"0 ریال","مبلغ جریمه بابت انقضا پروانه":"0 ریال","مبلغ تفاوت انشعاب آزاد":"0 ریال","مبلغ تخفیف عدم گاز رسانی":"0 ریال","مبلغ بخشودگی":"0 ریال","تاریخ ابطال صورتحساب در صورت باطل شدن":"1357/03/20","تعداد روزهای سرد":"25","تعداد روزهای گرم":"0","تعداد کل روزها":"25"}',
        'fullName': 'بنیاد شهید',
        'insuranceAmount': '8333',
        'paymentDate': '03/02/2023 00:00:00',
        'paymentId': '1421211237',
        'payTollAmount': '0',
        'powerPaytollAmount': '75841',
        'previousDate': '01/28/2023 00:00:00',
        'saleYear': '1401',
        'tariffType': 'تجاری',
        'taxAmount': '38411',
        'totalDays': '25',
    };

    const {
        isLoading: sendOtpIsLoading,
        mutateAsync: sendOtpRequest,
        isSuccess: sendOtpIsSuccess,
    } = useRequest({
        path: '/wallet/otp',
        isMutation: true,
        customSuccessMessage: 'رمز پویا با موفقیت ارسال شد',
    });

    const {
        isLoading,
        mutateAsync: electricityBillInquiryRequest,
        data,
        reset,
    } = useRequest({
        path: '/services/bills/inquiry/electricity',
        isMutation: true,
        customSuccessMessage: 'اطلاعات با موفقیت دریافت شد',
    });

    const {
        isLoading: payIsLoading,
        mutateAsync: payBillRequest,
    } = useRequest({
        path: '/services/bills/pay/bills',
        isMutation: true,
    });

    const response = data?.response || {};

    const handleElectricityBillInquiry = async (formData) => await electricityBillInquiryRequest(formData)
        .catch(() => {
        });

    const handlePayBill = async () => {
        try {
            await formRef?.validateFields(['otp']);

            const data = {
                amount: response?.amount?.toString(),
                billId: response?.billId?.toString(),
                paymentId: response?.payId?.toString(),
                otp: formRef?.getFieldValue('otp'),
                billType: '1',
            };

            await payBillRequest(data);

            await queryClient.refetchQueries(['request', "walletInventoryRequest", auth?.walletIdentifier]);

            await setOtpModalVisible(false);


            await navigate("/merchantProfile/wallet")
            await reset();
        } catch (error) {
            console.log('handlePayBill >>>>', error);
            await navigate("/merchantProfile/wallet")
        }
    };

    // Send OTP request
    const handleSendOtp = async () => {
        try {
            await sendOtpRequest({amount: 50000});
            await setOtpModalVisible(true);
        } catch (error) {
            console.log('error in handleSendOtp >>>>', error);
        }
    };


    return (
        <Form
            form={formRef}
            name="waterBillInquiryFrom"
            autoComplete="off"
            scrollToFirstError
            labelCol={{
                span: 24,
            }}
            wrapperCol={{
                span: 24,
            }}
            onFinish={handleElectricityBillInquiry}
        >
            <Spin spinning={isLoading || sendOtpIsLoading} className={"relative"}
                  indicator={<LoadingOutlined className={"!hidden"}/>} tip={<div>
                <BeatLoader
                    color={"#1447a0"}
                    loading={true}
                    size={9}
                    aria-label="Loading Spinner"
                    data-testid="loader"
                />
                <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
            </div>}>
                <TransitionsPage>
                    <div className={'flex gap-2 !text-center !items-center mb-[10px]'}>
                        <img className={'w-7'} src={'/images/electricity.png'}/>
                        <h1 className={'!mb-0'}>قبض برق</h1>
                    </div>


                    {!!Object.keys(response)?.length ?
                        <Col span={24} className="--response">
                            <div className={'lg:w-2/3 mx-auto'}>
                                <div
                                    className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                    مبلغ بدهی:
                                    <Space size={5}>
                                        {formatNumber(response?.amount || 0)}

                                        ریال
                                    </Space>
                                </div>


                                {(+response?.amount > 10000 && response?.taxAmount) &&
                                    <div
                                        className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>

                                        مبلغ مالیات :


                                        <Space size={5}>
                                            {formatNumber(response?.taxAmount)}

                                            ریال
                                        </Space>

                                    </div>
                                }
                                <div
                                    className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                    آدرس :
                                    <div>
                                        {response?.address}
                                    </div>
                                </div>
                                <div
                                    className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                    شناسه قبض :
                                    <div>
                                        {response?.billId}
                                    </div>
                                </div>
                                <div
                                    className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                    شناسه پرداخت :
                                    <div>
                                        {response?.payId}
                                    </div>
                                </div>


                                {response?.totalDays &&
                                    <div
                                        className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>

                                        تعداد روز :

                                        <div>
                                            {response?.totalDays}
                                        </div>
                                    </div>
                                }

                            </div>

                            <Row gutter={10} justify={'center'} className={'lg:mt-[90px] max-lg:mt-[50px]'}>
                                <Col xs={12} sm={10} lg={8}>
                                    <Button
                                        type="default"
                                        block
                                        colored={false}
                                        onClick={reset}
                                    >
                                        بازگشت
                                    </Button>
                                </Col>

                                <Col xs={12} sm={10} lg={8}>
                                    <Button
                                        type="secondary"
                                        block
                                        disabled={+(response?.amount) < 10000}
                                        onClick={handleSendOtp}
                                    >
                                        پرداخت از کیف پول
                                    </Button>
                                </Col>
                            </Row>
                        </Col> :
                        <Col span={24} className="--formContent">
                            <Input
                                name={'billId'}
                                label={'شناسه قبض'}
                                labelColor={'#FFFFFF'}
                                rules={[
                                    {
                                        required: true,
                                        message: 'شناسه قبض را وارد کنید'
                                    },
                                    {
                                        required: true,
                                        message: inputRule('must be number input', {inputName: 'شناسه قبض ثابت'}),
                                    },

                                ]}
                                justNumber
                                ltr
                                formRef={formRef}
                            />

                            <Row gutter={16} justify={"center"}
                                 className={"items-center text-center mx-auto mt-[120px]"}>
                                <Col xs={24} lg={8} className={"max-lg:hidden"}>
                                    <Button
                                        type={'default'}
                                        className={"w-full"}
                                        block
                                        onClick={handleBack}
                                    >
                                        بازگشت
                                    </Button>
                                </Col>
                                <Col xs={24} lg={8}>
                                    <Button
                                        type={'secondary'}
                                        htmlType={'submit'}
                                        block
                                        className={"w-full"}
                                    >
                                        استعلام قبض
                                    </Button>
                                </Col>
                            </Row>
                        </Col>
                    }

                    <div className="--vector"/>
                </TransitionsPage>
            </Spin>

            <Modal
                open={otpModalVisible}
                centered
                onCancel={() => setOtpModalVisible(false)}
                style={{
                    top: '-10vh',
                }}
            >
                <OtpContainer align="middle">
                    <Col flex="1 1">
                        <Input
                            name={'otp'}
                            label={'رمز پویا'}
                            formRef={formRef}
                            justNumber
                            minLength={4}
                            rules={[
                                {
                                    required: true,
                                    message: 'رمز پویا را وارد کنید'
                                }
                            ]}
                        />
                    </Col>

                    <Col flex="100px" className={"max-lg:mt-[17px]"}>
                        <Button
                            type={'secondary'}
                            block
                            height={40}
                            onClick={handleSendOtp}
                            loading={sendOtpIsLoading}
                            disabled={resendCode}
                        >
                            ارسال مجدد
                        </Button>
                    </Col>

                    <Col span={24} className="mt-[10px]">
                        <SendPinReminder
                            resendCode={resendCode}
                            setResendCode={setResendCode}
                            sendPinIsSuccess={sendOtpIsSuccess}
                        />
                    </Col>

                    <Col xs={24} lg={12} className="text-center mx-auto mt-[40px]">
                        <Button onClick={handlePayBill} loading={payIsLoading}
                                className={'w-full'}
                                type={'secondary'}
                        >
                            پرداخت
                        </Button>
                    </Col>
                </OtpContainer>
            </Modal>
        </Form>
    );
};

export default WaterBill;
