import React, {useRef, useState} from 'react';
import 'index.scss';
import {DatePicker, SelectBox, Table} from 'templates/Ui';
import {Col, Divider, Form, Row, Space, Spin} from 'antd';
import {useRequest} from 'utils/useRequest';
import SvgIcon from 'templates/components/SvgIcon';
import {formatNumber, inputRule} from 'utils/helper';
import {DateObject} from 'react-multi-date-picker';
import persian from 'react-date-object/calendars/persian';
import * as PropTypes from 'prop-types';
import gregorian from 'react-date-object/calendars/gregorian';
import {useAuth} from 'contexts/auth/AuthContext';
import {MatchBreakpoint} from 'react-hook-breakpoints';
import CashFlowMobile from './cashFlowMobile';
import transport from 'assets/icons/transport.svg';
import {LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../../assets/icons/refahLogo.svg";

function TransactionsListContainer(props) {
    return null;
}

TransactionsListContainer.propTypes = {
    gutter: PropTypes.arrayOf(PropTypes.number),
    children: PropTypes.node,
};
const CashFlow = ({handleFilterModal}) => {

    const {
        auth,
        handleChangeUserData,
    } = useAuth();

    const [transactionDetailModal, setTransactionDetailModal] = useState(false);

    const [selectedTransaction, setSelectedTransaction] = useState({});

    const [filterModal, setFilterModal] = useState(false);

    const handleOpenModal = transactionDetail => {
        setSelectedTransaction(transactionDetail);
        setTransactionDetailModal(true);
    };

    const handleCloseModal = () => {
        setSelectedTransaction({});
        setTransactionDetailModal(false);
    };

    const [filterFormRef] = Form.useForm();

    const tableRef = useRef();

    const [page, setPage] = useState(1);

    const [pageSize, setPageSize] = useState(10);

    const currentData = new DateObject({calendar: persian});
    const currentData2 = new DateObject({calendar: persian});

    const lastDayDate = new DateObject({calendar: persian});
    const lastDayDate2 = new DateObject({calendar: persian});

    const [startDate, setStartDate] = useState(lastDayDate2?.subtract(2, 'day')?.convert(gregorian)?.format('YYYY-MM-DD'));

    const [endDate, setEndDate] = useState(currentData2?.convert(gregorian)?.format('YYYY-MM-DD'));

    const [transactionType, setTransactionType] = useState(0);

    const [status, setStatus] = useState(3);


    const {
        isLoading,
        data,
        dataUpdatedAt,
    } = useRequest({
        path: '/wallet/micro-transaction',
        params: {
            pageNumber: page,
            startDate: startDate,
            endDate: endDate,
            pageIndex: pageSize,
            transactionType: transactionType || null,
            status: status === 3 ? null : status,
            rowPage: 30,
        },
        options: {
            retry: false,
        },
        key: ['cashFlow', page, startDate, endDate, pageSize, transactionType, status],
    });


    const response = data || [];

    const handleFilter = () => {

        const values = filterFormRef?.getFieldsValue(true);

        setStartDate(() => {
            return new DateObject({
                date: values?.startDate,
                calendar: persian,
            })?.convert(gregorian).format('YYYY-MM-DD');
        });

        setEndDate(() => {
            return new DateObject({
                date: values?.endDate,
                calendar: persian,
            })?.convert(gregorian).format('YYYY-MM-DD');
        });
        setTransactionType(values?.transactionType);
        setStatus(values?.status);
        setFilterModal(false);
    };


    const statusType = {
        0: 'نامشخص',
        1: 'موفق',
        2: 'ناموفق',
    };

    const tableColumns = [
        {
            title: 'transactionType',
            dataIndex: 'transactionType',
            key: 'transactionType',
            align: 'start',
            render: (_, item) => <div className="text-[#21409A] text-[12px] font-[500]">
                {item?.transactionTypeDesc} - {[3, 5].includes(item?.transactionType) ? item?.toWalletName : item?.description}
            </div>,
        },

        {
            title: 'transactionDate ',
            dataIndex: 'transactionDate',
            key: 'transactionDate',
            align: 'center',
            render: (_, row) => {
                const hour = row?.transactionDate?.split('T')[1]?.split(':');
                const date = new DateObject({
                    date: new Date(row?.transactionDate),
                    calendar: gregorian,
                });
                return date.add(7, 'hour').convert(persian).format(`${hour[0]}:${hour[1]} - YYYY/MM/DD`);
            },
        },

        {
            title: 'transactionPrice',
            dataIndex: 'transactionPrice',
            key: 'transactionPrice',
            align: 'center',
            render: (_, item) => <div className={item?.status === 1 ? "text-[#00B892] text-[12px] " :
                item?.status === 2 ? "text-[#FE2301] text-[12px] " : item?.status === 0 ? "text-[#F9BD15] text-[12px] " : ""}>
                <Space className={'text-[12px]'}>
                    <div className=" text-[13px] ">
                        {formatNumber(item?.transactionPrice || 0)}
                    </div>
                    ریال
                </Space>
            </div>,
        },

        {
            title: 'transactionStatus ',
            dataIndex: 'transactionStatus',
            key: 'transactionStatus',
            align: 'center',
            render: (_, item) => <div className={`${item?.status === 0 ? 'text-[#F9BD15]' :
                item?.status === 1 ? 'text-[#00B892]' :
                    'text-[#FE2301]'}   rounded-[5px] w-full text-center h-[16px] leading-[17px] px-[5px] text-[11px] font-[500] mx-auto`}>
                {statusType[item?.status || 0]}
            </div>,
        },
    ];

    const showDesc = typeId => {
        let desc;
        if (typeId === 1) desc = 'شارژ کیف پول';
        else if (typeId === 2) desc = 'برداشت از کیف پول';
        else if (typeId === 3) desc = 'انتقال از کیف پول';
        else if (typeId === 4) desc = 'پرداخت بابت خرید';
        else if (typeId === 5) desc = 'دریافت از کیف پول';
        else if (typeId === 6) desc = 'دریافت بابت فروش';
        else if (typeId === 7) desc = 'پرداخت قبض';
        else desc = '';
        return desc;
    };


    return (
        <Spin spinning={isLoading} className={"relative"} indicator={<LoadingOutlined className={"!hidden"}/>}
              tip={<div>
                  <BeatLoader
                      color={"#1447a0"}
                      loading={true}
                      size={9}
                      aria-label="Loading Spinner"
                      data-testid="loader"
                  />
                  <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
              </div>}>
            <MatchBreakpoint min="lg">
                <Space className={'max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]'}>
                    <img src={transport}/>
                    مشاهده گردش کیف پول
                </Space>
                <Divider className={'max-lg:hidden !bg-[#C6D4FF] !mt-[9px] !mb-[25px]'}/>
                <div className={'cashback'}>
                    <Form
                        form={filterFormRef}
                        name="indexFrom"
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={{
                            span: 24,
                        }}
                        wrapperCol={{
                            span: 24,
                        }}
                        onFinish={handleFilter}
                        initialValues={{
                            transactionType: 0,
                            status: 3,
                        }}
                    >
                        <Row className="px-3 pt-3 ">
                            <Col span={24} className="__filterSection">
                                <Row gutter={20} align={'middle'} justify={'space-between'}>
                                    <Col span={20}>
                                        <Row gutter={20}>
                                            <Col span={6}>
                                                <DatePicker
                                                    name={'startDate'}
                                                    placeholder={'از تاریخ'}
                                                    hiddenLabel
                                                    initialValue={lastDayDate?.subtract(2, 'day').format('YYYY-MM-DD')}
                                                    rules={[
                                                        {
                                                            required: true,
                                                            message: inputRule('required selectBox', {inputName: 'تاریخ '}),
                                                        },
                                                    ]}
                                                    rtl

                                                />
                                            </Col>
                                            <Col span={6}>
                                                <DatePicker
                                                    name={'endDate'}
                                                    placeholder={'تا تاریخ'}
                                                    hiddenLabel
                                                    initialValue={currentData.format('YYYY-MM-DD')}

                                                    rules={[
                                                        {
                                                            required: true,
                                                            message: inputRule('required selectBox', {inputName: 'تاریخ '}),
                                                        },
                                                    ]}
                                                    rtl

                                                />
                                            </Col>
                                            <Col span={7}>
                                                <SelectBox
                                                    name="transactionType"
                                                    label={''}
                                                    allowClear={false}
                                                    options={[
                                                        {
                                                            value: 0,
                                                            label: 'همه',
                                                        },
                                                        {
                                                            value: 1,
                                                            label: 'شارژ مستقیم',
                                                        },
                                                        {
                                                            value: 2,
                                                            label: 'برداشت',
                                                        },
                                                        {
                                                            value: 3,
                                                            label: 'انتقال',
                                                        },
                                                        {
                                                            value: 4,
                                                            label: 'خرید',
                                                        },
                                                        {
                                                            value: 5,
                                                            label: 'دریافت',
                                                        },
                                                        {
                                                            value: 6,
                                                            label: 'فروش',
                                                        },
                                                        {
                                                            value: 7,
                                                            label: 'پرداخت قبض',
                                                        },
                                                        {
                                                            value: 8,
                                                            label: 'استعلام',
                                                        },
                                                        {
                                                            value: 9,
                                                            label: 'دریافت بابت استعلام',
                                                        },
                                                        {
                                                            value: 10,
                                                            label: 'دریافت بابت پرداخت قبض',
                                                        },
                                                        {
                                                            value: 11,
                                                            label: 'خرید شارژ موبایل',
                                                        },
                                                        {
                                                            value: 12,
                                                            label: 'دریافت بابت شارژ موبایل',
                                                        },
                                                        {
                                                            value: 13,
                                                            label: 'کارمزد',
                                                        },
                                                    ]}
                                                />
                                            </Col>
                                            <Col span={5}>
                                                <SelectBox
                                                    name="status"
                                                    label={''}
                                                    rules={[
                                                        {
                                                            required: true,
                                                            message: 'وضعیت تراکنش را انتخاب نمایید',
                                                        },
                                                    ]}
                                                    allowClear={false}
                                                    options={[
                                                        {
                                                            value: 3,
                                                            label: 'همه',
                                                        },
                                                        {
                                                            value: 1,
                                                            label: 'موفق',
                                                        },
                                                        {
                                                            value: 2,
                                                            label: 'ناموفق',
                                                        },
                                                        {
                                                            value: 0,
                                                            label: 'نامعلوم',
                                                        },
                                                    ]}
                                                />
                                            </Col>
                                        </Row>
                                    </Col>

                                    <Col span={4} className="text-end pb-6">
                                        <button onClick={handleFilter}
                                                className={'bg-backbtn w-full max-w-[150px] h-[42px] text-white rounded-lg'}>
                                            اعمال
                                        </button>
                                    </Col>
                                </Row>
                            </Col>

                            <Col span={24} className="__table" ref={tableRef}>
                                <Table
                                    rowClassName={'cursor-pointer'}
                                    showHeader={false}
                                    onRow={record => ({
                                        onClick: () => handleOpenModal(record),
                                    })}
                                    columns={tableColumns}
                                    className="my-form"
                                    dataSource={response}
                                    loading={isLoading}
                                    onChange={({
                                                   current,
                                                   pageSize,
                                               }) => {
                                        setPage(current);
                                        setPageSize(pageSize);
                                    }}
                                    bordered
                                    tableLayout={'fixed'}
                                    pagination={{
                                        hideOnSinglePage: true,
                                        defaultPageSize: 10,
                                        total: response?.totalCountRow,
                                        showSizeChanger: true,
                                        responsive: true,
                                        position: ['bottomLeft'],
                                        nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                                           color={'#999999'}
                                                           style={{margin: '6px auto'}}/>,
                                        prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                                           color={'#999999'}
                                                           style={{margin: '6px auto'}}/>,
                                        onChange: () => tableRef?.current.scrollIntoView({behavior: 'smooth'}),
                                    }}
                                />
                            </Col>
                        </Row>
                    </Form>

                </div>
            </MatchBreakpoint>

            <MatchBreakpoint max={'md'}>
                <CashFlowMobile
                    response={response}
                    showDesc={showDesc}
                    handleFilterModal={handleFilterModal}
                    filterModal={filterModal}
                    setFilterModal={setFilterModal}
                    currentData={currentData}
                    currentData2={currentData2}
                    lastDayDate={lastDayDate}
                    lastDayDate2={lastDayDate2}
                    startDate={startDate}
                    endDate={endDate}
                    transactionType={transactionType}
                    status={status}
                    handleFilter={handleFilter}
                    filterFormRef={filterFormRef}
                    isLoading={isLoading}
                    statusType={statusType}
                />

            </MatchBreakpoint>
        </Spin>
    )
        ;
};

export default CashFlow;