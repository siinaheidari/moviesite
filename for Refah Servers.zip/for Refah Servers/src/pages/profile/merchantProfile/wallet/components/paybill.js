import React, {useState} from 'react';
import {Col, Divider, Row, Space} from 'antd';
import ElectricityBill from "./payBill/ElectricityBill";
import {TransitionsPage} from "../../../../../templates/Ui";
import GasBill from "./payBill/GasBill";
import WaterBill from "./payBill/WaterBill";
import TelephoneBill from "./payBill/TelephoneBill";
import MobileBill from "./payBill/MobileBill";
import mobile from "assets/icons/mobile1.svg"
import {ReactComponent as IpadIcon} from 'assets/icons/ipad.svg';

const Paybill = ({goToWalletPage}) => {

    const [currentBill, setCurrentBill] = useState('');


    const bills = [
        {
            key: 'waterBill',
            component: <WaterBill handleBack={() => setCurrentBill('')} />
        },
        {
            key: 'electricityBill',
            component: <ElectricityBill handleBack={() => setCurrentBill('')} />
        },

        {
            key: 'gasBill',
            component: <GasBill handleBack={() => setCurrentBill('')} />
        },
        {
            key: 'telephoneBill',
            component: <TelephoneBill handleBack={() => setCurrentBill('')} />
        },
        {
            key: 'mobileBill',
            component: <MobileBill handleBack={() => setCurrentBill('')} />
        },
    ];


    const activeBill = bills?.find(item => item?.key === currentBill);

    return (
        <div className={""}>
            <Space className={"max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]"}>
                <IpadIcon/>
                پرداخت قبوض
            </Space>
            <Divider className={"max-lg:hidden  !bg-[#C6D4FF] !mt-[9px] !mb-[25px]"}/>
            <div className={"items-center"}>
                <TransitionsPage id={currentBill || 'initialId'} coordinates={'x'}>
                    {!currentBill ?
                        <div>
                            <h1 className={"text-[14px] max-lg:hidden font-[400]"}>لطفا قبض مورد نظر خود را انتخاب
                                کنید.</h1>
                            <Col span={24} className={" flex justify-center pt-[30px] pb-[80px]"}>
                                <Row gutter={[{xs: 10, sm: 15, md: 20}, 24]} justify={"center"}>
                                    <Col>
                                        <div onClick={() => setCurrentBill('waterBill')}
                                             className={"flex justify-center text-center items-center shadow-box rounded-[8px] w-[85px] h-[85px] cursor-pointer"}>
                                            <div>
                                                <img className={"aspect-square inline w-[45px] max-lg:w-14 mb-2"}
                                                     src={"/images/water.png"}/>
                                                <div className={"font-[400]"}>
                                                    قبض آب
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                    <Col>
                                        <div onClick={() => setCurrentBill("electricityBill")}
                                             className={"flex justify-center text-center items-center shadow-box rounded-[8px] w-[85px] h-[85px] cursor-pointer"}>
                                            <div>
                                                <img className={"aspect-square inline w-[45px] mb-2"}
                                                     src={"/images/electricity.png"}/>
                                                <div className={"font-[400]"}>
                                                    قبض برق
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                    <Col>
                                        <div onClick={() => setCurrentBill("gasBill")}
                                             className={"flex justify-center text-center items-center shadow-box rounded-[8px] w-[85px] h-[85px] cursor-pointer"}>
                                            <div>
                                                <img className={"aspect-square inline w-[45px] mb-2"}
                                                     src={"/images/gas.png"}/>
                                                <div className={"font-[400]"}>
                                                    قبض گاز
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                    <Col>
                                        <div onClick={() => setCurrentBill("telephoneBill")}
                                             className={"flex justify-center text-center items-center shadow-box rounded-[8px] w-[85px] h-[85px] cursor-pointer"}>
                                            <div>
                                                <img className={"inline w-[45px] mb-[12px]"}
                                                     src={"/images/telephone.png"}/>
                                                <div className={"font-[400]"}>
                                                    قبض تلفن
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                    <Col>
                                        <div onClick={() => setCurrentBill("mobileBill")}
                                             className={"flex justify-center text-center items-center shadow-box rounded-[8px] w-[85px] h-[85px] cursor-pointer"}>
                                            <div>
                                                <img className={"inline w-[25px] mb-[12px]"} src={mobile}/>
                                                <div className={"font-[400]"}>
                                                    قبض موبایل
                                                </div>
                                            </div>
                                        </div>
                                    </Col>
                                </Row>
                            </Col>
                        </div> :
                        activeBill?.component
                    }
                </TransitionsPage>
            </div>
        </div>
    );
};

export default Paybill;