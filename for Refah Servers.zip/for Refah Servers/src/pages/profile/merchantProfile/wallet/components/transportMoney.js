import React, {useRef, useState} from 'react';
import {LeftOutlined, LoadingOutlined} from '@ant-design/icons';
import {Col, Divider, Form, Row, Space, Spin, Statistic} from 'antd';

import styled from 'styled-components';
import {Button, Input, Modal, TransitionsPage} from 'templates/Ui';
import {formatNumber, inputRule} from 'utils/helper';
import {useRequest} from 'utils/useRequest';
import {useAuth} from '../../../../../contexts/auth/AuthContext';
import starkString from 'starkstring';
import facilities from '../../../../../assets/images/facilities.svg';
import transport from 'assets/icons/transport.svg';
import {toast} from 'react-toastify';
import {requestMessages} from '../../../../../utils/axios/requestMessages';
import SendPinReminder from "./SendPinReminder";
import {useQueryClient} from "@tanstack/react-query";
import {Link} from "react-router-dom";
import refahLogo from "assets/icons/refahLogo.svg"
import {BeatLoader} from "react-spinners";


const ForgetPasswordContainer = styled(Row)`
  .--title {
    margin-bottom: 50px;
    text-align: center;
    font-size: 1rem;
  }

  .--otpStatus {
    &,
    .ant-statistic-content {
      color: #557EFF;
      font-size: .875rem;
    }

    .__resend {
      display: inline-block;
      cursor: pointer;

      &:hover {
        color: #3264ff;
      }

      &.--disable {
        pointer-events: none;
      }
    }
  }

  .--btn {
    margin-top: 30px;
  }

  .--goToSignIn {
    margin-top: 35px;
  }
`;

const layout = {
    labelCol: {
        span: 24,
    },
    wrapperCol: {
        span: 24,
    },
};

const TransportMoney = () => {
    const {auth} = useAuth();

    const {Countdown} = Statistic;
    const [transportFormRef] = Form.useForm();
    const userMobile = transportFormRef?.getFieldValue('mobile');
    const increaseWalletWatch = Form.useWatch('amount', transportFormRef);
    const mobileWatch = Form.useWatch('mobile', transportFormRef);
    const otpInputWatch = Form.useWatch('inputCode', transportFormRef);
    const [transportStep, setTransportStep] = useState(0);
    const [resendCode, setResendCode] = useState(false);
    const [submitVisible, setSubmitVisible] = useState(false);

    const [transactionDetailModal, setTransactionDetailModal] = useState(false);
    const mobile = Form.useWatch('mobile', transportFormRef);
    const inputsRef = useRef([]);
    const queryClient = useQueryClient();

    const {
        isLoading: sendOtpIsLoading,
        mutateAsync: sendOtpRequest,
        isSuccess: sendOtpIsSuccess,
    } = useRequest({
        path: '/wallet/otp',
        isMutation: true,
        customSuccessMessage: 'رمز پویا با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال رمز پویا لطفا مجددا تلاش فرمایید',
    });


    const {
        isLoading: findWalletKeyIsLoading,
        data: findWalletKeyData,
        refetch: findWalletKeyRequest,
    } = useRequest({
        path: '/wallet/find-wallet-key',
        key: ['find-wallet-key', mobileWatch],
        params: {
            mobileNumber: mobileWatch || null,
        },
        options: {
            enabled: false,
            cacheTime: 0,
            retry: false,
        },
    });

    const walletKeyRes = findWalletKeyData?.[0];


    const {
        isLoading: transferIsLoading,
        mutateAsync: transferRequest,
        data: transferData
    } = useRequest({
        path: '/wallet/transfer',
        isMutation: true,
        customSuccessMessage: 'اتقال با موفقیت انجام شد',
    });


    const transferRes = transferData?.response?.[0] || [];


    const handleOpenModal = async () => {
        try {
            await transportFormRef?.validateFields();

            const res = await findWalletKeyRequest();

            if (!!res?.data?.length) {
                const toWalletIdentifier = res?.data[0]?.walletIdentifier;

                await transportFormRef.setFieldValue(
                    'toWalletIdentifier',
                    toWalletIdentifier,
                );

                setTransactionDetailModal(true);
            } else {
                const findMessage = await requestMessages.find(
                    (item) => item?.en === res?.error?.message,
                );

                await toast.error(
                    findMessage?.fa || 'خطا در دریافت اطلاعات لطفا مجددا تلاش کنید',
                    {
                        toastId: 'find-wallet-key' + '/' + mobileWatch,
                    },
                );
            }
        } catch (error) {
            console.log('error in handleOpenConfirmModal >>>', error);
        }
    };


    const handleSendOtp = async () => {
        try {
            await sendOtpRequest({amount: 5000});
            await setTransportStep(1);
            await setTransactionDetailModal(false);
        } catch (error) {
            console.log('error in handleSendOtp >>>>', error);
        }
    };

    const handleTransport = async () => {
        try {
            await transportFormRef.validateFields(['otp']);
            const values = transportFormRef.getFieldsValue(true);

            await transferRequest({
                walletIdentifier: auth?.walletIdentifier,
                otp: values.otp,
                amount: +(values?.amount?.replace(/,/g, '')),
                toWalletIdentifier: values?.toWalletIdentifier,
            });

            await queryClient.refetchQueries(['request', "walletInventoryRequest", auth?.walletIdentifier]);

            await setTransportStep(2)

        } catch (error) {

        }
    };


    const handleAmountButtons = amount => {
        transportFormRef.setFields([{
            name: 'amount',
            value: formatNumber(starkString(amount).parseNumber().englishNumber().toString()),
        }]);
    };

    const handleOnInput = (event, count, index) => {
        const {value} = event.target;
        if (value.length === count) {
            event.preventDefault();
            if (index < inputsRef.current.length - 1) {
                inputsRef.current[index + 1].focus();
            }
        }
    };


    const {
        isLoading: walletInventoryIsLoading,
        data: walletInventory,

    } = useRequest({
        path: '/wallet/inventory',
        key: ["walletInventoryRequest", auth?.walletIdentifier],
        params: {
            walletIdentifier: auth.walletIdentifier || null,
        },
        options: {
            enabled: !!auth?.walletIdentifier,
            cacheTime: 0,
        },

    });

    const response = walletInventory?.balance || {}



    return (
        <TransitionsPage coordinates={'x'}>

            <Spin spinning={transferIsLoading || sendOtpIsLoading} className={"relative"}
                  indicator={<LoadingOutlined className={"!hidden"}/>} tip={<div>
                <BeatLoader
                    color={"#1447a0"}
                    loading={true}
                    size={9}
                    aria-label="Loading Spinner"
                    data-testid="loader"
                />
                <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
            </div>}>

                <Space className={'max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]'}>
                    <img src={transport}/>
                    انتقال
                </Space>


                <Divider className={'max-lg:hidden !bg-[#C6D4FF] !mt-[9px] !mb-[25px]'}/>

                <>
                    <Form
                        form={transportFormRef}
                        {...layout}
                        name="forgetPasswordFrom"
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={{
                            span: 24,
                        }}
                        wrapperCol={{
                            span: 24,
                        }}
                        onFinish={handleTransport}
                    >
                        <ForgetPasswordContainer className="">
                            {transportStep === 0 &&
                                <div className={'items-center w-full'}>

                                    <Col xs={24} lg={24}>
                                        <Input
                                            name={'mobile'}
                                            label={'شماره موبایل'}
                                            rules={[
                                                {
                                                    required: true,
                                                    message: inputRule('required input', {inputName: 'شماره موبایل مقصد'}),
                                                },
                                                {
                                                    pattern: new RegExp(/^[0-9]+$/),
                                                    message: inputRule('must be number input', {inputName: 'شماره موبایل مقصد'}),
                                                },
                                                {
                                                    min: 11,
                                                    message: inputRule('minLength input', {
                                                        inputName: 'شماره موبایل مقصد',
                                                        length: 11,
                                                    }),
                                                    validateTrigger: 'onBlur',
                                                },
                                                {
                                                    max: 11,
                                                    message: inputRule('maxLength input', {
                                                        inputName: 'شماره موبایل مقصد',
                                                        length: 11,
                                                    }),
                                                },
                                            ]}
                                            maxLength={11}
                                            justNumber
                                            formRef={transportFormRef}
                                            ltr
                                            focus
                                            ref={el => inputsRef.current[1] = el}
                                            onInput={(e) => handleOnInput(e, 11, 1)}
                                        />
                                    </Col>

                                    <div className={' w-full'}>
                                        <p className={'!mb-3 max-lg:text-[12px] font-[400] max-lg:font-[500] '}>مبالغ
                                            پیش
                                            فرض</p>


                                        <div className={'mb-4'}>
                                            <div className={'flex gap-4 items-center text-center '}>
                                                <Button type={"default"} onClick={() => handleAmountButtons(1000000)}
                                                        className={'focus:bg-textblue focus:!text-white hover:bg-textblue hover:!text-white !border-[#D9D9D9] shadow-shadow !items-center !text-center !h-[42px] max-lg:w-1/3 !border rounded-md w-1/3 cursor-pointer'}>
                                                    <p className={'leading-[38px] max-lg:text-[12px] max-lg:font-[400]'}>۱,۰۰۰,۰۰۰
                                                        ریال</p>
                                                </Button>
                                                <Button type={"default"} onClick={() => handleAmountButtons(2000000)}
                                                        className={'focus:bg-textblue focus:text-white hover:bg-textblue !border-[#D9D9D9] hover:!text-white shadow-shadow !items-center !text-center !h-[42px] max-lg:w-1/3 !border rounded-md w-1/3 cursor-pointer'}>
                                                    <p className={'leading-[38px] max-lg:text-[12px] max-lg:font-[400]'}>۲,۰۰۰,۰۰۰
                                                        ریال</p>
                                                </Button>
                                                <Button type={"default"} onClick={() => handleAmountButtons(5000000)}
                                                        className={'focus:bg-textblue focus:text-white hover:bg-textblue hover:!text-white !border-[#D9D9D9] shadow-shadow !items-center !text-center !h-[42px] max-lg:w-1/3 !border rounded-md w-1/3 cursor-pointer'}>
                                                    <p className={'leading-[38px] max-lg:text-[12px] max-lg:font-[400]'}>۵,۰۰۰,۰۰۰
                                                        ریال</p>
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                    <div/>
                                    <Col xs={24} lg={24}>
                                        <Input
                                            name="amount"
                                            label="مبلغ (ریال)"
                                            placeholder={'مبلغ (ریال)'}
                                            validateFirst
                                            rules={[
                                                {
                                                    required: true,
                                                    message: inputRule('required input', {inputName: 'مبلغ'}),
                                                },
                                                {
                                                    validator: (_, value) => {
                                                        if (value?.length && +(value?.replace(/,/g, '')) < 10000) {
                                                            return Promise.reject(new Error(inputRule('minLength amount', {
                                                                inputName: 'مبلغ',
                                                                length: '10,000 ریال',
                                                            })));
                                                        }

                                                        return Promise.resolve();
                                                    },
                                                },
                                                {
                                                    validator: (_, value) => {
                                                        if (value?.length && +(value?.replace(/,/g, '')) > 1000000000) {
                                                            return Promise.reject(new Error(inputRule('maxLength amount', {
                                                                inputName: 'مبلغ',
                                                                length: '1,000,000,000 ریال',
                                                            })));
                                                        }

                                                        return Promise.resolve();
                                                    },
                                                },
                                                {
                                                    validator: (_, value) => {
                                                        if (value > response) {
                                                            return Promise.reject(new Error(inputRule('maxAmount amount', {
                                                                inputName: 'مبلغ',
                                                                // length: formatNumber(response),
                                                            })));
                                                        }

                                                        return Promise.resolve();
                                                    },
                                                },
                                            ]}
                                            ref={el => inputsRef.current[2] = el}
                                            maxLength={response?.toString().length}
                                            onPressEnter={handleOpenModal}
                                        />
                                    </Col>

                                    <Col xs={24} sm={24} lg={8} className={' mb-[10px] mx-auto mt-[70px]'}>
                                        <Button
                                            loading={findWalletKeyIsLoading}
                                            className={'w-full '}
                                            type={'secondary'}
                                            onClick={handleOpenModal}
                                            icon={<LeftOutlined/>}
                                            iconAlign={'end'}
                                        >
                                            ادامه
                                        </Button>
                                    </Col>
                                    <Modal
                                        open={transactionDetailModal}
                                        onCancel={() => setTransactionDetailModal(false)}
                                        size={{
                                            sm: 90,
                                            xs: 90,
                                            md: 90,
                                            lg: 55,
                                            xl: 55,
                                            xxl: 30,
                                        }}
                                        header={false}
                                        closable={false}
                                        bodyStyle={{
                                            padding: 5,
                                            backgroundColor: 'rgba(140,140,140)',
                                        }}
                                        style={{
                                            top: '28vh',
                                        }}
                                    >
                                        <div
                                            className={'lg:px-[49px] max-lg:px-[18px] bg-white lg:pt-[30px] rounded-[10px] pb-[38px] items-center text-center m-auto'}>
                                            <div className={'relative top-[-6px] lg:hidden'}>
                                                <img src={facilities} className={'mx-auto '}/>
                                                <div
                                                    className={'relative text-white top-[-26px] mx-auto text-center items-center text-[12px]'}>
                                                    اطلاعات مقصد
                                                </div>
                                            </div>
                                            <div
                                                className={' text-center items-center text-textcolor max-lg:!text-[12px] max-lg:mt-[11px]'}>
                                                <h1 className={'pb-4 text-textblue text-[16px] max-lg:hidden'}>اطلاعات
                                                    مقصد</h1>
                                                <div className={'flex justify-between gap-2 mx-auto pb-[16px] '}>
                                                    <h1>نام:</h1>
                                                    <h1>{walletKeyRes?.PersonName}</h1>
                                                </div>
                                                <div
                                                    className={'flex justify-between gap-2 mx-auto pb-8 max-lg:pb-[40px]'}>
                                                    <h1>شناسه کیف پول:</h1>
                                                    <h1>{walletKeyRes?.walletIdentifier}</h1>
                                                </div>
                                            </div>
                                            <Col xs={24} sm={24} className={' mb-[10px] mx-auto'}>
                                                <Button
                                                    className={'w-full '}
                                                    type={'secondary'}
                                                    onClick={handleSendOtp}
                                                    loading={sendOtpIsLoading}
                                                    icon={<LeftOutlined/>}
                                                    iconAlign={'end'}
                                                >
                                                    تایید و ارسال کد یکبار مصرف
                                                </Button>
                                            </Col>
                                        </div>
                                    </Modal>
                                </div>
                            }
                            {transportStep === 1 &&
                                <div className={'w-full items-center'}>
                                    <div className={'w-full mb-[30px]'}>
                                        <Input
                                            name={'otp'}
                                            noPlaceHolder
                                            maxLength={6}
                                            label={('کد ارسال شده را وارد نمایید')?.replaceAll('{{mobileNumber}}', userMobile)}
                                            rules={[
                                                {
                                                    required: true,
                                                    message: inputRule('required input', {inputName: 'کد تایید'}),
                                                },
                                            ]}
                                        />
                                    </div>
                                    {
                                        resendCode ? ""
                                            : <div onClick={handleSendOtp} className={"text-textblue cursor-pointer"}>
                                                ارسال مجدد
                                            </div>
                                    }


                                    <Col span={24} className="mt-[10px]">
                                        <SendPinReminder
                                            resendCode={resendCode}
                                            setResendCode={setResendCode}
                                            sendPinIsSuccess={sendOtpIsSuccess}

                                        />
                                    </Col>
                                    <Col xs={24} sm={12} lg={8}
                                         className={'lg:mt-[9rem] max-lg:mt-[7rem] m-auto text-center items-center mb-[10px] mx-auto'}>
                                        <Button
                                            type={'secondary'}
                                            htmlType={'submit'}
                                            className={'w-full'}
                                            icon={<LeftOutlined/>}
                                            iconAlign={'end'}
                                            loading={transferIsLoading}
                                        >
                                            انتقال
                                        </Button>
                                    </Col>

                                </div>
                            }
                        </ForgetPasswordContainer>
                    </Form>
                </>
                {
                    transportStep === 2 &&
                    <div className={'bg-white text-center items-center lg:w-full lg:max-w-[600px] mx-auto'}>
                        <div className={'text-textcolor text-[14px]'}>
                            <div className={'m-auto text-center items-center lg:pb-6 max-lg:pb-4'}>
                                <img className={'inline text-tick pb-5 drop-shadow-xl'}
                                     src={'/images/Tick Square.svg'}/>

                                <h1 className={'text-[#1CC500] text-[16px] max-lg:text-[12px] font-[500]'}>
                                    انتقال با موفقیت انجام شد
                                </h1>

                            </div>
                            <div
                                className={'flex justify-between gap-3 items-center max-lg:text-[12px]'}>
                                <h1>مبلغ:</h1>
                                <h1 className={"text-textblue font-[600]"}>  {formatNumber(transferRes?.transactionPrice)} ریال </h1>
                            </div>
                            <div
                                className={'flex justify-between gap-3 items-center max-lg:text-[12px] pb-[27px] max-lg:pb-[10px]'}>
                            </div>

                            <div
                                className={'flex justify-between gap-3 items-center max-lg:text-[12px] pb-[27px] max-lg:pb-[10px]'}>
                                <h1>کد رهگیری:</h1>
                                <h1 className={"text-textblue font-[500]"}>{transferRes?.referenceNumber}</h1>

                            </div>

                            <div
                                className={'flex justify-between gap-3 items-center max-lg:text-[12px] pb-[43px] max-lg:pb-[23px]'}>
                                <h1>تاریخ و ساعت:</h1>
                                <h1 className={"text-textblue font-[500]"}>{transferRes?.transactionDate}</h1>
                            </div>
                            <Col xs={24} sm={18} lg={16} className={'mx-auto relative'}>
                                <Button
                                    type={'default'}
                                    className={'w-full'}

                                >
                                    بازگشت به صفحه کیف پول
                                </Button>
                                <Link to={"/merchantProfile/wallet"} className={"absolute inset-0"}/>
                            </Col>
                        </div>
                    </div>
                }
                {/*{*/}
                {/*    transportStep === 3 &&*/}
                {/*    <div className={'bg-white !text-center !items-center lg:w-2/3 m-auto  '}>*/}
                {/*        <div className={'text-textcolor text-[14px] '}>*/}
                {/*            <div className={'m-auto !text-center !items-center pb-8 '}>*/}
                {/*                <img className={'inline text-tick pb-5 drop-shadow-xl'}*/}
                {/*                     src={'/images/Close Square.svg'}/>*/}
                {/*                <h1 className={'text-error text-[16px] max-lg:text-[14px] max-lg:font-[500]'}>*/}
                {/*                    انتقال ناموفق*/}
                {/*                </h1>*/}
                {/*            </div>*/}
                {/*            <div className={'flex justify-between items-center max-lg:text-[12px] font-[500] pb-[27px]'}>*/}
                {/*                <h1>توضیحات:</h1>*/}
                {/*                /!*<h1>{ errorMessages[transportMoneyError?.output] || '--' }</h1>*!/*/}
                {/*            </div>*/}
                {/*            <Col xs={24} sm={18} lg={20} className={'mx-auto mt-[50px]'}>*/}
                {/*                <Button*/}
                {/*                    type={'default'}*/}
                {/*                    className={'w-full'}*/}

                {/*                >*/}
                {/*                    بازگشت به صفحه کیف پول*/}
                {/*                </Button>*/}
                {/*            </Col>*/}
                {/*        </div>*/}
                {/*    </div>*/}
                {/*}*/}
            </Spin>
        </TransitionsPage>
    );
};

export default TransportMoney;

