import React, {useRef, useState} from 'react';
import {Col, Divider, Form, Row, Select, Space, Spin} from 'antd';
import {formatCadNumber, inputRule} from '../../../../../utils/helper';
import {useRequest} from '../../../../../utils/useRequest';
import {Button, Input, SelectBox} from '../../../../../templates/Ui';
import {LeftOutlined, LoadingOutlined} from '@ant-design/icons';
import increase from 'assets/icons/increaseMoney.svg';
import styled from 'styled-components';
import {Link, useNavigate} from 'react-router-dom';
import {useAuth} from '../../../../../contexts/auth/AuthContext';
import SendPinReminder from "./SendPinReminder";
import tw from "twin.macro";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../assets/icons/refahLogo.svg";


const CustomLabel = styled(Col)`
  font-weight: 400;
  color: #646464 !important;
  font-size: 14px !important;
  padding-bottom: 9px;
  margin-top: 4.5px;
  ${tw`max-lg:!mt-[7.2px]`};
  text-align: start !important;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  ${tw`max-lg:!text-[12px]`};

  &:before {
    display: inline-block;
    margin-inline-end: 4px;
    color: #c62606;
    font-size: 14px;
    font-family: SimSun, sans-serif;
    line-height: 1;
    content: "*";
    ${tw`max-lg:!text-[12px]`};
  }
`;


const layout = {
    labelCol: {
        span: 24,
    },
    wrapperCol: {
        span: 24,
    },
};
const IncreaseMoney = () => {

    const {auth} = useAuth();
    const [increaseMoneyForm] = Form.useForm();
    const increaseWalletWatch = Form.useWatch('amount', increaseMoneyForm);
    const inputsRef = useRef([]);
    const [resendCode, setResendCode] = useState(false);
    const navigate = useNavigate()

    const {
        isLoading: cartTypeDataIsLoading,
        data: cartTypeData,
    } = useRequest({
        path: '/wallet/iban-pan',
        key: ['cartType'],
        options: {
            retry: false,
        },
    });

    const cartType = cartTypeData || [];


    const {
        isLoading: sendPinIsLoading,
        mutateAsync: sendPinRequest,
        isSuccess: sendPinIsSuccess,
    } = useRequest({
        path: '/wallet/pin',
        customSuccessMessage: 'رمز پویا با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال رمز پویا لطفا مجددا تلاش فرمایید',
        isMutation: true,
    });

    const {
        isLoading: walletChargeIsLoading,
        mutateAsync: walletChargeRequest,
    } = useRequest({
        path: '/wallet/pin',
        isMutation: true,

    });


    const handleSendPin = async () => {
        try {
            await increaseMoneyForm?.validateFields(['panSelected', 'cvv2', 'expireMonth', 'expireYear', 'amount']);

            const values = increaseMoneyForm?.getFieldsValue(true);

            await sendPinRequest({
                ...values,
                amount: +(values?.amount?.replace(/,/g, '')),
            });

        } catch (error) {
            console.log('error in handleSendPin >>> ', error);
        }
    };


    const handleIncreaseMoneyForm = async () => {
        try {
            await increaseMoneyForm?.validateFields;
            const formData = increaseMoneyForm.getFieldsValue(true);
            await walletChargeRequest({
                ...formData,
                type: 'bpg',
                walletIdentifier: auth.walletIdentifier,
            });

            navigate('/merchantProfile/wallet');

        } catch (error) {
            navigate('/merchantProfile/wallet');
        }
    };
    console.log(auth);
    const handleOnInput = (event, count, index) => {
        const {value} = event.target;
        if (value.length === count) {
            event.preventDefault();
            if (index < inputsRef.current.length - 1) {
                inputsRef.current[index + 1].focus();
            }
        }
    };

    const handleOnKeyDown = (event, index) => {
        if (event.key === 'Backspace' && event.target.value === '') {
            event.preventDefault();
            if (index > 0) {
                inputsRef.current[index - 1].focus();
            }
        }
    };

    const handleOnChange = (event, index) => {
        if (event) {
            if (index < inputsRef.current.length - 1) {
                inputsRef.current[index + 1].focus();
            }
        }
    };

    return (
        <Spin spinning={sendPinIsLoading || walletChargeIsLoading} className={"relative"}
              indicator={<LoadingOutlined className={"!hidden"}/>} tip={<div>
            <BeatLoader
                color={"#1447a0"}
                loading={true}
                size={9}
                aria-label="Loading Spinner"
                data-testid="loader"
            />
            <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
        </div>}>
            <Space className={'max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]'}>
                <img src={increase}/>
                افزایش موجودی
            </Space>
            <Divider className={'max-lg:hidden !bg-[#C6D4FF] !mt-[9px] !mb-[25px]'}/>
            {/*<Spin>*/}
            <Form
                {...layout}
                form={increaseMoneyForm}
                name="increaseMoneyForm"
                onFinish={handleIncreaseMoneyForm}
            >

                <Col xs={24} lg={24}>
                    <SelectBox
                        name="panSelected"
                        label="انتخاب کارت"
                        loading={cartTypeDataIsLoading}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required selectBox', {inputName: 'کارت'}),
                            },
                        ]}
                        allowClear
                        focus
                        showSearch={false}
                        dropdownRender={menu => {
                            return (
                                <>
                                    <div className={' flex gap-2 items-center px-2.5 py-[2px]'}>
                                        <p className={'relative text-[18px] text-blue-400 cursor-pointer'}>+</p>
                                        <div className={'relative text-blue-400 cursor-pointer'}>اضافه کردن کارت بانکی
                                        </div>
                                        <Link to={'/merchantProfile/wallet/add-cart-bank'}
                                              className={'absolute inset-0'}></Link>
                                    </div>

                                    <Divider style={{margin: '8px 0'}}/>
                                    {menu}
                                </>
                            );
                        }}
                        formRef={increaseMoneyForm}
                        ref={el => inputsRef.current[0] = el}
                        onChange={e => handleOnChange(e, 0)}
                    >
                        {cartType?.map(item => (
                            <Select.Option value={item?.rowId}
                                           ref={el => inputsRef.current[1] = el}>
                                {formatCadNumber(item?.pan)}
                            </Select.Option>
                        ))}

                    </SelectBox>
                </Col>

                <Row gutter={10} className={"max-lg:mb-[7px] max-lg:mt-[-9px]"}>
                    <Col span={12}>
                        <Input
                            name={'cvv2'}
                            label={'cvv2'}
                            allowClear={false}
                            justNumber
                            inputClassName='!min-h-[41px]'
                            maxLength={4}
                            formRef={increaseMoneyForm}
                            ref={el => inputsRef.current[1] = el}
                            onKeyDown={(e) => handleOnKeyDown(e, 1)}
                            onInput={(e) => handleOnInput(e, 4, 1)}
                            rules={[
                                {
                                    required: true,
                                    message: inputRule('required input', {inputName: 'cvv2'}),
                                },
                                {
                                    min: 4,
                                    message: inputRule('minLength input', {
                                        inputName: 'cvv2',
                                        length: 4
                                    }),
                                },
                            ]}

                        />
                    </Col>

                    <Col span={12}>
                        <Row gutter={10}>
                            <CustomLabel span={24}>
                                تاریخ انقضا
                            </CustomLabel>

                            <Col span={12}>
                                <Input
                                    name={'expireMonth'}
                                    placeholder={'ماه'}
                                    justNumber
                                    maxLength={2}
                                    inputClassName='!min-h-[41px]'
                                    formRef={increaseMoneyForm}
                                    allowClear={false}
                                    ref={el => inputsRef.current[2] = el}
                                    onInput={(e) => handleOnInput(e, 2, 2)}
                                    onKeyDown={(e) => handleOnKeyDown(e, 2)}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'ماه'}),
                                        },
                                        {
                                            min: 2,
                                            message: inputRule('minLength input', {
                                                inputName: 'ماه',
                                                length: 2
                                            }),
                                        },
                                    ]}

                                />
                            </Col>

                            <Col span={12}>
                                <Input
                                    name={'expireYear'}
                                    placeholder={'سال'}
                                    hiddenLabel
                                    justNumber
                                    inputClassName='!min-h-[41px]'
                                    minLength={2}
                                    maxLength={2}
                                    formRef={increaseMoneyForm}
                                    allowClear={false}
                                    ref={el => inputsRef.current[3] = el}
                                    onInput={(e) => handleOnInput(e, 2, 2)}
                                    onKeyDown={(e) => handleOnKeyDown(e, 3)}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'سال'}),
                                        },
                                    ]}
                                />
                            </Col>
                        </Row>
                    </Col>

                </Row>

                <Col xs={24} lg={24}>
                    <Input
                        name="amount"
                        label="مبلغ (ریال)"
                        placeholder={'مبلغ (ریال)'}
                        validateFirst
                        justNumber
                        formRef={increaseMoneyForm}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'مبلغ'}),
                            },
                            {
                                validator: (_, value) => {
                                    if (value?.length && +(value?.replace(/,/g, '')) < 10000) {
                                        return Promise.reject(new Error(inputRule('minLength amount', {
                                            inputName: 'مبلغ',
                                            length: '10,000 ریال',
                                        })));
                                    }

                                    return Promise.resolve();
                                },
                            },
                            {
                                validator: (_, value) => {
                                    if (value?.length && +(value?.replace(/,/g, '')) > 10000000000) {
                                        return Promise.reject(new Error(inputRule('maxLength amount', {
                                            inputName: 'مبلغ',
                                            length: '10,000,000,000 ریال',
                                        })));
                                    }

                                    return Promise.resolve();
                                },
                            },
                        ]}
                        ref={el => inputsRef.current[4] = el}
                        ltr

                    />
                </Col>


                <Col xs={24} lg={24}>
                    <Row>
                        <Col flex="1 1">
                            <Input
                                name={'pin'}
                                label={'رمز پویا'}
                                formRef={increaseMoneyForm}
                                className={'!rounded-s-none'}
                                placeholder={'رمز پویا'}
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'رمز پویا'}),
                                    },
                                ]}
                            />
                        </Col>

                        <Col flex="19%" className={'items-center'}>
                            {
                                resendCode ?

                                    <Button
                                        block
                                        type={'secondary'}
                                        className="!mt-[36px] !h-[43px] !rounded-s-none text-[12px] !bg-purple !border-white"
                                        height={42}
                                        width={'100%'}
                                        disabled={!!resendCode}
                                        onClick={handleSendPin}
                                    >
                                        ارسال مجدد
                                    </Button> :
                                    <Button
                                        block
                                        type={'secondary'}
                                        className="!mt-[36px] !h-[43px] !rounded-s-none max-lg:text-[12px] !bg-purple !border-white"
                                        height={42}
                                        width={'100%'}
                                        onClick={handleSendPin}
                                    >
                                        دریافت رمز پویا
                                    </Button>
                            }
                        </Col>
                        <Col span={24} className="mt-[10px]">
                            <SendPinReminder
                                resendCode={resendCode}
                                setResendCode={setResendCode}
                                sendPinIsSuccess={sendPinIsSuccess}

                            />
                        </Col>
                    </Row>
                </Col>


                <Col xs={24} sm={10} lg={8} className={'mb-[13px] mx-auto mt-[3rem]'}>
                    <Button
                        className={'w-full'}
                        type={'secondary'}
                        htmlType={'submit'}
                        icon={<LeftOutlined/>}
                        iconAlign={'end'}
                        loading={walletChargeIsLoading}
                    >
                        افزایش کیف پول
                    </Button>
                </Col>

            </Form>
            {/*</Spin>*/}
        </Spin>
    );
};

export default IncreaseMoney;