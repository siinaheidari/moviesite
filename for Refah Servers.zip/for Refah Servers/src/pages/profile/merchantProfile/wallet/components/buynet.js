import React, {useEffect, useRef, useState} from 'react';
import {Col, Divider, Form, Radio, Row, Select, Space, Spin} from 'antd';
import {Button, Input, SelectBox} from '../../../../../templates/Ui';
import {inputRule} from '../../../../../utils/helper';
import {useRequest} from '../../../../../utils/useRequest';
import {ReactComponent as NetIcon} from 'assets/icons/net.svg';
import {getMobileOperator} from '../../../../../utils/mobileCheckers';
import styled from "styled-components";
import {useQueryClient} from "@tanstack/react-query";
import {useAuth} from "../../../../../contexts/auth/AuthContext";
import {LeftOutlined, LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../assets/icons/refahLogo.svg";
import dowanload from "assets/icons/download.svg"
import {useNavigate} from "react-router-dom";


const layout = {
    labelCol: {
        span: 24,
    },
    wrapperCol: {
        span: 24,
    },
};


const RadioContainer = styled(Col)`

  .ant-radio-button-checked {
    background-color: #E8F0FE;
    border: 1px solid #CDDAFF !important;
    scale: 1.05;
    border-radius: 5px;
  }

`


const BuyNet = ({goToWalletPage}) => {
    const {auth} = useAuth()
    const [buyNetForm] = Form.useForm();
    const [buyNetStep, setBuyNetStep] = useState(0);
    const inputsRef = useRef([]);
    const mobileWatch = Form.useWatch('mobileNumber', buyNetForm);
    const queryClient = useQueryClient();
    const [selectedPackage, setSelectedPackage] = useState("")
    const navigate = useNavigate()


    const {
        mutateAsync: packagesRequest,
        isLoading: packagesLoading,
        data: packages,
    } = useRequest({
        path: '/services/bills/inquiry/internet-packages',
        isMutation: true,
    });

    const response = packages || []


    const {
        mutateAsync: buyNetRequest,
        isLoading: buyNetLoading,
    } = useRequest({
        path: '/services/bills/pay/buy-internet',
        isMutation: true,
    });


    const handlePackages = async () => {
        try {
            await buyNetForm.validateFields()
            const values = buyNetForm.getFieldsValue(true)
            console.log(values)
            await packagesRequest({
                ...values
            })

        } catch (err) {
            console.log(err);
        }
    };


    console.log(selectedPackage)

    const handleBuyNet = async () => {

        try {
            const formData = buyNetForm.getFieldsValue(true)
            console.log("adsdasads", formData)

            await setSelectedPackage("552320665")
            await buyNetRequest({
                operator: formData?.operator,
                packageId: selectedPackage,
                mobileNumber: formData?.mobileNumber
            })
            await navigate("/merchantProfile/wallet")
        } catch (err) {
            navigate("/merchantProfile/wallet")
            console.log(err)
        }
    };


    const handleOnInput = (event, count, index) => {
        const {value} = event.target;
        if (value.length === count) {
            event.preventDefault();
            if (index < inputsRef.current.length - 1) {
                inputsRef.current[index + 1].focus();
            }
        }
    };


    useEffect(() => {
        if (mobileWatch?.length >= 4) {
            buyNetForm.setFields([
                {
                    name: 'operator',
                    value: getMobileOperator(mobileWatch),
                    errors: [],
                },
            ]);
        }
    }, [mobileWatch]);

    return (
        <Spin spinning={packagesLoading} className={"relative"} indicator={<LoadingOutlined className={"!hidden"}/>}
              tip={<div>
                  <BeatLoader
                      color={"#1447a0"}
                      loading={true}
                      size={9}
                      aria-label="Loading Spinner"
                      data-testid="loader"
                  />
                  <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
              </div>}>
            <div className={'bg-white max-lg:px-[18px] pt-[20px] pb-[50px] rounded-[10px] '}>
                <Space className={'max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]'}>
                    <NetIcon/>
                    بسته اینترنت
                </Space>
                <Divider className={'max-lg:hidden  !bg-[#C6D4FF] !mt-[9px] !mb-[25px]'}/>
                <Form
                    {...layout}
                    form={buyNetForm}
                    name="buyNetForm"
                    onFinish={handleBuyNet}

                >
                    {buyNetStep === 0 &&
                        <div>
                            <div>
                                <Row gutter={16}>

                                    <Col xs={24} lg={16}>
                                        <Input
                                            name={'mobileNumber'}
                                            label={'شماره موبایل'}

                                            rules={[
                                                {
                                                    required: true,
                                                    message: inputRule('required input', {inputName: 'شماره موبایل مقصد'}),
                                                },
                                                {
                                                    pattern: new RegExp(/^[0-9]+$/),
                                                    message: inputRule('must be number input', {inputName: 'شماره موبایل مقصد'}),
                                                },
                                                {
                                                    min: 11,
                                                    message: inputRule('minLength input', {
                                                        inputName: 'شماره موبایل مقصد',
                                                        length: 11,
                                                    }),
                                                    validateTrigger: 'onBlur',
                                                },
                                                {
                                                    max: 11,
                                                    message: inputRule('maxLength input', {
                                                        inputName: 'شماره موبایل مقصد',
                                                        length: 11,
                                                    }),
                                                },
                                                {
                                                    validator: (_, value) => (value?.length >= 4 && !getMobileOperator(value)) ?
                                                        Promise.reject(new Error('پیش شماره وارد شده جزو اپراتور های همراه اول - ایرانسل یا رایتل نمیباشد')) :
                                                        Promise.resolve(),
                                                },
                                            ]}
                                            maxLength={11}
                                            justNumber
                                            formRef={buyNetForm}
                                            focus

                                        />
                                    </Col>
                                    <RadioContainer xs={24} sm={12} lg={8}
                                                    className={'max-sm:flex max-lg:justify-center max-lg:mt-[20px]'}>
                                        <Form.Item
                                            className={'form'}
                                            name="operator"
                                            label={'اپراتور'}
                                            rules={[
                                                {
                                                    required: true,
                                                    message: 'لطفا اپراتور را انتخاب نمایید',
                                                },

                                            ]}

                                        >
                                            <Radio.Group
                                                className={'[&>.ant-radio-button ant-radio-button-checked]:!bg-red-500 flex gap-2 items-center text-center '}>

                                                <Radio.Button value="mci"
                                                              className={' w-1/3 flex justify-center !items-center !text-center h-[42px] !border rounded-md '}
                                                >
                                                    <img className={' !min-w-[32px] aspect-square'}
                                                         src={'/images/mci.svg '}
                                                         alt={''}/>
                                                </Radio.Button>
                                                <Radio.Button
                                                    className={'w-1/3 flex justify-center !items-center !text-center h-[42px] !border rounded-md'}
                                                    value="mtn">
                                                    <img className={'aspect-square !min-w-[30px]'}
                                                         src={'/images/irancell.svg'} alt={''}/>
                                                </Radio.Button>
                                                <Radio.Button
                                                    className={'w-1/3 flex justify-center !items-center !text-center h-[42px] !border rounded-md'}
                                                    value="rtl">
                                                    <img className={'aspect-square !min-w-[30px]'}
                                                         src={'/images/rightle.svg'} alt={''}/>
                                                </Radio.Button>
                                            </Radio.Group>

                                        </Form.Item>
                                    </RadioContainer>
                                </Row>


                                <Col span={24}>
                                    <SelectBox
                                        name="simType"
                                        label="نوع سیمکارت"
                                        placeholder="نوع سیمکارت"

                                        rules={[
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', {inputName: 'نوع سیمکارت'}),
                                            },
                                        ]}
                                        allowClear
                                        showSearch={false}
                                        ref={el => inputsRef.current[3] = el}
                                        onInput={(e) => handleOnInput(e, 1, 1)}

                                    >

                                        <Select.Option value={1}>دائمی</Select.Option>
                                        <Select.Option value={2}>اعتباری</Select.Option>

                                    </SelectBox>
                                </Col>
                            </div>


                            <Col sm={8} xs={24} lg={10}
                                 className={'mt-[110px] mb-[20px] items-center text-center mx-auto'}>
                                <Button
                                    className={'w-full mx-auto '}
                                    type={'secondary'}
                                    onClick={handlePackages}
                                    iconAlign={'end'}
                                    icon={<LeftOutlined/>}
                                    loading={packagesLoading}
                                >
                                    ادامه
                                </Button>
                            </Col>
                        </div>
                    }

                    {
                        buyNetStep === 1 &&
                        <Row gutter={[16, 12]}>

                            {
                                response?.map((item) =>
                                    <Col xs={24} lg={12} className={"shadow-4"}>
                                        <div className={"bg-white rounded-[10px] shadow-6 p-[12px]"}>
                                            <div className={"text-textcolor text-[13px] font-[400]"}>
                                                <Space size={5}>
                                                    <img src={dowanload} className={"w-[17px]"}/>
                                                    {item?.PackageInfo}
                                                </Space>

                                            </div>
                                            <div className={"text-textcolor text-[12px] font-[400]"}>
                                                مبلغ با احتساب 9 درصد مالیات
                                            </div>
                                            <div
                                                className={"flex justify-between items-center text-textblue text-[12px]"}>
                                                <div>
                                                    اعتباری
                                                </div>
                                                <Button
                                                    type={"secondary"}
                                                    onClick={handleBuyNet}
                                                >
                                                    {item?.PackageCostWithVat}
                                                </Button>
                                            </div>
                                        </div>
                                    </Col>
                                )
                            }

                        </Row>
                    }

                    {buyNetStep === 2 &&
                        <div className={'mx-auto text-textcolor !text-center !items-center text-[14px] pb-10 '}>
                            <div className={'m-auto text-center items-center pb-8'}>
                                <img className={'inline text-tick pb-5'} src={'/images/Tick Square.svg'}/>
                                <h1 className={'text-tick text-[16px] max-lg:text-[12px] max-lg:font-[500]'}>
                                    شارژ موفق
                                </h1>
                                <div
                                    className={'flex justify-between gap-3 items-center pt-8 pb-[43px] max-lg:text-[12px] max-lg:font-[500]'}>
                                    <h1>شناسه پرداخت:</h1>
                                    {/*<h1>{buyNetDataResponse?.orderId}</h1>*/}
                                </div>
                            </div>

                            <Button
                                type={'default'}
                                className={'max-lg:text-[12px]'}
                                onClick={goToWalletPage}

                            >
                                بازگشت به صفحه کیف پول
                            </Button>
                        </div>
                    }
                </Form>
            </div>
        </Spin>
    );
};

export default BuyNet;
