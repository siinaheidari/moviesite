import React, {useEffect, useState} from 'react';
import {LeftOutlined, LoadingOutlined, ShareAltOutlined, WarningOutlined} from '@ant-design/icons';
import { Col, Divider, Form, Row, Space, Spin, Statistic } from 'antd';
import styled from 'styled-components';
import {Button, Input, Modal} from 'templates/Ui';
import {Else, If, Then} from 'utils/Condition';
import {fn_deadline, formatNumber, inputRule} from 'utils/helper';
import {useRequest} from 'utils/useRequest';
import {useAuth} from "../../../../../contexts/auth/AuthContext";
import {toast} from "react-toastify";

import {errorMessages} from "../../../../../utils/axios/errorMessages";
import starkString from "starkstring";
import facilitiesBanner from "assets/images/facilitiesBanner.svg"
import facilities from "../../../../../assets/images/facilities.svg";
import increase from '../../../../../assets/icons/increaseMoney.svg';
import buyMerchant from '../../../../../assets/icons/buyMerchant.svg';
import { Link } from 'react-router-dom';


const ForgetPasswordContainer = styled(Row)`
  .--title {
    margin-bottom: 50px;
    text-align: center;
    font-size: 1rem;
  }

  .--otpStatus {
    &,
    .ant-statistic-content {
      color: #557EFF;
      font-size: .875rem;
    }

    .__resend {
      display: inline-block;
      cursor: pointer;

      &:hover {
        color: #3264ff;
      }

      &.--disable {
        pointer-events: none;
      }
    }
  }

  .--btn {
    margin-top: 30px;
  }

  .--goToSignIn {
    margin-top: 35px;
  }
`;

const {NODE_ENV} = process.env;

const BuyFromMerchant = ({goToWalletPage}) => {
  const {auth, handleChangeUserData} = useAuth();
  const {Countdown} = Statistic;
  const [buyFromMerchantFormRef] = Form.useForm();
  const userMobile = buyFromMerchantFormRef?.getFieldValue('mobile'); // get user mobile
  const mobileWatch = Form.useWatch('mobile', buyFromMerchantFormRef);
  const otpInputWatch = Form.useWatch('inputCode', buyFromMerchantFormRef); // watch otp value
  const [transportStep, setTransportStep] = useState(0);
  const [resendCode, setResendCode] = useState(false);
  const [submitVisible, setSubmitVisible] = useState(false);
  const [resendCodeDeadline, setResendCodeDeadline] = useState(0);
  const [buyFromMerchantModal, setBuyFromMerchantModal] = useState(false);
  const mobile = Form.useWatch('mobile', buyFromMerchantFormRef);

  console.log(mobile?.length)

  const {isLoading: personIdentityIsLoading, data: personIdentity, refetch} = useRequest({
    path: '/api/core/wallet/person-identity',
    params: {
      mobile
    },
    key: ['person-identity'],
    options: {
      enabled: false,
      retry: false,
      cacheTime: 0,
    }
  });

  const response = personIdentity?.output || [];


  const {isLoading: userWalletsIsLoading, data: userWalletsData, isFetched, dataUpdatedAt} = useRequest({
    path: '/api/core/wallet/info',
    key: ['userWalletInfo'],
    options: {
      enabled: (transportStep === 2),
      cacheTime: 0,
    }
  });


  const handleOpenModal = () => {
    buyFromMerchantFormRef.validateFields()
      .then(() => {
        refetch()
          .then((res) => {
            if (res?.error?.output) {
              const errorMessage = errorMessages[res?.error?.output];

              toast.warning(errorMessage, {toastId: mobile+ '_'+ errorMessage});
            }
            else {
              setBuyFromMerchantModal(true)
            }
          })
      });
  }
  const handleCloseModal = () => {
    setBuyFromMerchantModal(false);
  }
  const handleOnBlurMobile = () => {
    if (mobileWatch?.length < 11) {
      buyFromMerchantFormRef?.setFields([
        {
          name: 'mobile',
          errors: [inputRule('minLength input', {inputName: 'شماره موبایل', length: 11})]
        }
      ]);
    }
  };

  const {mutateAsync: sendOtpRequest2, isLoading: sendOtpIsLoading} = useRequest({
    path: '/api/core/otp',
    isMutation: true
  });

  const handleSendOtpCode = () => {
    sendOtpRequest2({
      // mobile: auth?.mobile,
      // nationalCode: auth?.nationalCode
    })
      .then(() => {
        setTransportStep(1); // go to next step
      })
      .catch(() => {
        if (NODE_ENV === 'development') {
          setTransportStep(1); // if in develop mode go to next step
        }
      });
  };


  const {mutateAsync: transportMoneyRequest, isLoading: transportMoneyLoading, data: transportMoneyData, error: transportMoneyError} = useRequest({
    path: '/api/core/wallet/transfer',
    isMutation: true,
  });

  const transportMoneyResponse = transportMoneyData?.output || {};

  const handleBuyFromMerchant = () => {
    console.log(response)
    transportMoneyRequest({
      amount: +(buyFromMerchantFormRef.getFieldValue("amount")?.replace(/,/g, '')),
      destWalletSerial: response?.personWalletInfo?.walletSerial,
      otp: (buyFromMerchantFormRef.getFieldValue("inputCode")),
      sourceWalletSerial: +(auth?.walletDetails?.walletSerial),
    })
      .then(() => {
      toast.success("خرید از پذیرنده با موفقیت انجام نشد")
      setTransportStep(2); // go to next step
    })
      .catch(error => {
        if (error?.output === 'Invalid Otp') {
          toast.error('کد وارد شده صحیح نمی‌باشد')
        }
        else {
          toast.error("خرید از پذیرنده انجام نشد")
          setTransportStep(3); // go to next step
        }
    })
  };

  useEffect(() => {
    if (!sendOtpIsLoading) {
      setResendCodeDeadline(fn_deadline('02.01'));
      setResendCode(false);
    }
  }, [sendOtpIsLoading]);


  useEffect(() => setSubmitVisible(!!!(otpInputWatch && otpInputWatch?.length === 6)), [otpInputWatch]);

  useEffect(() => {
    if (transportStep === 2 && isFetched) {
      let draftUserInfo = auth;

      if (userWalletsData?.output) {
        draftUserInfo.walletDetails = userWalletsData?.output;
      }

      handleChangeUserData(draftUserInfo)
    }
  }, [transportStep, isFetched, dataUpdatedAt])


  return (
    <Spin spinning={sendOtpIsLoading || transportMoneyLoading || userWalletsIsLoading || personIdentityIsLoading}>

      <Space className={"max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]"}>
        <img src={buyMerchant}/>
        خرید از پذیرنده
      </Space>
      <Divider className={"max-lg:hidden !bg-[#C6D4FF] !mt-[9px] !mb-[25px]"}/>

      <Form
        form={buyFromMerchantFormRef}
        name='forgetPasswordFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleBuyFromMerchant}
      >
        <ForgetPasswordContainer className=''>
          {transportStep === 0 &&
            <div className={"items-center w-full min-h-[350px]"}>
              <div className={"w-1/2 max-lg:w-full"}>
                <Input
                  name={'mobile'}
                  label={'شماره موبایل'}
                  noPlaceHolder
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'شماره موبایل مقصد'})
                    },
                    {
                      pattern: new RegExp(/^[0-9]+$/),
                      message: inputRule('must be number input', {inputName: 'شماره موبایل مقصد'})
                    },
                    {
                      min: 11,
                      message: inputRule('minLength input', {inputName: 'شماره موبایل مقصد', length: 11}),
                      validateTrigger: 'onBlur'
                    },
                    {
                      max: 11,
                      message: inputRule('maxLength input', {inputName: 'شماره موبایل مقصد', length: 11})
                    }
                  ]}
                  maxLength={11}
                  justNumber
                  formRef={buyFromMerchantFormRef}
                  ltr
                  focus
                />
              </div>
              <div/>
              <div className={"w-1/2 max-lg:w-full"}>
                <Input
                  name='amount'
                  label={'مبلغ'}
                  noPlaceHolder
                  placeholderAlign={'right'}
                  validateFirst
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'مبلغ'})
                    },
                    {
                      validator: (_, value) => {
                        if (value?.length && +(value?.replace(/,/g, '')) < 10000) {
                          return Promise.reject(new Error(inputRule("minLength amount", {
                            inputName: "مبلغ",
                            length: "10,000 ریال"
                          })))
                        }

                        return Promise.resolve();
                      }
                    },
                    {
                      validator: (_, value) => {
                        if (value?.length && +(value?.replace(/,/g, '')) > 10000000000) {
                          return Promise.reject(new Error(inputRule("maxLength amount", {
                            inputName: "مبلغ",
                            length: "10,000,000,000 ریال"
                          })))
                        }

                        return Promise.resolve();
                      }
                    },
                  ]}
                  onChange={e => {
                    buyFromMerchantFormRef.setFields([
                      {
                        name: 'amount',
                        value: e?.target?.value ? formatNumber(starkString(e?.target?.value).parseNumber().englishNumber().toString()) : null,
                        errors: []
                      },
                    ])
                  }}
                  onBlur={handleOnBlurMobile}
                  rtl
                  justNumber
                  formRef={buyFromMerchantFormRef}
                  maxLength={11}
                  suffix={"ریال"}
                  onPressEnter={handleOpenModal}
                />
              </div>
              <Col xs={ 24 } sm={ 10 } className={ 'mb-[10px] mx-auto lg:mt-[9rem] max-lg:mt-[140px]' }>
                <Button
                    className={ 'w-full ' }
                    type={'secondary'}
                    onClick={handleOpenModal}
                    icon={<LeftOutlined/>}
                    iconAlign={'end'}
                >
                  ادامه
                </Button>
              </Col>
              <Modal
                open={buyFromMerchantModal}
                onCancel={handleCloseModal}
                header={false}
                closable={false}
                size={{
                  sm: 90,
                  xs: 90,
                  md: 90,
                  lg: 55,
                  xl: 55,
                  xxl: 30
                }}
                bodyStyle={{
                  padding: 5,
                  backgroundColor:"rgba(140,140,140)",

                }}
                style={{
                  top: '28vh',
                }}
              >
                <div className={"px-[49px] bg-white pt-[3px] rounded-[10px] pb-[38px] items-center text-center mx-auto"}>
                  <div className={"relative top-[-8px] lg:hidden"}>
                    <img src={facilities} className={"mx-auto "}/>
                    <div className={"relative text-white top-[-26px] mx-auto text-center items-center text-[12px]"}>
                      اطلاعات مقصد
                    </div>
                  </div>
                  <div className={" text-center items-center text-textcolor max-lg:!text-[12px] max-lg:mt-[11px]"}>
                    <h1 className={"pb-4 text-textblue text-[16px] max-lg:hidden"}>اطلاعات مقصد</h1>
                    <div className={"flex justify-center gap-2 mx-auto pb-[16px] "}>
                      <h1>نام:</h1>
                      <h1>{response?.personInfo?.firstname}</h1>
                    </div>
                    <div className={"flex justify-center gap-2 mx-auto pb-[16px]"}>
                      <h1>نام خانوادگی:</h1>
                      <h1>{response?.personInfo?.lastname}</h1>
                    </div>
                    <div className={"flex justify-center gap-2 mx-auto pb-8 max-lg:pb-[40px]"}>
                      <h1>شناسه کیف پول:</h1>
                      <h1>{response?.personWalletInfo
                        ?.walletSerial}</h1>
                    </div>
                  </div>

                  <Col span={24} className={" lg:mb-[10px] flex justify-center"}>
                    <Button
                        className={"w-1/3 max-lg:w-full  max-lg:text-[12px] font-[400]"}
                        type={'secondary'}
                        onClick={handleSendOtpCode}
                        icon={<LeftOutlined/>}
                        iconAlign={'end'}
                    >
                      تایید و ارسال کد یکبار مصرف
                    </Button>
                  </Col>
                </div>
              </Modal>
            </div>
          }
          {transportStep === 1 &&
            <div className={"w-full text-center items-center"}>
              <div className={"w-full lg:max-w-[310px] mb-[30px]"}>
                <Input
                  name={'inputCode'}
                  noPlaceHolder
                  label={('کد ارسال شده را وارد نمایید')?.replaceAll('{{mobileNumber}}', userMobile)}
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'کد تایید'})
                    }
                  ]}
                />
              </div>
              <div className={"lg:w-[310px] max-lg:w-full "}>
                <div className='--otpStatus'>
                  <Row justify='space-between' gutter={17}>
                    <If condition={!resendCode}>
                      <Then>
                        <Col className={"max-lg:!text-[12px] font-![400]"}>
                          <WarningOutlined/>
                          {'اعتبار باقیمانده کد ارسال شده'}
                        </Col>

                        <Col>
                          <Countdown value={resendCodeDeadline} onFinish={() => setResendCode(true)} format='mm:ss'/>
                        </Col>
                      </Then>

                    </If>
                  </Row>
                </div>
              </div>


              <Col xs={24} sm={14} lg={10} className={"lg:mt-[7rem] max-lg:mt-[7rem] mx-auto"}>
                <Button
                    className={"w-full"}
                    type={'secondary'}
                    onClick={handleBuyFromMerchant}
                    icon={<LeftOutlined/>}
                    iconAlign={'end'}
                >
                  انتقال
                </Button>
              </Col>

            </div>
          }
          {
            transportStep === 2  &&
            <div className={"bg-white text-center items-center w-full max-w-[500px] m-auto max-lg:px-[18px] px-[30px] pb-[35px] pt-[15px]"}>
              <div className={"text-textcolor text-[14px]"}>
                <div className={"m-auto text-center items-center pb-8"}>
                  <img className={"inline text-tick pb-5"} src={"/images/Tick Square.svg"}/>

                  <h1 className={"text-tick text-[16px] max-lg:text-[12px] font-[500]"}>
                    خرید از پذیرنده با موفقیت انجام شد
                  </h1>

                </div>
                <div className={"flex justify-between items-center max-lg:text-[12px] pb-[27px] max-lg:pb-[10px]"}>
                  <h1>مبلغ: (ریال)</h1>
                  <h1>{transportMoneyResponse?.transactionPrice}</h1>
                </div>
                <div className={"flex justify-between items-center max-lg:text-[12px] pb-[27px] max-lg:pb-[10px]"}>
                  <h1>شماره ترمینال:</h1>
                  <div className={"flex gap-1"}>
                    <h1>{response?.personInfo?.firstname}</h1>
                    <h1>{response?.personInfo?.lastname}</h1>
                  </div>
                </div>

                <div className={"flex justify-between items-center max-lg:text-[12px] pb-[27px] max-lg:pb-[10px]"}>
                  <h1>کد رهگیری:</h1>
                  <h1>{transportMoneyResponse?.referenceNumber}</h1>
                </div>

                <div className={"flex justify-between items-center max-lg:text-[12px] pb-[43px] max-lg:pb-[23px]"}>
                  <h1>تاریخ و ساعت:</h1>
                  <h1>{transportMoneyResponse?.transactionDate}</h1>
                </div>
                <Col xs={24} sm={14} lg={12} className={" max-lg:mt-[1rem] mx-auto"}>
                  <Button
                      type={"default"}
                      className={"w-full relative"}
                  >
                    بازگشت به صفحه کیف پول
                  </Button>
                  <Link to={-1} className={"absolute inset-0"}></Link>
                </Col>

              </div>
            </div>
          }
          {
            transportStep === 3  &&
            <div className={"bg-white !text-center !items-center w-full max-w-[650px] m-auto px-1 pb-[35px] pt-[15px] "}>
              <div className={"text-textcolor text-[14px] "}>
                <div className={"m-auto !text-center !items-center pb-8 "}>
                  <img className={"inline text-tick pb-5"} src={"/images/Close Square.svg"}/>
                  <h1 className={"text-error text-[16px] max-lg:text-[13px] max-lg:font-[500]"}>
                    خرید از پذیرنده انجام نشد
                  </h1>
                </div>
                <Col xs={24} sm={14} lg={12} className={" max-lg:mt-[1rem] mx-auto"}>

                    <Button
                        type={"default"}
                        className={"w-full relative"}
                    >
                      بازگشت به صفحه کیف پول
                    </Button>

                </Col>
                <Link to={-1} className={"absolute inset-0"}></Link>
              </div>
            </div>
          }
        </ForgetPasswordContainer>
      </Form>
    </Spin>
  );
};

export default BuyFromMerchant;


