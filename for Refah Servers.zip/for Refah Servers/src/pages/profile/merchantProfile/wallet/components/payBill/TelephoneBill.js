import React, {useState} from 'react';
import {Col, Form, Row, Space, Spin} from 'antd';
import {Button, Input, Modal, Radio, RadioFormItem, RadioGroup, TransitionsPage,} from '../../../../../../templates/Ui';
import {formatNumber, inputRule} from '../../../../../../utils/helper';
import {useRequest} from '../../../../../../utils/useRequest';
import SendPinReminder from '../SendPinReminder';
import styled from 'styled-components';
import {useNavigate} from "react-router-dom";
import {useQueryClient} from "@tanstack/react-query";
import {useAuth} from "../../../../../../contexts/auth/AuthContext";
import {LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../../assets/icons/refahLogo.svg";


const OtpContainer = styled(Row)`
  .ant-input {
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  .ant-btn {
    border-start-start-radius: 0;
    border-end-start-radius: 0;
    margin-top: 12px;
  }
`;

const TelephoneBill = ({handleBack}) => {
    const {
        auth,
        handleChangeUserData,
    } = useAuth();
    const [formRef] = Form.useForm();

    const telephoneNumber = formRef?.getFieldValue('phoneNumber');
    const billTypeWatch = Form.useWatch('billType', formRef);

    const [otpModalVisible, setOtpModalVisible] = useState(false);

    // state for show btn To resend the verification code:
    const [resendCode, setResendCode] = useState(false);
    const navigate = useNavigate()
    const queryClient = useQueryClient();

    const mockResponse = {
        'finalTermAmount': 272000,
        'finalTermBillId': '849311121141',
        'finalTermCycle': '',
        'finalTermPaymentId': '27211126',
        'midTermAmount': 350000,
        'midTermBillId': '849311121141',
        'midTermCycle': '',
        'midTermPaymentId': '35020151',
    };

    const {
        isLoading: sendOtpIsLoading,
        mutateAsync: sendOtpRequest,
        isSuccess: sendOtpIsSuccess,
    } = useRequest({
        path: '/wallet/otp',
        isMutation: true,
        customSuccessMessage: 'رمز پویا با موفقیت ارسال شد',
    });

    const {
        isLoading,
        mutateAsync: telephoneBillInquiryRequest,
        data,
        reset,
    } = useRequest({
        path: '/services/bills/inquiry/phone',
        isMutation: true,
        customSuccessMessage: 'اطلاعات با موفقیت دریافت شد',
    });

    const {
        isLoading: payIsLoading,
        mutateAsync: payBillRequest,
    } = useRequest({
        path: '/services/bills/pay/bills',
        isMutation: true,
    });

    const response = data?.response || {};

    const handleTelephoneBillInquiry = async (formData) => await telephoneBillInquiryRequest(formData)
        .catch(() => {
        });

    const handlePayBill = async () => {
        try {
            await formRef?.validateFields(['otp']);

            const billType = await formRef?.getFieldValue('billType');

            const data = {
                amount: response[billType]?.amount?.toString(),
                billId: response[billType]?.billId,
                paymentId: response[billType]?.payId,
                otp: formRef?.getFieldValue('otp'),
                billType: "1",
            };

            await payBillRequest(data);
            await setOtpModalVisible(false);
            await navigate("/merchantProfile/wallet")
            await queryClient.refetchQueries(['request', "walletInventoryRequest", auth?.walletIdentifier]);



            await reset();
        } catch (error) {
            await setOtpModalVisible(false);
            await navigate("/merchantProfile/wallet")
        }
    };

    // Send OTP request
    const handleSendOtp = async () => {
        try {
            await sendOtpRequest({amount: 50000});
            await setOtpModalVisible(true);
        } catch (error) {
            console.log('error in handleSendOtp >>>>', error);
        }
    };

    return (
        <>
            <div className={'flex gap-2 !text-center !items-center mb-[10px]'}>
                <img className={'w-8'} src={'/images/tci.svg'}/>
                <h1 className={'!mb-0'}>قبض تلفن</h1>
            </div>
            <Form
                form={formRef}
                name="telephoneBillInquiryFrom"
                autoComplete="off"
                scrollToFirstError
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
                onFinish={handleTelephoneBillInquiry}
            >
                <Spin spinning={isLoading || payIsLoading} className={"relative"}
                      indicator={<LoadingOutlined className={"!hidden"}/>} tip={<div>
                    <BeatLoader
                        color={"#1447a0"}
                        loading={true}
                        size={9}
                        aria-label="Loading Spinner"
                        data-testid="loader"
                    />
                    <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
                </div>}>
                    <TransitionsPage>
                        {
                            !!Object.keys(response)?.length ?
                                <Col span={24} className="lg:w-[600px] mx-auto">
                                    <div
                                        className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                        شناسه قبض :
                                        <div>
                                            {response?.finalTerm?.billId || response?.midTerm?.billId}
                                        </div>

                                    </div>
                                    <div
                                        className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500]'}>
                                        شماره تلفن :
                                        <div>
                                            {telephoneNumber}
                                        </div>
                                    </div>


                                    <div className="__pay">
                                        <Row>
                                            <Col span={24} className="__selectBill">
                                                <RadioFormItem
                                                    name={'billType'}
                                                    initialValue={response?.finalTerm?.amount ? 'finalTerm' : 'midTerm'}
                                                >
                                                    <RadioGroup
                                                        defaultValue={response?.finalTerm?.amount ? 'finalTerm' : 'midTerm'}>
                                                        <Row gutter={[0, 10]}>
                                                            <Col span={24} className="__billItem">
                                                                <Radio value={'finalTerm'}
                                                                       selectedColor={'secondaryColor'}>
                                                                    <Space size={14}>
                                                                        قبض پایان دوره:

                                                                        <div>
                                                                            {formatNumber(response?.finalTerm?.amount)} ریال
                                                                        </div>
                                                                    </Space>
                                                                </Radio>
                                                            </Col>

                                                            <Col span={24} className="__billItem">
                                                                <Radio value={'midTerm'}
                                                                       selectedColor={'secondaryColor'}>
                                                                    <Space size={14}>
                                                                        قبض میان دوره:

                                                                        <div>
                                                                            {formatNumber(response?.midTerm?.amount)} ریال
                                                                        </div>
                                                                    </Space>
                                                                </Radio>
                                                            </Col>
                                                        </Row>
                                                    </RadioGroup>
                                                </RadioFormItem>
                                            </Col>
                                        </Row>
                                    </div>

                                    <Row gutter={10} justify={'center'} className={'lg:mt-[70px] max-lg:mt-[50px]'}>
                                        <Col xs={12} sm={10} lg={10} className={"max-lg:hidden"}>
                                            <Button
                                                type="default"
                                                block
                                                onClick={reset}
                                            >
                                                بازگشت
                                            </Button>
                                        </Col>

                                        <Col xs={24} sm={10} lg={10}>
                                            <Button
                                                type="secondary"
                                                block
                                                disabled={(+response?.[billTypeWatch]?.amount < 10000)}
                                                onClick={handleSendOtp}
                                                loading={isLoading}
                                            >
                                                پرداخت از کیف پول
                                            </Button>
                                        </Col>
                                    </Row>
                                </Col> :
                                <Col span={24}>
                                    <Input
                                        name={'phoneNumber'}
                                        label={'شماره تلفن ثابت به همراه پیش شماره'}
                                        formRef={formRef}
                                        ltr
                                        rules={[
                                            {
                                                required: true,
                                                message: 'شماره تلفن ثابت را وارد کنید'
                                            },
                                            {
                                                pattern: new RegExp(/^[0-9]+$/),
                                                message: inputRule('must be number input', {inputName: 'شماره تلفن ثابت'}),
                                            },
                                            {
                                                min: 11,
                                                message: inputRule('minLength input', {
                                                    inputName: 'شماره تلفن ثابت',
                                                    length: 11,
                                                }),
                                            },
                                        ]}
                                        justNumber

                                        maxLength={11}


                                    />

                                    <Row gutter={16} justify={"center"}
                                         className={"items-center text-center mx-auto mt-[120px]"}>
                                        <Col xs={24} lg={8} className={"max-lg:hidden"}>
                                            <Button
                                                type={'default'}
                                                className={"w-full"}
                                                block
                                                onClick={handleBack}
                                            >
                                                بازگشت
                                            </Button>
                                        </Col>
                                        <Col xs={24} lg={8}>
                                            <Button
                                                type={'secondary'}
                                                htmlType={'submit'}
                                                block
                                                className={"w-full"}
                                            >
                                                استعلام قبض
                                            </Button>
                                        </Col>
                                    </Row>

                                </Col>
                        }

                        <div className="--vector"/>


                    </TransitionsPage>
                </Spin>

                <Modal
                    open={otpModalVisible}
                    centered
                    onCancel={() => setOtpModalVisible(false)}
                >
                    <OtpContainer align="middle">
                        <Col flex="1 1">
                            <Input
                                name={'otp'}
                                label={'رمز پویا'}
                                formRef={formRef}
                                justNumber
                                minLength={4}
                                rules={[
                                    {
                                        required: true,
                                        message: 'رمز پویا را وارد کنید'
                                    }
                                ]}
                            />
                        </Col>

                        <Col flex="100px" className={"max-lg:mt-[17px]"}>
                            <Button
                                type={'secondary'}
                                block
                                height={40}
                                onClick={handleSendOtp}
                                loading={sendOtpIsLoading}
                                disabled={resendCode}
                            >
                                ارسال مجدد
                            </Button>
                        </Col>

                        <Col span={24} className="mt-[10px]">
                            <SendPinReminder
                                resendCode={resendCode}
                                setResendCode={setResendCode}
                                sendPinIsSuccess={sendOtpIsSuccess}
                            />
                        </Col>

                        <Col xs={24} lg={12} className='text-center mx-auto mt-[40px]'>
                            <Button onClick={handlePayBill} loading={payIsLoading}
                                    className={"w-full"}
                                    type={"secondary"}
                            >
                                پرداخت
                            </Button>
                        </Col>
                    </OtpContainer>
                </Modal>
            </Form>
        </>
    );
};

export default TelephoneBill;