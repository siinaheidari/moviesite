import { useEffect, useState } from 'react';
import { useTheme } from 'contexts/theme/ThemeContext';
import { fn_deadline } from 'utils/helper';
import { Progress, Statistic } from 'antd';

const  SendPinReminder = ({
  resendCode,
  setResendCode,
  sendPinIsSuccess,
}) => {
  const { theme } = useTheme();
  
  const [ reminder, setReminder ] = useState(100);
  // state for show countdown for resend code (after: 2 Minute):
  const [ resendCodeDeadline, setResendCodeDeadline ] = useState(0);
  
  // handle for set resend code: show resend time
  useEffect(() => {
    if (sendPinIsSuccess) {
      setResendCodeDeadline(fn_deadline('02.01'));
      setResendCode(true);
    }
  }, [ sendPinIsSuccess ]);
  
  /// handle reminder down
  useEffect(() => {
    let interval = null;
    
    // start countdown
    const startCountdown = () => {
      setReminder(100);
      interval = setInterval(() => {
        setReminder((prevCount) => prevCount - 1);
      }, 1200);
    };
    
    // stop countdown
    const stopCountdown = () => {
      clearInterval(interval);
    };
    
    // start countdown if send pin is success
    if (sendPinIsSuccess && resendCode) {
      stopCountdown();
      
      startCountdown();
      
      setTimeout(() => {
        stopCountdown();
        setReminder(0);
      }, 120000);
    }
    
    // stop countdown if resendCode is false
    if (!resendCode) {
      stopCountdown();
    }
    
    // stop countdown before unMount
    return () => {
      stopCountdown();
    };
  }, [ sendPinIsSuccess, resendCode ]);
  
  return (
    !!resendCode &&
    <Progress
      type="line"
      percent={ reminder }
      strokeColor={{
        '100%': '#D01575',
        '0%': '#15469F',
      }}
      format={ () => <Statistic.Countdown
        value={ resendCodeDeadline }
        format="mm:ss"
        valueStyle={ {
          fontSize: 15,
        } }
        onFinish={ () => setResendCode(false) }
      /> }
    />
  
  );
};

export default SendPinReminder;