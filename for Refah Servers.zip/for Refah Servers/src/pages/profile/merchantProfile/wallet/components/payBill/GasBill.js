import React, {useState} from 'react';
import styled from 'styled-components';
import SendPinReminder from '../SendPinReminder';
import {Col, Form, Row, Space, Spin} from 'antd';
import {Button, Input, Modal, TransitionsPage} from '../../../../../../templates/Ui';
import {formatNumber, inputRule} from '../../../../../../utils/helper';
import {useRequest} from '../../../../../../utils/useRequest';
import {useNavigate} from "react-router-dom";
import {useQueryClient} from "@tanstack/react-query";
import {useAuth} from "../../../../../../contexts/auth/AuthContext";
import {LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../../assets/icons/refahLogo.svg";


// Styled component for OTP container
const OtpContainer = styled(Row)`
  .ant-input {
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  .ant-btn {
    border-start-start-radius: 0;
    border-end-start-radius: 0;
    margin-top: 12px;
  }
`;

const WaterBill = ({handleBack}) => {
    const {
        auth,
        handleChangeUserData,
    } = useAuth();
    const [formRef] = Form.useForm();

    const [otpModalVisible, setOtpModalVisible] = useState(false);

    // state for show btn To resend the verification code:
    const [resendCode, setResendCode] = useState(false);

    const navigate = useNavigate()
    const queryClient = useQueryClient();


    const mockData = {
        'address': 'خ بلوارکشاورزخ وصال شیرازی  نبش فردانش پ50',
        'amount': 6454000,
        'billId': '0093998206233',
        'payId': '645419940',
    };

    const {
        isLoading: sendOtpIsLoading,
        mutateAsync: sendOtpRequest,
        isSuccess: sendOtpIsSuccess,
    } = useRequest({
        path: '/wallet/otp',
        isMutation: true,
        customSuccessMessage: 'رمز پویا با موفقیت ارسال شد',
    });

    const {
        isLoading,
        mutateAsync: gasBillInquiryRequest,
        data,
        reset,
    } = useRequest({
        path: '/services/bills/inquiry/gas',
        isMutation: true,
        customSuccessMessage: 'اطلاعات با موفقیت دریافت شد',
    });

    const {
        isLoading: payIsLoading,
        mutateAsync: payBillRequest,
    } = useRequest({
        path: '/services/bills/pay/bills',
        isMutation: true,
    });

    const response = data?.response || {};

    const handleGasBillInquiry = async (formData) => await gasBillInquiryRequest(formData)
        .catch(() => {
        });

    const handlePayBill = async () => {
        try {
            await formRef?.validateFields(['otp']);

            const data = {
                amount: response?.amount?.toString(),
                billId: response?.billId?.toString(),
                paymentId: response?.payId?.toString(),
                otp: formRef?.getFieldValue('otp'),
                billType: "3",
            };

            await payBillRequest(data);

            await queryClient.refetchQueries(['request', "walletInventoryRequest", auth?.walletIdentifier]);

            await setOtpModalVisible(false);


            await reset();

            await navigate("/merchantProfile/wallet")
        } catch (error) {
            console.log('handlePayBill >>>>', error);
            await navigate("/merchantProfile/wallet")
        }
    };

    // Send OTP request
    const handleSendOtp = async () => {
        try {
            await sendOtpRequest({amount: 50000});
            await setOtpModalVisible(true);
        } catch (error) {
            console.log('error in handleSendOtp >>>>', error);
        }
    };

    return (
        <Form
            form={formRef}
            name="waterBillInquiryFrom"
            autoComplete="off"
            scrollToFirstError
            labelCol={{
                span: 24,
            }}
            wrapperCol={{
                span: 24,
            }}
            onFinish={handleGasBillInquiry}
        >
            <Spin spinning={isLoading || sendOtpIsLoading} className={"relative"}
                  indicator={<LoadingOutlined className={"!hidden"}/>} tip={<div>
                <BeatLoader
                    color={"#1447a0"}
                    loading={true}
                    size={9}
                    aria-label="Loading Spinner"
                    data-testid="loader"
                />
                <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
            </div>}>
                <TransitionsPage>
                    <div className={"flex gap-2 !text-center !items-center"}>
                        <img className={"w-8"} src={"/images/gas.png"}/>
                        <h1 className={"!mb-0"}>قبض گاز</h1>
                    </div>


                    {!!Object.keys(response)?.length ?
                        <Col span={24} className="--response">
                            <div>
                                <div
                                    className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                    مبلغ بدهی:
                                    <Space size={5}>
                                        {formatNumber(response?.amount || 0)}
                                        ریال
                                    </Space>
                                </div>

                                {(response?.amount > 50000 && response?.tax) &&
                                    <>
                                        <Col span={12} className="__title">
                                            مبلغ مالیات :
                                        </Col>
                                        <Col span={12} className="__value">
                                            <Space size={5}>
                                                {formatNumber(response?.tax || 0)}

                                                ریال
                                            </Space>
                                        </Col>
                                    </>
                                }

                                <div
                                    className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                    شناسه قبض :
                                    <div>
                                        {response?.billId}
                                    </div>

                                </div>

                                <div
                                    className={'flex justify-between items-center mb-[20px] max-lg:mb-[10px] max-lg:text-[12px] max-lg:font-[500] max-lg:mt-[20px]'}>
                                    شناسه پرداخت :
                                    <div>
                                        {response?.payId}
                                    </div>

                                </div>


                            </div>

                            <Row gutter={10} justify={'center'} className={'lg:mt-[90px] max-lg:mt-[50px]'}>
                                <Col xs={12} sm={10} lg={10}>
                                    <Button
                                        type="default"
                                        block
                                        colored={false}
                                        onClick={reset}
                                    >
                                        بازگشت
                                    </Button>
                                </Col>

                                <Col xs={12} sm={10} lg={10}>
                                    <Button
                                        type="secondary"
                                        block
                                        disabled={+(response?.amount) < 10000}
                                        onClick={handleSendOtp}
                                    >
                                        پرداخت از کیف پول
                                    </Button>
                                </Col>
                            </Row>
                        </Col> :
                        <Col span={24} className="--formContent">
                            <Input
                                name={'billId'}
                                label={'شناسه قبض'}
                                formRef={formRef}
                                rules={[
                                    {
                                        required: true,
                                        message: 'شناسه قبض را وارد کنید'
                                    },
                                    {
                                        required: true,
                                        message: inputRule('must be number input', {inputName: 'شناسه قبض'}),
                                    },
                                    {
                                        min: 11,
                                        message: inputRule('minLength input', {
                                            inputName: 'شناسه قبض',
                                            length: 11,
                                        }),
                                    },
                                ]}
                                justNumber
                                ltr

                            />

                            <Row gutter={16} justify={"center"}
                                 className={"items-center text-center mx-auto mt-[120px]"}>
                                <Col xs={24} lg={8} className={"max-lg:hidden"}>
                                    <Button
                                        type={'default'}
                                        className={"w-full"}
                                        block
                                        onClick={handleBack}
                                    >
                                        بازگشت
                                    </Button>
                                </Col>
                                <Col xs={24} lg={8}>
                                    <Button
                                        type={'secondary'}
                                        htmlType={'submit'}
                                        block
                                        className={"w-full"}
                                    >
                                        استعلام قبض
                                    </Button>
                                </Col>
                            </Row>
                        </Col>
                    }

                    <div className="--vector"/>
                </TransitionsPage>
            </Spin>

            <Modal
                open={otpModalVisible}
                centered
                onCancel={() => setOtpModalVisible(false)}
                style={{
                    top: "-10vh"
                }}
            >
                <OtpContainer align="middle">
                    <Col flex="1 1">
                        <Input
                            name={'otp'}
                            label={'رمز پویا'}
                            formRef={formRef}
                            justNumber
                            minLength={4}
                            rules={[
                                {
                                    required: true,
                                    message: 'رمز پویا را وارد کنید'
                                }
                            ]}
                        />
                    </Col>

                    <Col flex="100px" className={"max-lg:mt-[17px]"}>
                        <Button
                            type={'secondary'}
                            block
                            height={40}
                            onClick={handleSendOtp}
                            loading={sendOtpIsLoading}
                            disabled={resendCode}
                        >
                            ارسال مجدد
                        </Button>
                    </Col>

                    <Col span={24} className="mt-[10px]">
                        <SendPinReminder
                            resendCode={resendCode}
                            setResendCode={setResendCode}
                            sendPinIsSuccess={sendOtpIsSuccess}
                        />
                    </Col>

                    <Col xs={24} lg={12} className='text-center mx-auto mt-[40px]'>
                        <Button onClick={handlePayBill} loading={payIsLoading}
                                className={"w-full"}
                                type={"secondary"}
                        >
                            پرداخت
                        </Button>
                    </Col>
                </OtpContainer>
            </Modal>
        </Form>
    );
};

export default WaterBill;
