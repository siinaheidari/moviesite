import React, {useRef, useState} from 'react';
import {LeftOutlined, LoadingOutlined} from '@ant-design/icons';
import {Col, Divider, Form, Row, Select, Space, Spin, Statistic} from 'antd';
import styled from 'styled-components';
import {Button, Input, Modal, SelectBox} from 'templates/Ui';
import {formatCadNumber, formatNumber, inputRule} from 'utils/helper';
import starkString from 'starkstring';
import cashOut from 'assets/icons/useMoney.svg';
import {useRequest} from '../../../../../utils/useRequest';
import {Link, useNavigate} from 'react-router-dom';
import {useAuth} from '../../../../../contexts/auth/AuthContext';
import {useQueryClient} from "@tanstack/react-query";
import SendPinReminder from "./SendPinReminder";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../../assets/icons/refahLogo.svg";


const ForgetPasswordContainer = styled(Row)`
  .--title {
    margin-bottom: 50px;
    text-align: center;
    font-size: 12px !important;
    font-weight: 400 !important;
  }

  .--otpStatus {
    &,
    .ant-statistic-content {
      color: #21409A;


      &,
      .anticon-warning {

        font-size: 12px;
        font-weight: 400;
      }
    }

    .__resend {
      display: inline-block;
      cursor: pointer;

      &:hover {
        color: #3264ff;
      }

      &.--disable {
        pointer-events: none;
      }
    }
  }

  .--btn {
    margin-top: 30px;
  }

  .--goToSignIn {
    margin-top: 35px;
  }
`;

const CashOut = ({goToWalletPage}) => {
    const {auth} = useAuth();
    const {Countdown} = Statistic;
    const [cashOutFormRef] = Form.useForm();
    const userMobile = cashOutFormRef?.getFieldValue('mobile');
    const mobileWatch = Form.useWatch('mobile', cashOutFormRef);
    const otpInputWatch = Form.useWatch('inputCode', cashOutFormRef);
    const amountWatch = Form.useWatch('amount', cashOutFormRef);
    const [errorModal, setErrorModal] = useState(false);
    const inputsRef = useRef([]);
    const queryClient = useQueryClient();
    const navigate = useNavigate()
    const [cashOutStep, setcashOutStep] = useState(0);
    const [resendCode, setResendCode] = useState(false);


    const {
        isLoading: cartTypeDataIsLoading,
        data: cartTypeData,
    } = useRequest({
        path: '/wallet/iban-pan',
        key: ['CashOutCartType'],
        options: {
            retry: false,
        },
    });

    const cartType = cartTypeData || [];


    const handleCloseModal = () => {
        setErrorModal(false);
    };


    const {
        isLoading: sendOtpIsLoading,
        mutateAsync: sendOtpRequest,
        isSuccess: sendOtpIsSuccess,
    } = useRequest({
        path: '/wallet/otp',
        isMutation: true,
        customSuccessMessage: 'رمز پویا با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال رمز پویا لطفا مجددا تلاش فرمایید',
    });


    const {
        isLoading: cashOutLoading,
        mutateAsync: cashOutRequest,
        isSuccess: cashOutSuccess,
    } = useRequest({
        path: '/wallet/cash-out',
        isMutation: true,

    });

    const handleSendOtp = async () => {
        try {

            await cashOutFormRef?.validateFields(['panSelected', 'amount']);

            await sendOtpRequest({amount: 5000});
        } catch (error) {
            console.log('error in handleSendOtp >>>>', error);
        }
    };


    const handleCashOut = async () => {
        try {
            const values = cashOutFormRef.getFieldsValue(true);
            await cashOutRequest({
                ...values,
                amount: +(values?.amount?.replace(/,/g, '')),
                walletIdentifier: auth?.walletIdentifier,
            });

            await queryClient.refetchQueries(['request', "walletInventoryRequest", auth?.walletIdentifier]);

            await setcashOutStep(2)

        } catch (error) {
            navigate('/merchantProfile/wallet');
        }
    };


    const handleAmountButtons = amount => {
        cashOutFormRef.setFields([{
            name: 'amount',
            value: formatNumber(starkString(amount)
                .parseNumber()
                .englishNumber()
                .toString()),
        }]);
    };


    const handleOnChange = (event, index) => {
        if (event) {
            if (index < inputsRef.current.length - 1) {
                inputsRef.current[index + 1].focus();
            }
        }
    };


    const {
        isLoading: walletInventoryIsLoading,
        data: walletInventory,

    } = useRequest({
        path: '/wallet/inventory',
        key: ["walletInventoryRequest", auth?.walletIdentifier],
        params: {
            walletIdentifier: auth.walletIdentifier || null,
        },
        options: {
            enabled: !!auth?.walletIdentifier,
            cacheTime: 0,
        },

    });

    const response = walletInventory?.balance || {}


    return (
        <Spin spinning={ cashOutLoading || sendOtpIsLoading} className={"relative"}
              indicator={<LoadingOutlined className={"!hidden"}/>} tip={<div>
            <BeatLoader
                color={"#1447a0"}
                loading={true}
                size={9}
                aria-label="Loading Spinner"
                data-testid="loader"
            />
            <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
        </div>}>
            <Space className={'max-lg:hidden text-[#1447A0] font-[400] max-lg:text-[12px]'}>
                <img src={cashOut}/>
                برداشت
            </Space>
            <Divider className={'max-lg:hidden  max-lg:hidden !bg-[#C6D4FF] !mt-[9px] !mb-[25px]'}/>

            <Form
                form={cashOutFormRef}
                name="cashOut"
                autoComplete="off"
                scrollToFirstError
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
                onFinish={handleCashOut}
            >
                <ForgetPasswordContainer>


                    {cashOutStep === 0 &&

                        <div className={'items-center w-full max-lg:text-[12px] max-lg:font-[400]'}>
                            <Col xs={24} lg={24}>
                                <SelectBox
                                    name="panSelected"
                                    label="انتخاب کارت"
                                    loading={cartTypeDataIsLoading}

                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required selectBox', {inputName: 'کارت'}),
                                        },
                                    ]}
                                    allowClear
                                    showSearch={false}
                                    dropdownRender={menu => {
                                        return (
                                            <>
                                                <div className={' flex gap-2 items-center px-2.5 py-[2px]'}>
                                                    <p className={'relative text-[18px] text-blue-400 cursor-pointer'}>+</p>
                                                    <div className={'relative text-blue-400 cursor-pointer'}>اضافه کردن
                                                        کارت
                                                        بانکی
                                                    </div>
                                                    <Link to={'/merchantProfile/wallet/add-cart-bank'}
                                                          className={'absolute inset-0'}></Link>
                                                </div>

                                                <Divider style={{margin: '8px 0'}}/>
                                                {menu}
                                            </>
                                        );
                                    }}
                                    formRef={cashOutFormRef}

                                >
                                    {cartType?.map(item => (
                                        <Select.Option value={item?.rowId}>
                                            {formatCadNumber(item?.pan)}
                                        </Select.Option>
                                    ))}

                                </SelectBox>
                            </Col>
                            <div className={'w-full'}>
                                <div className={'mb-4'}>
                                    <p className={'!mb-3 max-lg:text-[12px] font-[400] max-lg:font-[500] '}>مبالغ پیش
                                        فرض</p>
                                    <div className={'flex gap-2 items-center text-center '}>
                                        <Button type={"default"} onClick={() => handleAmountButtons(1000000)}
                                                className={'focus:bg-textblue focus:!text-white hover:bg-textblue hover:!text-white !border-[#D9D9D9] shadow-shadow !items-center !text-center !h-[42px] max-lg:w-1/3 !border rounded-md w-1/3 cursor-pointer'}>
                                            <p className={'leading-[38px] max-lg:text-[12px] max-lg:font-[400]'}>۱,۰۰۰,۰۰۰
                                                ریال</p>
                                        </Button>
                                        <Button type={"default"} onClick={() => handleAmountButtons(2000000)}
                                                className={'focus:bg-textblue focus:text-white hover:bg-textblue  !border-[#D9D9D9] hover:!text-white shadow-shadow !items-center !text-center !h-[42px] max-lg:w-1/3 !border rounded-md w-1/3 cursor-pointer'}>
                                            <p className={'leading-[38px] max-lg:text-[12px] max-lg:font-[400]'}>۲,۰۰۰,۰۰۰
                                                ریال</p>
                                        </Button>
                                        <Button type={"default"} onClick={() => handleAmountButtons(5000000)}
                                                className={'focus:bg-textblue focus:text-white hover:bg-textblue hover:!text-white !border-[#D9D9D9] shadow-shadow !items-center !text-center !h-[42px] max-lg:w-1/3 !border rounded-md w-1/3 cursor-pointer'}>
                                            <p className={'leading-[38px] max-lg:text-[12px] max-lg:font-[400]'}>۵,۰۰۰,۰۰۰
                                                ریال</p>
                                        </Button>
                                    </div>
                                </div>
                            </div>


                            <Col xs={24} lg={24}>
                                <Input
                                    name="amount"
                                    label="مبلغ (ریال)"
                                    placeholder={'مبلغ (ریال)'}
                                    validateFirst
                                    formRef={cashOutFormRef}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'مبلغ'}),
                                        },
                                        {
                                            validator: (_, value) => {
                                                if (value?.length && +(value?.replace(/,/g, '')) < 10000) {
                                                    return Promise.reject(new Error(inputRule('minLength amount', {
                                                        inputName: 'مبلغ',
                                                        length: '10,000 ریال',
                                                    })));
                                                }

                                                return Promise.resolve();
                                            },
                                        },
                                        {
                                            validator: (_, value) => {
                                                if (value?.length && +(value?.replace(/,/g, '')) > 1000000000) {
                                                    return Promise.reject(new Error(inputRule('maxLength amount', {
                                                        inputName: 'مبلغ',
                                                        length: '1,000,000,000 ریال',
                                                    })));
                                                }

                                                return Promise.resolve();
                                            },
                                        },
                                        {
                                            validator: (_, value) => {
                                                if (value > response) {
                                                    return Promise.reject(new Error(inputRule('maxAmount amount', {
                                                        inputName: 'مبلغ',
                                                        // length: formatNumber(response),
                                                    })));
                                                }

                                                return Promise.resolve();
                                            },
                                        },

                                    ]}
                                    maxLength={response?.toString().length}
                                    ref={el => inputsRef.current[2] = el}
                                    rootClassName={'h-[42px] border border-borderblue ltr'}

                                />
                            </Col>


                            <Col xs={24} lg={24}>
                                <Row>
                                    <Col flex="1 1">
                                        <Input
                                            name={'otp'}
                                            label={'رمز پویا'}
                                            formRef={cashOutFormRef}
                                            className={'!rounded-s-none'}
                                            placeholder={'رمز پویا'}
                                            rules={[
                                                {
                                                    required: true,
                                                    message: inputRule('required input', {inputName: 'رمز پویا'}),
                                                },
                                            ]}
                                        />
                                    </Col>

                                    <Col flex="19%" className={'items-center'}>
                                        {
                                            resendCode ?

                                                <Button
                                                    block
                                                    type={'secondary'}
                                                    className="!mt-[36px] !h-[43px] !rounded-s-none text-[12px] !bg-purple !border-white"
                                                    height={42}
                                                    width={'100%'}
                                                    disabled={!!resendCode}
                                                    onClick={handleSendOtp}
                                                >
                                                    ارسال مجدد
                                                </Button> :
                                                <Button
                                                    block
                                                    type={'secondary'}
                                                    className="!mt-[36px] !h-[43px] !rounded-s-none max-lg:text-[12px] !bg-purple !border-white"
                                                    height={42}
                                                    width={'100%'}
                                                    onClick={handleSendOtp}
                                                >
                                                    دریافت رمز پویا
                                                </Button>
                                        }

                                    </Col>
                                </Row>
                            </Col>


                            <Col span={24} className="mt-[10px]">
                                <SendPinReminder
                                    resendCode={resendCode}
                                    setResendCode={setResendCode}
                                    sendPinIsSuccess={sendOtpIsSuccess}

                                />
                            </Col>

                            <Col xs={24} sm={12} lg={8} className={' mb-[10px] mx-auto mt-[50px]'}>
                                <Button
                                    className={'w-full text-[13px]'}
                                    type={'secondary'}
                                    htmlType={'submit'}
                                    icon={<LeftOutlined/>}
                                    iconAlign={'end'}

                                >
                                    برداشت از کیف پول
                                </Button>
                            </Col>
                        </div>
                    }
                    {
                        cashOutStep === 1 &&
                        <div
                            className={'mx-auto relative text-textcolor !text-center !items-center text-[14px] pb-8 w-2/3'}>
                            <div className={'m-auto text-center items-center mt-8'}>
                                <img className={'inline text-tick pb-5'} src={'/images/Tick Square.svg'}/>
                                <h1 className={'text-tick text-[16px] max-lg:text-[12px]'}>
                                    برداشت موفقیت آمیز بود
                                </h1>
                                <div className={'flex justify-between items-center pt-8 pb-[43px] '}>

                                </div>
                            </div>
                            <Col xs={24} sm={14} lg={12} className={' max-lg:mt-[1rem] mx-auto'}>
                                <Button
                                    type={'default'}
                                    className={'w-full'}
                                >
                                    بازگشت به صفحه کیف پول
                                </Button>
                            </Col>

                        </div>
                    }
                    <Modal
                        onCancel={handleCloseModal}
                        size={{
                            sm: 55,
                            xs: 55,
                            md: 55,
                            lg: 55,
                            xl: 55,
                            xxl: 30,
                        }}
                        bodyStyle={{
                            padding: 0,
                        }}
                        style={{
                            top: '30vh',
                        }}
                    >

                        <div className={'mx-auto text-textcolor !text-center !items-center text-[14px] pb-10 w-2/3'}>
                            <div className={' items-center text-center pt-8 pb-[43px]'}>
                                <img className={'inline text-tick pb-5'} src={'/images/Close Square.svg'}/>
                                <h1 className={'text-error text-[16px]'}>
                                    برداشت ناموفق
                                </h1>
                            </div>
                            <div className={'flex justify-center items-center pb-[27px] mx-auto'}>
                                {/*<h1>{ errorMessages[cashOutError?.output] || '--' }</h1>*/}
                            </div>
                            <Button
                                type={'default'}
                                className={'max-lg:text-[12px]'}
                                onClick={goToWalletPage}

                            >
                                بازگشت به صفحه کیف پول
                            </Button>
                        </div>

                    </Modal>

                </ForgetPasswordContainer>
            </Form>
        </Spin>
    );
};

export default CashOut;

