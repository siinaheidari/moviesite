import React, {useEffect} from 'react';
import {Button, Form, Input, Radio, Select} from "antd";
import {inputRule} from "../../../../../utils/helper";
import {DatePicker, SelectBox} from "../../../../../templates/Ui";
import starkString from "starkstring";


const {Option} = Select;
const layout = {
  labelCol: {
    span: 24,
  },
  wrapperCol: {
    span: 24,
  },
};

const CreateWallet = () => {
  const [form] = Form.useForm();
  const onFinish = (values) => {
    console.log(values);
  };

  const CreateWalletPhone = Form.useWatch('CreateWalletPhone', form);

  useEffect(() => {
    form.setFields([
      {
        name: 'CreateWalletPhone',
        value: starkString(CreateWalletPhone).parseNumber().englishNumber().toString(),
        errors: []
      }
    ])
  }, [CreateWalletPhone]);

  const nationalCode = Form.useWatch('nationalCode', form);

  useEffect(() => {
    form.setFields([
      {
        name: 'nationalCode',
        value: starkString(nationalCode).parseNumber().englishNumber().toString(),
        errors: []
      }
    ])
  }, [nationalCode]);
  const postNumber = Form.useWatch('postNumber', form);

  useEffect(() => {
    form.setFields([
      {
        name: 'postNumber',
        value: starkString(postNumber).parseNumber().englishNumber().toString(),
        errors: []
      }
    ])
  }, [postNumber]);

  const cartNumber = Form.useWatch('cartNumber', form);

  useEffect(() => {
    form.setFields([
      {
        name: 'cartNumber',
        value: starkString(cartNumber).parseNumber().englishNumber().toString(),
        errors: []
      }
    ])
  }, [cartNumber]);

  return (
    <div className={""}>
      <div className={"flex gap-3 bg-backbtn text-white px-5"}>
        <img
          className={" border-2 rounded-md"}
          src={"/images/wallet.svg"}/>
        <p className={"my-3"}>فعال سازی کیف پول</p>
      </div>
      <div className={"mt-[20px] px-[36px]"}>
        <Form
          className={"items-center mx-auto"}
          {...layout}
          form={form}
          name="createWallet"
          onFinish={onFinish}
          style={{
            maxWidth: 600,
          }}
        >
          <div className={"flex justify-center items-center gap-6 "}>
            <div className={"w-1/2"}>
              <Form.Item
                name="CreateWalletPhone"
                label="شماره موبایل"
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'شماره موبایل'})
                  },
                  {
                    pattern: new RegExp(/^[0-9]+$/),
                    message: inputRule('must be number input', {inputName: 'شماره موبایل'})
                  },
                  {
                    min: 11,
                    message: inputRule('minLength input', {inputName: 'شماره موبایل', length: 11}),
                    validateTrigger: 'onBlur'
                  },
                  {
                    max: 11,
                    message: inputRule('maxLength input', {inputName: 'شماره موبایل', length: 11})
                  }
                ]}
              >
                <Input rootClassName={"h-[42px] border border-borderblue"}/>
              </Form.Item>
            </div>
            <div className={"w-1/2"}>
              <Form.Item
                name="nationalCode"
                label="کد ملی"
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'کد ملی'})
                  },
                  {
                    pattern: new RegExp(/^[0-9]+$/),
                    message: inputRule('must be number input', {inputName: 'کد ملی'})
                  },
                  {
                    min: 10,
                    message: inputRule('minLength input', {inputName: 'کد ملی', length: 10}),
                    validateTrigger: 'onBlur'
                  },
                  {
                    max: 10,
                    message: inputRule('maxLength input', {inputName: 'کد ملی', length: 10})
                  }
                ]}
              >
                <Input rootClassName={"h-[42px] border border-borderblue"}/>
              </Form.Item>

            </div>
          </div>
          <div className={"flex  gap-6 "}>
            <div className={"w-1/2"}>
              <DatePicker
                name='birthDate'
                label='تاریخ تولد'
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required selectBox', {inputName: 'تاریخ تولد'})
                  }
                ]}
                maxDate={true}
                ltr
              />
            </div>
            <div className={"w-1/2"}>
              <Form.Item
                name="postNumber"
                label="کد پستی"
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'کد پستی'})
                  },
                  {
                    pattern: new RegExp(/^[0-9]+$/),
                    message: inputRule('must be number input', {inputName: 'کد پستی'})
                  },
                  {
                    min: 10,
                    message: inputRule('minLength input', {inputName: 'کد پستی', length: 10}),
                  },
                  {
                    max: 10,
                    message: inputRule('maxLength input', {inputName: 'کد پستی', length: 10})
                  }
                ]}
              >
                <Input rootClassName={"h-[42px] border border-borderblue"}/>
              </Form.Item>

            </div>
          </div>

          <div className={"flex  gap-6 "}>
            <div className={"w-1/2"}>
              <Form.Item
                name="cartNumber"
                label="شماره کارت"
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'شماره کارت'})
                  },
                  {
                    pattern: new RegExp(/^[0-9]+$/),
                    message: inputRule('must be number input', {inputName: 'شماره کارت'})
                  },
                  {
                    min: 10,
                    message: inputRule('minLength input', {inputName: 'شماره کارت', length: 10}),
                  },
                  {
                    max: 10,
                    message: inputRule('maxLength input', {inputName: 'شماره کارت', length: 10})
                  }
                ]}
              >
                <Input rootClassName={"h-[42px] border border-borderblue"}/>
              </Form.Item>
            </div>
            <div className={"w-1/2"}>
              <Form.Item
                name="shabNumber"
                label="شماره شبا"
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'شماره شبا'})
                  },

                  {
                    min: 14,
                    message: inputRule('minLength input', {inputName: 'شماره شبا', length: 14}),
                    validateTrigger: 'onBlur'
                  },
                  {
                    max: 14,
                    message: inputRule('maxLength input', {inputName: 'شماره شبا', length: 14})
                  }
                ]}
              >
                <Input rootClassName={"h-[42px] border border-borderblue"}/>
              </Form.Item>

            </div>
          </div>

          <div className={"mt-10  items-center text-center m-auto w-full max-w-[420px]"}>
            <Form.Item rootClassName={""}>
              <div className={"flex gap-3 "}>
                <Button className={"bg-chargblue w-1/2 h-[38px] !text-white"} htmlType="submit">
                  فعال سازی کیف پول
                </Button>

                <Button className={" w-1/2  h-[38px] hover:bg-chargblue hover:!text-white"}
                        htmlType="submit">
                  انصراف
                </Button>
              </div>
            </Form.Item>
          </div>
        </Form>
      </div>
    </div>
  );
};

export default CreateWallet;