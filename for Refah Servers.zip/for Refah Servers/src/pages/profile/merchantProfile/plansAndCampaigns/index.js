import { Col, Row, Space } from 'antd';
import { motion } from 'framer-motion';
import styled from 'styled-components';

// plans image
import plan1 from 'assets/images/plans/plan1.png';
import plan2 from 'assets/images/plans/plan2.png';
import plan3 from 'assets/images/plans/plan3.png';
import plan4 from 'assets/images/plans/plan4.png';
import TitleByCircle from '../../../../templates/components/TitleByCircle';
import ListCircle from '../../../../templates/components/ListCircle';
import { Link } from 'react-router-dom';
import rightArrow from '../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../assets/icons/mobile/circle.svg';
import React from 'react';




const PlansAndCampaigns = () => {
  return (
      <>
          <Col span={ 24 } className={ ' mb-[13px] lg:hidden' }>
              <Link to={ -1 } className={ '' }> <img src={ rightArrow }/></Link>
          </Col>
          <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
              <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                  <img src={ circle }/>
                  طرح ها و کمپین ها
              </Space>
          </div>
    <Row gutter={ [16, 20] } className={"text-justify text-textcolor font-[500] text-[12px]  [&>div>div>img]:w-full"}>
      <Col xs={ 24 } md={ 12 }>
        <motion.div whileTap={ { scale: 0.95 } } className={" bg-white rounded-[20px] overflow-hidden"}>
          <img src={ plan1 } draggable={ false }/>
          <Space align={"center"} className={"text-[14px] max-lg:text-[12px] max-lg:font-[400] px-[18px] font-[500] text-textblue mt-[15px] mb-[10px]"}>
              <ListCircle width={10} height={10} space={0} linear/>
           طرح وام فوری بدون ضامن بانک رفاه
          </Space>
          <p className={"leading-5 max-lg:text-[12px] max-lg:font-[400] px-[18px] text-[12px]"}>به گزارش بانک اول هر چند بانک ها به طور سنتی و از سالهای پیش معمولا پرداخت وام و تسهیلات را در ماه پایانی سال به حداقل می رسانند و یا به طور کلی متوقف می کنند. </p>
          <div className={"w-full text-[#407BFF] px-[18px] !pb-[21px] underline mt-[10px]  max-lg:text-[12px] max-lg:font-[400]"}>اطلاعات بیشتر</div>
        </motion.div>
      </Col>
      <Col xs={ 24 } md={ 12 }>
        <motion.div whileTap={ { scale: 0.95 } } className={" bg-white rounded-[20px] overflow-hidden"}>
          <img src={ plan2 } draggable={ false }/>
          <Space align={"center"} className={"text-[14px] px-[18px] max-lg:text-[12px] font-[500] text-textblue mt-[15px] mb-[10px]"}>
            <ListCircle width={10} height={10} space={0} linear/>
            طرح وام فوری بدون ضامن بانک رفاه
          </Space>
          <p className={"leading-5 max-lg:text-[12px] max-lg:font-[400] px-[18px] text-[12px]"}>به گزارش بانک اول هر چند بانک ها به طور سنتی و از سالهای پیش معمولا پرداخت وام و تسهیلات را در ماه پایانی سال به حداقل می رسانند و یا به طور کلی متوقف می کنند. </p>
          <div className={"w-full text-[#407BFF] px-[18px] !pb-[21px] underline mt-[10px]  max-lg:text-[12px] max-lg:font-[400]"}>اطلاعات بیشتر</div>
        </motion.div>
      </Col>
      <Col xs={ 24 } md={ 12 }>
        <motion.div whileTap={ { scale: 0.95 } } className={" bg-white rounded-[20px] overflow-hidden"}>
          <img src={ plan3 } draggable={ false }/>
          <Space align={"center"} className={"text-[14px] max-lg:text-[12px] px-[18px] font-[500] text-textblue mt-[15px] mb-[10px]"}>
            <ListCircle width={10} height={10} space={0} linear/>
            طرح وام فوری بدون ضامن بانک رفاه
          </Space>
          <p className={"leading-5 max-lg:text-[12px] max-lg:font-[400] px-[18px] text-[12px]"}>به گزارش بانک اول هر چند بانک ها به طور سنتی و از سالهای پیش معمولا پرداخت وام و تسهیلات را در ماه پایانی سال به حداقل می رسانند و یا به طور کلی متوقف می کنند. </p>
          <div className={"w-full text-[#407BFF] px-[18px] !pb-[21px] underline mt-[10px]  max-lg:text-[12px] max-lg:font-[400]"}>اطلاعات بیشتر</div>
        
        </motion.div>
      </Col>
      <Col xs={ 24 } md={ 12 }>
        <motion.div whileTap={ { scale: 0.95 } } className={" bg-white rounded-[20px] overflow-hidden"}>
          <img src={ plan4 } draggable={ false }/>
          <Space align={"center"} className={"text-[14px] max-lg:text-[12px] px-[18px] font-[500] text-textblue mt-[15px] mb-[10px]"}>
            <ListCircle width={10} height={10} space={0} linear/>
            طرح وام فوری بدون ضامن بانک رفاه
          </Space>
          <p className={"leading-5 max-lg:text-[12px] max-lg:font-[400] px-[18px] text-[12px]"}>به گزارش بانک اول هر چند بانک ها به طور سنتی و از سالهای پیش معمولا پرداخت وام و تسهیلات را در ماه پایانی سال به حداقل می رسانند و یا به طور کلی متوقف می کنند. </p>
            <div className={"w-full  max-lg:text-[12px] max-lg:font-[400] text-[#407BFF] px-[18px] !pb-[21px] underline mt-[10px]"}>اطلاعات بیشتر</div>
        </motion.div>
      </Col>
    </Row>
      </>
  );
};

export default PlansAndCampaigns;
