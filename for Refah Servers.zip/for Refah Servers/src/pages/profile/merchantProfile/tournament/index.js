import { Col, Image, Row, Space } from 'antd';
import styled from 'styled-components';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

// images
import tournament1 from 'assets/images/tournament/tournament1.png';
import tournament2 from 'assets/images/tournament/tournament2.png';
import tournament3 from 'assets/images/tournament/tournament3.png';

import mobile1 from 'assets/images/tournament/mobile1.svg';
import mobile2 from 'assets/images/tournament/mobile2.svg';
import mobile3 from 'assets/images/tournament/mobile3.svg';

import { MatchBreakpoint } from 'react-hook-breakpoints';
import rightArrow from '../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../assets/icons/mobile/circle.svg';
import filter from '../../../../assets/icons/mobile/Filter.svg';
import React from 'react';
import { TransitionsPage } from '../../../../templates/Ui';

const TournamentContainer = styled(Row)`
  .--image {
    box-shadow: 0 4px 4px rgba(122, 122, 122, 0.1);
    border-radius: 10px;
    overflow: hidden;
    position: relative;
  
    img {
      -webkit-transition: ease all .3s;
      -moz-transition: ease all .3s;
      -o-transition: ease all .3s;
      transition: ease all .3s;
      -webkit-transform: scale(1);
      -moz-transform: scale(1);
      -o-transform: scale(1);
      transform: scale(1);
    }

    :hover {
      img {
        -webkit-transform: scale(1.1);
        -moz-transform: scale(1.1);
        -ms-transform: scale(1.1);
        -o-transform: scale(1.1);
        transform: scale(1.1);
      }
    }

    a {
      position: absolute;
      inset: 0;
      z-index: 2;
    }
  }
`;


const Tournament = () => {
  return (
      <TransitionsPage  coordinates={'x'}>

      <MatchBreakpoint max="md">
              <Col span={ 24 } className={ ' mb-[13px] lg:hidden' }>
                  <Link to={ "/merchantProfile" } className={ '' }> <img src={ rightArrow }/></Link>
              </Col>
              <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
                  <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                      <img src={ circle }/>
                      نمایش اطلاعات بانکی
                  </Space>
              </div>
              <Row gutter={[0,15]}>
                  <Col span={ 24 } className='--image'>
                      <motion.div whileTap={ { scale: .95 } }>
                          <Image src={ mobile1 } width={ '100%' } height={ '100%' } preview={ false } draggable={ false }/>

                          <Link to=''/>
                      </motion.div>
                  </Col>

                  <Col span={ 24 } className='--image'>
                      <motion.div whileTap={ { scale: .95 } }>
                          <Image src={ mobile2 } width={ '100%' } height={ '100%' } preview={ false } draggable={ false }/>

                          <Link to=''/>
                      </motion.div>
                  </Col>

                  <Col span={ 24 } className='--image'>
                      <motion.div whileTap={ { scale: .95 } }>
                          <Image src={ mobile3 } width={ '100%' } height={ '100%' } preview={ false } draggable={ false }/>

                          <Link to=''/>
                      </motion.div>
                  </Col>

              </Row>

      </MatchBreakpoint>

    <MatchBreakpoint min="lg">
        <TournamentContainer gutter={ [0, 30] } >
            <Col span={ 24 } className='--image'>
                <motion.div whileTap={ { scale: .95 } }>
                    <Image src={ tournament1 } width={ '100%' } height={ '100%' } preview={ false } draggable={ false }/>

                    <Link to=''/>
                </motion.div>
            </Col>

            <Col span={ 24 } className='--image'>
                <motion.div whileTap={ { scale: .95 } }>
                    <Image src={ tournament2 } width={ '100%' } height={ '100%' } preview={ false } draggable={ false }/>

                    <Link to=''/>
                </motion.div>
            </Col>

            <Col span={ 24 } className='--image'>
                <motion.div whileTap={ { scale: .95 } }>
                    <Image src={ tournament3 } width={ '100%' } height={ '100%' } preview={ false } draggable={ false }/>

                    <Link to=''/>
                </motion.div>
            </Col>
        </TournamentContainer>
    </MatchBreakpoint>
</TransitionsPage>
  );
};

export default Tournament;
