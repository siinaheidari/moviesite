import { Col, ConfigProvider, Popover, Row, Statistic } from 'antd';
import styled from 'styled-components';
import TitleByCircle from 'templates/components/TitleByCircle';
import { formatNumber } from 'utils/helper';
import { useEffect, useState } from 'react';

const { Countdown } = Statistic;

const LotteryChanceContainer = styled(Row)`
  .--timeLeft,
  .--remainingTransaction {
    padding: 0 12px;

    .__description {
      color: #4D4D4D;
      font-size: .75rem;
      font-weight: 400;
    }
  }
  
  .--countDown {
    direction: ltr;
  }

  .--timeLeft {
    direction: ltr;

    .__box {
      > div {
        background: linear-gradient(44.14deg, #F61982 2.69%, #21409A 93.25%);
        border-radius: 10px;
        text-align: center;
        padding: 1.6vw 5px;

        .--title,
        .--number {
          color: #FFFFFF;
          font-weight: 400;
          font-size: .625rem;
        }

        .--number {
          font-weight: 500;
          font-size: 1.125rem;
          margin-top: 12px;
        }
      }
    }

    .__box,
    .__description {
      direction: rtl;
    }
  }

  .--remainingTransaction {
    > .ant-row {
      background: #F9F9F9;
      border-radius: 10px;
      padding: 20px 16px;

      .--progress {
        background: #D9D9D9;
        border-radius: 4px;
        overflow: hidden;
        position: relative;
        height: 9px;
        direction: ltr;

        .__tail {
          background: linear-gradient(269.82deg, #21409A 0%, #F61982 100%);
          border-radius: 4px;
          height: 100%;
          cursor: pointer;
        }
      }

      .--amounts {
        margin-top: 10px;
        direction: ltr;

        .__amount {
          direction: rtl;

          > div {
            font-size: .625rem;

            :first-child {
              color: #232429;
              font-weight: 500;
            }

            :last-child {
              color: #7A7A7A;
              font-weight: 400;
              margin-top: 3px;
            }
          }
        }
      }
    }
  }
`;

const LotteryChance = () => {
  
  const THREE_DAYS_IN_MS = 3 * 24 * 60 * 60 * 1000;
  const NOW_IN_MS = new Date().getTime();
  
  const dateTimeAfterThreeDays = NOW_IN_MS + THREE_DAYS_IN_MS;
  
  const [targetDate, setTargetDate] = useState(new Date(dateTimeAfterThreeDays));
  
  const [days, hours, minutes, seconds] = useCountdown(targetDate);
  
  return (
    <LotteryChanceContainer gutter={ [0, 25] }>
      <Col span={ 24 }>
        <TitleByCircle text={ 'شانس شرکت در قرعه کشی' }/>
      </Col>
      
      <Col span={ 24 } className='--timeLeft'>
        <Row gutter={ [14, 12] }>
          <Col span={ 6 } className='__box __day'>
            <TimeLeftBox title={ 'روز' } number={ days }/>
          </Col>
          
          <Col span={ 6 } className='__box __day'>
            <TimeLeftBox title={ 'ساعت' } number={ hours }/>
          </Col>
          
          <Col span={ 6 } className='__box __day'>
            <TimeLeftBox title={ 'دقیقه' } number={ minutes }/>
          </Col>
          
          <Col span={ 6 } className='__box __day'>
            <TimeLeftBox title={ 'ثانیه' } number={ seconds }/>
          </Col>
          
          <Col span={ 24 } className='__description'>
            باقیمانده تا زمان قرعه کشی
          </Col>
        </Row>
      </Col>
      
      <Col span={ 24 } className='--remainingTransaction'>
        <Row gutter={ [0, 22] }>
          <Col span={ 24 } className='__description'>
            مقدار تراکنش باقیمانده تا شرکت در قرعه کشی
          </Col>
          
          <Col span={ 24 }>
            <div className='--progress'>
              <Popover
                placement={ 'bottomRight' }
                content={ `${ formatNumber(1500000) } تومان` }
                overlayClassName='__currentTransaction'
              >
                <div className='__tail' style={ { width: '52%' } }/>
              </Popover>
            </div>
            
            <Row gutter={ 16 } justify={ 'space-between' } className='--amounts'>
              <Col className='__amount'>
                <div>{ formatNumber(0) }</div>
                <div>تومان</div>
              </Col>
              
              <Col className='__amount'>
                <div>{ formatNumber(3000000) }</div>
                <div>تومان</div>
              </Col>
            </Row>
          </Col>
        </Row>
      </Col>
    </LotteryChanceContainer>
  );
};

const TimeLeftBox = ({ title, number }) => {
  return (
    <div>
      <div className='--title'>{ title }</div>
      
      <div className='--number'>{ number }</div>
    </div>
  );
};

const useCountdown = (targetDate) => {
  const countDownDate = new Date(targetDate).getTime();
  
  const [countDown, setCountDown] = useState(
    countDownDate - new Date().getTime()
  );
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCountDown(countDownDate - new Date().getTime());
    }, 1000);
    
    return () => clearInterval(interval);
  }, [countDownDate]);
  
  return getReturnValues(countDown);
};

const getReturnValues = (countDown) => {
  // calculate time left
  const days = Math.floor(countDown / (1000 * 60 * 60 * 24));
  const hours = Math.floor(
    (countDown % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
  );
  const minutes = Math.floor((countDown % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((countDown % (1000 * 60)) / 1000);
  
  return [days, hours, minutes, seconds];
};

export default LotteryChance;
