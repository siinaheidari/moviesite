import { Col, Row } from 'antd';
import styled from 'styled-components';

// Gauge Chart
import { Cell, Legend, Pie, PieChart, Tooltip } from 'recharts';
import TitleByCircle from 'templates/components/TitleByCircle';

const ScorePointsCharContainer = styled(Row)`
  .--chart {
    text-align: center;

    .recharts-wrapper {
      width: 100% !important;
      height: 100% !important;

      .recharts-legend-wrapper {
        width: 100% !important;
        bottom: 0 !important;

        .recharts-default-legend {
          text-align: center !important;

          .recharts-legend-item {
            margin-inline-start: 0 !important;
            margin-inline-end: 30px !important;

            .recharts-surface {
              margin-inline-start: 0 !important;
              margin-inline-end: 7px !important;
            }

            .recharts-legend-item-text {
              color: #4D4D4D !important;
              font-size: .875rem;
              font-weight: 400;
            }
          }
        }
      }
    }
  }
`;

const ScorePointsChart = () => {
  
  const COLORS = ['#1447A0', '#D11575'];
  
  const data = [
    {
      name: 'مالی',
      value: 75
    },
    {
      name: 'غیر مالی',
      value: 25
    }
  ];
  
  const RADIAN = Math.PI / 180;
  
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }) => {
    const radius = innerRadius + ( outerRadius - innerRadius ) * 0.5;
    let percentDraft;
    if (percent <= 0.25) {
      percentDraft = percent * 90;
    }
    else if (percent > 0.25 && percent <= 0.5) {
      percentDraft = percent * 25;
    }
    else if (percent > 0.5) {
      percentDraft = percent;
    }
    
    const x = cx + radius * Math.cos(-midAngle * RADIAN) + percentDraft;
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    
    return (
      <text x={ x } y={ y } fill='white' textAnchor={ x > cx ? 'start' : 'end' } dominantBaseline='central'>
        { `${ ( percent * 100 ).toFixed(0) }%` }
      </text>
    );
  };
  
  return (
    <ScorePointsCharContainer gutter={ [0, 25] }>
      <Col span={ 24 } className='--topSection'>
        <TitleByCircle text={ 'نمودار جزئیات امتیازات کسب شده' }/>
      </Col>
      
      <Col span={ 24 } className='--chart'>
        <PieChart width={ 176 } height={ 176 }>
          <Legend layout='horizontal' verticalAlign='bottom' align='right'/>
          <Pie
            data={ data }
            cx='50%'
            cy='50%'
            labelLine={ false }
            label={ renderCustomizedLabel }
            outerRadius={ 80 }
            fill={ '#8884d8' }
            dataKey='value'
          >
            { data.map((_, index) => (
              <Cell key={ `cell-${ index }` } fill={ COLORS[ index % COLORS.length ] }/>
            )) }
            <Tooltip/>
          </Pie>
        </PieChart>
      </Col>
    </ScorePointsCharContainer>
  );
};

export default ScorePointsChart;
