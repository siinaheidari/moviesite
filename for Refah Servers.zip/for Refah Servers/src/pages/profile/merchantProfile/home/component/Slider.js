import { Image } from 'antd';
import styled from 'styled-components';
import tw from 'twin.macro';
// sliders image
import profileSliderImg1 from 'assets/images/profile/profileSliderImg1.png';
import profileSliderImg2 from 'assets/images/profile/profileSliderImg2.png';
import profileSliderImg3 from 'assets/images/profile/profileSliderImg3.png';


import slide1 from 'assets/images/mobile/slide1.svg';
import slide2 from 'assets/images/mobile/slide2.svg';
import slide3 from 'assets/images/mobile/slide3.svg';

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// import Swiper core and required modules
import SwiperCore, { Autoplay, Pagination } from 'swiper';

// Import Swiper styles
import 'swiper/css/bundle';
import 'swiper/css/pagination';
import 'swiper/css';


// install Swiper modules
SwiperCore.use([ Autoplay, Pagination ]);

const SliderContainer = styled(Swiper)`
  border-radius: 10px;
  overflow: hidden;
  
  ${ tw`max-lg:(!rounded-none) max-lg:!mx-[-19px] max-lg:!my-[-40px]` }
  .swiper-scrollbar {
    display: none;
  }

  .swiper-pagination {
    bottom: 22px !important;

    .swiper-pagination-bullet {
      width: 10px;
      height: 10px;
      background-color: #fff;
      opacity: 1;
      box-shadow: 0 4px 4px rgba(0, 0, 0, 0.05);
      margin: 0 6px !important;

      &.swiper-pagination-bullet-active {
        background-color: #21409A;
      }
    }
  }
`;

const SwiperSlideContent = styled(SwiperSlide)`
`;

const Slider = ({ mode = 'desktop' }) => {
  
  const swiperProps = {
    dir: 'rtl',
    slidesPerView: 1,
    spaceBetween: 13,
    scrollbar: {
      hide: true,
    },
    direction: 'horizontal',
    loop: true,
    autoplay: {
      delay: 4000,
      disableOnInteraction: false,
      pauseOnMouseEnter: true,
    },
    pagination: {
      'clickable': true,
    },
  };
  
  if (mode == 'desktop') {
    return (
      <SliderContainer { ...swiperProps }>
        <SwiperSlideContent dir={ 'rtl' } className="--sliderOne">
          <Image src={ profileSliderImg1 } width={ '100%' } height={ 250 } preview={ false }/>
        </SwiperSlideContent>
        
        <SwiperSlideContent dir={ 'rtl' } className="--sliderTow">
          <Image src={ profileSliderImg2 } width={ '100%' } height={ 250 } preview={ false }/>
        </SwiperSlideContent>
        
        <SwiperSlideContent dir={ 'rtl' } className="--sliderTow">
          <Image src={ profileSliderImg3 } width={ '100%' } height={ 250 } preview={ false }/>
        </SwiperSlideContent>
      </SliderContainer>
    );
  }
  
  return (
    <SliderContainer { ...swiperProps }>
      <SwiperSlideContent dir={ 'rtl' } className="--sliderOne">
        <Image src={ slide1 } width={ '100%' } preview={ false }/>
      </SwiperSlideContent>
      
      <SwiperSlideContent dir={ 'rtl' } className="--sliderTow">
        <Image src={ slide2 } width={ '100%' } preview={ false }/>
      </SwiperSlideContent>
      
      <SwiperSlideContent dir={ 'rtl' } className="--sliderTow">
        <Image src={ slide3 } width={ '100%' } preview={ false }/>
      </SwiperSlideContent>
    </SliderContainer>
  );
};

export default Slider;
