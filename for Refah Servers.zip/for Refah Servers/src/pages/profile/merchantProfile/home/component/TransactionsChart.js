import { Col, ConfigProvider, Row, Select, Space } from 'antd';
import { useMemo, useState } from 'react';
import styled from 'styled-components';
import TitleByCircle from 'templates/components/TitleByCircle';
import { SelectBox } from 'templates/Ui';

// chart
import { Line } from '@ant-design/plots';
import { formatNumber } from 'utils/helper';

const TransactionsChartContainer = styled(Row)`
  .--topSection {
    .__actions {
      text-align: end;

      > .ant-space {
        text-align: start;
      }
    }
  }

  .--bottomSection {
    text-align: center;
    
    .g2-tooltip {
      .g2-tooltip-list {
        .g2-tooltip-list-item {
          display: flex;
          flex-direction: row;
          row-gap: 10px;
          
          .g2-tooltip-marker {
            margin-right: 0 !important;
            margin-inline-end: 5px;
          }
          
          .g2-tooltip-value {
            margin-left: 0 !important;
            margin-inline-start: 30px;
          }
        }
      }
    }
  }
`;

const TransactionsChart = () => {
  const [transactionPeriod, setTransactionPeriod] = useState('M');
  
  const test = {
    "status": "successed",
    "description": {
      "report": [
        {
          "month": 'فرودین',
          value: 3400000
        },
        {
          "month": 'اردیبهشت',
          value: 1400000
        },
        {
          "month": 'خرداد',
          value: 1500000
        },
        {
          "month": 'تیر',
          value: 3400000
        },
        {
          "month": 'مرداد',
          value: 4000000
        },
        {
          "month": 'شهریور',
          value: 360000
        },
        {
          "month": 'مهر',
          value: 900000
        },
        {
          "month": 'آبان',
          value: 3000000
        },
        {
          "month": 'آذر',
          value: 700000
        },
        {
          "month": 'دی',
          value: 2500000
        },
        {
          "month": 'بهمن',
          value: 1600000
        },
        {
          "month": 'اسفند',
          value: 1500000
        },
      ],
      "trackID": "",
      "timeStamp": 1661587739810
    }
  }
  
  const handleModifyData = data => {
    let periodParam;
    
    switch (transactionPeriod) {
      case "W":
        periodParam =  "day";
        break;
      
      case "M":
        periodParam =  "month";
        break;
      
      case "Y" || "A":
        periodParam =  "year";
        break;
      
      default:
        periodParam =  "from_to_IR";
    }
    
    const periodObject = [];
    
    data?.description?.report?.map(item => {
      periodObject.push({
          type: "success",
          period: item?.[periodParam],
          value : item.value
        })
    });
    
    return periodObject
  }
  
  const modifiedTransactions = useMemo(() => test ? handleModifyData(test) : [], [test]);
  
  const config = {
    data: modifiedTransactions,
    height: 250,
    autoFit: true,
    color: '#F61982',
    xField: 'period',
    yField: 'value',
    yAxis: {
      nice: true,
      tickCount: 12,
    },
    xAxis: {
      nice: true,
      tickCount: 12,
      label: {
        autoHide: false,
        autoRotate: true,
      },
    },
    legend: false,
    seriesField: 'type',
    point: {
      color: '#F61982',
      style: {
        fill: '#F61982',
        stroke: '#F61982',
        lineWidth: 2,
      },
    },
    tooltip: {
      showMarkers: true,
      formatter: item => {
        return { name: 'تراکنش', value: formatNumber(item?.value) }
      },
    },
    interactions: [
      {
        type: 'custom-marker-interaction',
      },
    ],
    smooth: true,
    slider: {
      start: 0,
      end: 1,
    },
  };
  
  const handleTransactionExport = type => {
    console.log(type);
  };
  
  return (
    <TransactionsChartContainer gutter={ [0, 70] }>
      <Col span={ 24 } className='--topSection'>
        <Row align={ 'middle' } justify={ 'space-between' }>
          <Col span={ 10 } className='__title'>
            <TitleByCircle text={ 'تراکنش های انجام شده' }/>
          </Col>
          
          <Col span={ 10 } className='__actions'>
            <Space size={ 15 }>
              <SelectBox
                withoutForm
                placeholder={ 'بازه زمانی' }
                defaultValue={ transactionPeriod }
                onChange={ e => setTransactionPeriod(e) }
                selectBoxStyle={ {
                  minWidth: 93
                } }
              >
                <Select.Option value={ 'Y' }>سالانه</Select.Option>
                <Select.Option value={ 'M' }>ماهانه</Select.Option>
                <Select.Option value={ 'W' }>هفتگی</Select.Option>
                <Select.Option value={ 'D' }>روزانه</Select.Option>
              </SelectBox>
              
              <SelectBox
                withoutForm
                placeholder={ 'خروجی' }
                onChange={ e => handleTransactionExport(e) }
                selectBoxStyle={ {
                  minWidth: 93
                } }
              >
                <Select.Option value={ 'excel' }>اکسل</Select.Option>
              </SelectBox>
            </Space>
          </Col>
        </Row>
      </Col>
      
      <Col span={ 24 } className='--bottomSection'>
        <Line {...config} />
      </Col>
    </TransactionsChartContainer>
  );
};

export default TransactionsChart;
