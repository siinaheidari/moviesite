import { Col, Row } from 'antd';
import styled from 'styled-components';

// components
import Slider from '../component/Slider';
import ScorePointsChart from '../component/ScorePointsChart';
import LotteryChance from '../component/LotteryChance';
import TransactionsChart from '../component/TransactionsChart';

const ProfileContainer = styled(Row)`
  .--box {
    > .ant-row {
      background-color: #FFFFFF;
      box-shadow: 0 4px 4px rgba(122, 122, 122, 0.05);
      border-radius: 10px;
      overflow: hidden;
      padding: 20px 28px 40px;
      height: 100%;
    }
  }
`;

const HomeDesktop = () => {
  return (
    <ProfileContainer gutter={ [16, 20] } align={ 'stretch' }>
      <Col span={ 24 }>
        <Slider/>
      </Col>
      
      <Col xs={ 24 } md={ 12 } className='--box'>
        <ScorePointsChart/>
      </Col>
      
      <Col xs={ 24 } md={ 12 } className='--box'>
        <LotteryChance/>
      </Col>
      
      <Col span={ 24 } className='--box'>
        <TransactionsChart/>
      </Col>
    </ProfileContainer>
  );
};

export default HomeDesktop;
