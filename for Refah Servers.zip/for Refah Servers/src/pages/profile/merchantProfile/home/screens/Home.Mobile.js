import React from 'react';
import dashboard from "assets/icons/mobile/dashbord.svg"
import submitRequest from "assets/icons/mobile/submitRequest.svg"
import Request from "assets/icons/mobile/request.svg"
import Devices from "assets/icons/mobile/devices.svg"
import bankInformation from "assets/icons/mobile/bankInformation.svg"
import Loan from "assets/icons/mobile/loan.svg"
import Partners from "assets/icons/mobile/partner.svg"
import support from "assets/icons/mobile/support.svg"
import lottery from "assets/icons/mobile/lottery .svg"
import Competition from "assets/icons/mobile/competition.svg"
import Survey from "assets/icons/mobile/survey.svg"
import Campain from "assets/icons/mobile/campain.svg"
import discountCode from "assets/icons/mobile/discountCode.svg"


import { Col, Row } from 'antd';
import Slider from '../component/Slider';
import {Link, useNavigate} from 'react-router-dom';
import { TransitionsPage } from '../../../../../templates/Ui';


const HomeMobile = () => {
  const navigate = useNavigate();
  
  const homeMenu=[
    // {
    //   title:"داشبورد",
    //   icon:dashboard
    // },
    {
      title:"ثبت درخواست",
      icon:submitRequest,
      subMenuTitle: 'لیست درخواست ها',
      menuKey: 'requests',
    },
    {
      title:"پیگیری درخواست ها",
      icon:Request,
      link:"/merchantProfile/pursueRequests",
    },
    {
      title:"دستگاه ها و درگاه ها",
      icon:Devices,
      link:"/merchantProfile/terminals",
    },
    {
      title:" اطلاعات بانکی",
      icon:bankInformation,
      link:"/merchantProfile/myBankAccounts"
    },
    {
      title:"تسهیلات قابل اعطا",
      icon:Loan,
      link:"/merchantProfile/facilitiesGrants"

    },
    {
      title:"شرکای تجاری",
      icon:Partners,
      link:"/merchantProfile/businessPartners"
    },
    {
      title:"پشتیبانی",
      icon:support,
      subMenuTitle: 'پشتیبانی',
      menuKey: 'support',
    },
    {
      title:"شرکت در قرعه کشی",
      icon:lottery,
      link:"/merchantProfile/lottery"
    },
    {
      title:"شرکت در مسابقه ",
      icon:Competition,
      link:"/merchantProfile/tournament"
    },
    {
      title:"شرکت در نظرسنجی",
      icon:Survey,
      link:"/merchantProfile/survey"
    },
    {
      title:"طرح ها و کمپین ها",
      icon:Campain,
      link:"/merchantProfile/plansAndCampaigns"
    },
    {
      title:"کدهای تخفیف",
      icon:discountCode,
      link:"/merchantProfile/discountCodes"
    },
  ]
  
  
  return (
    <TransitionsPage coordinates={'x'} size={-35}>
    <Slider mode={'mobile'}/>
    <Row gutter={[13,10]} align={"stretch"} className={"pt-[55px]"}>
      {
        homeMenu?.map((item)=>
          <Col span={8} >
            <div className={"bg-white shadow-10 flex justify-center h-full items-center text-center px-[10px] w-full mx-auto text-[10px] py-[12px] rounded-[10px] text-title"}  onClick={() => {
              if (!!item?.menuKey) {
                navigate('/merchantProfile/subMenu', {state: {menuKey: item?.menuKey, subMenuTitle: item?.subMenuTitle}})
              }
              else {
                navigate(item?.link)
              }
            }}>
              <div>
                <img src={item?.icon} className={"inline mb-[12px]"}/>
                <div>
                  {item?.title}
                </div>
              </div>
            </div>
          </Col>
        )
      }
    </Row>
</TransitionsPage>
  );
};

export default HomeMobile;
