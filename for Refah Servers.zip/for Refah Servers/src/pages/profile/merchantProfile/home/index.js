import HomeMobile from './screens/Home.Mobile';
import HomeDesktop from './screens/Home.desktop';
import { MatchBreakpoint } from 'react-hook-breakpoints';

const Profile = () => {
  return (
   <>
     <MatchBreakpoint max="md">
       <HomeMobile />
     </MatchBreakpoint>
     
     <MatchBreakpoint min="lg">
       <HomeDesktop />
     </MatchBreakpoint>
   </>
  );
};

export default Profile;
