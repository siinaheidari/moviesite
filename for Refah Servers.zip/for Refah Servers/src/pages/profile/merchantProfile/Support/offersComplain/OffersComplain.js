import React, {useState} from 'react';
import {Col, Collapse, Empty, Form, Row, Select, Space} from 'antd';
import {Link} from 'react-router-dom';
import rightArrow from '../../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../../assets/icons/mobile/circle.svg';
import {Button, Modal, SelectBox, TextArea, TransitionsPage} from '../../../../../templates/Ui';
import plus from 'assets/icons/plus.svg';
import {LeftOutlined} from '@ant-design/icons';
import {inputRule} from '../../../../../utils/helper';
import {useRequest} from '../../../../../utils/useRequest';
import {useAuth} from '../../../../../contexts/auth/AuthContext';
import question from '../../../../../assets/icons/question.svg';
import styled from 'styled-components';


const CollapseContainer = styled(Collapse)`

  .ant-collapse {
    border: 0 !important;
    background-color: #F5F5F5 !important;
    border-radius: 50px !important;

    .ant-collapse-item {
      margin-bottom: 18px !important;
      border-radius: 10px !important;
      box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.09);
    }


  }

  :where(.css-dev-only-do-not-override-yp8pcc).ant-collapse {
    border: 0px solid white !important;
  }


  .ant-collapse-content-box {
    background-color: #F9F9F9 !important;
  }

  .ant-collapse-content-box {
    padding-top: 20px !important;
    color: #4d4d4d;
    font-size: 12px !important;
    border-radius: 20px;
  }

  //
  //.ant-collapse-expand-icon {
  //  display: none !important;
  //}
`;

const OffersComplain = () => {
    const {auth} = useAuth();
    const [offersForm] = Form.useForm();
    const {Panel} = Collapse;
    const [ticketModal, setTicketModal] = useState({});
    console.log(auth);



    const onChange = (key) => {
        console.log(key);
    };


    const {
        isLoading: addSuggestionLoading,
        mutateAsync: addSuggestionRequest,
    } = useRequest({
        path: '/suggestion/add',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: 'درخواست شما با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleOffers = async () => {
        const values = offersForm.getFieldsValue(['suggestionsDesc']);
        try {
            await addSuggestionRequest({
                personId: auth?.userId,
                suggestionsDesc: `'${values?.suggestionsDesc}'`,
            });
            await offersForm.resetFields();

        } catch (err) {
            console.log(err);
        }
    };


    const {
        isLoading: adminFaqIsLoading,
        data: adminFaqData,
        refetch: refetchFaq,
    } = useRequest({
        path: '/suggestion/list',
        params: {
            personId: auth?.userId
        },
        key: ['question'],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const FaqDataRes = adminFaqData;


    return (
        <TransitionsPage coordinates={'x'} size={-30}>

            <Row>
                <Col span={24} className={'mb-[13px] lg:hidden'}>
                    <Link to={-1} className={''}> <img src={rightArrow}/></Link>
                </Col>

                <div className={'flex mb-[17px] lg:hidden justify-between items-center'}>
                    <Space align={'center'} className={'text-[12px] font-[500] '}>
                        <img src={circle}/>
                        ثبت شکایات و پیشنهادات
                    </Space>
                </div>

                <Col span={24}
                     className={' mb-[17px] justify-between items-center bg-white lg:p-[33px] max-lg:px-[17px] rounded-[10px]'}>

                    <div align={'center'}
                         className={'text-[14px] flex justify-between text-title font-[500] max-lg:hidden'}>

                        <Space>
                            <img src={plus}/>
                            ثبت شکایات و انتقادات و پیشنهادات
                        </Space>
                        <Button type={"secondary"} onClick={() => setTicketModal(true)}>
                            مشاهده پاسخ ها
                        </Button>

                    </div>

                    <Col span={24}
                         className={'my-[27px] text-[14px] max-lg:text-[12px] font-[400] text-[#4D4D4D] leading-5'}>
                        به اطلاع پذیرندگان محترم می رساند جهت هرگونه شکایت، پیشنهاد و انتقاد می توانید از طریق فرم زیر
                        اقدام نمایید. توجه داشته باشید که پیام های ارسالی به صورت مستقیم توسط مدیریت بررسی خواهند شد.
                    </Col>

                    <Col span={24}>
                        <Form
                            form={offersForm}
                            autoComplete="off"
                            scrollToFirstError
                            labelCol={{
                                span: 24,
                            }}
                            wrapperCol={{
                                span: 24,
                            }}
                            onFinish={handleOffers}
                        >
                            <Row gutter={24}>

                                <Col xs={24} lg={12}>
                                    <SelectBox
                                        name="title"
                                        label={'عنوان'}
                                        placeholder={'شکایت'}
                                        showSearch={false}
                                        rules={[
                                            {
                                                required: true,
                                                message: 'عنوان را انتخاب نمایید',
                                            },
                                        ]}
                                        allowClear={false}
                                    >
                                        <Select.Option value={1}>شکایت</Select.Option>
                                        <Select.Option value={2}>انتقاد و پیشنهادات</Select.Option>

                                    </SelectBox>
                                </Col>
                                {/*<Col xs={ 24 } lg={ 12 }>*/}

                                {/*    <Input*/}
                                {/*        name={ 'subject' }*/}
                                {/*        label={ 'موضوع' }*/}
                                {/*        placeholder={ ' ' }*/}
                                {/*        rules={ [*/}
                                {/*            {*/}
                                {/*                required: true,*/}
                                {/*                message: inputRule('required input', { inputName: 'موضوع' }),*/}
                                {/*            },*/}
                                {/*        ] }*/}
                                {/*    />*/}
                                {/*</Col>*/}

                                <Col span={24}>
                                    <TextArea
                                        name={'suggestionsDesc'}
                                        label={'موضوع توضیحات'}
                                        rows={5}
                                        rules={[
                                            {
                                                required: true,
                                                message: inputRule('required input', {inputName: 'موضوع'}),
                                            },
                                        ]}
                                    />
                                </Col>

                                <Col span={24}
                                     className=" lg:mt-[65px] max-lg:mt-[35px] max-lg:mb-[25px] pb-[25px]">
                                    <Row gutter={16} justify={'center'}>
                                        <Col sm={8} xs={12}>
                                            <Button
                                                type={'default'}
                                                className={'w-full'}
                                            >
                                                <Link to={'/merchantProfile'}>
                                                    انصراف
                                                </Link>

                                            </Button>
                                        </Col>

                                        <Col sm={8} xs={12}>
                                            <Button
                                                type={'secondary'}
                                                htmlType={'submit'}
                                                iconAlign={'end'}
                                                className={'w-full'}
                                            >
                                                <LeftOutlined/>
                                                ارسال درخواست
                                            </Button>
                                        </Col>
                                    </Row>


                                </Col>
                            </Row>
                        </Form>
                    </Col>
                </Col>
                <Modal
                    open={ticketModal}
                    onCancel={() => setTicketModal('')}
                    header={false}
                    size={{
                        sm: 90,
                        xs: 90,
                        md: 90,
                        lg: 70,
                        xl: 70,
                        xxl: 70,
                    }}

                    bodyStyle={{
                        padding: 0,
                    }}
                    style={{
                        top: '10vh',

                    }}
                >
                    <div>
                        <Col span={24} className={"items-center text-center text-textblue pt-4"}>
                            لیست پاسخ ها
                        </Col>
                        <CollapseContainer xs={24} lg={24} className={'my-[20px]'}>
                            <Collapse defaultActiveKey={['1']} expandIconPosition={'end'} onChange={onChange}
                                      accordion
                                      className={'!border-0'}
                                      bordered={false}>
                                {!!FaqDataRes ?
                                    FaqDataRes?.map(item =>
                                        <Panel
                                            header={<div className={'flex gap-2 justify-between'}>
                                                <Space size={14}>
                                                    <img src={question}/>{item?.suggestionsDesc}
                                                </Space>
                                            </div>}
                                            key={item?.rowId}
                                            className={'bg-white'}>
                                            <div className={''}> {item?.answer}</div>
                                        </Panel>,
                                    )
                                    : <Col span={24} className="text-center">
                                        <Empty description={'چیزی یافت نشد'}/>
                                    </Col>
                                }

                            </Collapse>
                        </CollapseContainer>
                    </div>

                </Modal>
            </Row>
        </TransitionsPage>
    );
};

export default OffersComplain;
