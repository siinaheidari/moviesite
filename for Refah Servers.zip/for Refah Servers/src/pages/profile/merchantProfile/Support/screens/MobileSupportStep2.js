import React, { useState } from 'react';
import { Col, Row } from 'antd';
import Arrow from '../../../../../assets/icons/mobile/blueArrow.svg';
import { Modal, TransitionsPage } from '../../../../../templates/Ui';

const MobileSupportStep2 = () => {
  
  const [ currentTab, setCurrentTab ] = useState('');
  const [ supportMobileModal, setSupportMobileModal ] = useState(false);
  
  
  const handleToggleTab = (type) => {
    setCurrentTab(current => current === type ? '' : type);
  };
  
  const handleOpenModal = (type) => {
    setSupportMobileModal(type);
  };
  
  return (
    <Row gutter={ [ 0,16 ] }>
      
      <Col span={ 24 }>
        <div className={ 'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
          <div onClick={ () => handleToggleTab('1') } className={ 'mb-[13px]' }>
            <Row gutter={ [ 5, 13 ] } className={"pt-[20px]"}>
              <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                موضوع:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  اختلال
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                نوع پشتیبانی:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 مالی
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                درجه اهمیت:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        فوری
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                اطلاع رسانی از طریق پیامک:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        بله
                                </span>
              </Col>
            </Row>
          </div>
     
        
            {
              currentTab==="1" ?
                <TransitionsPage coordinates={ 'y' } size={ 10 }>
                
                
                <Row gutter={ [ 5, 13 ] }>
                  <Col span={ 24 } className={ 'text-[12px] font-[500] text-title' }>
                    تاریخ وساعت:
                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1401-08-28و16:14
                                </span>
                  </Col>
                  
                  <Col span={24} className={ 'text-[12px] font-[500] text-title' }>
                    توضیحات:
                  </Col>
                  <Col span={24} className={ 'leading-5 text-[10px] font-[400] text-justify text-[#4D4D4D] bg-[#F5F5F5] p-[14px] !px-[20px] rounded-[10px]' }>
                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                  </Col>
                  
                  <Col span={ 24 } className={ 'text-[12px] font-[500] text-[#407BFF] underline' } onClick={()=>handleOpenModal("1")}>
                    نمایش پاسخ اپراتور
                  </Col>
                  
                </Row>
                </TransitionsPage>
                  :""
          
            }
           
       
          
          <div onClick={ () => handleToggleTab('1') }
               className={ 'w-full items-center text-center' }>
            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
          </div>
        </div>
      </Col>
      <Col span={ 24 }>
        <div className={ 'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
          <div onClick={ () => handleToggleTab('2') } className={ 'mb-[13px]' }>
            <Row gutter={ [ 5, 13 ] } className={"pt-[20px]"}>
              <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                موضوع:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  اختلال
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                نوع پشتیبانی:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 مالی
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                درجه اهمیت:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        فوری
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                اطلاع رسانی از طریق پیامک:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        بله
                                </span>
              </Col>
            </Row>
          </div>
          
          
          {
            currentTab==="2" ?
              <TransitionsPage coordinates={ 'y' } size={ 10 }>
                
                
                <Row gutter={ [ 5, 13 ] }>
                  <Col span={ 24 } className={ 'text-[12px] font-[500] text-title' }>
                    تاریخ وساعت:
                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1401-08-28و16:14
                                </span>
                  </Col>
                  
                  <Col span={24} className={ 'text-[12px] font-[500] text-title' }>
                    توضیحات:
                  </Col>
                  <Col span={24} className={ 'leading-5 text-[10px] font-[400] text-justify text-[#4D4D4D] bg-[#F5F5F5] p-[14px] !px-[20px] rounded-[10px]' }>
                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                  </Col>
                  
                  <Col span={ 24 } className={ 'text-[12px] font-[500] text-[#407BFF] underline' } onClick={()=>handleOpenModal("2")}>
                    نمایش پاسخ اپراتور
                  </Col>
                
                </Row>
              </TransitionsPage>
              :""
            
          }
          
          
          
          <div onClick={ () => handleToggleTab('2') }
               className={ 'w-full items-center text-center' }>
            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
          </div>
        </div>
      </Col>
      <Col span={ 24 }>
        <div className={ 'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
          <div onClick={ () => handleToggleTab('3') } className={ 'mb-[13px]' }>
            <Row gutter={ [ 5, 13 ] } className={"pt-[20px]"}>
              <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                موضوع:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  اختلال
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                نوع پشتیبانی:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 مالی
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                درجه اهمیت:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        فوری
                                </span>
              </Col>
              <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                اطلاع رسانی از طریق پیامک:
                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        بله
                                </span>
              </Col>
            </Row>
          </div>
          
          
          {
            currentTab==="3" ?
              <TransitionsPage coordinates={ 'y' } size={ 10 }>
                
                
                <Row gutter={ [ 5, 13 ] }>
                  <Col span={ 24 } className={ 'text-[12px] font-[500] text-title' }>
                    تاریخ وساعت:
                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1401-08-28و16:14
                                </span>
                  </Col>
                  
                  <Col span={24} className={ 'text-[12px] font-[500] text-title' }>
                    توضیحات:
                  </Col>
                  <Col span={24} className={ 'leading-5 text-[10px] font-[400] text-justify text-[#4D4D4D] bg-[#F5F5F5] p-[14px] !px-[20px] rounded-[10px]' }>
                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                  </Col>
                  
                  <Col span={ 24 } className={ 'text-[12px] font-[500] text-[#407BFF] underline' } onClick={()=>handleOpenModal("3")}>
                    نمایش پاسخ اپراتور
                  </Col>
                
                </Row>
              </TransitionsPage>
              :""
            
          }
          
          
          
          <div onClick={ () => handleToggleTab('3') }
               className={ 'w-full items-center text-center' }>
            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
          </div>
        </div>
      </Col>
     
      <Modal
        open={ supportMobileModal }
        onCancel={ () => setSupportMobileModal(false) }
        header={ false }
        closable={ false }
        bodyStyle={{
          padding: 0,
          backgroundColor:"white"
        }}
        size={ {
          xs: 90,
          sm: 90,
          md: 90,
          lg: 40,
          xl: 40,
          xxl: 30,
        } }
        style={{
          top: "20vh",
        }}
      
      >
        <div className={"px-[30px] pt-[20px] pb-[30px]"}>
          <div className={"text-title mb-[10px] text-[12px] font-[500]"}>پاسخ اپراتور</div>
          <div className={"text-justify text-[#7A7A7A] text-[12px] font-[400]"}>
            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.  لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
          </div>
        </div>
      </Modal>
    </Row>
  );
};

export default MobileSupportStep2;
