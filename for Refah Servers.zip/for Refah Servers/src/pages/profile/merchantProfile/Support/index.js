import React, { useState } from 'react';
import { Col, Form, Row, Select, Space, Spin } from 'antd';
import { Button, Input, Radio, RadioFormItem, RadioGroup, SelectBox, TextArea, TransitionsPage } from 'templates/Ui';
import { LeftOutlined, LoadingOutlined, UnorderedListOutlined } from '@ant-design/icons';

import { Link } from 'react-router-dom';
import rightArrow from '../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../assets/icons/mobile/circle.svg';
import upload from 'assets/icons/upload.svg';
import { inputRule } from '../../../../utils/helper';
import MobileSupportStep2 from './screens/MobileSupportStep2';
import { useRequest } from '../../../../utils/useRequest';
import { useAuth } from '../../../../contexts/auth/AuthContext';
import { BeatLoader } from 'react-spinners';
import refahLogo from '../../../../assets/icons/refahLogo.svg';


const Support = () => {
    const { auth } = useAuth();
    const [ activeTabs, setActiveTabs ] = useState(1);
    const [ lostTerminalFormRef ] = Form.useForm();
    const { Option } = Select;


    const {
        isLoading: lostTerminalLoading,
        mutateAsync: lostTerminalRequest,
    } = useRequest({
        path: '/merchant/add-request',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: 'درخواست شما با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleSupport = async () => {
        const values = lostTerminalFormRef.getFieldsValue([ 'description' ]);
        try {
            await lostTerminalRequest({
                requestTypeId: '55',
                merchentCode: auth?.userId,
                terminalNumber: '445456',
                description: values.description.trim(),
            });

        } catch (err) {
            console.log(err);
        }
    };
    const handleTabs = (index) => {
        setActiveTabs(index);
    };

    return (
        <TransitionsPage id={ activeTabs } coordinates={ 'x' } size={ -30 }>
            <Spin spinning={lostTerminalLoading} className={"relative"} indicator={<LoadingOutlined className={"!hidden"}/>}
                  tip={<div>
                      <BeatLoader
                          color={"#1447a0"}
                          loading={true}
                          size={9}
                          aria-label="Loading Spinner"
                          data-testid="loader"
                      />
                      <img src={refahLogo} width={"90px"} height={"80px"} className={"mx-auto relative top-[-100px]"}/>
                  </div>}>
                <Col xs={ 24 } lg={ 12 }>
                    <Col span={ 24 } className={ 'mb-[13px] lg:hidden' }>
                        <Link to={ -1 } className={ '' }> <img src={ rightArrow }/></Link>
                    </Col>
                    <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
                        <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                            <img src={ circle }/>
                            ارسال تیکت
                        </Space>
                        {
                            activeTabs === 1 ?
                                <div onClick={ () => handleTabs(2) }>

                                    <Button type={ 'secondary' }
                                            className={ 'text-[12px] !min-w-[120px] ' }
                                            icon={ <UnorderedListOutlined style={ { color: 'white' } }/> }>لیست تیکت ها
                                    </Button>
                                </div> : ''
                        }
                    </div>

                </Col>

                <div className={ ' lg:bg-white lg:rounded-[10px]  ' }>
                    <div className={ 'flex justify-between px-[20px] pb-[12px] max-lg:hidden' }>
                        {/*<div onClick={() => handleTabs(1)} className={"flex  items-center gap-3"}>*/ }
                        {/*  <img className={"w-6"} src={"/images/plusicon.svg"}/>*/ }
                        {/*  <h2 className={"text-textblue"}>تیکت جدید</h2>*/ }
                        {/*</div>*/ }
                        {/*<div onClick={() => handleTabs(2)}>*/ }
                        {/*  <Button type={"secondary"}*/ }
                        {/*          icon={<UnorderedListOutlined style={{color: "white"}}/>}>لیست تیکت ها*/ }
                        {/*  </Button>*/ }
                        {/*</div>*/ }
                    </div>
                    <div
                        className={ activeTabs === 1 ? 'bg-white pb-[35px] rounded-[10px] px-[50px] max-lg:px-[18px]' : 'hidden' }>
                        <Form
                            form={ lostTerminalFormRef }
                            autoComplete="off"
                            scrollToFirstError
                            labelCol={ {
                                span: 24,
                            } }
                            wrapperCol={ {
                                span: 24,
                            } }
                            onFinish={ handleSupport }
                        >

                            <Row gutter={ [ 50 ] }>

                                {/*<Col xs={24} lg={12}>*/ }
                                {/*  <Input*/ }
                                {/*    name={ 'title' }*/ }
                                {/*    label={ 'موضوع' }*/ }
                                {/*    rules={ [*/ }
                                {/*      {*/ }
                                {/*        required: true,*/ }
                                {/*        message: inputRule('required input', { inputName: 'موضوع' }),*/ }
                                {/*      },*/ }
                                {/*    ] }*/ }
                                {/*  />*/ }
                                {/*</Col>*/ }


                                <Col xs={ 24 } lg={ 12 }>
                                    <SelectBox
                                        name={ 'supportType' }
                                        label={ 'نوع پشتیبانی' }
                                        placeholder={ 'مالی' }
                                        // rules={[
                                        //   {
                                        //     required: true,
                                        //     message: inputRule('required selectBox', {inputName: 'نوع پشتیبانی'})
                                        //   }
                                        // ]}
                                    >
                                        <Option value={ 0 }>مالی</Option>
                                        <Option value={ 1 }>اداری</Option>
                                    </SelectBox>
                                </Col>

                                <Col xs={ 24 } lg={ 12 }>
                                    <SelectBox
                                        name={ 'important' }
                                        label={ 'درجه اهمیت' }
                                        placeholder={ 'فوری' }
                                        // rules={[
                                        //   {
                                        //     required: true,
                                        //     message: inputRule('required selectBox', {inputName: 'درجه اهمیت'})
                                        //   }
                                        // ]}
                                    >
                                        <Option value={ 0 }>فوری</Option>
                                        <Option value={ 1 }>معمولی</Option>
                                    </SelectBox>
                                </Col>

                                <Col xs={ 24 } lg={ 12 }>
                                    <Row>
                                        <Col flex="1 1">
                                            <Input
                                                name={ 'uploadFile' }
                                                label={ 'فایل ضمیمه' }
                                                formRef={ lostTerminalFormRef }
                                                className={ '!rounded-s-none' }
                                                placeholder
                                                // rules={[
                                                //   {
                                                //     required: true,
                                                //     message: inputRule('required input', {inputName: 'فایل ضمیمه'})
                                                //   }
                                                // ]}
                                                ltr
                                            />
                                        </Col>

                                        <Col flex="20%" className={ 'items-center' }>
                                            <Button
                                                block
                                                type={ 'secondary' }
                                                className="!mt-[36px] !rounded-s-none"
                                                height={ 42 }
                                                width={ '100%' }
                                            >
                                                <img src={ upload } className={ 'w-[15px] h-[15px] inline mb-1' }/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Col>

                                <Col xs={ 24 } lg={ 12 }>
                                    <RadioFormItem
                                        name={ 'sms' }
                                        label={ 'اطلاع از طریق پیامک' }
                                        initialValue={ 1 }
                                    >
                                        <RadioGroup>
                                            <Radio value={ 1 }>بله</Radio>

                                            <Radio value={ 2 }>خیر</Radio>

                                        </RadioGroup>
                                    </RadioFormItem>
                                </Col>


                                <Col span={ 24 }>
                                    <TextArea
                                        name={ 'description' }
                                        rules={ [
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', { inputName: 'موضوع ' }),
                                            },
                                        ] }
                                        label={ 'توضیحات' }
                                        rows={ 4 }
                                    />
                                </Col>

                                <Col span={ 24 }
                                     className=" lg:mt-[65px] max-lg:mt-[35px] max-lg:mb-[20px] pb-[25px]">
                                    <Row gutter={ 16 } justify={ 'center' }>
                                        <Col sm={ 8 } xs={ 12 }>
                                            <Button
                                                type={ 'default' }
                                                className={ 'w-full' }
                                            >
                                                <Link to={ '/merchantProfile' }>
                                                    انصراف
                                                </Link>

                                            </Button>
                                        </Col>

                                        <Col sm={ 8 } xs={ 12 }>
                                            <Button
                                                type={ 'secondary' }
                                                // htmlType={ 'submit' }
                                                iconAlign={ 'end' }
                                                className={ 'w-full' }
                                            >
                                                <LeftOutlined/>
                                                ارسال درخواست
                                            </Button>
                                        </Col>
                                    </Row>


                                </Col>

                            </Row>
                        </Form>
                    </div>

                    <div className={ activeTabs === 2 ? 'bg-white text-cashblack max-lg:hidden' : 'hidden' }>
                        <div className={ ' text-center items-center gap-5 ' }>
                            <div className={ 'w-full px-[12px] bg-ticketback py-[16px] border-b ' }>
                                <div className={ 'flex  ' }>
                                    <div className={ 'w-1/6' }>
                                        <h2 className={ 'font-[500] text-[12px]' }>موضوع</h2>
                                    </div>

                                    <div className={ 'w-1/6' }>
                                        <h2 className={ 'font-[500] text-[12px]' }>تاریخ و ساعت</h2>
                                    </div>

                                    <div className={ 'w-1/6' }>
                                        <h2 className={ 'font-[500] text-[12px]' }>نوع پشتیبانی</h2>
                                    </div>

                                    <div className={ 'w-1/6' }>
                                        <h2 className={ 'font-[500] text-[12px]' }>درجه اهمیت</h2>
                                    </div>

                                    <div className={ 'w-2/6' }>
                                        <h2 className={ 'font-[500] text-[12px]' }>اطلاع رسانی از طریق پیامک</h2>
                                    </div>

                                    <div className={ 'w-1/6' }>
                                        <h2 className={ 'font-[500] text-[12px]' }>...</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className={ 'text-center items-center gap-5 border-b  ' }>
                            <div className={ 'w-full px-[12px] py-[16px]' }>
                                <div className={ 'flex font-[400] text-[12px]' }>
                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2 className={ 'text-12px font-[400] text-black' }>اختلال</h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2>۱۶:۱۴ ۲۸-۲-۱۴۰۱ </h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2>مالی</h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2>فوری</h2>
                                    </div>

                                    <div className={ 'w-2/6 py-[20px]' }>
                                        <h2>بله</h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2 className={ 'text-tickettext' }>جزيیات</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className={ 'text-center items-center gap-5 ' }>
                            <div className={ 'w-full px-[12px] py-[16px]' }>
                                <div className={ 'flex font-[400] text-[12px]' }>
                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2 className={ 'text-12px font-[400] text-black' }>اختلال</h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2>۱۶:۱۴ ۲۸-۲-۱۴۰۱ </h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2>مالی</h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2>فوری</h2>
                                    </div>

                                    <div className={ 'w-2/6 py-[20px]' }>
                                        <h2>بله</h2>
                                    </div>

                                    <div className={ 'w-1/6 py-[20px]' }>
                                        <h2 className={ 'text-tickettext' }>جزيیات</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className={ activeTabs === 1 ? 'hidden lg:hidden' : 'lg:hidden' }>
                        <MobileSupportStep2/>
                    </div>

                </div>
            </Spin>
        </TransitionsPage>
    );
};

export default Support;