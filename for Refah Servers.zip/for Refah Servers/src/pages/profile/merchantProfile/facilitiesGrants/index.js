import React from 'react';
import {MatchBreakpoint} from "react-hook-breakpoints";
import FacilitiesGrantsMobile from "./screens/facilitiesGrantsMobile";
import FacilitiesGrantsDesktop from "./screens/facilitiesGrantsDesktop";

const facilitiesGrants = () => {
    return (
        <>
          <MatchBreakpoint max="md">
            <FacilitiesGrantsMobile />
          </MatchBreakpoint>

          <MatchBreakpoint min="lg">
            <FacilitiesGrantsDesktop />
          </MatchBreakpoint>
        </>
    );
};

export default facilitiesGrants;
