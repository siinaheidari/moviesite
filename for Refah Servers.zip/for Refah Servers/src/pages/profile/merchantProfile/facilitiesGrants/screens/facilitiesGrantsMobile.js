import React, {useState} from 'react';
import {Col, Form, Popover, Row, Select, Space} from "antd";
import {Link} from "react-router-dom";
import rightArrow from "../../../../../assets/icons/mobile/rightArrow.svg";
import circle from "../../../../../assets/icons/mobile/circle.svg";
import facilities from "assets/images/facilities.svg"
import {Button, Modal, SelectBox, TransitionsPage} from "../../../../../templates/Ui";
import {formatNumber, inputRule} from "../../../../../utils/helper";
import {SearchOutlined} from "@ant-design/icons";
import download from "assets/icons/mobile/download.svg"
import downArrow from "assets/icons/mobile/downArrow.svg"
import facilitiesBanner from "assets/images/facilitiesBanner.svg"
import styled from "styled-components";
import Check from "../../../../../assets/icons/check.svg";
import Cross from "../../../../../assets/icons/cross.svg";


const LotteryChanceContainer = styled(Row)`
  .--timeLeft,
  .--remainingTransaction {
    padding: 0 8px;

    .__description {
      color: #4D4D4D;
      font-size: .75rem;
      font-weight: 400;
    }
  }

  .--countDown {
    direction: ltr;
  }

  .--timeLeft {
    direction: ltr;

    .__box {
      > div {
        background: linear-gradient(44.14deg, #F61982 2.69%, #21409A 93.25%);
        border-radius: 10px;
        text-align: center;
        padding: 1.6vw 5px;

        .--title,
        .--number {
          color: #FFFFFF;
          font-weight: 400;
          font-size: .625rem;
        }

        .--number {
          font-weight: 500;
          font-size: 1.125rem;
          margin-top: 12px;
        }
      }
    }

    .__box,
    .__description {
      direction: rtl;
    }
  }

  .--remainingTransaction {
    > .ant-row {
      background: #F9F9F9;
      border-radius: 10px;
      padding: 10px 16px;

      .--progress {
        background: #D9D9D9;
        border-radius: 4px;
        overflow: hidden;
        position: relative;
        height: 9px;
        direction: ltr;

        .__tail {
          background: linear-gradient(269.82deg, #21409A 0%, #F61982 100%);
          border-radius: 4px;
          height: 100%;
          cursor: pointer;
        }
      }

      .--amounts {
        margin-top: 1px;
        direction: ltr;

        .__amount {
          direction: rtl;

          > div {
            font-size: .625rem;

            :first-child {
              color: #232429;
              font-weight: 500;
            }

            :last-child {
              color: #7A7A7A;
              font-weight: 400;
              margin-top: 3px;
            }
          }
        }
      }
    }
  }
`;

const FacilitiesGrantsMobile = () => {

    const [facilitiesMobileFormRef] = Form.useForm();

    const [facilitiesModal, setFacilitiesModal] = useState(false);

    const [viewMore, setViewMore] = useState("open")

    const {Option} = Select;
    const handleFacilities = value => {
        console.log(value)
        setFacilitiesModal(true)
    };




    const handleViewMore = (type) => {
        setViewMore(current => current === type ? "" : type);
    };

    return (
        <TransitionsPage coordinates={ 'x' } size={ 30 }>
            <Col span={24}>
                <Col span={24} className={'mb-[13px] lg:hidden'}>
                    <Link to={"/merchantProfile"} className={''}> <img src={rightArrow}/></Link>
                </Col>
                <div className={'flex mb-[17px] lg:hidden justify-between items-center'}>
                    <Space align={'center'} className={'text-[12px] font-[500] '}>
                        <img src={circle}/>
                        نمایش میزان تسهیلات قابل اعطا
                    </Space>
                </div>
                <div className={"relative bg-white shadow-6 rounded-[10px]"}>
                    <div className={"relative top-[-6px]"}>
                        <img src={facilities} className={"mx-auto "}/>
                        <div className={"relative text-white top-[-27px] mx-auto text-center items-center text-[12px]"}>
                            انتخاب تسهیلات
                        </div>
                    </div>
                    <Col span={24} className={"px-[18px] pb-[30px]"}>
                        <Form
                            form={facilitiesMobileFormRef}
                            autoComplete="off"
                            scrollToFirstError
                            onFinish={handleFacilities}
                            labelCol={{
                                span: 24,
                            }}
                            wrapperCol={{
                                span: 24,
                            }}

                        >

                            <Col span={24}>
                                <SelectBox
                                    name={'category'}
                                    label={'نوع تسهیلات درخواستی'}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required selectBox', {inputName: 'تحصیلات'})
                                        }
                                    ]}
                                >
                                    <Option value={0}>وام</Option>

                                </SelectBox>
                            </Col>

                            <Col span={24}>
                                <SelectBox
                                    name={'profit'}
                                    label={'میزان درصد سود'}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required selectBox', {inputName: 'تحصیلات'})
                                        }
                                    ]}
                                >
                                    <Option value={0}>12%</Option>
                                    <Option value={1}> 22%</Option>
                                </SelectBox>
                            </Col>
                            <Col span={24}>
                                <SelectBox
                                    name={'loan'}
                                    label={'تعداد اقساط ماهانه'}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required selectBox', {inputName: 'تحصیلات'})
                                        }
                                    ]}
                                >
                                    <Option value={0}>6 ماهه</Option>
                                    <Option value={1}> 12 ماهه</Option>
                                    <Option value={1}> 18 ماهه</Option>
                                </SelectBox>
                            </Col>
                            <Col xs={24} sm={12} className={"mt-[55px] flex justify-center mx-auto"}>
                                <Button
                                    className={"w-full"}
                                    type={'secondary'}
                                    htmlType={'submit'}
                                    iconAlign={'end'}
                                >
                                    <SearchOutlined/>
                                    جستجو و محاسبه
                                </Button>
                            </Col>
                        </Form>
                    </Col>
                </div>
                <div className={"w-full text-end text-[12px] text-textblue mt-[11px]"}>
                    <Space>
                        <img src={download}/>
                        دانلود جدول شرایط تسهیلات
                    </Space>
                </div>
            </Col>
            <Modal
                open={facilitiesModal}
                onCancel={() => setFacilitiesModal(false)}
                header={false}
                closable={false}
                bodyStyle={{
                    padding: 0,
                    backgroundColor: "white"
                }}
                size={{
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 40,
                    xl: 40,
                    xxl: 30,
                }}
                style={{
                    top: "10vh",
                }}
            >
                <div className={"px-[8px] py-[12px]"}>
                    <img src={facilitiesBanner} className={"w-full"}/>
                    <Col span={24} className={"text-[12px] text-title my-[13px]"}>
                        توضیحات :
                    </Col>
                    <Col span={24} className={"text-[12px] font-[400] leading-[170.898%] px-[11px]"}>
                        بانک رفاه کارگران با هدف حمایت و تأمین مالی کسب و کارهای بهره‌بردار از پایانه‌های فروشگاهی و
                        درگاه پرداخت اینترنتی و تنوع‌بخشی بیشتر به خدمات اعتباری، نسبت به پرداخت تسهیلات و جایزه به این
                        دسته از مشتریان در قالب "طرح اوج" اقدام می‌کند.

                        <Col span={24} className={"text-[#407BFF] text-[12px] underline my-[12px]"}>
                            اطلاعات بیشتر
                        </Col>
                        <Space align={"baseline"}>
                            <img src={circle} className={"!w-[10px]"}/>
                            <div className={"pb-[4px] text-[12px] font-[400]"}>
                                افراد می‌توانند با ارائه میانگین حساب خود به بانک تا سقف ۱۰۰ میلیون تومان از این تسهیلات
                                استفاده کنند
                            </div>

                        </Space>

                        <LotteryChanceContainer gutter={[0, 10]}>


                            <Col span={24} className='--remainingTransaction'>
                                <Row gutter={[0, 22]}>
                                    <Col span={24} className='__description'>
                                        مقدار تراکنش باقیمانده برای استفاده از این تسهیلات
                                    </Col>

                                    <Col span={24}>
                                        <div className='--progress'>
                                            <Popover
                                                placement={'bottomRight'}
                                                content={`${formatNumber(1500000)} تومان`}
                                                overlayClassName='__currentTransaction'
                                            >
                                                <div className='__tail' style={{width: '52%'}}/>
                                            </Popover>
                                        </div>

                                        <Row gutter={16} justify={'space-between'} className='--amounts'>
                                            <Col className='__amount'>
                                                <div>{formatNumber(0)}</div>
                                                <div>تومان</div>
                                            </Col>

                                            <Col className='__amount'>
                                                <div>{formatNumber(1500000)}</div>
                                            </Col>

                                            <Col className='__amount'>
                                                <div>{formatNumber(3000000)}</div>
                                                <div>تومان</div>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>
                            </Col>
                        </LotteryChanceContainer>
                        <Col span={24}
                             className={"text-textblue text-[12px] font-[400] items-center text-center my-[23px]"}>
                            <Space onClick={() => handleViewMore("open")}>
                                نمایش چگونگی کسب امتیاز برای این طرح
                                < img src={downArrow} className={viewMore?"0":"rotate-180"}/>
                            </Space>
                        </Col>
                        {viewMore ? "" :

                            <TransitionsPage coordinates={ 'x' } size={ -30 }>
                                <div className={"[&>div:nth-child(odd):not(:first-child)]:bg-[#F9F9F9] [&>div:nth-child(odd)]:border-[#EEE] border border-[#fff] shadow-lg"}>
                                    <div className={ 'flex justify-between items-center py-[5px] bg-[#eeee] text-[12px] !font-[400] rounded-t-[10px]' }>
                                        <div className={ 'w-1/3 text-center font-[500]' }>شرایط</div>
                                        <div className={ 'w-1/3 text-center font-[500]' }>وضعیت من</div>
                                        <div className={ 'w-1/4 text-center font-[500]' }><p></p></div>
                                    </div>
                                    <div className={ 'flex justify-between items-center py-[5px]' }>
                                        <div className={ 'w-1/3 text-center !font-[400] text-[#407BFF] underline' }>تعداد تراکنش</div>
                                        <div className={ 'w-1/3 text-center !font-[400]' }>123456</div>
                                        <div className={ 'w-1/4 !text-center flex justify-center' }>
                                            <img src={Check}/>
                                        </div>
                                    </div>
                                    <div className={ 'flex justify-between items-center  py-[5px]' }>
                                        <div className={ 'w-1/3 text-center !font-[400] text-[#407BFF] underline' }>مبلغ سودآوری</div>
                                        <div className={ 'w-1/3 text-center !font-[400]' }>12.500.000 ریال</div>
                                        <div className={ 'w-1/4 !text-center flex justify-center !font-[400]' }>
                                            <img src={Check}/>
                                        </div>
                                    </div>
                                    <div className={ 'flex justify-between items-center  py-[5px]' }>
                                        <div className={ 'w-1/3 text-center !font-[400] text-[#407BFF] underline' }>مبلغ تراکنش</div>
                                        <div className={ 'w-1/3  text-center !font-[400]' }>12.500.000 ریال</div>
                                        <div className={ 'w-1/4 !text-center flex justify-center !font-[400]' }>
                                            <img src={Cross}/>
                                        </div>
                                    </div>
                                </div>

                                <div className={"w-full text-end text-[12px] text-textblue mt-[21px]"}>
                                    <Space>
                                        <img src={download}/>
                                        دانلود جدول شرایط تسهیلات
                                    </Space>
                                </div>
                            </TransitionsPage>

                        }
                    </Col>
                </div>

            </Modal>
        </TransitionsPage>
    );
};

export default FacilitiesGrantsMobile;
