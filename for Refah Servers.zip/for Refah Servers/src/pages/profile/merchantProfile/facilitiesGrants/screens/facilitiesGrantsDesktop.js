import React, { useState } from 'react';
import { SelectBox, TransitionsPage } from 'templates/Ui';

import { Button, Col, Form, Popover, Row, Select } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import { formatNumber, inputRule } from 'utils/helper';
import styled from 'styled-components';
import Check from "assets/icons/check.svg"
import Cross from "assets/icons/cross.svg"
import CircleColor from "assets/icons/circleColor.svg"
import DownVector from "assets/icons/downVector.svg"

const { Option } = Select;
const layout = {
    labelCol: {
        span: 24,
    },
    wrapperCol: {
        span: 24,
    },
};
const tailLayout = {
    wrapperCol: {
        offset: 8,
        span: 16,
    },
};


const LotteryChanceContainer = styled(Row)`
  .--timeLeft,
  .--remainingTransaction {
    padding: 0 12px;

    .__description {
      color: #4D4D4D;
      font-size: .75rem;
      font-weight: 400;
    }
  }

  .--countDown {
    direction: ltr;
  }

  .--timeLeft {
    direction: ltr;

    .__box {
      > div {
        background: linear-gradient(44.14deg, #F61982 2.69%, #21409A 93.25%);
        border-radius: 10px;
        text-align: center;
        padding: 1.6vw 5px;

        .--title,
        .--number {
          color: #FFFFFF;
          font-weight: 400;
          font-size: .625rem;
        }

        .--number {
          font-weight: 500;
          font-size: 1.125rem;
          margin-top: 12px;
        }
      }
    }

    .__box,
    .__description {
      direction: rtl;
    }
  }

  .--remainingTransaction {
    > .ant-row {
      background: #F9F9F9;
      border-radius: 10px;
      padding: 20px 16px;

      .--progress {
        background: #D9D9D9;
        border-radius: 4px;
        overflow: hidden;
        position: relative;
        height: 9px;
        direction: ltr;

        .__tail {
          background: linear-gradient(269.82deg, #21409A 0%, #F61982 100%);
          border-radius: 4px;
          height: 100%;
          cursor: pointer;
        }
      }

      .--amounts {
        margin-top: 10px;
        direction: ltr;

        .__amount {
          direction: rtl;

          > div {
            font-size: .625rem;

            :first-child {
              color: #232429;
              font-weight: 500;
            }

            :last-child {
              color: #7A7A7A;
              font-weight: 400;
              margin-top: 3px;
            }
          }
        }
      }
    }
  }
`;


const FacilitiesGrantsDesktop = () => {


    const [ form ] = Form.useForm();

    const [ activeTabs, setActiveTabs ] = useState(0);
    const [ activeBottomPage, setActiveBottomPage ] = useState(false);

    const handleTabs = (index) => {
        if (activeTabs === 2) {
            setActiveTabs(0);
        }
        else {
            setActiveTabs(0);
        }
    };

    const onFinish = (values) => {
        setActiveTabs(1);
        console.log(values);
    };


    return (
        <div className={ 'bg-white py-[31px] px-[37px] rounded-[10px]' }>
            <div className={ 'flex gap-3 pb-[24px] items-center' }>
                <img className={ 'w-[12px]' } src={ '/images/Ellipse.svg' }/>
                <h2 className={ 'text-tickettext my-1' }>نمایش میزان تسهیلات قابل اعطا</h2>
            </div>
            <div className={ 'bg-eeeeee pt-[31px] px-[33px] border rounded-[10px]' }>
                <div className={ 'flex gap-2 text-start pt-[21px]' }>
                    <div className={ 'w-1/3' }>
                        <h2 className={ 'text-tickettext font-[500]' }>نام و نام خوانوادگی :<span
                            className={ 'mr-[12px] font-[400] text-black' }>نجمه علوی</span></h2>
                    </div>
                    <div className={ 'w-1/3' }>
                        <h2 className={ 'text-tickettext font-[500]' }>کد ملی :<span
                            className={ 'mr-[12px] text-textcolor font-[400]' }>224567892147</span></h2>
                    </div>
                    <div className={ 'w-1/3' }>
                        <h2 className={ 'text-tickettext font-[500]' }>شماره مشتری :<span
                            className={ 'mr-[12px] text-textcolor font-[400]' }>46468421187</span></h2>
                    </div>
                </div>
                <div>
                    <div className={ 'flex gap-2 text-start py-[21px]' }>
                        <div className={ 'w-1/3 flex gap-2 ' }>
                            <h2 className={ 'text-tickettext font-[500]' }>نوع شخص پذیرنده :<span
                                className={ 'mr-[12px] text-textcolor font-[400]' }>حقیقی</span></h2>
                        </div>

                        <div className={ 'w-1/3' }>
                            <h2 className={ 'text-tickettext font-[500]' }>مجموع تعداد تراکنش :<span
                                className={ 'mr-[12px] text-textcolor font-[400]' }>2245678147</span></h2>
                        </div>
                        <div className={ 'w-1/3' }>
                            <h2 className={ 'text-tickettext font-[500]' }>امتیازات کل :<span
                                className={ 'mr-[12px] text-textcolor font-[400]' }>۴۵۶۸۵۶۸۷۶</span></h2>
                        </div>
                    </div>
                </div>

                <div>
                    <div className={ 'flex gap-2 text-start pb-[15px]' }>
                        <div className={ 'w-2/3' }>
                            <h2 className={ 'text-tickettext font-[500]' }>مجموع مبلغ تراکنش ها :<span
                                className={ 'mr-[12px] text-textcolor font-[400]' }>۲۳۴۲۳۴۲۳۴۲۳۴ ریال</span></h2>
                        </div>
                    </div>
                </div>
            </div>
            {
                activeTabs === 0 && <div>
                    <div className={ 'w-[100%] bg-white border rounded-[7px] mt-[22px]' }>
                        <div className={ 'bg-newnlue border rounded-t-[10px] w-full px-[38px] py-[19px] border-b' }>
                            <div className={ '' }>
                                <h2 className={ 'text-[14px] font-[500] text-white' }>انتخاب تسهیلات</h2>
                            </div>
                        </div>
                        <Form className={ 'p-[38px] mx-auto items-center border-1 rounded-[10px] ' }
                              { ...layout }
                              form={ form }
                              name="control-hooks"
                              onFinish={ onFinish }
                        >
                            <div className={ 'flex justify-center gap-4 ' }>
                                <div className={ 'w-2/3' }>
                                    <SelectBox
                                        name="tashilat"
                                        label=" نوع تسلیهات درخواستی"
                                        placeholder="طرح اوج بانک رفاه"

                                        rules={ [
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', { inputName: 'نوع تسلیهات درخواستی' }),
                                            },
                                        ] }
                                        allowClear
                                    >
                                        <Select.Option value={ 'firozeyi' }> طرح اوج بانک رفاه</Select.Option>
                                        <Select.Option value={ 'ghahveyi' }>اعتباری</Select.Option>
                                    </SelectBox>
                                </div>
                                <div className={ 'w-1/3' }>
                                    <SelectBox
                                        name="sod"
                                        label="میزان درصد سود"
                                        placeholder="12%"

                                        rules={ [
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', { inputName: 'میزان درصد سود' }),
                                            },
                                        ] }
                                        allowClear
                                    >
                                        <Select.Option value={ 12 }> ۱۲٪</Select.Option>
                                        <Select.Option value={ 14 }>۱۴٪</Select.Option>
                                        <Select.Option value={ 16 }>۱۶٪</Select.Option>
                                    </SelectBox>
                                </div>
                                <div className={ 'w-1/3' }>
                                    <SelectBox
                                        name="ghest"
                                        label="تعداد اقساط ماهانه"
                                        placeholder="6 ماهه"

                                        rules={ [
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', { inputName: 'تعداد اقساط ماهانه' }),
                                            },
                                        ] }
                                        allowClear
                                    >
                                        <Select.Option value={ 6 }>6 ماهه</Select.Option>
                                        <Select.Option value={ 12 }>12 ماهه</Select.Option>
                                        <Select.Option value={ 18 }>18 ماهه</Select.Option>
                                    </SelectBox>
                                </div>
                            </div>

                            <Form.Item className={ ' text-center' }>
                                <div className={ 'px-[38px] mt-[65px] ' }>
                                    <Button className={ 'bg-chargblue  h-[38px] !text-white' } htmlType="submit"
                                            icon={ <SearchOutlined/> }>
                                        جستجو و مقایسه
                                    </Button>
                                </div>
                            </Form.Item>

                        </Form>
                    </div>


                    <div className={ 'flex justify-end items-center gap-2 text-end pt-[16px] cursor-pointer' }>
                        <img className={ 'w-[18px]' } src={ '/images/download.svg' }/>
                        <h2 className={ 'text-tickettext' }>دانلود جدول شرایط تسهیلات </h2>

                    </div>

                </div>

            }

            {
                activeTabs === 1 && <TransitionsPage coordinates={ 'x' } size={ -30 }>

                    <div className={ 'mb-7 py-3 border-b' }>
                        تسهیلات :
                    </div>
                    <div className={ 'flex gap-4 p-[22px] ' }>
                        <img className={ 'w-[300px] border-[10px]' } src={ '/images/Rectangle.svg' }/>
                        <div>
                            <div className="mb-[6px] font-[500] text-tickettext">
                                توضیحات :
                            </div>

                            <div className={ 'text-justify text-textcolor leading-[171%] font-[400]' }>
                                بانک رفاه کارگران با هدف حمایت و تأمین مالی کسب و کارهای بهره‌بردار از پایانه‌های
                                فروشگاهی و
                                درگاه پرداخت
                                اینترنتی و تنوع‌بخشی بیشتر به خدمات اعتباری، نسبت به پرداخت تسهیلات و جایزه به این
                                دسته
                                از
                                مشتریان در قالب
                                "طرح اوج" اقدام می‌کند.
                            </div>
                            <div className={ 'font-[400] text-[14px]  text-blue-500 underline py-3' }>اطلاعات بیشتر</div>
                            <div className={ 'flex items-start gap-2 ' }>
                                <img src={CircleColor} className={"mt-1"}/>
                                <div className={"font-[400] text-[14px] text-textcolor"}>
                                    افراد می‌توانند با ارائه میانگین حساب خود به بانک <span className={ 'text-backbtn ' }> تا سقف ۱۰۰ میلیون تومان</span> از
                                    این تسهیلات استفاده کنند.
                                </div>
                            </div>

                            <div className={ 'my-5' }>
                                <LotteryChanceContainer>
                                    <Col span={ 24 } className="--remainingTransaction">
                                        <Row gutter={ [ 0, 22 ] }>
                                            <Col span={ 24 } className="__description">
                                                مقدار تراکنش باقیمانده برای استفاده از این تسهیلات
                                            </Col>

                                            <Col span={ 24 }>
                                                <div className="--progress">
                                                    <Popover
                                                        placement={ 'bottomRight' }
                                                        content={ `${ formatNumber(0) } تومان` }
                                                        overlayClassName="__currentTransaction"
                                                    >
                                                        <div className="__tail" style={ { width: '20%' } }/>
                                                    </Popover>
                                                </div>

                                                <Row gutter={ 16 } justify={ 'space-between' } className="--amounts">
                                                    <Col className="__amount">
                                                        <div>{ formatNumber(0) }</div>
                                                        <div>تومان</div>
                                                    </Col>
                                                    <Col className="__amount">
                                                        <div>{ formatNumber(1500000) }</div>
                                                        <div>تومان</div>
                                                    </Col>
                                                    <Col className="__amount">
                                                        <div>{ formatNumber(50000000) }</div>
                                                        <div>تومان</div>
                                                    </Col>
                                                </Row>
                                            </Col>
                                        </Row>
                                    </Col>
                                </LotteryChanceContainer>
                            </div>
                        </div>

                    </div>
                    <div onClick={ () => setActiveBottomPage(true) } className={"w-full text-center flex items-center justify-center gap-2 pb-[20px]"}>
                        <p className={ 'text-chargblue  text-[12px] font-[500] cursor-pointer' }>
                            نمایش چگونگی کسب امتیاز برای این طرح
                        </p>
                        <img src={DownVector} className={activeBottomPage?"rotate-180 decoration-8":""}/>
                    </div>
                    {
                        activeBottomPage ?
                            <TransitionsPage coordinates={ 'x' } size={ -30 }>
                                <div className={"[&>div:nth-child(odd)]:bg-[#eee] [&>div:nth-child(odd)]:border-[#EEE] [&>div:nth-child(even)]:bg-gray-100/[0.20] border border-[#fff]"}>
                                    <div className={ 'flex justify-between items-center py-[16px] bg-[#eeee] text-[14px] !font-[400]' }>
                                        <div className={ 'w-1/3 text-center font-[500]' }>شرایط</div>
                                        <div className={ 'w-1/3 border-x border-x-white text-center font-[500]' }>وضعیت من</div>
                                        <div className={ 'w-1/3 text-center font-[500]' }><p></p></div>
                                    </div>
                                    <div className={ 'flex justify-between items-center py-[16px]' }>
                                        <div className={ 'w-1/3 text-center !font-[400] text-textLink underline' }>تعداد تراکنش</div>
                                        <div className={ 'w-1/3 text-center !font-[400]' }>123456</div>
                                        <div className={ 'w-1/3 !text-center flex justify-center' }>
                                            <img src={Check}/>
                                        </div>
                                    </div>
                                    <div className={ 'flex justify-between items-center  py-[16px]' }>
                                        <div className={ 'w-1/3 text-center !font-[400] text-textLink underline' }>مبلغ سودآوری</div>
                                        <div className={ 'w-1/3 text-center !font-[400]' }>12.500.000 ریال</div>
                                        <div className={ 'w-1/3 !text-center flex justify-center !font-[400]' }>
                                            <img src={Check}/>
                                        </div>
                                    </div>
                                    <div className={ 'flex justify-between items-center  py-[16px]' }>
                                        <div className={ 'w-1/3 text-center !font-[400] text-textLink underline' }>مبلغ تراکنش</div>
                                        <div className={ 'w-1/3  text-center !font-[400]' }>12.500.000 ریال</div>
                                        <div className={ 'w-1/3 !text-center flex justify-center !font-[400]' }>
                                            <img src={Cross}/>
                                        </div>
                                    </div>
                                </div>
                            </TransitionsPage> : ''
                    }
                </TransitionsPage>
            }
        </div>
    );
};

export default FacilitiesGrantsDesktop;
