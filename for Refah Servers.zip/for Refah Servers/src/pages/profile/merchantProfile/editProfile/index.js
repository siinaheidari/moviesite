import React from 'react';
import { MatchBreakpoint } from 'react-hook-breakpoints';
import EditProfileMobile from './screens/editProfileMobile';
import EditProfileDesktop from './screens/editProfile.Desktop';

const EditProfile = () => {
    return (
        <>
          <MatchBreakpoint max="md">
            <EditProfileMobile />
          </MatchBreakpoint>

          <MatchBreakpoint min="lg">
            <EditProfileDesktop />
          </MatchBreakpoint>
        </>
    );
};

export default EditProfile;
