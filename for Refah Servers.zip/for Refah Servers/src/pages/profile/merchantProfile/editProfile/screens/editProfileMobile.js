import React, { useState } from 'react';
import { Col, Row, Space } from 'antd';
import personalInfo from 'assets/icons/mobile/personalInfo.svg';
import personalMobile from 'assets/icons/mobile/personalMobile.svg';
import personalEducation from 'assets/icons/mobile/personalEducation.svg';
import changePass from 'assets/icons/mobile/changePass.svg';
import inviteFriends from 'assets/icons/mobile/inviteFriends.svg';

import Arrow from 'assets/icons/mobile/arrow.svg';
import Coin from 'assets/icons/mobile/coin.svg';
import PersonalInfo from './editProfileMobile/components/PersonalInfo';
import PersonalMobile from './editProfileMobile/components/PersonalMobile';
import PersonalEducation from './editProfileMobile/components/PersonalEducation';
import ChangePassword from './editProfileMobile/components/ChangePassword';
import InviteFriends from './editProfileMobile/components/InviteFriends';
import { TransitionsPage } from '../../../../../templates/Ui';
import circle from '../../../../../assets/icons/mobile/circle.svg';
import profilePhoto from 'assets/images/profilePhoto.svg';
import { useAuth } from '../../../../../contexts/auth/AuthContext';

const EditProfileMobile = () => {

    const [ currentTab, setCurrentTab ] = useState('');
    const handleToggleTab = (type) => {
        setCurrentTab(current => current === type ? '' : type);
    };

    const {auth} = useAuth();


    return (
        <TransitionsPage coordinates={ 'x' }>
            <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
                <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                    <img src={ circle }/>
                    لیست تراکنش ها
                </Space>


            </div>
            <Row gutter={ [ 0, 10 ] } className={ 'mb-[15%]' }>


                <Col span={ 24} className={"text-[#2C419B] space-y-2 text-[12px] font-[500] bg-white p-[10px] border border-dashed border-[rgba(120,120,120,0.30)] rounded-[14px] items-center text-center"}>
                    <img src={ profilePhoto } className={"inline "}/>
                    <div>
                        {auth?.firstNameFa}  خوش آمدید
                    </div>
                    <div className={"text-[14px]"}>
                        0{auth?.mobile}
                    </div>
                </Col>

                <Col span={ 24 }>
                    <div
                        className={ 'bg-white p-[10px] border border-dashed border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('personalInfo') }
                             className={ 'flex justify-between items-center gap-2 bg-[#FF7201] text-white text-[12px] font-[500] w-full p-[10px] rounded-[10px]' }>

                            <Space align={ 'center' }>
                                <img src={ personalInfo }/>
                                اطلاعات فردی من
                            </Space>

                            <Space align={ 'center' }>
                                1 امتیاز
                                <img src={ Coin } className={ 'pt-[5px]' }/>
                            </Space>


                        </div>

                        {
                            currentTab === 'personalInfo' ? <PersonalInfo/> :
                                ''
                        }


                        <div onClick={ () => handleToggleTab('personalInfo') }
                             className={ 'w-full items-center text-center pt-[8px]' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>
                <Col span={ 24 }>
                    <div
                        className={ 'bg-white p-[10px] border border-dashed border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('personalMobile') }
                             className={ 'flex justify-between items-center gap-2 bg-[#FF7201] text-white text-[12px] font-[500] w-full p-[10px] rounded-[10px]' }>

                            <Space align={ 'center' }>
                                <img src={ personalMobile }/>
                                اطلاعات تماس و محل سکونت من
                            </Space>

                            <Space align={ 'center' }>
                                1 امتیاز
                                <img src={ Coin } className={ 'pt-[5px]' }/>
                            </Space>

                        </div>


                        {
                            currentTab === 'personalMobile' ? <PersonalMobile/> :
                                ''
                        }

                        <div onClick={ () => handleToggleTab('personalMobile') }
                             className={ 'w-full items-center text-center pt-[8px]' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>

                    </div>
                </Col>
                <Col span={ 24 }>
                    <div
                        className={ 'bg-white p-[10px] border border-dashed border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('personalEducation') }
                             className={ 'flex justify-between items-center gap-2 bg-[#FF7201] text-white text-[12px] font-[500] w-full p-[10px] rounded-[10px]' }>

                            <Space align={ 'center' }>
                                <img src={ personalEducation }/>
                                اطلاعات تحصیلی و شغلی من
                            </Space>

                            <Space align={ 'center' }>
                                1 امتیاز
                                <img src={ Coin } className={ 'pt-[5px]' }/>
                            </Space>
                        </div>

                        {
                            currentTab === 'personalEducation' ? <PersonalEducation/> :
                                ''
                        }

                        <div onClick={ () => handleToggleTab('personalEducation') }
                             className={ 'w-full items-center text-center pt-[8px]' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>

                    </div>
                </Col>
                <Col span={ 24 }>
                    <div
                        className={ 'bg-white p-[10px] border border-dashed border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('ChangePassword') }
                             className={ 'flex justify-between items-center gap-2 bg-[#FF7201] text-white text-[12px] font-[500] w-full p-[10px] rounded-[10px]' }>

                            <Space align={ 'center' }>
                                <img src={ changePass }/>
                                تغییر رمز عبور
                            </Space>

                            <Space align={ 'center' }>
                                1 امتیاز
                                <img src={ Coin } className={ 'pt-[5px]' }/>
                            </Space>

                        </div>


                        {
                            currentTab === 'ChangePassword' ? <ChangePassword/> :
                                ''
                        }

                        <div onClick={ () => handleToggleTab('ChangePassword') }
                             className={ 'w-full items-center text-center pt-[8px]' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>

                    </div>
                </Col>
                <Col span={ 24 }>
                    <div
                        className={ 'bg-white p-[10px] border border-dashed border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div onClick={ () => handleToggleTab('InviteFriends') }
                             className={ 'flex justify-between items-center gap-2 bg-[#FF7201] text-white text-[12px] font-[500] w-full p-[10px] rounded-[10px]' }>

                            <Space align={ 'center' }>
                                <img src={ inviteFriends }/>
                                دعوت از دوستان
                            </Space>

                            <Space align={ 'center' }>
                                1 امتیاز
                                <img src={ Coin } className={ 'pt-[5px]' }/>
                            </Space>

                        </div>


                        {
                            currentTab === 'InviteFriends' ? <InviteFriends/> :
                                ''
                        }

                        <div onClick={ () => handleToggleTab('InviteFriends') }
                             className={ 'w-full items-center text-center pt-[8px]' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>

                    </div>
                </Col>
            </Row>
        </TransitionsPage>
    );
};

export default EditProfileMobile;
