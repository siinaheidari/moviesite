import React from 'react';

import whatsappMessengerIcon from '../../../../../../../assets/icons/mobile/whatsApp.svg';
import soroushMessengerIcon from '../../../../../../../assets/icons/mobile/soroush.svg';
import eitaaMessengerIcon from '../../../../../../../assets/icons/mobile/orange.svg';
import baleMessengerIcon from '../../../../../../../assets/icons/mobile/bale.svg';
import { Col, Row, Space, Typography } from 'antd';
import {TransitionsPage} from "../../../../../../../templates/Ui";

const InviteFriends = () => {
    const { Paragraph } = Typography;
    return (
        <TransitionsPage coordinates={ 'y' } size={ 30 }>
        <div className={ 'px-[10px] py-[12px] text-[#4D4D4D]' }>

            <Col span={ 24 } className="text-[12px] font-[400] mt-[20px]">
                لینک ویژه شما برای ارسال به دوستان:
            </Col>
            <Col span={ 24 }>

                        <Paragraph className={"border border-[#C6D4FF] rounded-[5px] flex justify-between items-center w-full my-[25px]"}
                            copyable={ {
                                text: 'https://www.refah.ir/invite/52A2N6',
                                icon: <div className="bg-[#383C47] text-white text-[12px] font-[500] p-[12px] rounded-l-[5px]">کپی لینک</div>,
                            } }
                        >
                            <div className="py-[12px] pr-[12px] text-[12px] text-[#555]">
                                https://www.refah.ir/invite/52A2N6
                            </div>
                        </Paragraph>


            </Col>

                <Col span={ 24 } className={"mt-[35px] text-[12px] text-[#555]"}>
                    از روش های زیر برای ارسال لینک استفاده نمایید.
                </Col>

                <Col span={ 24 } className={ 'w-full items-center text-center mt-[34px] mb-[10px] border border-dashed border-[rgb(77,77,77)]/.50 rounded-[5px] pt-[4px]' }>
                    <Space>
                        <img src={ whatsappMessengerIcon } className={"inline"}/>
                        <img src={ soroushMessengerIcon } className={"inline"}/>
                        <img src={ eitaaMessengerIcon } className={"inline"}/>
                        <img src={ baleMessengerIcon } className={"inline"}/>
                    </Space>
                </Col>


        </div>

        </TransitionsPage>
    );
};

export default InviteFriends;
