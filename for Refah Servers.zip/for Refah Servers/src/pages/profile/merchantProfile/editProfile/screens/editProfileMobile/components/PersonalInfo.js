import React from 'react';
import { Col, Form, Select } from 'antd';
import {Button, Input, SelectBox, TransitionsPage} from '../../../../../../../templates/Ui';
import { inputRule } from '../../../../../../../utils/helper';

const PersonalInfo = () => {
    const [ personalInformationFormRef ] = Form.useForm();
    const {Option} = Select;
    const handlePersonalInfo = value => {
        console.log(value);
    };

    return (

        <TransitionsPage coordinates={ 'y' } size={ 30 }>
        <div className={"px-[10px] py-[12px] "}>

            <Form
                form={ personalInformationFormRef }
                autoComplete="off"
                scrollToFirstError
                labelCol={ {
                    span: 24,
                } }
                wrapperCol={ {
                    span: 24,
                } }
                onFinish={ handlePersonalInfo }
            >

                <Col span={ 24 }>
                    <Input
                        name={ 'firstName' }
                        label={ 'نام' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'نام' }),
                            },
                        ] }
                    />
                </Col>
                <Col span={ 24 }>
                    <Input
                        name={ 'lastName' }
                        label={ 'نام خانوادگی' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'نام خانوادگی' }),
                            },
                        ] }
                    />
                </Col>
                <Col span={ 24 }>
                    <SelectBox
                        name={ 'gender' }
                        label={ 'جنسیت' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'جنسیت' }),
                            },
                        ] }
                    >
                        <Option value={ 0 }>ایرانی</Option>
                        <Option value={ 1 }>خارچی</Option>
                    </SelectBox>
                </Col>
                <Col span={ 24 } className={"max-lg:mt-[-10px]"}>
                    <SelectBox
                        name={ 'nation' }
                        label={ 'ملیت' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'ملیت' }),
                            },
                        ] }
                    >
                        <Option value={ 0 }>ایرانی</Option>
                        <Option value={ 1 }>خارچی</Option>
                    </SelectBox>
                </Col>
                <Col sm={8} xs={10} className={"items-center text-center mt-[34px] mx-auto"}>
                    <Button
                        className={"w-full"}
                        htmlType={'submit'}
                        type={'default'}

                    >
                        ذخیره
                    </Button>
                </Col>
            </Form>
        </div>

        </TransitionsPage>
    );
};

export default PersonalInfo;
