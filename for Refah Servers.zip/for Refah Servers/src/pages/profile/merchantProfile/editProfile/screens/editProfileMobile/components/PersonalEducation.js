import React from 'react';
import { Col, Form, Select } from 'antd';
import {Button, Input, SelectBox, TransitionsPage} from '../../../../../../../templates/Ui';
import { inputRule } from '../../../../../../../utils/helper';


const PersonalEducation = () => {

    const [ personalMobileFormRef ] = Form.useForm();
    const {Option} = Select;
    const handlePersonalEducation = formData => {
        console.log(formData);
    };

    return (
        <TransitionsPage coordinates={ 'y' } size={ 30 }>
        <div className={"px-[10px] py-[12px]"}>
            <Form
                form={ personalMobileFormRef }
                autoComplete="off"
                scrollToFirstError
                labelCol={ {
                    span: 24,
                } }
                wrapperCol={ {
                    span: 24,
                } }
                onFinish={ handlePersonalEducation }
            >

                <Col span={24}>
                    <SelectBox
                        name={'education'}
                        label={'تحصیلات'}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required selectBox', {inputName: 'تحصیلات'})
                            }
                        ]}
                    >
                        <Option value={0}>دکتری</Option>
                        <Option value={1}> کارشناسی ارشد</Option>
                        <Option value={1}> کارشناسی</Option>
                    </SelectBox>
                </Col>
                <Col span={24}>
                    <Input
                        name={'fieldStudy'}
                        label={'رشته تحصیلی'}
                        placeholder={"طراح UI/UX"}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'شغل'})
                            }
                        ]}
                    />
                </Col>

                <Col span={24}>
                    <Input
                        name={'job'}
                        label={'شغل'}
                        placeholder={"طراح UI/UX"}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'شغل'})
                            }
                        ]}
                    />
                </Col>
                <Col sm={8} xs={10} className={"items-center text-center mt-[34px] mx-auto"}>
                    <Button
                        className={"w-full"}
                        type={'default'}
                    >
                        ذخیره
                    </Button>
                </Col>
            </Form>
        </div>

        </TransitionsPage>
    );
};

export default PersonalEducation;
