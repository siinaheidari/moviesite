import {Avatar, Col, Form, Row, Select, Space, Spin, Typography, Upload} from 'antd';
import {ReactComponent as DollarCoin} from 'assets/icons/dollarCoin.svg';
import {ReactComponent as DollarCoins} from 'assets/icons/dollarCoins.svg';
import {ReactComponent as Edit} from 'assets/icons/edit.svg';
import lockIcon from 'assets/icons/lock.svg';
import marketIcon from 'assets/icons/market.svg';
import baleMessengerIcon from 'assets/icons/messengers/bale.svg';
import eitaaMessengerIcon from 'assets/icons/messengers/eitaa.svg';
import soroushMessengerIcon from 'assets/icons/messengers/soroush.svg';
import whatsappMessengerIcon from 'assets/icons/messengers/whatsapp.svg';
import phoneIcon from 'assets/icons/phone.svg';
import suitcaseIcon from 'assets/icons/suitcase.svg';
import {ReactComponent as UploadIcon} from 'assets/icons/upload.svg';
import userIcon from 'assets/icons/user.svg';
import usersIcon from 'assets/icons/users.svg';
import {ReactComponent as InviteLinkBg} from 'assets/images/inviteLinkBg.svg';

// icons and images
import userImage from 'assets/images/user.png';
import React, {useState} from 'react';
import styled from 'styled-components';
import ListCircle from 'templates/components/ListCircle';
import {Button, Input, InputPassword, SelectBox, TextArea} from 'templates/Ui';
import {inputRule} from 'utils/helper';
import {useAuth} from "../../../../../contexts/auth/AuthContext";

const {Option} = Select;
const {Paragraph} = Typography;

const EditProfileContainer = styled(Row)`
  .--box {
    .ant-form {
      &,
      > .ant-row {
        height: 100%;
      }

      .__formInputs {
        align-self: flex-start;

        .--uploadIcon {
          .ant-form-item-label {
            padding-bottom: 4px;
            text-align: start;

            label {
              color: #4D4D4D;
              font-size: .875rem;
              font-weight: 400;

              &.ant-form-item-required {
                &:after {
                  display: inline-block;
                  margin-left: 4px;
                  margin-top: -5px;
                  color: #FF0000;
                  font-size: .875rem;
                  font-family: SimSun, sans-serif;
                  font-weight: bolder;
                  line-height: 1;
                  content: '*';
                }

                &:before {
                  display: none !important;
                }
              }
            }
          }

          .ant-form-item-control-input-content {
            [class*="rtl"] {
              direction: ltr !important;
            }
          }

          .ant-upload-wrapper {
            display: block;

            .ant-upload-select {
              width: 100%;
              border: 1px solid #C6D4FF;
              border-radius: 5px;
              display: ${props => props?.isuploadmarketlogo ? 'none' : 'inline-block'};

              > .ant-upload {
                span {
                  display: inline-block;
                  text-align: center;
                  width: 60px;
                  height: 42px;
                  line-height: 46px;
                  background-color: #21409A;
                  border: 1px solid #21409A;
                  border-radius: 5px;

                  svg {
                    height: 16px;
                  }

                }
              }
            }

            .ant-upload-list-picture {
              .ant-upload-list-item {
                height: 42px;
                margin: 0;
                border: 1px solid #C6D4FF;
                border-radius: 5px;

                .ant-upload-list-item-thumbnail {
                  height: 39px;
                  line-height: 39px;
                }
              }
            }
          }
        }

        .__userImage {
          text-align: center;
          margin-bottom: 10px;

          > div {
            display: inline-block;
            position: relative;

            .ant-avatar {
              border: 2px solid #1CC500;
            }

            .__editAvatar {
              width: 24px;
              height: 24px;
              background-color: #FFFFFF;
              border-radius: 50%;
              display: inline-block;
              position: absolute;
              bottom: -2px;
              right: -5px;

              svg {
                width: 10px;
              }
            }
          }
        }
      }

      .__formSubmit {
        align-self: flex-end;
        text-align: center;
      }

      .--attention {
        color: #1447A0;
        font-weight: 400;
        font-size: .875rem;
        margin-bottom: 35px;
      }
    }

    .__inviteFriends {
      .--copyLinkDescription {
        color: #4D4D4D;
        font-size: .875rem;
        font-weight: 400;
      }

      .--copyLink {
        .ant-typography {
          margin: 0;
          border: 1px solid #C6D4FF;
          border-radius: 5px;
          line-height: 48px;
          display: flex;
          justify-content: space-between;
          align-items: center;

          .__link {
            color: #555555;
            font-size: .875rem;
            font-weight: 400;
            padding: 0 15px;
            direction: ltr;
          }

          .ant-typography-copy {
            width: 136px;
            background-color: #383C47 !important;
            border: 1px solid #C6D4FF !important;
            border-radius: 5px 0 0 5px;
            text-align: center;
            color: #FFFFFF;
            font-weight: 500;
            font-size: .875rem;
          }
        }
      }

      .--messengers {
        .__desc,
        .__lists {
          text-align: center;
        }

        .__desc {
          color: #4D4D4D;
          font-size: .875rem;
          font-weight: 400;
        }

        .__lists {
          .ant-space {
            border: 1px dashed rgba(77, 77, 77, 0.5);
            border-radius: 5px;
            padding-top: 5px;

            .ant-space-item {
              img {
                width: 49px;
                height: 49px;
              }
            }
          }
        }
      }

      .--bg {
        svg {
          height: 100%;
        }
      }
    }
  }
`;

const FormBoxContainer = styled(Row)`
  background: #FFFFFF;
  border: 1px dashed rgba(120, 120, 120, 0.3);
  box-shadow: 0 4px 10px rgba(122, 122, 122, 0.1);
  border-radius: 10px;
  padding: 14px 10px 17px;
  height: 100%;

  .--topSection {
    height: 61px;
    background: #FF7201;
    border-radius: 10px;
    padding: 19px 27px;
    align-self: flex-start;

    .__title {
      color: #FFFFFF;
      font-weight: 500;
      font-size: 1rem;
    }

    .__scoreSection {
      text-align: end;

      .--scoreImg {
        display: block;
        height: 23px;
      }
    }
  }

  .--content {
    padding: 0 15%;
    height: calc(100% - 82px);

    &.ant-col-24 {
      padding: 0 5%;
    }
  }
`;


const EditProfileDesktop = () => {
    const {auth} = useAuth()
    const [personalInformationFormRef] = Form.useForm();
    const [contactsInformationFormRef] = Form.useForm();
    const [eduAndCareerInformationFormRef] = Form.useForm();
    const [passwordFormRef] = Form.useForm();
    const [marketInformationFormRef] = Form.useForm();

    const newPasswordWatch = Form.useWatch('newPassword', passwordFormRef);
    const repeatedPasswordWatch = Form.useWatch('repeatedPassword', passwordFormRef);

    const validateRepeatedPassword = (rule, value, callback) => {
        if (value?.length && value !== newPasswordWatch) {
            callback(inputRule('invalidate repeated password'));
        } else {
            callback();
        }
    };


    const [isLoading, setIsLoading] = useState(false);
    const [isUploadMarketLogo, setIsUploadMarketLogo] = useState(false);

    const handleChangePersonalInformation = formData => {
        console.log(formData);
    };


    const validaShenasnameh = (_, value) => {
        if (!!value?.serial && !!value?.char && value?.seri) {
            return Promise.resolve();
        }
        return Promise.reject(new Error(inputRule('required input', {inputName: 'سریال و سری شناسنامه'})));
    };

    const ShenasnamehInputs = ({value = {}, onChange}) => {
        const triggerChange = (changedValue) => {
            onChange?.({
                ...value,
                ...changedValue
            });
        };

        const onSerialChange = (e) => {
            const serial = e.target.value;

            triggerChange({
                serial
            });
        };

        const onCharChange = char => {
            triggerChange({
                char
            });
        };

        const onSeriChange = e => {
            const seri = e.target.value;

            triggerChange({
                seri
            });
        };

        return (
            <Row gutter={8}>
                <Col xs={24} md={8}>
                    <Input
                        placeholder={'سریال'}
                        withoutForm
                        value={value.serial}
                        onChange={onSerialChange}
                        allowClear={false}
                        maxLength={6}
                    />
                </Col>

                <Col xs={24} md={8}>
                    <SelectBox
                        placeholder={'حرف'}
                        withoutForm
                        onChange={onCharChange}
                        allowClear={false}
                    >
                        <Select.Option value={'الف'}>الف</Select.Option>
                        <Select.Option value={'ب'}>ب</Select.Option>
                    </SelectBox>
                </Col>

                <Col xs={24} md={8}>
                    <Input
                        placeholder={'عدد'}
                        withoutForm
                        value={value.seri}
                        onChange={onSeriChange}
                        allowClear={false}
                        maxLength={6}
                    />
                </Col>
            </Row>
        );
    }


    // console.log(auth)

    return (
        <Spin spinning={isLoading}>
            <EditProfileContainer gutter={[10, 22]} align={'stretch'} isuploadmarketlogo={+isUploadMarketLogo}
                                  className={""}>
                <Col xs={24} md={12} className='--box'>
                    <FormBox
                        formName={'اطلاعات فردی من'}
                        score={1}
                        icon={userIcon}
                    >
                        <Form
                            form={personalInformationFormRef}
                            autoComplete='off'
                            scrollToFirstError
                            labelCol={{
                                span: 24
                            }}
                            wrapperCol={{
                                span: 24
                            }}
                            onFinish={handleChangePersonalInformation}
                        >
                            <Row>
                                <Col span={24} className='__formInputs'>
                                    <Row gutter={12}>
                                        <Col span={24} className='__userImage'>
                                            <div>
                                                <Avatar
                                                    shape='circle'
                                                    size={68}
                                                    src={userImage}
                                                />
                                                <span className='__editAvatar'>
                      <Edit/>
                    </span>
                                            </div>
                                        </Col>
                                        <Col span={24}>
                                            <Input
                                                name={'firstName'}
                                                label={'نام'}
                                                placeholder={auth?.firstNameFa}
                                                formRef={ handleChangePersonalInformation }
                                                disabled
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'نام'})
                                                    }
                                                ]}
                                            />
                                        </Col>

                                        <Col span={24}>
                                            <Input
                                                name={'lastName'}
                                                label={'نام خانوادگی'}
                                                placeholder={auth?.lastNameFa}
                                                disabled
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'نام خانوادگی'})
                                                    }
                                                ]}
                                            />
                                        </Col>
                                        <Col span={24}>
                                            <Row gutter={10}>
                                                <Col span={24}>
                                                    <SelectBox
                                                        name={'gender'}
                                                        label={'جنسیت'}
                                                        placeholder={auth?.genderId===1?"مرد":"زن"}
                                                        disabled
                                                        rules={[
                                                            {
                                                                required: true,
                                                                message: inputRule('required selectBox', {inputName: 'جنسیت'})
                                                                /**/
                                                            }
                                                        ]}
                                                    >
                                                        <Option value={0}>مرد</Option>
                                                        <Option value={1}>زن</Option>
                                                    </SelectBox>
                                                </Col>
                                                <Col span={24}>
                                                    <SelectBox
                                                        name={'nation'}
                                                        label={'ملیت'}
                                                        rules={[
                                                            {
                                                                required: true,
                                                                message: inputRule('required selectBox', {inputName: 'ملیت'})
                                                            }
                                                        ]}
                                                    >
                                                        <Option value={0}>ایرانی</Option>
                                                        <Option value={1}>خارچی</Option>
                                                    </SelectBox>
                                                </Col>
                                            </Row>
                                        </Col>
                                    </Row>
                                </Col>
                                <Col span={24} className='__formSubmit'>
                                    <Button
                                        htmlType={'submit'}
                                        type={'default'}
                                        className={"w-1/2"}
                                    >
                                        ذخیره
                                    </Button>
                                </Col>

                            </Row>
                        </Form>
                    </FormBox>
                </Col>

                <Col xs={24} md={12} className='--box'>
                    <FormBox
                        formName={'اطلاعات تماس من'}
                        score={1}
                        icon={phoneIcon}
                    >
                        <Form
                            form={contactsInformationFormRef}
                            autoComplete='off'
                            scrollToFirstError
                            labelCol={{
                                span: 24
                            }}
                            wrapperCol={{
                                span: 24
                            }}
                            onFinish={handleChangePersonalInformation}
                        >
                            <Row>
                                <Col span={24} className='__formInputs'>
                                    <Row gutter={12}>
                                        <Col span={24}>
                                            <Input
                                                className={"!bg-transparent"}
                                                name={'mobile'}
                                                label={'شماره همراه'}
                                                placeholder={0+auth?.mobile}
                                                disabled
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'شماره همراه'})
                                                    }
                                                ]}
                                                validateType={'mobile'}
                                                formRef={contactsInformationFormRef}
                                                maxLength={11}
                                                ltr
                                                disabled
                                            />
                                        </Col>

                                        <Col span={24}>
                                            <Row>
                                                <Col flex='1 1'>
                                                    <Input
                                                        name={'PostalCode'}
                                                        label={'کد پستی'}
                                                        formRef={contactsInformationFormRef}
                                                        className={'!rounded-s-none'}
                                                        placeholder
                                                        rules={[
                                                            {
                                                                required: true,
                                                                message: inputRule('required input', {inputName: 'کد پستی'})
                                                            }
                                                        ]}
                                                        ltr
                                                    />
                                                </Col>

                                                <Col flex='20%'>
                                                    <Button
                                                        type={'secondary'}
                                                        className='!mt-[36px] !rounded-s-none'
                                                        height={42}

                                                        block
                                                    >
                                                        استعلام
                                                    </Button>
                                                </Col>
                                            </Row>
                                        </Col>

                                        <Col span={24}>
                                            <TextArea
                                                name={'address'}
                                                rows={3}
                                                label={'نشانی'}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'نشانی'})
                                                    }
                                                ]}
                                            />
                                        </Col>
                                    </Row>
                                </Col>

                                <Col span={24} className='__formSubmit'>
                                    <Button
                                        htmlType={'submit'}
                                        type={'default'}
                                        className={"w-1/2"}
                                    >
                                        ذخیره
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    </FormBox>
                </Col>

                <Col xs={24} md={12} className='--box'>
                    <FormBox
                        formName={'اطلاعات تحصیلی و شغلی من'}
                        score={1}
                        icon={suitcaseIcon}
                    >
                        <Form
                            form={eduAndCareerInformationFormRef}
                            autoComplete='off'
                            scrollToFirstError
                            labelCol={{
                                span: 24
                            }}
                            wrapperCol={{
                                span: 24
                            }}
                            onFinish={handleChangePersonalInformation}
                        >
                            <Row>
                                <Col span={24} className='__formInputs'>
                                    <Row gutter={12}>
                                        <Col span={24}>
                                            <SelectBox
                                                name={'education'}
                                                label={'تحصیلات'}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required selectBox', {inputName: 'تحصیلات'})
                                                    }
                                                ]}
                                            >
                                                <Option value={0}>دکتری</Option>
                                                <Option value={1}> کارشناسی ارشد</Option>
                                                <Option value={1}> کارشناسی</Option>
                                            </SelectBox>
                                        </Col>

                                        <Col span={24}>
                                            <Input
                                                name={'fieldStudy'}
                                                label={'رشته تحصیلی'}
                                                placeholder={"طراح UI/UX"}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'شغل'})
                                                    }
                                                ]}
                                            />
                                        </Col>

                                        <Col span={24}>
                                            <Input
                                                name={'job'}
                                                label={'شغل'}
                                                placeholder={"طراح UI/UX"}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'شغل'})
                                                    }
                                                ]}
                                            />
                                        </Col>
                                    </Row>
                                </Col>

                                <Col span={24} className='__formSubmit'>
                                    <Button
                                        htmlType={'submit'}
                                        type={'default'}
                                        className={"w-1/2"}
                                    >
                                        ذخیره
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    </FormBox>
                </Col>

                <Col xs={24} md={12} className='--box'>
                    <FormBox
                        formName={'تغییر رمز عبور'}
                        score={1}
                        icon={lockIcon}
                    >
                        <Form
                            form={passwordFormRef}
                            autoComplete='off'
                            scrollToFirstError
                            labelCol={{
                                span: 24
                            }}
                            wrapperCol={{
                                span: 24
                            }}
                            onFinish={handleChangePersonalInformation}
                        >
                            <Row>
                                <Col span={24} className='__formInputs'>
                                    <Row gutter={12}>
                                        <Col span={24}>
                                            <InputPassword
                                                name={'currentPassword'}
                                                label={'رمز فعلی'}
                                                min={8}
                                                formRef={passwordFormRef}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'رمز فعلی'})
                                                    }
                                                ]}

                                            />
                                        </Col>

                                        <Col span={24}>
                                            <InputPassword
                                                name={'newPassword'}
                                                label={'رمز جدید'}
                                                min={8}
                                                formRef={passwordFormRef}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'رمز جدید'})
                                                    }
                                                ]}

                                            />
                                        </Col>

                                        <Col span={24}>
                                            <InputPassword
                                                name={'repeatedPassword'}
                                                label={'تکرار رمز جدید'}
                                                dependencies={['newPassword']}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'تکرار رمز جدید'})
                                                    },

                                                ]}

                                            />
                                        </Col>
                                    </Row>
                                </Col>

                                <Col span={24} className='__formSubmit'>
                                    <Button
                                        htmlType={'submit'}
                                        type={'default'}
                                        className={"w-1/2"}
                                    >
                                        ذخیره
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    </FormBox>
                </Col>

                <Col span={24} className='--box'>
                    <FormBox
                        formName={'اطلاعات فروشگاه من'}
                        score={3}
                        icon={marketIcon}
                    >
                        <Form
                            form={marketInformationFormRef}
                            autoComplete='off'
                            scrollToFirstError
                            labelCol={{
                                span: 24
                            }}
                            wrapperCol={{
                                span: 24
                            }}
                            onFinish={handleChangePersonalInformation}
                        >
                            <Row>
                                <Col span={24} className='__formInputs'>
                                    <Row gutter={21}>
                                        <Col xs={24} md={8}>
                                            <Input
                                                name={'marketMail'}
                                                label={'پست الکترونیک'}
                                                validateType={'email'}
                                                formRef={marketInformationFormRef}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'پست الکترونیک'})
                                                    }
                                                ]}
                                                ltr
                                            />
                                        </Col>

                                        <Col xs={24} md={8}>
                                            <Input
                                                name={'marketWebsite'}
                                                label={'نشانی وبسایت'}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: inputRule('required input', {inputName: 'نشانی وبسایت'})
                                                    },
                                                    {
                                                        type: 'url',
                                                        message: inputRule(`URL invalid`, {inputName: 'نشانی وبسایت'})
                                                    }
                                                ]}
                                                ltr
                                            />
                                        </Col>

                                        <Col xs={24} md={8} className='--uploadIcon'>
                                            <Form.Item
                                                name={'marketLogo'}
                                                label={'بارگذاری تصویر لوگو'}
                                            >
                                                <Upload
                                                    action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
                                                    listType='picture'
                                                    maxCount={1}
                                                    onPreview={(file) => console.log('in on preview', file)}
                                                    onChange={(info) => {
                                                        if (info?.fileList?.length) {
                                                            setIsUploadMarketLogo(true);
                                                        } else {
                                                            setTimeout(() => setIsUploadMarketLogo(false), 200);
                                                        }

                                                        console.log(info);
                                                    }}
                                                    fileList={[]}
                                                >
                                                    <div>
                            <span>
                              <UploadIcon/>
                            </span>
                                                    </div>
                                                </Upload>
                                            </Form.Item>
                                        </Col>

                                        <Col span={24} className='--attention'>
                                            <div style={{marginBottom: 13}}>توجه:</div>

                                            <Row gutter={[0, 30]}>
                                                <Col span={24}>
                                                    <Row gutter={17}>
                                                        <Col flex='10px'>
                                                            <ListCircle width={10} height={10} space={0}/>
                                                        </Col>

                                                        <Col flex='1 1'>
                                                            تصویر لوگو (تصویر لوگو همان عکسی می باشد که در بخش لیست
                                                            پذیرندگان و در قسمت بر روی درگاه
                                                            پرداخت این فروشگاه اعمال می شود)
                                                        </Col>
                                                    </Row>
                                                </Col>

                                                <Col span={24}>
                                                    <Row gutter={17}>
                                                        <Col flex='10px'>
                                                            <ListCircle width={10} height={10} space={0}
                                                                        color={'#1447A0'}/>
                                                        </Col>

                                                        <Col flex='1 1'>
                                                            عکس های بالاتر از 1 مگابایت دریافت نمی شود
                                                        </Col>
                                                    </Row>
                                                </Col>
                                            </Row>
                                        </Col>
                                    </Row>
                                </Col>

                                <Col span={24} className='__formSubmit'>
                                    <Button
                                        htmlType={'submit'}
                                        type={'default'}
                                        className={"w-1/3"}
                                        width={127}
                                    >
                                        ذخیره
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    </FormBox>
                </Col>

                <Col span={24} className='--box'>
                    <FormBox
                        formName={'دعوت از دوستان'}
                        icon={usersIcon}
                        score={3}
                    >
                        <Row gutter={16} justify={'space-between'} align={'middle'} className='__inviteFriends'>
                            <Col span={14}>
                                <Row gutter={[0, 60]} justify={'end'}>
                                    <Col span={24}>
                                        <Row gutter={[0, 23]}>
                                            <Col span={24} className='--copyLinkDescription'>
                                                لینک ویژه شما برای ارسال به دوستان:
                                            </Col>

                                            <Col span={24} className='--copyLink'>
                                                <Paragraph
                                                    copyable={{
                                                        text: 'https://www.refah.ir/invite/52A2N6',
                                                        icon: <div className='__copyBtn'>کپی لینک</div>
                                                    }}
                                                >
                                                    <div className='text-truncate __link'>
                                                        https://www.refah.ir/invite/52A2N6
                                                    </div>
                                                </Paragraph>
                                            </Col>
                                        </Row>
                                    </Col>

                                    <Col span={24} className='--messengers'>
                                        <Row gutter={[0, 18]}>
                                            <Col span={24} className='__desc'>
                                                از روش های زیر برای ارسال لینک استفاده نمایید.
                                            </Col>

                                            <Col span={24} className='__lists'>
                                                <Space size={0}>
                                                    <img src={whatsappMessengerIcon} title='پیام رسان واتس آپ'/>
                                                    <img src={soroushMessengerIcon} title='پیام رسان سروش'/>
                                                    <img src={eitaaMessengerIcon} title='پیام رسان ایتا'/>
                                                    <img src={baleMessengerIcon} title='پیام رسان بله'/>
                                                </Space>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>
                            </Col>

                            <Col span={10} className='--bg'>
                                <InviteLinkBg/>
                            </Col>
                        </Row>
                    </FormBox>
                </Col>
            </EditProfileContainer>
        </Spin>
    );
};

const FormBox = ({score, icon, formName, children}) => {
    return (
        <FormBoxContainer gutter={[0, 20]}>
            <Col span={24} className='--topSection'>
                <Row gutter={16} justify={'space-between'} align={'middle'}>
                    <Col span={15}>
                        <Space size={12} align={'start'}>
                            <img src={icon} alt={formName} className='__img'/>

                            <span className='__title'>{formName}</span>
                        </Space>
                    </Col>

                    {score &&
                        <Col span={5} className='__scoreSection'>
                            <Space size={6}>
                                <span className='__title'>{score} {'امتیاز'}</span>
                                {score <= 1 ? <DollarCoin className='--scoreImg'/> :
                                    <DollarCoins className='--scoreImg'/>}
                            </Space>
                        </Col>
                    }
                </Row>
            </Col>

            <Col span={24} className='--content'>
                {children}
            </Col>
        </FormBoxContainer>
    );
};

export default EditProfileDesktop;
