import React from 'react';
import { Col, Form, Row } from 'antd';
import {Button, Input, TextArea, TransitionsPage} from '../../../../../../../templates/Ui';
import { inputRule } from '../../../../../../../utils/helper';

const PersonalMobile = () => {
    const [ personalMobileFormRef ] = Form.useForm();

    const handlePersonalMobile = formData => {
        console.log(formData);
    };


    return (
        <TransitionsPage coordinates={ 'y' } size={ 30 }>
        <div className={"px-[10px] py-[12px]"}>
            <Form
                form={ personalMobileFormRef }
                autoComplete="off"
                scrollToFirstError
                labelCol={ {
                    span: 24,
                } }
                wrapperCol={ {
                    span: 24,
                } }
                onFinish={ handlePersonalMobile }
            >
                <Col span={24}>
                    <Input
                        className={"!bg-transparent"}
                        name={'mobile'}
                        label={'شماره همراه'}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'شماره همراه'})
                            }
                        ]}
                        validateType={'mobile'}
                        formRef={personalMobileFormRef}
                        maxLength={11}
                        ltr
                        disabled
                    />
                </Col>

                <Col span={24}>
                    <Row>
                        <Col flex='1 1'>
                            <Input
                                name={'PostalCode'}
                                label={'کد پستی'}
                                formRef={personalMobileFormRef}
                                className={'!rounded-s-none'}
                                placeholder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'کد پستی'})
                                    }
                                ]}
                                ltr
                            />
                        </Col>

                        <Col flex='20%'>
                            <Button
                                type={'secondary'}
                                className='!mt-[36px] !rounded-s-none'
                                height={42}
                                width={'100%'}
                                block
                            >
                                استعلام
                            </Button>
                        </Col>
                    </Row>
                </Col>

                <Col span={24}>
                    <TextArea
                        name={'address'}
                        rows={3}
                        label={'نشانی'}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'نشانی'})
                            }
                        ]}
                    />
                </Col>
                <Col sm={8} xs={10} className={"items-center text-center mt-[34px] mx-auto"}>
                    <Button
                        className={"w-full"}
                        htmlType={'submit'}
                        type={'default'}

                    >
                        ذخیره
                    </Button>
                </Col>
            </Form>
        </div>
        </TransitionsPage>
    );
};

export default PersonalMobile;
