import React from 'react';
import { Col, Form, Select } from 'antd';
import {Button, InputPassword, TransitionsPage} from '../../../../../../../templates/Ui';
import { inputRule } from '../../../../../../../utils/helper';

const ChangePassword = () => {

    const [ changePassFormRef ] = Form.useForm();
    const {Option} = Select;
    const handleChangePass = formData => {
        console.log(formData);
    };


    return (
        <TransitionsPage coordinates={ 'y' } size={ 30 }>
        <div className={"px-[10px] py-[12px]"}>
            <Form
                form={ changePassFormRef }
                autoComplete="off"
                scrollToFirstError
                labelCol={ {
                    span: 24,
                } }
                wrapperCol={ {
                    span: 24,
                } }
                onFinish={ handleChangePass }
            >

                <Col span={24}>
                    <InputPassword
                        className={"!ltr"}
                        name={'currentPassword'}
                        label={'رمز فعلی'}
                        min={8}
                        formRef={changePassFormRef}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'رمز فعلی'})
                            }
                        ]}

                    />
                </Col>

                <Col span={24}>
                    <InputPassword
                        name={'newPassword'}
                        label={'رمز جدید'}
                        min={8}
                        formRef={changePassFormRef}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'رمز جدید'})
                            }
                        ]}

                    />
                </Col>


                <Col span={24}>
                    <InputPassword
                        name={'repeatedPassword'}
                        label={'تکرار رمز جدید'}
                        dependencies={['newPassword']}
                        rules={[
                            {
                                required: true,
                                message: inputRule('required input', {inputName: 'تکرار رمز جدید'})
                            },
                        ]}

                    />
                </Col>
                <Col sm={8} xs={10} className={"items-center text-center mt-[34px] mx-auto"}>
                    <Button
                        className={"w-full"}
                        htmlType={'submit'}
                        type={'default'}
                        width={127}
                    >
                        ذخیره
                    </Button>
                </Col>
            </Form>

        </div>
        </TransitionsPage>
    );
};

export default ChangePassword;
