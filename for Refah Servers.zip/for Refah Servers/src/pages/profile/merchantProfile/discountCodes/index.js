import { Col, Row, Space } from 'antd';
import styled from 'styled-components';
import { Button, TransitionsPage } from 'templates/Ui';

// icons
import fidibo from 'assets/icons/fidibo.svg';
import snap from 'assets/icons/snap.svg';
import digikala from 'assets/icons/digikala.svg';
import circle from '../../../../assets/icons/mobile/circle.svg';
import { Link } from 'react-router-dom';
import rightArrow from '../../../../assets/icons/mobile/rightArrow.svg';

const DiscountCodesContainer = styled(Row)`
  .--box {
    > .ant-row {
      height: 210px;
    }
  }
`;

const DiscountBoxContainer = styled(Row)`
  background: #FEFEFE;
  border-radius: 25px;
  padding: 17px 0;
  position: relative;

  .--circleStart,
  .--circleEnd {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    border: 1px solid transparent;
    position: absolute;
    bottom: 37px;
    background-color: #f5f5f5;

    :after {
      content: '';
      width: 17px;
      height: 33px;
      display: inline-block;
      background-color: #f5f5f5;
      position: absolute;
      top: -2px;
    }
  }

  .--circleStart {
    inset-inline-start: -16.5px;

    :after {
      inset-inline-start: -5px;
    }
  }

  .--circleEnd {
    inset-inline-end: -16.5px;

    :after {
      inset-inline-end: -5px;
    }
  }

  .--dashedTail {
    width: calc(100% - 30px);
    height: 1px;
    border-top: 1px dashed #99ADC2;
    position: absolute;
    bottom: 50px;
    inset-inline-end: 14px;
  }

  .--topSection,
  .--bottomSection {
    text-align: center;
  }

  .--topSection {
    align-self: flex-start;

    .__icon {
      text-align: center;

      > div {
        width: 70px;
        height: 70px;
        display: inline-block;

        img {

          height: 100%;
        }
      }
    }

    .__discountFrom,
    .__discountExpirationDate {
      .ant-space-item {
        div {
          color:#787878;
          font-size: 12px;
          font-weight: 400;
        }
      }
    }

    .__discountFrom {
      margin-bottom: 7px;
    }
  }

  .--bottomSection {
    align-self: flex-end;
  }
`;

const DiscountCodes = () => {
  return (
      <TransitionsPage coordinates={'x'}>
      <div >
          <Col span={24} className={"mb-[13px] lg:hidden"}>
              <Link to={"/merchantProfile"} className={""}> <img src={rightArrow}/></Link>
          </Col>
          <Col span={24}  className={"mb-[17px] lg:hidden"}>
              <Space align={ 'center'} className={"text-[12px] font-[500] "}>
                  <img src={ circle }/>
                  کدهای تخفیف
              </Space>
          </Col>
    <DiscountCodesContainer gutter={ [18, 18] } align={ 'stretch' }>
      <Col xs={12} lg={ 6 } className='--box'>
        <DiscountBox
          icon={ snap }
          discount={ 20 }
          discountFrom={ 'اسنپ' }
          expirationDate={ '9 دی 1401' }
        />
      </Col>
      
      <Col xs={12} lg={ 6 } className='--box'>
        <DiscountBox
          icon={ fidibo }
          discount={ 30 }
          discountFrom={ 'فیدیبو' }
          expirationDate={ '11 دی 1401' }
        />
      </Col>
      
      <Col xs={12} lg={ 6 } className='--box'>
        <DiscountBox
          icon={ digikala }
          discount={ 20 }
          discountFrom={ 'اسنپ' }
          expirationDate={ '9 دی 1401' }
        />
      </Col>
      
      <Col xs={12} lg={ 6 } className='--box'>
        <DiscountBox
          icon={ fidibo }
          discount={ 30 }
          discountFrom={ 'فیدیبو' }
          expirationDate={ '11 دی 1401' }
        />
      </Col>
      
      <Col xs={12} lg={ 6 } className='--box'>
        <DiscountBox
          icon={ snap }
          discount={ 20 }
          discountFrom={ 'اسنپ' }
          expirationDate={ '9 دی 1401' }
        />
      </Col>
      
      <Col xs={12} lg={ 6 } className='--box'>
        <DiscountBox
          icon={ digikala }
          discount={ 30 }
          discountFrom={ 'فیدیبو' }
          expirationDate={ '11 دی 1401' }
        />
      </Col>
        <Col xs={12} lg={ 6 } className='--box'>
            <DiscountBox
                icon={ fidibo }
                discount={ 30 }
                discountFrom={ 'فیدیبو' }
                expirationDate={ '11 دی 1401' }
            />
        </Col>
        <Col xs={12} lg={ 6 } className='--box'>
            <DiscountBox
                icon={ snap }
                discount={ 20 }
                discountFrom={ 'اسنپ' }
                expirationDate={ '9 دی 1401' }
            />
        </Col>
    </DiscountCodesContainer>
      </div>
      </TransitionsPage>
  );
};

const DiscountBox = ({ icon, discount, discountFrom, expirationDate }) => {
  return (
    <DiscountBoxContainer gutter={ [0, 60] }>
      <div className='--circleStart'/>
      <div className='--circleEnd'/>
      <div className='--dashedTail'/>
      
      <Col span={ 24 } className='--topSection'>
        <Row gutter={ [0, 20] }>
          <Col span={ 24 } className='__icon'>
            <div>
              <img src={ icon } alt={ discountFrom }/>
            </div>
          </Col>
          
          <Col span={ 24 }>
            <div className='__discountFrom'>
              <Space size={ 10 }>
                <div className={"!text-[14px] !text-[#4D4D4D]"}>
                  { 'تخفیف' } { `${ discount }٪` }
                </div>

                  <div className={"!text-[14px] !text-[#4D4D4D]"}>
                  { 'از' } { discountFrom }
                </div>
              </Space>
            </div>
            
            <div className='__discountExpirationDate'>
              <Space size={ 8 }>
                <div>تاریخ انقضا:</div>
                
                <div>{ expirationDate }</div>
              </Space>
            </div>
          </Col>
        </Row>
          <div className=' !mt-[25px] !text-center'>
              <div
                  className={"text-[#1447A0] text-[12px] font-[500] !text-center"}
              >
                  استفاده از کد تخفیف
              </div>
          </div>
      </Col>

    </DiscountBoxContainer>
  );
};

export default DiscountCodes;
