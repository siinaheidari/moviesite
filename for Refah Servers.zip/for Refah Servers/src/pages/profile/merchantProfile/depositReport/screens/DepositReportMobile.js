import React, { useState } from 'react';
import {
    Button,
    DatePicker,
    Input,
    Modal,
    Radio,
    RadioFormItem,
    RadioGroup,
    TransitionsPage,
} from '../../../../../templates/Ui';
import { Col, Divider, Form, Row, Space } from 'antd';
import { Link } from 'react-router-dom';
import rightArrow from '../../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../../assets/icons/mobile/circle.svg';
import filter from '../../../../../assets/icons/mobile/Filter.svg';
import Arrow from '../../../../../assets/icons/mobile/blueArrow.svg';
import search from '../../../../../assets/icons/mobile/search.svg';
import { inputRule } from '../../../../../utils/helper';
import { DateObject } from 'react-multi-date-picker';
import persian from 'react-date-object/calendars/persian';
import gregorian from 'react-date-object/calendars/gregorian';

const DepositReportMobile = () => {

    const [ depositReportFormRef ] = Form.useForm();
    const [ currentTab, setCurrentTab ] = useState('');
    const [ depositReportModal, setDepositReportModal ] = useState(false);

    const currentData = new DateObject({calendar: persian});
    const currentData2 = new DateObject({calendar: persian});

    const lastDayDate = new DateObject({calendar: persian});
    const lastDayDate2 = new DateObject({calendar: persian});

    const [startDate, setStartDate] = useState(lastDayDate2?.subtract(1, 'day')?.convert(gregorian)?.format('YYYY-MM-DD'))

    const [endDate, setEndDate] = useState(currentData2?.convert(gregorian)?.format('YYYY-MM-DD'));

    const handleDepositReport=(values)=>{

        setDepositReportModal(false)
        console.log(values);
        setStartDate(() => {
            return new DateObject({
                date: values?.startDate,
                calendar: persian
            })?.convert(gregorian).format('YYYY-MM-DD')
        });

        setEndDate(() => {
            return new DateObject({
                date: values?.endDate,
                calendar: persian
            })?.convert(gregorian).format('YYYY-MM-DD')
        });
    }


    const handleToggleTab = (type) => {
        setCurrentTab(current => current === type ? '' : type);
    };

    return (
        <TransitionsPage coordinates={'x'}>
            <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
                <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                    <img src={ circle }/>
                    لیست تراکنش ها
                </Space>
                <div className={ 'bg-white p-[8px] rounded-[5px] shadow-6' } onClick={ () => setDepositReportModal(true) }>
                    <img src={ filter }/>
                </div>

            </div>
            <Row gutter={ [ 0, 20 ] }>

                <Col span={ 24 }>
                    <div className={ 'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div
                            className={ 'bg-[#00B892] font-[500] text-[11px] text-white px-[7px] py-[3px] rounded-[5px] text-center mb-[15px] w-[55px]' }>
                            موفق
                        </div>
                        <div onClick={ () => handleToggleTab('1') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    نوع حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  جاری
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 1234567897
                                </span>
                                </Col>
                                <Col span={ 24 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره شبا:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        IR۲۵۰۱۹۰۰۰۰۰۰۰۱۰۱۴۱۶۲۹۷۰۰۷
                                </span>
                                </Col>
                            </Row>
                        </div>
                        
                        {
                            currentTab==="1" ?  <TransitionsPage coordinates={ 'y' } size={ 10 }>
                                <Row gutter={ [ 5, 13 ] }
                                     className={ currentTab === '1' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        موجودی حساب:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1.230.000 ریال
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        ترمینال متصل:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1234567
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ راه اندازی:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  1401-08-28
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ جمع آوری:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   1401-08-28
                                </span>
                                    </Col>
                                </Row>
                            </TransitionsPage>:''
                        }
                        
                        
                        
                        <div onClick={ () => handleToggleTab('1') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>
                <Col span={ 24 }>
                    <div className={ 'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div
                            className={ 'bg-[#FE2301] font-[500] text-[11px] text-white px-[7px] py-[3px] rounded-[5px] text-center mb-[15px] w-[55px]' }>
                            ناموفق
                        </div>
                        <div onClick={ () => handleToggleTab('2') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    نوع حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  جاری
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 1234567897
                                </span>
                                </Col>
                                <Col span={ 24 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره شبا:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        IR۲۵۰۱۹۰۰۰۰۰۰۰۱۰۱۴۱۶۲۹۷۰۰۷
                                </span>
                                </Col>
                            </Row>
                        </div>
                        
                        {
                            currentTab==="2" ?  <TransitionsPage coordinates={ 'y' } size={ 10 }>
                                <Row gutter={ [ 5, 13 ] }
                                     className={ currentTab === '2' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        موجودی حساب:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1.230.000 ریال
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        ترمینال متصل:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1234567
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ راه اندازی:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  1401-08-28
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ جمع آوری:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   1401-08-28
                                </span>
                                    </Col>
                                </Row>
                            </TransitionsPage>:''
                        }
                        
                        
                        
                        <div onClick={ () => handleToggleTab('2') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>
                <Col span={ 24 }>
                    <div className={ 'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div
                          className={ 'bg-[#00B892] font-[500] text-[11px] text-white px-[7px] py-[3px] rounded-[5px] text-center mb-[15px] w-[55px]' }>
                            موفق
                        </div>
                        <div onClick={ () => handleToggleTab('3') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    نوع حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  جاری
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 1234567897
                                </span>
                                </Col>
                                <Col span={ 24 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره شبا:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        IR۲۵۰۱۹۰۰۰۰۰۰۰۱۰۱۴۱۶۲۹۷۰۰۷
                                </span>
                                </Col>
                            </Row>
                        </div>
                        
                        {
                            currentTab==="3" ?  <TransitionsPage coordinates={ 'y' } size={ 10 }>
                                <Row gutter={ [ 5, 13 ] }
                                     className={ currentTab === '3' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        موجودی حساب:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1.230.000 ریال
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        ترمینال متصل:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1234567
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ راه اندازی:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  1401-08-28
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ جمع آوری:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   1401-08-28
                                </span>
                                    </Col>
                                </Row>
                            </TransitionsPage>:''
                        }
                        
                        
                        
                        <div onClick={ () => handleToggleTab('3') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>
                <Col span={ 24 }>
                    <div className={ 'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]' }>
                        <div
                          className={ 'bg-[#FE2301] font-[500] text-[11px] text-white px-[7px] py-[3px] rounded-[5px] text-center mb-[15px] w-[55px]' }>
                            ناموفق
                        </div>
                        <div onClick={ () => handleToggleTab('4') } className={ 'mb-[13px]' }>
                            <Row gutter={ [ 5, 13 ] }>
                                <Col xs={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    نوع حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  جاری
                                </span>
                                </Col>
                                <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره حساب:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                 1234567897
                                </span>
                                </Col>
                                <Col span={ 24 } className={ 'text-[12px] font-[500] text-title' }>
                                    شماره شبا:
                                    <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                        IR۲۵۰۱۹۰۰۰۰۰۰۰۱۰۱۴۱۶۲۹۷۰۰۷
                                </span>
                                </Col>
                            </Row>
                        </div>
                        
                        {
                            currentTab==="4" ?  <TransitionsPage coordinates={ 'y' } size={ 10 }>
                                <Row gutter={ [ 5, 13 ] }
                                     className={ currentTab === '4' ? ' duration-1500 pb-[12px]' : 'hidden duration-1000' }>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        موجودی حساب:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1.230.000 ریال
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        ترمینال متصل:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                    1234567
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ راه اندازی:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                  1401-08-28
                                </span>
                                    </Col>
                                    <Col span={ 12 } className={ 'text-[12px] font-[500] text-title' }>
                                        تاریخ جمع آوری:
                                        <span className={ 'text-[12px] font-[400] text-[#4D4D4D] mr-2' }>
                                   1401-08-28
                                </span>
                                    </Col>
                                </Row>
                            </TransitionsPage>:''
                        }
                        
                        
                        
                        <div onClick={ () => handleToggleTab('4') }
                             className={ 'w-full items-center text-center' }>
                            <img src={ Arrow } className={ !currentTab ? 'inline' : 'inline rotate-180 ' }/>
                        </div>
                    </div>
                </Col>

            </Row>

            <Modal
                open={ depositReportModal }
                onCancel={ () => setDepositReportModal(false) }
                header={ false }
                closable={ false }
                bodyStyle={{
                    padding: 0,
                    backgroundColor:"white"
                }}
                size={ {
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 40,
                    xl: 40,
                    xxl: 30,
                } }
                style={{
                    top: "20vh",
                }}

            >
                <div className={"pb-[24px]"}>
                    <div className={"--modal text-[12px] text-[#4D4D4D]"}>
                        <Space className={"px-[24px] pt-[16px]"}>
                            <img src={filter}/>
                            فیلترها
                        </Space>
                    </div>
                    <Divider className={"!m-2"}/>
                    <div className={"px-[22px]"}>
                    <Form
                        form={ depositReportFormRef }
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={ {
                            span: 24,
                        } }
                        wrapperCol={ {
                            span: 24,
                        } }
                        onFinish={ handleDepositReport }
                    >
                        <Col span={24}>
                            <Input
                                name={'search'}
                                placeholder={"جستجو شماره پیگیری"}
                                formRef={depositReportFormRef}
                                focus
                                suffix={<img src={search}/> }
                            />
                        </Col>
                        <Col span={24} className={"my-[20px]"}>
                            <Row gutter={20}>
                                <Col span={12}>
                                    <DatePicker
                                        name={'startDate'}
                                        placeholder={'از تاریخ'}
                                        hiddenLabel
                                        initialValue={lastDayDate?.subtract(1, 'day').format('YYYY-MM-DD')}
                                        rules={[
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', {inputName: 'تاریخ '})
                                            }
                                        ]}
                                        rtl
                                    />
                                </Col>
                                <Col span={12}>
                                    <DatePicker
                                        name={'endDate'}
                                        placeholder={'تا تاریخ'}
                                        hiddenLabel
                                        initialValue={currentData.format('YYYY-MM-DD')}
                                        rules={[
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', {inputName: 'تاریخ '})
                                            }
                                        ]}
                                        rtl
                                    />
                                </Col>
                            </Row>
                        </Col>
                        <Col span={ 24 } className={"text-center items-center "}>
                            <RadioFormItem
                                name={ '' }
                                initialValue='1'

                            >
                                <RadioGroup  className={"w-full flex justify-between !px-[-50px]"}>
                                    <Radio className={""} value='all'>همه</Radio>

                                    <Radio className={" "} value='ipg'>درگاه پرداخت</Radio>

                                    <Radio className={" "} value='pos'>POS</Radio>
                                </RadioGroup>
                            </RadioFormItem>
                        </Col>
                        <Col sm={10} xs={24} className={" mt-[47px] mx-auto"}>
                            <Button
                                className={"!rounded-[5px] text-[12px] font-[400] w-full"}
                                htmlType={'submit'}
                                type={'secondary'}
                                radius={50}
                                width={127}
                            >
                                اعمال فیلتر
                            </Button>
                        </Col>
                    </Form>
                    </div>
                </div>
            </Modal>
        </TransitionsPage>
    );
};

export default DepositReportMobile;
