import { Col, Form, Row, Spin } from 'antd';
import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import SvgIcon from 'templates/components/SvgIcon';
import { DatePicker, Input, Table } from 'templates/Ui';
import { formatNumber, inputRule } from 'utils/helper';
import { useRequest } from '../../../../../utils/useRequest';
import { DateObject } from 'react-multi-date-picker';
import persian from 'react-date-object/calendars/persian';
import gregorian from 'react-date-object/calendars/gregorian';

const DepositReportContainer = styled(Row)`
  .--filters {
    padding: 0 23px;
  }

  .--discrepanciesListLink {
    padding-inline-start: 32px;
    margin-top: -70px;

    a {
      text-decoration-line: underline;
      font-weight: 400;
    }
  }
`;


const DepositReport = () => {
    const [ filterFormRef ] = Form.useForm();

    const transactionTableRef = useRef(null);


    const [ page, setPage ] = useState(1);

    const [ pageSize, setPageSize ] = useState(10);

    const currentData = new DateObject({ calendar: persian });
    const currentData2 = new DateObject({ calendar: persian });

    const lastDayDate = new DateObject({ calendar: persian });
    const lastDayDate2 = new DateObject({ calendar: persian });

    const [ startDate, setStartDate ] = useState(lastDayDate2?.subtract(2, 'day')?.convert(gregorian)?.format('YYYY-MM-DD'));

    const [ endDate, setEndDate ] = useState(currentData2?.convert(gregorian)?.format('YYYY-MM-DD'));

    const [ terminalNo, setTerminalNo ] = useState(1);

    const [ pspCode, setPspCode ] = useState(1);



    const {
        isLoading,
        data,
        dataUpdatedAt,
    } = useRequest({
        path: '/bank/get-shaparak-transaction',
        params: {
            pageNumber: page,
            fromDate: +(startDate?.replace(/-/g, '')),
            toDate: +(endDate?.replace(/-/g, '')),
            pageIndex: pageSize,
            pspCode: pspCode,
            terminalNo: terminalNo,
            rowPage: 30,
        },
        options: {
            retry: false,
        },
        apiType: 'club',
        key: [ 'get-shaparak-transaction', page, startDate, endDate, pageSize, pspCode, terminalNo ],
    });


    const response = data || [];

    const handleFilter = () => {

        const values = filterFormRef?.getFieldsValue(true);

        setStartDate(() => {
            return new DateObject({
                date: values?.startDate,
                calendar: persian,
            })?.convert(gregorian).format('YYYY-MM-DD');
        });

        setEndDate(() => {
            return new DateObject({
                date: values?.endDate,
                calendar: persian,
            })?.convert(gregorian).format('YYYY-MM-DD');
        });
        setTerminalNo(values?.terminalNo);
        setPspCode(values?.pspCode);
    };


    const tableColumns = [
        {
            title: 'ترمینال',
            dataIndex: 'terminal',
            key: 'terminal',
            align: 'center',
        },
        {
            title: 'نوع درگاه',
            dataIndex: 'portType',
            key: 'portType',
            align: 'center',
        },
        {
            title: 'شرکت PSP',
            dataIndex: 'PSPInc',
            key: 'PSPInc',
            align: 'center',
        },
        {
            title: 'شماره رسید تراکنش',
            dataIndex: 'transactionNumber',
            key: 'transactionNumber',
            align: 'center',
        },
        {
            title: 'تاریخ',
            dataIndex: 'date',
            key: 'date',
            align: 'center',
        },
        {
            title: 'ساعت',
            dataIndex: 'time',
            key: 'time',
            align: 'center',
        },
        {
            title: 'شماره پیگیری',
            dataIndex: 'trackingCode',
            key: 'trackingCode',
            align: 'center',
        },
        {
            title: 'شماره کارت',
            dataIndex: 'cardNumber',
            key: 'cardNumber',
            align: 'center',
        },
        {
            title: 'مبلغ تراکنش',
            dataIndex: 'transactionAmount',
            key: 'transactionAmount',
            align: 'center',
            render: (_, { transactionAmount }) => formatNumber(transactionAmount),
        },
        {
            title: 'امتیاز',
            dataIndex: 'score',
            key: 'score',
            align: 'center',
        },
    ];


    return (
        <Spin spinning={ false }>
            <Form
                form={ filterFormRef }
                name="indexFrom"
                autoComplete="off"
                scrollToFirstError
                labelCol={ {
                    span: 24,
                } }
                wrapperCol={ {
                    span: 24,
                } }
                onFinish={ handleFilter }
            >
                <DepositReportContainer gutter={ [ 0, 30 ] }>
                    <Col span={ 24 } className="--filters">
                        <Row gutter={ 16 } justify={ 'space-between' }>
                            {/*<Col span={ 8 }>*/ }

                            {/*    <RadioFormItem*/ }
                            {/*        name={ 'input1' }*/ }
                            {/*    >*/ }
                            {/*        <RadioGroup defaultValue={ 'test' } block>*/ }
                            {/*            <RadioButton value={ 'test' }>*/ }
                            {/*                همه*/ }
                            {/*            </RadioButton>*/ }

                            {/*            <RadioButton value={ 'test1' }>*/ }
                            {/*                درگاه پرداخت*/ }
                            {/*            </RadioButton>*/ }

                            {/*            <RadioButton value={ 'test2' }>*/ }
                            {/*                POS*/ }
                            {/*            </RadioButton>*/ }
                            {/*        </RadioGroup>*/ }
                            {/*    </RadioFormItem>*/ }
                            {/*</Col>*/ }

                            <Col span={ 10 }>
                                <Row gutter={ 16 }>
                                    <Col span={ 12 }>
                                        <Input
                                            name={ 'terminalNo' }
                                            placeholder={ 'شماره ترمینال ' }
                                            bordered
                                            allowClear
                                            // rules={ [
                                            //     {
                                            //         required: true,
                                            //     },
                                            // ] }
                                        />
                                    </Col>
                                    <Col span={ 12 }>
                                        <Input
                                            name={ 'pspCode' }
                                            placeholder={ 'کد شرکت پرداخت یاری' }
                                            bordered
                                            allowClear
                                            // rules={ [
                                            //     {
                                            //         required: true,
                                            //     },
                                            // ] }
                                        />
                                    </Col>


                                    {/*<Col span={ 8 }>*/ }
                                    {/*    <SelectBox*/ }
                                    {/*        name={ 'extract' }*/ }
                                    {/*        placeholder={ 'خروجی' }*/ }
                                    {/*    >*/ }
                                    {/*        <Select.Option value={ 'Pdf' }>Pdf</Select.Option>*/ }
                                    {/*        <Select.Option value={ 'excel' }>اکسل</Select.Option>*/ }
                                    {/*    </SelectBox>*/ }
                                    {/*</Col>*/ }
                                </Row>
                            </Col>

                            {/*<Col span={ 10 }>*/ }
                            {/*    <RadioFormItem*/ }
                            {/*        name={ 'input2' }*/ }
                            {/*    >*/ }
                            {/*        <RadioGroup defaultValue={ 'test' } block>*/ }
                            {/*            <RadioButton value={ 'test' }>*/ }
                            {/*                سالانه*/ }
                            {/*            </RadioButton>*/ }

                            {/*            <RadioButton value={ 'test1' }>*/ }
                            {/*                ماهانه*/ }
                            {/*            </RadioButton>*/ }

                            {/*            <RadioButton value={ 'test2' }>*/ }
                            {/*                هفتگی*/ }
                            {/*            </RadioButton>*/ }
                            {/*            <RadioButton value={ 'test3' }>*/ }
                            {/*                روزانه*/ }
                            {/*            </RadioButton>*/ }
                            {/*        </RadioGroup>*/ }
                            {/*    </RadioFormItem>*/ }
                            {/*</Col>*/ }


                            <Row gutter={ 16 } justify={ 'end' }>
                                <Col span={ 8 }>
                                    <DatePicker
                                        name={ 'startDate' }
                                        placeholder={ 'از تاریخ' }
                                        hiddenLabel
                                        initialValue={ lastDayDate?.subtract(2, 'day').format('YYYY-MM-DD') }
                                        rules={ [
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', { inputName: 'تاریخ ' }),
                                            },
                                        ] }
                                        rtl

                                    />
                                </Col>
                                <Col span={ 8 }>
                                    <DatePicker
                                        name={ 'endDate' }
                                        placeholder={ 'تا تاریخ' }
                                        hiddenLabel
                                        initialValue={ currentData.format('YYYY-MM-DD') }

                                        rules={ [
                                            {
                                                required: true,
                                                message: inputRule('required selectBox', { inputName: 'تاریخ ' }),
                                            },
                                        ] }
                                        rtl

                                    />
                                </Col>
                                <Col span={ 6 } className="text-end pb-6">
                                    <button onClick={ handleFilter }
                                            className={ 'bg-backbtn w-full max-w-[150px] h-[42px] text-white rounded-lg' }>
                                        اعمال
                                    </button>
                                </Col>
                            </Row>

                        </Row>
                    </Col>

                    <Col span={ 24 } className="--table" ref={ transactionTableRef }>
                        <Table
                            columns={ tableColumns }
                            dataSource={ response }
                            bordered
                            tableLayout={ 'fixed' }
                            rowClassName={ pageData => {
                                if (pageData?.status) {
                                    return '--statusTrue';
                                }
                                return '--statusFalse';
                            } }
                            pagination={ {
                                hideOnSinglePage: true,
                                defaultPageSize: 10,
                                total: 30,
                                showSizeChanger: false,
                                responsive: true,
                                position: [ 'bottomLeft' ],
                                nextIcon: <SvgIcon icon={ 'leftCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                                                   style={ { margin: '6px auto' } }/>,
                                prevIcon: <SvgIcon icon={ 'rightCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                                                   style={ { margin: '6px auto' } }/>,
                                onChange: () => transactionTableRef?.current.scrollIntoView({ behavior: 'smooth' }),
                            } }
                        />
                    </Col>

                    <Col span={ 24 } className="--discrepanciesListLink">
                        <Link to={ '' }>
                            لیست مغایرت ها
                        </Link>
                    </Col>
                </DepositReportContainer>
            </Form>
        </Spin>
    );
};

export default DepositReport;
