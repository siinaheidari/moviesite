import React from 'react';
import { MatchBreakpoint } from 'react-hook-breakpoints';
import DepositReportDesktop from './screens/DepositReportDesktop';
import DepositReportMobile from './screens/DepositReportMobile';

const DepositReport = () => {
  return (
      <>
        <MatchBreakpoint max="md">
          <DepositReportMobile />
        </MatchBreakpoint>

        <MatchBreakpoint min="lg">
          <DepositReportDesktop />
        </MatchBreakpoint>
      </>
  );
};

export default DepositReport;
