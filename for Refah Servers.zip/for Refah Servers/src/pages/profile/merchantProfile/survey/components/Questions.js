// import { Col, Form, Rate, Row, Spin } from 'antd';
// import { AnimatePresence, motion } from 'framer-motion';
// import { Button, Modal, TextArea } from '../../../../../templates/Ui';
// import { LeftOutlined } from '@ant-design/icons';
// import MessageModal from './MessageModal';
// import React from 'react';
//
// <QuestionsContainer className={ 'max-lg:bg-white max-lg:rounded-[5px] max-lg:py-[30px]' }>
//     <Col span={ 24 }>
//         <Spin spinning={ false }>
//             {
//                 toolsListRes?.map(item =>
//                     <Col span={ 24 } className="--question">
//                         { item?.pollDesc }
//                     </Col>,
//                 )
//             }
//             <Form
//                 form={ questionsFormRef }
//                 autoComplete="off"
//                 labelCol={ {
//                     span: 24,
//                 } }
//                 wrapperCol={ {
//                     span: 24,
//                 } }
//                 onFinish={ handleOnFinishSurvey }
//                 scrollToFirstError
//             >
//                 <SurveyContainer gutter={ [ 0, 50 ] }>
//                     <Col span={ 24 } className="--formContent">
//                         <AnimatePresence mode={ 'wait' }>
//                             <motion.div
//                                 key={ currentQuestion || 'empty' }
//                                 initial={ {
//                                     x: 70,
//                                     opacity: 0,
//                                 } }
//                                 animate={ {
//                                     x: 0,
//                                     opacity: 1,
//                                 } }
//                                 exit={ {
//                                     x: -70,
//                                     opacity: 0,
//                                 } }
//                                 transition={ { duration: 0.3 } }
//                             >
//                                 <Col span={ 24 } className="--rate">
//                                     <Form.Item
//                                         name={ 'rate' }
//                                         rules={ [
//                                             {
//                                                 validator: (_, value) => !!value ? Promise.resolve() : Promise.reject(new Error('لطفا امتیاز خود را ثبت کنید')),
//                                             },
//                                         ] }
//                                     >
//                                         <Rate
//                                             count={ 5 }
//                                         />
//                                     </Form.Item>
//                                 </Col>
//
//                                 <Col span={ 24 } className="--descriptions">
//                                     <TextArea
//                                         name={ [ 'question1', 'descriptions' ] }
//                                         label={ 'توضیحات (اختیاری)' }
//                                         placeholder={ 'توضیحات' }
//                                     />
//                                 </Col>
//                             </motion.div>
//                         </AnimatePresence>
//                     </Col>
//
//                     <Col span={ 24 } className={ ' mx-auto items-center text-center px-[18px]' }>
//                         <Row gutter={ 16 } justify={ 'center' }>
//
//
//                             {/*<Col sm={ 8 } xs={ 12 } lg={ 6 }>*/ }
//                             {/*    <Button*/ }
//                             {/*        className={ 'w-full' }*/ }
//                             {/*        type={ 'default' }*/ }
//                             {/*        onClick={ handlePrevQuestion }*/ }
//                             {/*    >*/ }
//                             {/*        <RightOutlined/>*/ }
//                             {/*        قبلی*/ }
//                             {/*    </Button>*/ }
//                             {/*</Col>*/ }
//
//
//                             <Col sm={ 8 } xs={ 12 } lg={ 6 }>
//                                 <Button
//                                     className={ 'w-full' }
//                                     type={ 'secondary' }
//                                     iconAlign={ 'end' }
//                                     onClick={ handleNextQuestion }
//                                 >
//                                     <LeftOutlined/>
//                                     ثبت نظر
//                                 </Button>
//                             </Col>
//
//                         </Row>
//                     </Col>
//                 </SurveyContainer>
//             </Form>
//         </Spin>
//     </Col>
//     <Modal
//         open={ surveyMessageModalVisible }
//         title={ '' }
//         onCancel={ handleCloseSurveyMessageModal }
//         header={ false }
//         closable={ false }
//         size={ {
//             xs: 90,
//             sm: 90,
//             md: 90,
//             lg: 40,
//             xl: 40,
//             xxl: 30,
//         } }
//         style={ {
//             top: '23vh',
//         } }
//
//     >
//         <MessageModal handleCloseModal={ handleCloseSurveyMessageModal }/>
//     </Modal>
// </QuestionsContainer>