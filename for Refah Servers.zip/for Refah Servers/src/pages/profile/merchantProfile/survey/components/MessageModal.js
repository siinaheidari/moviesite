import { Col, Row } from 'antd';
import styled from 'styled-components';
import RefahLogo  from 'assets/icons/mobile/refahLogo.svg';
import { Button } from 'templates/Ui';

const MessageModalContainer = styled(Row)`
  .--icon,
  .--message,
  .--btn {
    text-align: center;
  }

  .--icon {
    svg {
      height: 115px;
    }
  }

  .--message {
    color: #4D4D4D;
    font-size: .875rem;
    font-weight: 400;
  }

  .--btn {
    margin-top: 19px;
  }
`;

const MessageModal = ({ handleCloseModal }) => {
  return (
    <MessageModalContainer gutter={ [0, 25] } >
      <Col span={ 24 } className='--icon justify-center flex'>
        <img src={RefahLogo}/>

      </Col>
      
      <Col span={ 24 } className='--message'>
        با سلام لطفا با پاسخ‌دهی به چند سوال کوتاه به ما کمک کنید تا نحوه ارائه خدمت به شما را بهبود دهیم.
      </Col>
      
      <Col xs={ 24 } sm={8} lg={8} className='--btn mx-auto'>
        <Button onClick={ handleCloseModal }
                className={"w-full"}
        type={"secondary"}
        >
          شروع
        </Button>
      </Col>
    </MessageModalContainer>
  );
};

export default MessageModal;
