import {Col, Empty, Form, Rate, Row, Space, Spin} from 'antd';
import { Button, Modal, TransitionsPage } from 'templates/Ui';
import styled from 'styled-components';
import React, { useState } from 'react';


// components use
import tw from 'twin.macro';
import { Link } from 'react-router-dom';
import rightArrow from '../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../assets/icons/mobile/circle.svg';
import { useRequest } from '../../../../utils/useRequest';
import MessageModal from './components/MessageModal';
import { DateObject } from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import { useAuth } from '../../../../contexts/auth/AuthContext';
import {LoadingOutlined} from "@ant-design/icons";
import {BeatLoader} from "react-spinners";
import refahLogo from "../../../../assets/icons/refahLogo.svg";

const QuestionsContainer = styled(Row)`
  .--question {
    text-align: center;
    color: #000000;
    font-size: .875rem;
    font-weight: 400;
    ${ tw`max-lg:text-[12px]` }
  }

  .--rate {
    text-align: center;
    direction: ltr;

    .ant-rate {
      direction: ltr;
      color: #F9B618;

      .ant-rate-star {
        .ant-rate-star-second,
        .ant-rate-star-second {
          color: transparent;
        }

        &.ant-rate-star-full {
          .ant-rate-star-second,
          .ant-rate-star-second {
            color: inherit;
          }
        }

        :after {
          color: #787878;
          font-size: .875rem;
          font-weight: 400;
        }

        :nth-child(1) {
          :after {
            content: '1';
          }
        }

        :nth-child(2) {
          :after {
            content: '2';
          }
        }

        :nth-child(3) {
          :after {
            content: '3';
          }
        }

        :nth-child(4) {
          :after {
            content: '4';
          }
        }

        :nth-child(5) {
          :after {
            content: '5';
          }
        }

        :nth-child(6) {
          :after {
            content: '6';
          }
        }

        :nth-child(7) {
          :after {
            content: '7';
          }
        }

        :nth-child(8) {
          :after {
            content: '8';
          }
        }

        :nth-child(9) {
          :after {
            content: '9';
          }
        }

        :nth-child(10) {
          :after {
            content: '10';
          }
        }
      }

      .anticon {
        svg {
          font-size: 33px;

          path {
            stroke: #F9B618;
            stroke-width: 50px;
            stroke-linejoin: round;
            paint-order: stroke;
          }
        }
      }
    }
  }

  .--descriptions {
    margin-top: -20px;
  }
`;


const Survey = () => {

    const { auth } = useAuth();

    const [ questionsFormRef ] = Form.useForm();

    const [ surveyMessageModalVisible, setSurveyMessageModalVisible ] = useState(true);

    const [ surveyModal, setSurveyModal ] = useState({});
    const handleCloseSurveyMessageModal = () => setSurveyMessageModalVisible(false);

    const handleSurveyModal = (survey) => {
        setSurveyModal(survey);
    };

    const {
        isLoading: toolsListIsLoading,
        data: toolsListData,
    } = useRequest({
        path: '/poll/tools-list-poll',
        key: [ 'tools-list-poll' ],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const toolsListRes = toolsListData;
    console.log(toolsListRes);


    const {
        isLoading: insertPollLoading,
        mutateAsync: insertPollRequest,
    } = useRequest({
        path: '/poll/insert-poll-answer',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: ' نظر شما با موفقیت ثبت شد',
        customErrorMessage: 'خطا در ارسال نظر شما لطفا مجددا تلاش فرمایید',
    });

    const handleOnFinishSurvey = async () => {
        const values = questionsFormRef.getFieldsValue(true);

        try {
            await insertPollRequest({
                ...values,
                personId: auth?.userId,
            });
            await questionsFormRef.resetFields();
            await setSurveyModal({})

        } catch (err) {
            console.log(err);
            await questionsFormRef.resetFields();
        }
    };


    return (
        <TransitionsPage coordinates={ 'x' } className={ 'lg:px-[25px]' }>
            <Spin spinning={insertPollLoading||toolsListIsLoading} className={'relative'}
                  indicator={<LoadingOutlined className={'!hidden'}/>}
                  tip={<div>
                      <BeatLoader
                          color={'#1447a0'}
                          loading={true}
                          size={9}
                          aria-label="Loading Spinner"
                          data-testid="loader"
                      />
                      <img src={refahLogo} width={'90px'} height={'80px'}
                           className={'mx-auto relative top-[-100px]'}/>
                  </div>}>

            <Col span={ 24 } className={ 'mb-[13px] lg:hidden' }>
                <Link to={ '/merchantProfile' } className={ '' }> <img src={ rightArrow }/></Link>
            </Col>
            <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
                <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                    <img src={ circle }/>
                    شرکت در نظرسنجی
                </Space>
            </div>


            <Row gutter={ [ 25, 20 ] }>
                { !!toolsListRes?.length ?
                    toolsListRes.map((item) => {
                        const date = item?.createDate.split('T')[1]?.split(':');
                        return (
                            <Col xs={ 24 } md={ 12 } key={ item?.rowId }>
                                <div
                                    className=" drop-shadow-md px-[15px] space-y-[10px] bg-[#f9f9f9] h-full py-[14px] rounded-[5px] ">
                                    <div className={ 'text-[14px] max-lg:text-[12px] font-[500] text-textblue' }>
                                        { item?.pollDesc }
                                    </div>
                                    <div className="text-[12px] gap-4">
                                        <div
                                            className={ 'cursor-pointer flex justify-between gap-2 text-[12px] font-[400] text-[#4D4D4D]' }>
                                            <div>
                                                تاریخ و ساعت:
                                                <span className={ 'text-[12px] font-[400] text-[#4D4D4D] ' }>
                                                {

                                                    new DateObject({
                                                        date: new Date(item?.createDate),
                                                        calendar: gregorian,
                                                    }).convert(persian).format(`${ date[0] }:${ date[1] } - YYYY/MM/DD`)
                                                }
                                            </span>
                                            </div>
                                            <div onClick={ () => handleSurveyModal(item) }
                                                 className={ 'text-blue-400 underline max-lg:text-[12px] max-lg:font-[400]' }>شرکت
                                                در نظرسنجی
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </Col>
                        );
                    })

                    :
                    <Col span={ 24 } className="text-center">
                        <Empty description={ ' نظرسنجی یافت نشد' }/>
                    </Col>
                }

            </Row>

            <Modal
                open={ surveyMessageModalVisible }
                title={ '' }
                onCancel={ handleCloseSurveyMessageModal }
                header={ false }
                closable={ false }
                size={ {
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 40,
                    xl: 40,
                    xxl: 30,
                } }
                style={ {
                    top: '23vh',
                } }

            >
                <MessageModal handleCloseModal={ handleCloseSurveyMessageModal }/>
            </Modal>


            <Modal
                open={ surveyModal?.rowId }
                title={ '' }
                onCancel={ () => setSurveyModal({}) }
                header={ false }
                closable={ false }
                size={ {
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 40,
                    xl: 40,
                    xxl: 30,
                } }
                style={ {
                    top: '23vh',
                } }

            >
                <Form
                    form={ questionsFormRef }
                    autoComplete="off"
                    labelCol={ {
                        span: 24,
                    } }
                    wrapperCol={ {
                        span: 24,
                    } }
                    onFinish={ handleOnFinishSurvey }
                    initialValues={ {
                        pollId: surveyModal?.rowId,
                    } }
                    scrollToFirstError
                >

                    <QuestionsContainer gutter={ [ 0, 25 ] }>
                        <div className={ 'text-center mx-auto text-textblue max-lg:text-[12px]' }>
                            { surveyModal?.pollDesc }
                        </div>

                        <Col span={ 24 } className="--rate">
                            <Form.Item
                                name={ 'pollScore' }
                                rules={ [
                                    {
                                        validator: (_, value) => !!value ? Promise.resolve() : Promise.reject(new Error('لطفا امتیاز خود را ثبت کنید')),
                                    },
                                ] }
                            >
                                <Rate
                                    count={ 5 }
                                />
                            </Form.Item>
                        </Col>

                        {/*<Col span={ 24 } className="--descriptions">*/ }
                        {/*    <TextArea*/ }
                        {/*        name={ 'descriptions' }*/ }
                        {/*        label={ 'توضیحات (اختیاری)' }*/ }
                        {/*        placeholder={ 'توضیحات' }*/ }
                        {/*    />*/ }
                        {/*</Col>*/ }
                    </QuestionsContainer>
                    <Col xs={ 24 } lg={ 12 } className={ 'mx-auto mt-[2rem]' }>
                        <Button
                            htmlType={ 'submit' }
                            type={ 'secondary' }
                            className={ 'w-full' }
                        >
                            ثبت امتیاز
                        </Button>
                    </Col>


                </Form>
            </Modal>
            </Spin>
        </TransitionsPage>
    );
};

export default Survey;
