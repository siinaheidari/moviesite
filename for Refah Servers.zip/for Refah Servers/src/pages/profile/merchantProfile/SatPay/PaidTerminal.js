import React, {useEffect, useRef, useState} from 'react';
import "../../../../index.scss"
import {Button, Col, Form, Row, Select, Spin} from "antd";
import {DateObject} from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import * as PropTypes from "prop-types";
import gregorian from "react-date-object/calendars/gregorian";
import {useRequest} from "../../../../utils/useRequest";
import {DatePicker, Modal, SelectBox, Table} from "../../../../templates/Ui";
import {inputRule} from "../../../../utils/helper";
import SvgIcon from "../../../../templates/components/SvgIcon";


function TransactionsListContainer(props) {
  return null;
}

TransactionsListContainer.propTypes = {
  gutter: PropTypes.arrayOf(PropTypes.number),
  children: PropTypes.node
};
const PaidTerminal = () => {

  const [filterFormRef] = Form.useForm();

  const tableRef = useRef();

  const [page, setPage] = useState(1);

  const [pageSize, setPageSize] = useState(10)

  const currentData = new DateObject({calendar: persian});

  const [startDate, setStartDate] = useState(currentData?.convert(gregorian)?.format('YYYY-MM-DD'))

  const [endDate, setEndDate] = useState(currentData?.convert(gregorian)?.format('YYYY-MM-DD'));



  const {isLoading, data, dataUpdatedAt} = useRequest({
    path: '/api/core/wallet/transaction-report',
    params: {
      pageNumber: page,
      pageIndex: pageSize,
      eDate: endDate,
      sDate: startDate,
    },
    options: {
      retry: false
    },
    key: ['cashFlow', page, startDate, endDate, pageSize],
  });

  const response = data?.output || [];

  const handleFilter = values => {
    setStartDate(values?.startDate);
    setEndDate(values?.endDate);
  }


  const tableColumns = [
    {
      title: 'شماره ترمینال',
      dataIndex: 'transactionDate',
      key: 'transactionDate',
      align: 'center',
    },
    {
      title: 'نام ترمینال',
      dataIndex: 'transactionType',
      key: 'transactionType',
      align: 'center',
    },

    {
      title: 'جمع مبلغ',
      dataIndex: 'transactionPrice',
      key: 'transactionPrice',
      align: 'center',
    },
    {
      title: 'علت عدم تسویه',
      dataIndex: 'rial',
      key: 'rial',
      align: 'center',
    },
  ];

  return (
    <div className={"cashback"}>
      <Form
        form={filterFormRef}
        name='indexFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleFilter}
      >
        <Row className='pt-8 bg-white rounded-lg'>
          <Col span={24} className='px-6'>
            <Row gutter={20} align={'middle'} justify={'space-between'}>
              <Col span={20}>
                <Row gutter={20}>
                  <Col span={8}>
                    <Row>
                      <img className={"ml-1"} src={"/images/purple.svg"}/>
                    <p>ترمینال‌های تسویه‌شده یک تاریخ مشخص</p>
                    </Row>
                  </Col>
                  <Col span={6}>
                    <DatePicker
                      name={'startDate'}
                      placeholder={'از تاریخ'}
                      hiddenLabel
                      initialValue={startDate}
                      dateFormat={'YYYY-MM-DD'}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required selectBox', {inputName: 'تاریخ '})
                        }
                      ]}
                    />
                  </Col>
                  <Col span={5}>
                    <DatePicker
                      name={'endDate'}
                      placeholder={'تا تاریخ'}
                      hiddenLabel
                      initialValue={endDate}
                      dateFormat={'YYYY-MM-DD'}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required selectBox', {inputName: 'تاریخ '})
                        }
                      ]}
                    />
                  </Col>
                  <Col span={5}>
                    <SelectBox
                      name="status"
                      placeholder="وضعیت تراکنش"
                      rules={[
                        {
                          required: true,
                          message: 'وضعیت تراکنش را انتخاب نمایید'
                        },
                      ]}
                      allowClear={false}
                    >
                      <Select.Option value={"all"}>همه</Select.Option>
                      <Select.Option value={'true'}>موفق</Select.Option>

                    </SelectBox>
                  </Col>
                </Row>
              </Col>

              <Col span={2.5} className='text-end pb-7'>
                <Button htmlType={'submit'} type={'default'}>
                  اعمال
                </Button>
              </Col>
            </Row>
          </Col>

          <Col span={24} className='__table' ref={tableRef}>
            <Table
              rowClassName={"cursor-pointer"}
              columns={tableColumns}
              className='my-form'
              dataSource={response}
              loading={isLoading}
              onChange={({current, pageSize}) => {
                setPage(current)
                setPageSize(pageSize)
              }}
              bordered
              tableLayout={'fixed'}
              pagination={{
                hideOnSinglePage: true,
                defaultPageSize: 10,
                total: 200,
                showSizeChanger: true,
                responsive: true,
                position: ['bottomLeft'],
                nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                   color={'#999999'}
                                   style={{margin: '6px auto'}}/>,
                prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                   color={'#999999'}
                                   style={{margin: '6px auto'}}/>,
                onChange: () => tableRef?.current.scrollIntoView({behavior: 'smooth'})
              }}
            />
          </Col>
        </Row>
      </Form>
    </div>

  );
};

export default PaidTerminal;