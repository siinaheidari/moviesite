import React, {useState} from 'react';
import {Button, Col, Form, Row} from "antd";
import {DatePicker} from "../../../../templates/Ui";
import {inputRule} from "../../../../utils/helper";
import {DateObject} from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import gregorian from "react-date-object/calendars/gregorian";
import {useRequest} from "../../../../utils/useRequest";

const DailyPaid = () => {

  const [filterFormRef] = Form.useForm();

  const [page, setPage] = useState(1);

  const [pageSize, setPageSize] = useState(10)

  const currentData = new DateObject({calendar: persian});

  const [startDate, setStartDate] = useState(currentData?.convert(gregorian)?.format('YYYY-MM-DD'))

  const [endDate, setEndDate] = useState(currentData?.convert(gregorian)?.format('YYYY-MM-DD'));


  const {isLoading, data, dataUpdatedAt} = useRequest({
    path: '/api/core/wallet/transaction-report',
    params: {
      pageNumber: page,
      pageIndex: pageSize,
      eDate: endDate,
      sDate: startDate,
    },
    options: {
      retry: false
    },
    key: ['cashFlow', page, startDate, endDate, pageSize],
  });


  const response = data?.output || [];

  const handleFilter = values => {
    setStartDate(values?.startDate);
    setEndDate(values?.endDate);
  }


  return (
    <div className={" rounded-lg"}>
      <Form
        form={filterFormRef}
        name='indexFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleFilter}
      >
        <Row className='px-8 pt-10 pb-14 bg-white rounded-lg'>
          <Col span={24} className='__filterSection'>
            <Row gutter={20} justify={"space-between"}>
              <Col span={12}>
                <Row>
                  <img className={"ml-1"} src={"/images/purple.svg"}/>
                  <p>گزارش تسویه روزانه کلی </p>
                </Row>

              </Col>
              <Col span={8}>
                <DatePicker
                  name={'endDate'}
                  placeholder={'تا تاریخ'}
                  hiddenLabel
                  initialValue={endDate}
                  dateFormat={'YYYY-MM-DD'}
                  rules={[
                    {
                      required: true,
                      message: inputRule('required selectBox', {inputName: 'تاریخ '})
                    }
                  ]}
                />
              </Col>
              <Col span={2.5} className='text-end pb-7'>
                <Button htmlType={'submit'} type={'default'} className={"!h-[42px]"}>
                  اعمال
                </Button>
              </Col>
            </Row>
          </Col>

          <Col span={24}>
            <Row gutter={[20,20]}>
              <Col span={8}>
                <div className={"bg-satPayback text-center items-center p-6 rounded-lg shadow-shadow"}>
                  <p className={"text-textblue"}>مبلغ کل ورودی (ریال)</p>
                  <p className={"my-4 text-[12px]"}>676735434343</p>
                </div>
              </Col>
              <Col span={8}>
                <div className={"bg-satPayback text-center items-center p-6 rounded-lg shadow-shadow"}>
                  <p className={"text-textblue"}>تعداد کل ترمینال های تراکنش‌ یافته</p>
                  <p className={"my-4 text-[12px]"}>676735434343</p>
                </div>
              </Col>
              <Col span={8}>
                <div className={"bg-satPayback text-center items-center p-6 rounded-lg shadow-shadow"}>
                  <p className={"text-textblue"}>تعداد کل ردیف تراکنش</p>
                  <p className={"my-4 text-[12px]"}>676735434343</p>
                </div>
              </Col>
              <Col span={8}>
                <div className={"bg-satPayback text-center items-center p-6 rounded-lg shadow-shadow"}>
                  <p className={"text-textblue"}>مبلغ کل تسویه</p>
                  <p className={"my-4 text-[12px]"}>676735434343</p>
                </div>
              </Col>
              <Col span={8}>
              <div className={"bg-satPayback text-center items-center p-6 rounded-lg shadow-shadow"}>
                <p className={"text-textblue"}>تعداد کل تراکنش‌های تسویه</p>
                <p className={"my-4 text-[12px]"}>676735434343</p>
              </div>
            </Col>
              <Col span={8}>
                <div className={"bg-satPayback text-center items-center p-6 rounded-lg shadow-shadow"}>
                  <p className={"text-textblue"}>موجودی بانک</p>
                  <p className={"my-4 text-[12px]"}>676735434343</p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>
    </div>
  );
};

export default DailyPaid;