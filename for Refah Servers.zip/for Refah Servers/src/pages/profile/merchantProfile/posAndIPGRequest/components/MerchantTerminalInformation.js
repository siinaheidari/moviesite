import { Col, Row, Select } from 'antd';
import { Checkbox, SelectBox, TextArea } from 'templates/Ui';
import { inputRule } from 'utils/helper';

const MerchantTerminalInformation = ({ formRef }) => {
  return (
    <Row gutter={ [16, 20] }>
      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <SelectBox
          name={ 'merchantCode' }
          label={ 'کد پذیرندگی' }
          rules={ [
            {
              required: true,
              message: inputRule('required selectBox', { inputName: 'کد پذیرندگی' })
            }
          ] }
        >
          <Select.Option value={ 545455454 }>545455454</Select.Option>
        </SelectBox>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <SelectBox
          name={ 'PSP' }
          label={ 'PSP' }
          rules={ [
            {
              required: true,
              message: inputRule('required selectBox', { inputName: 'PSP' })
            }
          ] }
        >
          <Select.Option value={ 333 }>33333</Select.Option>
        </SelectBox>
      </Col>
      
      <Col span={ 24 }>
        <Row gutter={ [16, 5] }>
          <Col xs={ 24 } md={ 12 }>
            <Checkbox
              name={ 'check1' }
              initialValue={ false }
            >
              امکان واریز تفکیکی وجوه (استفاده آتی)
            </Checkbox>
          </Col>
          
          <Col xs={ 24 } md={ 12 }>
            <Checkbox
              name={ 'check2' }
              initialValue={ false }
            >
              امکان برگشت وجه به دارنده کارت
            </Checkbox>
          </Col>
          
          <Col xs={ 24 } md={ 12 }>
            <Checkbox
              name={ 'check3' }
              initialValue={ false }
            >
              امکان پذیرش کارت اعتباری (استفاده آتی)
            </Checkbox>
          </Col>
          
          <Col xs={ 24 } md={ 12 }>
            <Checkbox
              name={ 'check4' }
              initialValue={ false }
            >
              امکان پدیرش کارت‌های سایر موسسات بین‌المللی
            </Checkbox>
          </Col>
          
          <Col xs={ 24 } md={ 12 }>
            <Checkbox
              name={ 'check5' }
              initialValue={ false }
            >
              امکان ارسال تراکنش خرید کالای ایرانی
            </Checkbox>
          </Col>
          
          <Col xs={ 24 } md={ 12 }>
            <Checkbox
              name={ 'check6' }
              initialValue={ false }
            >
              JCB امکان پذیرش کارت
            </Checkbox>
          </Col>
        </Row>
      </Col>
      
      <Col span={ 24 }>
        <TextArea
          name={ 'description' }
          label={ 'توضیحات' }
          rows={ 5 }
        />
      </Col>
    </Row>
  );
};

export default MerchantTerminalInformation;
