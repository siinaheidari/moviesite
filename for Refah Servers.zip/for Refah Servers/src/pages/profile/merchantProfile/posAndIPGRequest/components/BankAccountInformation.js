import { LoadingOutlined, UploadOutlined } from '@ant-design/icons';
import { Col, Form, message, Row, Select, Upload } from 'antd';
import { useState } from 'react';
import styled from 'styled-components';
import { Input, SelectBox } from 'templates/Ui';
import { inputRule } from 'utils/helper';
import { useRequest } from '../../../../../utils/useRequest';

const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
};

const BankAccountInformationContainer = styled(Row)`
  .--imageUpload {
    .ant-form-item {
      .ant-upload-select {
        border: 1px solid #C6D4FF !important;
        border-radius: 5px !important;
        background-color: #FFFFFF !important;
        height: 142px !important;
        width: 100% !important;
        margin: 0 !important;

        .ant-upload {
          display: block !important;

          .--uploadContent {
            height: 100%;

            .__topSection {
              align-self: center;
              height: calc(100% - 40px);

              .anticon {
                font-size: 2rem;
                margin-top: 30px;
                color: #21409A;

                &.anticon-upload {
                  font-size: 2.2rem;

                }
              }

              .--img {
                height: 100%;
                max-height: 100%;
                width: auto;
                max-width: 100%;
                display: inline-block;
              }
            }

            .__bottomSection {
              background-color: #1447A0;
              line-height: 40px;
              align-self: flex-end;
              color: #FFFFFF;
              font-size: .875rem;
              font-weight: 400;
            }
          }
        }
      }

      &.ant-form-item-has-error {
        .ant-upload-select {
          border-color: #ff4d4f !important;
        }
      }
    }
  }
`;

const BankAccountInformation = ({ formRef }) => {
  const [ uploadIsLoading, setUploadIsLoading ] = useState({
    identityCardImage: false,
    nationalCardFrontImage: false,
    nationalCardBackImage: false,
    confirmMohrImage: false,
    signinContractImage: false,
    rentalImage: false,
    certificateIssueImage: false,
    assasImage: false,
    newsPaperImage: false
  });
  
  const [ uploadImages, setUploadImages ] = useState({});
  
  const handleChangeUploadImage = (file, imageName) => {
    getBase64(file, (url) => {
      setUploadImages(current => ({
        ...current,
        [ imageName ]: url
      }));
    });
    return false;
  };
  
  const UploadButton = ({
    text,
    imageName
  }) => {
    return (
      <Row className="--uploadContent">
        <Col span={ 24 } className="__topSection text-center">
          { uploadImages[ imageName ] ? (
            <img src={ uploadImages[ imageName ] } className="--img"/>
          ) : (
            uploadIsLoading[ imageName ] ? <LoadingOutlined/> : <UploadOutlined/>
          ) }
        </Col>
        
        <Col span={ 24 } className="__bottomSection">
          { text }
        </Col>
      </Row>
    );
  };
  
  
  const {
    isLoading: terminalTypeLoading,
    data: terminalTypeData
  } = useRequest({
    path: '/setting/list-terminal-type',
    key: [ 'terminalType' ],
    apiType: 'club'
  });
  
  const terminalTypeRes = terminalTypeData || [];
  
  return (
    <BankAccountInformationContainer gutter={ [ 16, 5 ] }>
      
      <Col span={ 24 }>
        <Row gutter={ 20 }>
          <Col xs={ 24 } md={ 24 } lg={ 12 }>
            <SelectBox
              name={ 'terminalType' }
              label={ 'نوع پایانه درخواستی' }
              loading={ terminalTypeLoading }
              rules={ [
                {
                  required: true,
                  message: inputRule('required selectBox', { inputName: 'نوع پایانه درخواستی' })
                }
              ] }
            >
              
              {
                terminalTypeRes.map((item) =>
                  <Select.Option value={ item.rowId }>{ item.terminalTypeDesc }</Select.Option>
                )
              }
            
            </SelectBox>
          </Col>
          <Col xs={ 24 } md={ 24 } lg={ 12 }>
            <Input
              name={ 'branchCode' }
              label={ 'کد شعبه' }
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'کد شعبه' })
                }
              ] }
            />
          </Col>
        </Row>
      </Col>
      
      <Col xs={ 24 } md={ 9 } lg={ 8 }>
        <Input
          name={ 'accountNumber' }
          label={ 'شماره حساب' }
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'شماره حساب' })
            }
          ] }
          formRef={ formRef }
          justNumber
        />
      </Col>
      
      <Col xs={ 24 } md={ 10 } lg={ 12 }>
        <Input
          name={ 'accountIban' }
          label={ 'شماره شبا' }
          prefix={ 'IR - ' }
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'شماره شبا' })
            }
          ] }
          formRef={ formRef }
          justNumber
          ltr
          maxLength={ 24 }
        />
      </Col>
      
      <Col xs={ 24 } md={ 5 } lg={ 4 }>
        <Input
          name={ 'sharePercentage' }
          label={ 'درصد' }
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'درصد' })
            }
          ] }
          formRef={ formRef }
          justNumber
          ltr
        />
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'identityCardImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر شناسنامه' }),
              },
          ] }
        >
          <Upload
            name="identityCardImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'identityCardImage') }
          >
            <UploadButton text={ 'تصویر شناسنامه' } imageName={ 'identityCardImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'nationalCardFrontImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر روی کارت ملی' }),
              },
          ] }
        >
          <Upload
            name="nationalCardFrontImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'nationalCardFrontImage') }
          >
            <UploadButton text={ 'تصویر روی کارت ملی' } imageName={ 'nationalCardFrontImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'nationalCardBackImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر پشت کارت ملی' }),
              },
          ] }
        >
          <Upload
            name="nationalCardBackImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'nationalCardBackImage') }
          >
            <UploadButton text={ 'تصویر پشت کارت ملی' } imageName={ 'nationalCardBackImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'confirmMohrImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر مهر شده تاییدیه شبا' }),
              },
          ] }
        >
          <Upload
            name="confirmMohrImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'confirmMohrImage') }
          >
            <UploadButton text={ 'تصویر مهر شده تاییدیه شبا' } imageName={ 'confirmMohrImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'signinContractImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر قرارداد امضا شده توسط پذیرنده' }),
              },
          ] }
        >
          <Upload
            name="signinContractImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'signinContractImage') }
          >
            <UploadButton text={ 'تصویر قرارداد امضا شده توسط پذیرنده' } imageName={ 'signinContractImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'rentalImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر اجاره نامه یا سند' }),
              },
          ] }
        >
          <Upload
            name="rentalImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'rentalImage') }
          >
            <UploadButton text={ 'تصویر اجاره نامه یا سند' } imageName={ 'rentalImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'certificateIssueImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر جواز کسب' }),
              },
          ] }
        >
          <Upload
            name="certificateIssueImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'certificateIssueImage') }
          >
            <UploadButton text={ 'تصویر جواز کسب' } imageName={ 'certificateIssueImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'assasImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر اساس نامه' }),
              },
          ] }
        >
          <Upload
            name="assasImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'assasImage') }
          >
            <UploadButton text={ 'تصویر اساس نامه' } imageName={ 'assasImage' }/>
          </Upload>
        </Form.Item>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 } className="--imageUpload">
        <Form.Item
          name={ [ 'images', 'newsPaperImage' ] }
          rules={ [
              {
                  required: true,
                  message: inputRule('required upload', { inputName: 'تصویر روزنامه رسمی' }),
              },
          ] }
        >
          <Upload
            name="newsPaperImage"
            listType="picture-card"
            showUploadList={ false }
            accept={ '.png, .jpg, .jpeg' }
            beforeUpload={ file => handleChangeUploadImage(file, 'newsPaperImage') }
          >
            <UploadButton text={ 'تصویر روزنامه رسمی' } imageName={ 'newsPaperImage' }/>
          </Upload>
        </Form.Item>
      </Col>
    </BankAccountInformationContainer>
  );
};

export default BankAccountInformation;
