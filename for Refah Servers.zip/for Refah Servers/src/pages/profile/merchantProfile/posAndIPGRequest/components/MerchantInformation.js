import { Col, Form, Row, Select } from 'antd';
import { DatePicker, Input, SelectBox } from 'templates/Ui';
import { inputRule } from 'utils/helper';
import {useAuth} from "../../../../../contexts/auth/AuthContext";

const MerchantInformation = () => {
    const {auth} = useAuth()
  const formRef = Form.useFormInstance();
  console.log(auth)

  const nationalIdWatch = Form.useWatch('nationalId', formRef);
  
  const validaShenasnameh = (_, value) => {
    if (!!value?.serial && !!value?.char && value?.seri) {
      return Promise.resolve();
    }
    return Promise.reject(new Error(inputRule('required input', { inputName: 'سریال و سری شناسنامه' })));
  };
  
  const ShenasnamehInputs = ({ value = {}, onChange }) => {
    const triggerChange = (changedValue) => {
      onChange?.({
        ...value,
        ...changedValue
      });
    };
    
    const onSerialChange = (e) => {
      const serial = e.target.value;
      
      triggerChange({
        serial
      });
    };
    
    const onCharChange = char => {
      triggerChange({
        char
      });
    };
    
    const onSeriChange = e => {
      const seri = e.target.value;
      
      triggerChange({
        seri
      });
    };
    
    return (
      <Row gutter={ 11 }>
        <Col xs={ 10 } md={ 10 }>
          <Input
            placeholder={ 'سریال' }
            withoutForm
            value={ value.serial }
            onChange={ onSerialChange }
            allowClear={ false }
            // disabled={true}
            maxLength={ 6 }
          />
        </Col>
        
        <Col xs={ 7 } md={ 8 }>
          <SelectBox
            placeholder={ 'حرف' }

            onChange={ onCharChange}
            className={" !min-h-[47px]"}
            allowClear={ false }
            // disabled={true}
          >
            <Select.Option value={ 'الف' }>الف</Select.Option>
            <Select.Option value={ 'ب' }>ب</Select.Option>
            <Select.Option value={ 'پ' }>پ</Select.Option>
            <Select.Option value={ 'ت' }>ت</Select.Option>
            <Select.Option value={ 'ث' }>ث</Select.Option>
            <Select.Option value={ 'ج' }>ج</Select.Option>
            <Select.Option value={ 'چ' }>چ</Select.Option>
            <Select.Option value={ 'ح' }>ح</Select.Option>
            <Select.Option value={ 'خ' }>خ</Select.Option>
            <Select.Option value={ 'د' }>د</Select.Option>
            <Select.Option value={ 'ذ' }>ذ</Select.Option>
            <Select.Option value={ 'ر' }>ر</Select.Option>
            <Select.Option value={ 'ز' }>ز</Select.Option>
            <Select.Option value={ 'ژ' }>ژ</Select.Option>
            <Select.Option value={ 'س' }>س</Select.Option>
            <Select.Option value={ 'ش' }>ش</Select.Option>
            <Select.Option value={ 'ص' }>ص</Select.Option>
            <Select.Option value={ 'ض' }>ض</Select.Option>
            <Select.Option value={ 'ط' }>ط</Select.Option>
            <Select.Option value={ 'ظ' }>ظ</Select.Option>
            <Select.Option value={ 'ع' }>ع</Select.Option>
            <Select.Option value={ 'غ' }>غ</Select.Option>
            <Select.Option value={ 'ف' }>ف</Select.Option>
            <Select.Option value={ 'ق' }>ق</Select.Option>
            <Select.Option value={ 'ک' }>ک</Select.Option>
            <Select.Option value={ 'گ' }>گ</Select.Option>
            <Select.Option value={ 'ل' }>ل</Select.Option>
            <Select.Option value={ 'م' }>م</Select.Option>
            <Select.Option value={ 'ن' }>ن</Select.Option>
            <Select.Option value={ 'و' }>و</Select.Option>
            <Select.Option value={ 'ه' }>ه</Select.Option>
            <Select.Option value={ 'ی' }>ب</Select.Option>
          </SelectBox>
        </Col>
        
        <Col xs={ 7 } md={ 6 }>
          <Input
            placeholder={ 'عدد' }
            withoutForm
            value={ value.seri }
            onChange={ onSeriChange }
            allowClear={ false }
            // disabled={true}
            maxLength={ 6 }
          />
        </Col>
      </Row>
    );
  };

  return (
    <Row gutter={ [16, 5] }>
      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <Input
          name={ 'firstName' }
          initialValue={auth?.firstNameFa}
          placeholder={auth?.firstNameFa}
          label={ 'نام' }
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'نام' })
            }
          ] }
          allowClear={false}
          disabled={true}
          formRef={ formRef }
          className={" !min-h-[43px]"}
        />
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <Input
          name={ 'lastName' }
          label={ 'نام خانوادگی' }
          initialValue={auth?.lastNameFa}
          placeholder={auth?.lastNameFa}
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'نام خانوادگی' })
            }
          ] }
        allowClear={false}
          disabled={true}
          formRef={ formRef }
          className={" !min-h-[43px]"}
        />
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <Input
          name={ 'fatherName' }
          label={ 'نام پدر' }
          initialValue={auth?.fatherNameFa}
          placeholder={auth?.fatherNameFa}
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'نام پدر' })
            }
          ] }
          allowClear={false}
          disabled={true}
          formRef={ formRef }
          className={" !min-h-[43px]"}
        />
      </Col>


      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <SelectBox
          name={'gender'}
          label={'جنسیت'}
          placeholder={auth?.genderId===1?"مرد":"زن"}
          initialValue={auth?.genderId===1?"مرد":"زن"}
          disabled
          rules={[
            {
              required: true,
              message: inputRule('required selectBox', {inputName: 'جنسیت'})
            }
          ]}
        >
          <Select.Option value={1}>مرد</Select.Option>
          <Select.Option value={2}>زن</Select.Option>
        </SelectBox>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <SelectBox
          name={'nationality'}
          label={'ملیت'}
          rules={[
            {
              required: true,
              message: inputRule('required selectBox', {inputName: 'ملیت'})
            }
          ]}
        >
          <Select.Option value={"iranian"}>ایرانی</Select.Option>
          {/*<Select.Option  value={"foregn"}>خارجی</Select.Option>*/}
        </SelectBox>
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <Input
          name={ 'nationalId' }
          label={ 'کد ملی' }
          initialValue={auth?.nationalCode}
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'کد ملی' })
            },

          ] }
          formRef={ formRef }
          disabled={true}
          allowClear={false}
          className={" !min-h-[43px]"}
        />
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 8 }>
        <Input
          name={ 'shId' }
          label={ 'شماره شناسنامه' }
          rules={ [
            {
              required: true,
              message: inputRule('required input', { inputName: 'شماره شناسنامه' })
            }
          ] }
          className={" !min-h-[43px]"}
          formRef={ formRef }
          initialValue={auth?.ssn}
          placeholder={auth?.ssn}
          disabled={true}
          allowClear={false}
        />
      </Col>
      
      <Col xs={ 24 } md={ 12 } lg={ 12 }>
        <Form.Item
          label={ 'سریال و سری شناسنامه' }
          name={ 'sh' }
          rules={ [
            {
              validator: validaShenasnameh
            }
          ] }
        >
          <ShenasnamehInputs/>
        </Form.Item>
      </Col>
    </Row>
  );
};

export default MerchantInformation;
