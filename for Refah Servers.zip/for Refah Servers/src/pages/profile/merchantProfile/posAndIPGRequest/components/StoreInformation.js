import { Col, Form, Row, Select } from 'antd';
import { DatePicker, Input, SelectBox } from 'templates/Ui';
import { inputRule } from 'utils/helper';
import { useRequest } from '../../../../../utils/useRequest';
import React, { useState } from 'react';
import { Modal } from '../../../../../templates/Ui';


import AddPartnerModal from './storeInformationModal/AddPartnerModal';
import SignatureModal from './storeInformationModal/signaturModal';


const StoreInformation = () => {

    const formRef = Form.useFormInstance();
    const tradeWatch = Form.useWatch('businessCategoryCode', formRef);
    const [ storeModal, setStoreModal ] = useState('');

    const handleModals = (type) => {
        setStoreModal(type);
    };

    const {
        isLoading: merchantCategoryLoading,
        data: merchantCategoryData,
    } = useRequest({
        path: '/merchant/list-merchan-category',
        key: [ 'merchantCategory' ],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const merchantCategoryResponse = merchantCategoryData;
    console.log(merchantCategoryData);

    const {
        isLoading: merchantCategoryDetailLoading,
        data: merchantCategoryDetailData,
    } = useRequest({
        path: '/merchant/list-merchan-category-detail',
        params: {
            businessCategoryCode: tradeWatch,
        },
        key: [ 'merchantCategoryDetail', tradeWatch ],
        apiType: 'club',
        options: {
            enabled: !!tradeWatch,
            retry: false,
        },
    });
    const merchantCategoryDetail = merchantCategoryDetailData || [];
    console.log(merchantCategoryDetailData);


    const addPartner = (values) => {
        console.log(values);
    };


    return (
        <>
            <Row gutter={ [ 16, 5 ] }>
                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <Input
                        name={ 'farsiName' }
                        label={ 'نام فروشگاه (فارسی)' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'نام فروشگاه' }),
                            },
                        ] }
                        placeholder={ 'نام فروشگاه' }
                        justPersian
                    />
                </Col>

                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <Input
                        name={ 'englishName' }
                        label={ 'نام فروشگاه (انگلیسی)' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'نام فروشگاه' }),
                            },
                        ] }
                        placeholder={ 'store name' }
                        ltr
                        justEnglish
                        formRef={ formRef }

                    />
                </Col>

                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <Input
                        name={ 'telephoneNumber' }
                        label={ 'شماره تماس' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'شماره تماس' }),
                            },
                        ] }
                        ltr
                        justNumber
                        maxLength={ 11 }
                        formRef={ formRef }
                    />
                </Col>

                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <Input
                        name={ 'mobileNumber' }
                        label={ 'شماره همراه' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'شماره همراه' }),
                            },
                        ] }
                        validateType={ 'mobile' }
                        ltr
                        maxLength={ 11 }
                        formRef={ formRef }
                    />
                </Col>

                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <Input
                        name={ 'emailAddress' }
                        label={ 'پست الکترونیک' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'پست الکترونیک' }),
                            },
                        ] }
                        validateType={ 'email' }
                        ltr
                        formRef={ formRef }
                    />
                </Col>

                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <Input
                        name={ 'websiteAddress' }
                        label={ 'نشانی وبسایت' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required input', { inputName: 'نشانی وبسایت' }),
                            },
                            {
                                type: 'url',
                                message: inputRule(`URL invalid`, { inputName: 'نشانی وبسایت' }),
                            },
                        ] }
                        ltr
                    />
                </Col>


                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <SelectBox
                        name={ 'etrustCertificateType' }
                        label={ 'نوع نماد الکترونیکی' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'نوع نماد الکترونیکی' }),
                            },
                        ] }
                    >

                        <Select.Option value={ 0 }>بدون ستاره</Select.Option>
                        <Select.Option value={ 1 }>یک ستاره</Select.Option>
                        <Select.Option value={ 2 }>دو ستاره</Select.Option>

                    </SelectBox>
                </Col>

                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <DatePicker
                        name={ 'etrustCertificateIssueDate' }
                        label={ 'تاریخ شروع نماد الکترونیکی' }
                        // maxDate
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'تاریخ شروع نماد الکترونیکی' }),
                            },
                        ] }
                        formRef={ formRef }
                        ltr

                    />
                </Col>
                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <DatePicker
                        name={ 'etrustCertificateExpiryDate' }
                        label={ 'تاریخ پایان نماد الکترونیکی' }
                        // maxDate
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'تاریخ پایان نماد الکترونیکی' }),
                            },
                        ] }
                        formRef={ formRef }
                        ltr

                    />
                </Col>
                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <SelectBox
                        name={ 'businessCategoryCode' }
                        label={ 'گروه صنفی' }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'گروه صنفی' }),
                            },
                        ] }
                    >{
                        merchantCategoryResponse?.map(item => (
                            <Select.Option
                                value={ item?.businessCategoryCode }>{ item?.businessCategoryName }</Select.Option>
                        ))
                    }

                    </SelectBox>
                </Col>


                <Col xs={ 24 } md={ 12 } lg={ 9 }>
                    <SelectBox
                        name={ 'businessSubCategoryCode' }
                        label={ 'صنف' }
                        loading={ merchantCategoryLoading }
                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'صنف' }),
                            },
                        ] }
                    >
                        {
                            merchantCategoryDetail?.map(item => (
                                <Select.Option
                                    value={ item?.businessCategoryDetailCode }>{ item?.businessCategoryDetailName }</Select.Option>
                            ))
                        }

                    </SelectBox>
                </Col>

                <Col xs={ 24 } md={ 12 } lg={ 8 }>
                    <DatePicker
                        name={ 'certificateIssueDate' }
                        label={ 'تاریخ شروع جواز کسب' }

                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'تاریخ پایان جواز کسب' }),
                            },
                        ] }
                        formRef={ formRef }
                        ltr

                    />
                </Col>
                <Col xs={ 24 } md={ 12 } lg={ 9 }>
                    <DatePicker
                        name={ 'certificateExpiryDate' }
                        label={ 'تاریخ پایان جواز کسب' }

                        rules={ [
                            {
                                required: true,
                                message: inputRule('required selectBox', { inputName: 'تاریخ پایان جواز کسب' }),
                            },
                        ] }
                        formRef={ formRef }
                        ltr

                    />
                </Col>

                <Modal
                    open={ storeModal === 'addPartner' }
                    onCancel={ () => handleModals('') }
                    size={ {
                        sm: 90,
                        xs: 90,
                        md: 90,
                        lg: 90,
                        xl: 55,
                        xxl: 55,
                    } }

                    bodyStyle={ {
                        padding: 0,

                    } }
                    style={ {
                        top: '5vh',
                    } }
                >
                    <div className={ ' bg-white' }>
                        <AddPartnerModal/>
                    </div>
                </Modal>
                <Modal
                    open={ storeModal === 'addSignature' }
                    onCancel={ () => handleModals('') }
                    size={ {
                        sm: 90,
                        xs: 90,
                        md: 90,
                        lg: 55,
                        xl: 55,
                        xxl: 55,
                    } }
                    bodyStyle={ {
                        padding: 0,
                    } }
                    style={ {
                        top: '5vh',
                    } }
                >
                    <SignatureModal/>
                </Modal>


            </Row>


            {/*<div className={"flex gap-3 max-lg:!text-[12px] mb-[10px] max-lg:mt-[30px] flex-wrap"}>*/ }
            {/*    <div onClick={()=>handleModals("addPartner")} className={"flex gap-1 items-center  cursor-pointer"}>*/ }
            {/*        <img src={"/images/plusicon.svg"}/>*/ }
            {/*        <p className={"text-textblue"}>اضافه کردن شرکا</p>*/ }
            {/*    </div>*/ }
            {/*    <div className={"flex gap-2 text-center max-lg:!text-[12px]"}>*/ }
            {/*        <p*/ }
            {/*           className={" py-1 w-[74px] text-[#F61982] border border-[#F61982] rounded-lg text-[12px] cursor-pointer"}>شریک*/ }
            {/*            اول</p>*/ }
            {/*        <p className={"py-1 w-[74px] text-[#F61982] border border-[#F61982] rounded-lg text-[12px]"}>شریک*/ }
            {/*            دوم</p>*/ }
            {/*    </div>*/ }
            {/*</div>*/ }

            {/*<div className={"flex gap-3 max-lg:!text-[12px] mb-[10px]  flex-wrap"}>*/ }
            {/*    <div onClick={()=>handleModals("addSignature")} className={"flex gap-1 items-center cursor-pointer"}>*/ }
            {/*        <img src={"/images/plusicon.svg"}/>*/ }
            {/*        <p className={"text-textblue"}> اضافه کردن امضا کنندگان</p>*/ }
            {/*    </div>*/ }
            {/*    <div className={"flex gap-3 text-center max-lg:!text-[12px]"}>*/ }
            {/*        <p*/ }
            {/*           className={" py-1 w-[84px] text-[#F61982] border border-[#F61982] rounded-lg text-[12px] cursor-pointer"}>امضا*/ }
            {/*            کننده*/ }
            {/*            اول</p>*/ }
            {/*    </div>*/ }

            {/*</div>*/ }
        </>
    );
};

export default StoreInformation;
