
import { Col, Form, Row, Select } from 'antd';
import { DatePicker, Input, SelectBox } from 'templates/Ui';
import { inputRule } from 'utils/helper';
import { useRequest } from '../../../../../utils/useRequest';

const PropertyInformation = () => {

    const formRef = Form.useFormInstance();
    const countryWatch = Form.useWatch('country', formRef);
    const stateWatch = Form.useWatch('state', formRef);
    const cityWatch = Form.useWatch('city', formRef);
    const ownershipType = Form.useWatch('ownershipType', formRef);

    console.log(ownershipType?.toString() === '0');

    const {
        isLoading: ownershipLoading,
        data: ownershipData,
    } = useRequest({
        path: '/merchant/list-ownership-type',
        key: [ 'ownership' ],
        apiType: 'club',
    });
    const ownershipRes = ownershipData || [];
    console.log(ownershipData);





    // const {
    //     isLoading: countryLoading,
    //     data: countryData,
    // } = useRequest({
    //     path: 'setting/location-list-country',
    //     key: [ 'country' ],
    //     // apiType: 'club',
    // });
    // const countryRes = countryData || [];
    //


    const {
        isLoading: stateLoading,
        data: stateData,
    } = useRequest({
        path: '/services/general/state-list',
        key: [ 'stateList' ],
        body: {
            pageNumber: 1,
            rowPage: 100,
        },
        method: 'POST',
        apiType: 'merchant',
    });

    const stateDataRes = stateData || [];

    console.log(stateWatch);




    const {
        isLoading: cityLoading,
        data: cityData,
    } = useRequest({
        path: '/services/general/city-list',
        key: [ 'cityList', stateWatch],

        body: {
            pageNumber: 1,
            rowPage: 100,
            stateCode:stateWatch
        },
        method: 'POST',
        apiType: 'merchant',
        options:{
            enabled: !!stateWatch
        }
    });

    const cityDataRes = cityData || [];






    const {
        isLoading: areaLoading,
        data: areaData,
    } = useRequest({
        path: '/services/general/area-list',
        key: [ 'area', cityWatch],

        body: {
            pageNumber: 1,
            rowPage: 100,
            cityCode:cityWatch
        },
        method: 'POST',
        apiType: 'merchant',
        options:{
            enabled: !!cityWatch
        }
    });

    const areaDataRes = areaData || [];




    return (
        <Row gutter={ [ 16, 5 ] }>
            <Col xs={ 24 } md={ 12 } lg={ 6 }>
                <SelectBox
                    name={ 'ownershipType' }
                    label={ 'نوع ملک' }
                    loading={ ownershipLoading }
                    rules={ [
                        {
                            required: true,
                            message: inputRule('required selectBox', { inputName: 'نوع ملک' }),
                        },
                    ] }
                    onChange={ val => {
                        if (val === 0) {
                            formRef.setFields([
                                {
                                    name: 'rentalExpiryDate',
                                    value: null,
                                    errors: [],
                                },
                            ]);
                        }
                    } }
                >
                    {
                        ownershipRes.map((item) =>
                            <Select.Option value={ item.ownershipTypeID }>{ item.ownershipTypeDesc }</Select.Option>,
                        )
                    }
                </SelectBox>
            </Col>

            <Col xs={ 24 } md={ 12 } lg={ 6 }>
                <DatePicker
                    name={ 'rentalExpiryDate' }
                    label={ 'تاریخ پایان قرارداد اجاره' }

                    rules={ [
                        {
                            required: ownershipType?.toString() === '0' ? false : true,
                            message: inputRule('required input', { inputName: 'تاریخ پایان قرارداد اجاره' }),
                        },
                    ] }
                    formRef={ formRef }
                    ltr
                    disabled={ ownershipType === 0 ? true : false }
                />
            </Col>
            <Col xs={ 24 } md={ 12 } lg={ 6 }>
                <Input
                    name={ 'rentalContractNumber' }
                    label={ 'کد قرارداد اجاره' }
                    minDate
                    rules={ [
                        {
                            required: ownershipType?.toString() === '0' ? false : true,
                            message: inputRule('required input', { inputName: 'کد قرارداد اجاره' }),
                        },
                    ] }
                    formRef={ formRef }
                    ltr
                    disabled={ ownershipType === 0 ? true : false }
                />
            </Col>

            <Col xs={ 24 } md={ 8 } lg={ 6 }>
                <Input
                    name={ 'taxCode' }
                    label={ 'کد مالیاتی' }
                    rules={ [
                        {
                            required: true,
                            message: inputRule('required input', { inputName: 'کد مالیاتی' }),
                        },
                    ] }
                    formRef={ formRef }
                    justNumber
                    maxLength={ 12 }
                    ltr
                />
            </Col>

            <Col xs={ 24 } md={ 8 } lg={ 6 }>
                <SelectBox
                    name={ 'countryCode' }
                    label={ 'کشور' }

                    rules={ [
                        {
                            required: true,
                            message: inputRule('required selectBox', { inputName: 'کشور' }),
                        },
                    ] }
                >


                            <Select.Option value={ 1 }>ایران</Select.Option>,


                </SelectBox>
            </Col>

            <Col xs={ 24 } md={ 8 } lg={ 6 }>
                <SelectBox
                    name={ 'state' }
                    label={ 'استان' }
                    loading={ stateLoading }
                    rules={ [
                        {
                            required: true,
                            message: inputRule('required selectBox', { inputName: 'استان' }),
                        },
                    ] }
                >
                    {
                        stateDataRes.map((item) =>
                            <Select.Option value={ item.StateCode }>{ item.StateName }</Select.Option>,
                        )
                    }

                </SelectBox>
            </Col>

            <Col xs={ 24 } md={ 8 } lg={ 6 }>
                <SelectBox
                    name={ 'city' }
                    label={ 'شهر' }
                    loading={ cityLoading }
                    rules={ [
                        {
                            required: true,
                            message: inputRule('required selectBox', { inputName: 'شهر' }),
                        },
                    ] }
                >
                    {
                        cityDataRes.map((item) =>
                            <Select.Option value={ item.CityCode }>{ item.CityName }</Select.Option>,
                        )
                    }
                </SelectBox>
            </Col>

            <Col xs={ 24 } md={ 8 } lg={ 6 }>
                <SelectBox
                    name={ 'areaId' }
                    label={ 'شهرستان' }
                    loading={ areaLoading }
                    rules={ [
                        {
                            required: true,
                            message: inputRule('required selectBox', { inputName: 'شهر' }),
                        },
                    ] }
                >
                    {
                        areaDataRes.map((item) =>
                            <Select.Option value={ item.AreaNumber }>{ item.AreaName }</Select.Option>,
                        )
                    }
                </SelectBox>
            </Col>

            <Col xs={ 24 } md={ 12 } lg={ 8 }>
                <Input
                    name={ 'postalCode' }
                    label={ 'کد پستی' }
                    rules={ [
                        {
                            required: true,
                            message: inputRule('required input', { inputName: 'کد پستی' }),
                        },
                    ] }
                    formRef={ formRef }
                    justNumber
                    maxLength={ 10 }
                    ltr
                />
            </Col>
            <Col xs={ 24 } md={ 12 } lg={ 16 }>
                <Input
                    name={ 'Address' }
                    label={ 'آدرس' }
                    rules={ [
                        {
                            required: true,
                            message: inputRule('required input', { inputName: 'آدرس' }),
                        },
                    ] }
                />
            </Col>


        </Row>
    );
};

export default PropertyInformation;
