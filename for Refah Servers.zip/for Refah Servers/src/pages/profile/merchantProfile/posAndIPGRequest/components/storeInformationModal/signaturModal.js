import React from 'react';
import {Col, Form, Row, Select} from "antd";
import {Button, DatePicker, Input, SelectBox, TextArea} from "../../../../../../templates/Ui";
import {inputRule} from "../../../../../../utils/helper";
import facilities from "../../../../../../assets/images/facilities.svg";

const SignatureModal = () => {

    const [signatureFormRef] = Form.useForm();
    const nationality2 = Form.useWatch("nationality2", signatureFormRef)
    const handleSignature=(value)=>{
        console.log(value)
    }


    const validaShenasnameh = (_, value) => {
        if (!!value?.serial && !!value?.char && value?.seri) {
            return Promise.resolve();
        }
        return Promise.reject(new Error(inputRule('required input', {inputName: 'سریال و سری شناسنامه'})));
    };

    const ShenasnamehInputs = ({value = {}, onChange}) => {
        const triggerChange = (changedValue) => {
            onChange?.({
                ...value,
                ...changedValue
            });
        };

        const onSerialChange = (e) => {
            const serial = e.target.value;

            triggerChange({
                serial
            });
        };

        const onCharChange = char => {
            triggerChange({
                char
            });
        };

        const onSeriChange = e => {
            const seri = e.target.value;

            triggerChange({
                seri
            });
        };

        return (
            <Row gutter={8}>
                <Col xs={10} md={8}>
                    <Input
                        placeholder={'سریال'}
                        withoutForm
                        value={value.serial}
                        onChange={onSerialChange}
                        allowClear={false}
                        maxLength={6}
                    />
                </Col>

                <Col xs={7} md={8}>
                    <SelectBox
                        placeholder={'حرف'}
                        withoutForm
                        onChange={onCharChange}
                        allowClear={false}
                    >
                        <Select.Option value={'الف'}>الف</Select.Option>
                        <Select.Option value={'ب'}>ب</Select.Option>
                    </SelectBox>
                </Col>

                <Col xs={7} md={8}>
                    <Input
                        placeholder={'عدد'}
                        withoutForm
                        value={value.seri}
                        onChange={onSeriChange}
                        allowClear={false}
                        maxLength={6}
                    />
                </Col>
            </Row>
        );
    }

    return (
        <div className={" max-lg:px-[18px] "}>
            <div className={"relative top-[-1px] "}>
                <img src={facilities} className={"mx-auto "}/>
                <div className={"relative text-white top-[-27px] mx-auto text-center items-center text-[12px]"}>
                    اضافه کردن امضا کنندگان
                </div>
            </div>
            <div className={"lg:px-[5rem] py-4"}>
                <Form
                    form={signatureFormRef}
                    name='partnerForm'
                    autoComplete='off'
                    scrollToFirstError
                    labelCol={{
                        span: 24
                    }}
                    wrapperCol={{
                        span: 24
                    }}
                    onFinish={handleSignature}
                >
                    <Row gutter={[20, 5]}>
                        <Col xs={24} md={12} lg={8}>
                            <Input
                                name={'name2'}
                                label={'نام'}
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: ''})
                                    }
                                ]}
                                formRef={signatureFormRef}
                                ltr
                                focus
                            />
                        </Col>
                        <Col xs={24} md={12} lg={8}>
                            <Input
                                name={'lastName2'}
                                label={'نام خانوادگی'}
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: ''})
                                    }
                                ]}
                                formRef={signatureFormRef}
                                focus
                            />
                        </Col>
                        <Col xs={24} md={12} lg={8}>
                            <Input
                                name={'fatherName2'}
                                label={'نام پدر'}
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'نام پدر'})
                                    }
                                ]}
                                formRef={signatureFormRef}
                                focus
                            />
                        </Col>
                        <Col xs={24} md={12} lg={8}>
                            <SelectBox
                                name="gender2"
                                label="جنسیت"
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required selectBox', {inputName: 'جنسیت'})
                                    },
                                ]}
                                allowClear
                            >
                                <Select.Option value={"male"}>مرد</Select.Option>
                                <Select.Option value={"female"}>زن</Select.Option>
                            </SelectBox>
                        </Col>
                        <Col xs={24} md={12} lg={8}>
                            <DatePicker
                                name='birthDate2'
                                label='تاریخ تولد'
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required selectBox', {inputName: 'تاریخ تولد'})
                                    }
                                ]}
                                maxDate={true}
                                formRef={signatureFormRef}
                                ltr
                            />
                        </Col>
                        <Col xs={24} md={12} lg={8}>
                            <SelectBox
                                name={'nationality2'}
                                label={'ملیت'}
                                initialValue={1}
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required selectBox', {inputName: 'ملیت'})
                                    }
                                ]}
                            >
                                <Select.Option value={1}>ایرانی</Select.Option>
                                <Select.Option value={2}>خارجی</Select.Option>
                            </SelectBox>
                        </Col>

                            <Col xs={24} md={12} lg={8}>
                                <Input
                                    name={'nationalCode2'}
                                    label={nationality2!==1?'کد اتباع':"کد ملی"}
                                    noPlaceHolder
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: ''})
                                        }
                                    ]}
                                    formRef={signatureFormRef}
                                    ltr
                                    focus
                                />
                            </Col>

                            <Col xs={24} md={12} lg={7}>
                                <Input
                                    name={'shId2'}
                                    label={'شماره شناسنامه'}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'شماره شناسنامه'})
                                        }
                                    ]}
                                    justNumber
                                    ltr
                                />
                            </Col>

                            <Col xs={24} md={24} lg={9}>
                                <Form.Item
                                    label={'سریال و سری شناسنامه'}
                                    name={'sh2'}
                                    rules={[
                                        {
                                            validator: signatureFormRef
                                        }
                                    ]}
                                >
                                    <ShenasnamehInputs/>
                                </Form.Item>
                            </Col>
                            <Col xs={24} md={12} lg={8}>
                                <SelectBox
                                    name={'merchantType2'}
                                    label={'نوع مشتری'}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required selectBox', {inputName: 'نوع مشتری'})
                                        }
                                    ]}
                                >
                                    <Select.Option value={1}>حقیقی</Select.Option>
                                    <Select.Option value={2}>حقوقی</Select.Option>
                                </SelectBox>
                            </Col>
                            <Col xs={24} md={12} lg={8}>
                                <SelectBox
                                    name={'country2'}
                                    label={'کشور'}
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required selectBox', {inputName: 'کشور'})
                                        }
                                    ]}
                                >
                                    <Select.Option value={1}>ایران</Select.Option>
                                    <Select.Option value={2}>امارات</Select.Option>
                                </SelectBox>
                            </Col>
                            <Col xs={24} md={12} lg={8}>
                                <Input
                                    name={'passportCode2'}
                                    label={'شماره گذرنامه (اختیاری)'}
                                    noPlaceHolder
                                    formRef={signatureFormRef}
                                    ltr
                                    focus
                                />
                            </Col>
                            <Col xs={24} md={12} lg={8}>
                                <DatePicker
                                    name='birthDate2'
                                    label='تاریخ انقضای گذرنامه (اختیاری)'
                                    noPlaceHolder
                                    maxDate={true}
                                    formRef={signatureFormRef}
                                    ltr
                                />
                            </Col>
                            <Col xs={24} md={24} lg={24}>
                                <TextArea
                                    name={'description2'}
                                    label={'توضیحات'}
                                    noPlaceHolder
                                    formRef={signatureFormRef}
                                    ltr
                                    focus
                                />
                            </Col>

                        <Col xs={24} sm={10} lg={12} className={"mx-auto mt-8 mb-[20px]"}>

                            <Button htmlType={"submit"} className={"w-full mx-auto"} type={"secondary"}>ذخیره</Button>

                        </Col>
                    </Row>
                </Form>
            </div>
        </div>
    );
};

export default SignatureModal;
