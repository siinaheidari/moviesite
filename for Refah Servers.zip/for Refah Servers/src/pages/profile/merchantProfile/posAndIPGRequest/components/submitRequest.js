import React from 'react';
import done from "assets/icons/done.svg"
import {Col, Row} from "antd";
import {Link} from "react-router-dom";

const SubmitRequest = () => {
    return (
        <Row>
            <Col span={24} className={"items-center text-center space-y-[20px]"}>
                <img src={done} className={"inline"}/>
                <div className={"text-[14px] max-lg:text-[12px] text-title font-[400] "}>
                    درخواست شما با موفقیت انجام شده است،
                </div>

                <Link to={"/merchantProfile"} className={"border-1 border-solid bg-textblue !text-white p-2 rounded-[10px]"}>بازگشت به صفحه
                    اصلی</Link>
            </Col>

        </Row>
    );
};

export default SubmitRequest;
