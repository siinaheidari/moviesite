import { LeftOutlined, RightOutlined } from '@ant-design/icons';
import { Col, Form, Popover, Row, Space, Spin, Steps } from 'antd';
import { ReactComponent as CaretRight } from 'assets/icons/caretRight.svg';
import { AnimatePresence, motion } from 'framer-motion';
import React, { useState } from 'react';
import styled from 'styled-components';
import TitleByCircle from 'templates/components/TitleByCircle';
import { Button } from 'templates/Ui';

// steps component
import MerchantInformation from 'pages/profile/merchantProfile/posAndIPGRequest/components/MerchantInformation';
import StoreInformation from 'pages/profile/merchantProfile/posAndIPGRequest/components/StoreInformation';
import PropertyInformation from 'pages/profile/merchantProfile/posAndIPGRequest/components/PropertyInformation';
import BankAccountInformation from 'pages/profile/merchantProfile/posAndIPGRequest/components/BankAccountInformation';
import { useRequest } from '../../../../utils/useRequest';
import { Link } from 'react-router-dom';
import rightArrow from '../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../assets/icons/mobile/circle.svg';
import SubmitRequest from './components/submitRequest';

const PosAndIPGRequestContainer = styled(Row)`

  .--step.--desktop {
    background-color: #F9F9F9;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    border-radius: 10px;
    padding: 19px 30px;

    .ant-steps {
      padding-inline-end: 20px;

      .ant-steps-item {
        .ant-steps-item-container {
          display: inline-block;
          position: relative;

          .ant-steps-item-tail {
            display: none;
            background: linear-gradient(89.94deg, #FE2301 0.04%, #FE2301 97.19%);
            border-radius: 15px 15px 0 0;
            height: 5px;
            width: 100%;
            position: absolute;
            inset-block-start: 36px;
            margin: 0;

            :after {
              display: none;
            }
          }

          .ant-steps-item-icon {
            display: none;
            position: absolute;
            inset-inline-end: -22px;
            inset-block-start: 3px;
            margin: 0;
            width: 15px;
            height: 15px;
          }

          .ant-steps-item-content {
            margin: 0;
            width: auto;

            .ant-steps-item-title {
              color: #787878;
              font-weight: 500;
              font-size: .875rem;
            }
          }
        }

        &.ant-steps-item-process {
          .ant-steps-item-container {
            .ant-steps-item-tail {
              display: block;
            }

            .ant-steps-item-icon {
              display: inline-block;
            }

            .ant-steps-item-title {
              color: #21409A;
            }
          }
        }
      }
    }
  }

  .--step.--mobile {
    .ant-steps {
      .ant-steps-item {
        padding: 0 !important;

        .ant-steps-item-icon {
          margin: 0;
          background-color: #D6D6D6;
          border-color: #D6D6D6;
          border-width: 4px;


          .ant-steps-icon {
            font-size: 0 !important;

            .anticon {
              font-size: 14px !important;
              color: #FFF;
            }
          }
        }

        .ant-steps-item-content {
          & > .ant-steps-item-title {
            font-size: 0 !important;
            padding: 0;

            :after {
              height: 5px;
              top: 10px;
              background-color: #D6D6D6;
            }
          }
        }


        &.ant-steps-item-active {
          .ant-steps-item-icon {
            background-color: #FE2301;
          }
        }

        &.ant-steps-item-finish {
          .ant-steps-item-icon {
            border-color: #FE2301;
            background-color: #FE2301;
          }

          .ant-steps-item-content {
            & > .ant-steps-item-title {
              :after {
                background-color: #FE2301;
              }
            }
          }
        }
      }
    }
  }

  .--stepContent2 {
    background-color: #FFFFFF;
    box-shadow: 0 4px 10px rgba(122, 122, 122, 0.1);
    border-radius: 10px;
    padding: 34px 63px 65px;

  }
`;

const PosAndIPGRequest = () => {
    const [ requestFormRef ] = Form.useForm();

    const { NODE_ENV } = process.env;

    const [ currentStep, setCurrentStep ] = useState(0);

    const stepsItem = [
        {
            key: 0,
            title: 'اطلاعات شخص پذیرنده',

            content: <MerchantInformation formRef={ requestFormRef }/>,
        },
        {
            key: 1,
            title: 'اطلاعات فروشگاه',
            content: <StoreInformation formRef={ requestFormRef }/>,
        },
        {
            key: 2,
            title: 'اطلاعات ملک',
            content: <PropertyInformation formRef={ requestFormRef }/>,
        },
        {
            key: 3,
            title: 'حساب بانکی و مدارک',
            content: <BankAccountInformation formRef={ requestFormRef }/>,

        },
        {
            key: 4,
            title: 'ثبت نهایی',
            content: <SubmitRequest formRef={ requestFormRef }/>,
        },
    ];

    const customDot = () => (
        <Popover content={ null } open={ false }>
            <CaretRight/>
        </Popover>
    );

    const currentStepData = stepsItem?.find(item => item?.key === currentStep);

    const handlePrevStep = () => setCurrentStep(prev => prev - 1);


    const {
        mutateAsync: createShopRequest,
        isLoading: createShopRequestLoading,
    } = useRequest({
        path: '/merchant/insert-terminal',
        isMutation: true,
        apiType: 'club',
    });


    const {
        mutateAsync: updateTerminalRequest,
        isLoading: updateTerminalRequestLoading,
    } = useRequest({
        path: '/merchant/update-terminal',
        mutationMethod: 'PATCH',
        isMutation: true,
        apiType: 'club',
    });
    
    const {
        mutateAsync: uploadFileRequest,
        isLoading: uploadFileIsLoading,
    } = useRequest({
        path: `/merchant/uploader-files/${requestFormRef?.getFieldValue('rowId')}`,
        isMutation: true,
        apiType: 'club',
        formType: 0
    });

    const handleNextStep = async () => {
        try {
            await requestFormRef?.validateFields();
            if (currentStep === 1) {
                const formData = await requestFormRef.getFieldsValue(true);

                const createShopRequestRes = await createShopRequest({
                    farsiName: formData?.farsiName,
                    englishName: formData?.englishName,
                    telephoneNumber: formData?.telephoneNumber,
                    mobile: +(formData?.mobileNumber),
                    businessCategoryCode: formData.businessCategoryCode,
                    businessSubCategoryCode: formData?.businessSubCategoryCode,
                });

                await requestFormRef?.setFields([
                    {
                        name: 'rowId',
                        value: createShopRequestRes?.output[0]?.rowId,
                    },
                ]);
                
                console.log('createShopRequestRes >>>', createShopRequestRes);

                await setCurrentStep(prev => prev + 1); // go to next step

            }
            else if (currentStep === 3) {
                await handleRequestPos();
                await handleUploadImages();
                await setCurrentStep(prev => prev + 1); // go to next step
            }
            else {
                await setCurrentStep(prev => prev + 1); // go to next step
            }
        }
        catch (error) {
            console.log('error in handleNextStep >>>', error);
        }
    };
    
    const handleUploadImages = async () => {
        try {
            const images = requestFormRef?.getFieldValue(['images']);
            const formData = new FormData();
            
            await Object.entries(images)?.forEach(([key, image]) => {
                formData.append(key, image?.file);
            });
            
            const res = await uploadFileRequest(formData);
    
            console.log('ressssss >>>>>', res);
        }
        catch (error) {
            console.log('error in handleUploadImages >>>>>', error);
        }
    }
    
    const handleRequestPos = async () => {
        try {
            const formData = requestFormRef.getFieldsValue(true);
            await updateTerminalRequest(formData);
        }
        catch (error) {
            console.log('error in handleRequestPos >>>', error);
        }
    }

    return (
        <PosAndIPGRequestContainer gutter={ [ 0, 12 ] }>
            <Col span={ 24 } className="--step --desktop max-lg:hidden">
                <Steps
                    current={ currentStep }
                    progressDot={ customDot }
                    items={ stepsItem }
                />
            </Col>
            
            <Col span={ 24 } className={ 'mb-[13px] lg:hidden' }>
                <Link to={ -1 } className={ '' }> <img src={ rightArrow }/></Link>
            </Col>

            <div className={ 'flex mb-[17px] lg:hidden justify-between items-center' }>
                <Space align={ 'center' } className={ 'text-[12px] font-[500] ' }>
                    <img src={ circle }/>
                    {
                        currentStep === 0 ? 'اطلاعات شخص پذیرنده' :
                            currentStep === 1 ? 'اطلاعات فروشگاه' :
                                currentStep === 2 ? 'اطلاعات ملک' :
                                    currentStep === 3 ? 'حساب بانکی و مدارک' : ''
                    }

                </Space>
            </div>

            <Col span={ 24 } className={ '--step --mobile lg:hidden bg-white p-[14px] rounded-[10px]' }>
                <Steps
                    current={ currentStep }
                    items={ stepsItem }
                    responsive={ false }
                    size={ 'small' }

                />
            </Col>

            <Col span={ 24 }
                 className="--stepContent bg-white lg:px-[63px] max-lg:px-[18px] pt-[34px] pb-[60px] rounded-[10px]">
                <Row gutter={ [ 0, 35 ] }>
                    <Col span={ 24 } className="__breadcrumb max-lg:hidden">
                        <TitleByCircle text={ currentStepData?.title }/>
                    </Col>

                    <Col span={ 24 }>
                        <Spin spinning={ createShopRequestLoading || updateTerminalRequestLoading || uploadFileIsLoading }>
                            <Form
                                form={ requestFormRef }
                                autoComplete="off"
                                labelCol={ {
                                    span: 24,
                                } }
                                wrapperCol={ {
                                    span: 24,
                                } }
                                scrollToFirstError
                            >
                                <Row gutter={ [ 0, 24 ] }>
                                    <Col span={ 24 } className="__formContent">
                                        <AnimatePresence mode={ 'wait' }>
                                            <motion.div
                                                key={ currentStep || 'emptyCreateApi' }
                                                initial={ {
                                                    x: 70,
                                                    opacity: 0,
                                                } }
                                                animate={ {
                                                    x: 0,
                                                    opacity: 1,
                                                } }
                                                exit={ {
                                                    x: -70,
                                                    opacity: 0,
                                                } }
                                                transition={ { duration: 0.3 } }
                                            >
                                                { currentStepData?.content }
                                            </motion.div>
                                        </AnimatePresence>
                                    </Col>

                                    <Col span={ 24 } className={ 'mt-[30px] items-end text-end' }>
                                        <Row gutter={ 18 } justify={ 'end' }>
                                            <Col lg={ 8 } xs={ 12 }>
                                                { (currentStep > 0 && currentStep !== stepsItem?.length - 1 && currentStep !== stepsItem?.length - 2) &&
                                                    <Button
                                                        type={ 'default' }
                                                        onClick={ handlePrevStep }
                                                        className={ 'w-full max-lg:w-full text-[12px]' }
                                                    >
                                                        <RightOutlined/>
                                                        مرحله قبل
                                                    </Button>
                                                }
                                            </Col>

                                            <Col lg={ 8 } xs={ 12 }>
                                                { (currentStep < stepsItem?.length - 1) &&
                                                    <Button
                                                        type={ 'secondary' }
                                                        iconAlign={ 'end' }
                                                        onClick={ handleNextStep }
                                                        className={ 'w-full max-lg:w-full text-[12px]' }
                                                    >
                                                        <LeftOutlined/>
                                                        ذخیره و ادامه
                                                    </Button>
                                                }
                                            </Col>
                                            

                                        </Row>
                                    </Col>
                                </Row>
                            </Form>
                        </Spin>
                    </Col>
                </Row>
            </Col>
        </PosAndIPGRequestContainer>
    );
};

export default PosAndIPGRequest;
