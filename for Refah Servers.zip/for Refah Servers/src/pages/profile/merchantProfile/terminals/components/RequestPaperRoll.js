import { LeftOutlined } from '@ant-design/icons';
import { Col, Form, Row, Select, Space, Spin } from 'antd';
import styled from 'styled-components';
import { Button, Input, InputNumber, SelectBox, TextArea } from 'templates/Ui';
import { inputRule } from 'utils/helper';
import React from 'react';

const RequestPaperRollContainer = styled(Row)`
  .--actionBtn {
    text-align: end;
    margin-top: 40px;
  }
`;

const RequestPaperRoll = ({ onCloseModal }) => {
  const [requestPaperRollFormRef] = Form.useForm();
  
  const handleRequestPaperRoll = formData => {
    console.log(formData);
  };
  
  return (
    <Spin spinning={ false }>
      <Form
        form={ requestPaperRollFormRef }
        name='requestPaperRollFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={ {
          span: 24
        } }
        wrapperCol={ {
          span: 24
        } }
        labelWrap
        onFinish={ handleRequestPaperRoll }
      >
        <RequestPaperRollContainer gutter={ [16, 10] }>


          <Col xs={ 24 } md={ 6 }>
            <InputNumber
              name={ 'paperCount' }
              label={ 'تعداد رول کاغذ درخواستی' }
              min={ 1 }
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'تعداد رول' })
                }
              ] }
            />
          </Col>
          
          <Col xs={ 24 } md={ 8 }>
            <Input
              name={ 'postalCode' }
              label={ 'کد پستی' }
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'کد پستی' })
                }
              ] }
              maxLength={ 10 }
              justNumber
              formRef={ requestPaperRollFormRef }
              ltr
            />
          </Col>
          
          <Col xs={ 24 } md={ 10 }>
            <Input
              name={ 'address' }
              label={ 'آدرس' }
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'آدرس' })
                }
              ] }
            />
          </Col>
          
          <Col span={ 24 }>
            <TextArea
              name={ 'description' }
              label={ 'توضیحات' }
              rows={ 5 }
            />
          </Col>
          
          <Col span={ 24 } className='--actionBtn'>
            <Space size={ 14 }>
              <Button
                type={ 'default' }
                onClick={ onCloseModal }
              >
                انصراف
              </Button>
              
              <Button
                type={ 'secondary' }
                htmlType={ 'submit' }
                iconAlign={ 'end' }
              >
                <LeftOutlined/>
                ارسال درخواست
              </Button>
            </Space>
          </Col>
        </RequestPaperRollContainer>
      </Form>
    </Spin>
  );
};

export default RequestPaperRoll;
