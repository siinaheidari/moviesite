import { LeftOutlined } from '@ant-design/icons';
import { Col, Form, Popconfirm, Row, Select, Space, Spin } from 'antd';
import styled from 'styled-components';
import { Button, Input, SelectBox, TextArea } from 'templates/Ui';
import { inputRule } from 'utils/helper';

const RequestCloseTerminalContainer = styled(Row)`
  .--actionBtn {
    text-align: end;
    margin-top: 40px;
  }
`;

const RequestCloseTerminal = ({ onCloseModal }) => {
  const [requestCloseTerminalFormRef] = Form.useForm();
  
  const handleRequestCloseTerminal = () => {
    requestCloseTerminalFormRef.validateFields()
      .then(() => {
        const formData = requestCloseTerminalFormRef?.getFieldsValue(true);
        
        console.log(formData);
      });
  };
  
  return (
    <Spin spinning={ false }>
      <Form
        form={ requestCloseTerminalFormRef }
        name='requestCloseTerminalFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={ {
          span: 24
        } }
        wrapperCol={ {
          span: 24
        } }
      >
        <RequestCloseTerminalContainer gutter={ [16, 10] }>
          <Col xs={ 24 } md={ 7 }>
            <SelectBox
              name={ 'input1' }
              label={ 'علت جمع آوری پایانه' }
              rules={ [
                {
                  required: true,
                  message: inputRule('required selectBox', { inputName: 'علت جمع آوری پایانه' })
                }
              ] }
            >
              <Select.Option value={ 0 }>
                علت اول
              </Select.Option>
            </SelectBox>
          </Col>
          
          <Col xs={ 24 } md={ 6 }>
            <Input
              name={ 'postalCode' }
              label={ 'کد پستی' }
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'کد پستی' })
                }
              ] }
              maxLength={ 10 }
              justNumber
              formRef={ requestCloseTerminalFormRef }
              ltr
            />
          </Col>
          
          <Col xs={ 24 } md={ 11 }>
            <Input
              name={ 'address' }
              label={ 'آدرس' }
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'آدرس' })
                }
              ] }
            />
          </Col>
          
          <Col span={ 24 }>
            <TextArea
              name={ 'description' }
              label={ 'توضیحات' }
              rows={ 5 }
            />
          </Col>
          
          <Col span={ 24 } className='--actionBtn'>
            <Space size={ 14 }>
              <Button
                type={ 'default' }
                onClick={ onCloseModal }
              >
                انصراف
              </Button>
              
              <Popconfirm
                title={ 'درخواست جمع آوری پایانه' }
                description={ 'آیا از درخواست خود اطمینان دارید؟' }
                okText={ 'اطمینان دارم' }
                onConfirm={ handleRequestCloseTerminal }
                onCancel={ onCloseModal }
                cancelText={ 'منصرف شدم' }
              >
                <Button
                  type={ 'secondary' }
                  iconAlign={ 'end' }
                >
                  <LeftOutlined/>
                  ارسال درخواست
                </Button>
              </Popconfirm>
            </Space>
          </Col>
        </RequestCloseTerminalContainer>
      </Form>
    </Spin>
  );
};

export default RequestCloseTerminal;
