import React from 'react';
import { MatchBreakpoint } from 'react-hook-breakpoints';
import TerminalDesktop from './screens/TerminalDesktop';
import TerminalMobile from './screens/TerminalMobile';
import { useRequest } from '../../../../utils/useRequest';
import { useAuth } from '../../../../contexts/auth/AuthContext';


const Terminals = () => {


    return (
        <div>
            <MatchBreakpoint max="md">
                <TerminalMobile/>
            </MatchBreakpoint>

            <MatchBreakpoint min="lg">
                <TerminalDesktop/>
            </MatchBreakpoint>
        </div>
    );
};

export default Terminals;
