import React, {useState} from 'react';
import {Button, Input, Modal, SelectBox, TransitionsPage} from '../../../../../templates/Ui';
import {Col, Divider, Form, Row, Select, Space} from 'antd';
import {Link} from 'react-router-dom';
import rightArrow from '../../../../../assets/icons/mobile/rightArrow.svg';
import circle from '../../../../../assets/icons/mobile/circle.svg';
import filter from '../../../../../assets/icons/mobile/Filter.svg';
import Arrow from '../../../../../assets/icons/mobile/blueArrow.svg';
import search from '../../../../../assets/icons/mobile/search.svg';
import {DateObject} from 'react-multi-date-picker';
import persian from 'react-date-object/calendars/persian';
import gregorian from 'react-date-object/calendars/gregorian';
import {useRequest} from '../../../../../utils/useRequest';

const TerminalMobile = () => {

    const [terminalMobileFormRef] = Form.useForm();
    const [currentTab, setCurrentTab] = useState('');
    const [terminalMobileModal, setTerminalMobileModal] = useState(false);
    const [terminalType, setTerminalType] = useState();
    const [terminalNumber, setTerminalNumber] = useState();
    const currentData = new DateObject({calendar: persian});
    const currentData2 = new DateObject({calendar: persian});

    const lastDayDate = new DateObject({calendar: persian});
    const lastDayDate2 = new DateObject({calendar: persian});

    const [startDate, setStartDate] = useState(lastDayDate2?.subtract(1, 'day')?.convert(gregorian)?.format('YYYY-MM-DD'));

    const [endDate, setEndDate] = useState(currentData2?.convert(gregorian)?.format('YYYY-MM-DD'));

    const {Option} = Select;

    const handleDepositReport = (values) => {
        console.log(values);
        setTerminalMobileModal(false);
    };

    const handleToggleTab = (type) => {
        setCurrentTab(current => current === type ? '' : type);
    };

    const {
        isLoading: merchantListTerminalIsLoading,
        data: merchantListTerminalData,
    } = useRequest({
        path: '/merchant/terminal-list',
        params: {
            rowPage: 100,
            pageNumber: 1,
            terminalType: terminalType === 'all' ? null : terminalType,
        },
        key: ['terminal-list-merchant', terminalType],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const merchantListTerminalRes = merchantListTerminalData;


    const {
        isLoading: terminalTypeLoading,
        data: terminalTypeData,
    } = useRequest({
        path: '/setting/list-terminal-type',
        key: ['terminalType-mobile'],
        apiType: 'club',
    });

    const terminalTypeRes = terminalTypeData || [];


    const handleFilter = () => {
        const values = terminalMobileFormRef?.getFieldsValue(true);
        setTerminalNumber(values?.terminalNumber);
        setTerminalType(values?.terminalType);
        setTerminalMobileModal('');
    };


    return (
        <TransitionsPage coordinates={'x'}>
            <Col span={24} className={'mb-[13px] lg:hidden'}>
                <Link to={'/merchantProfile'} className={''}> <img src={rightArrow}/></Link>
            </Col>
            <div className={'flex mb-[17px] lg:hidden justify-between items-center'}>

                <Space align={'center'} className={'text-[12px] font-[500] '}>
                    <img src={circle}/>
                    لیست ترمینال و درگاه ها
                </Space>
                <div className={'bg-white p-[8px] rounded-[5px] shadow-6'}
                     onClick={() => setTerminalMobileModal(true)}>
                    <img src={filter}/>
                </div>

            </div>
            <Row gutter={[0, 20]}>

                {

                    merchantListTerminalRes?.map((item) => {
                        const date = item?.createDate?.split('T')[1]?.split(':') || [];
                        return <Col span={24}>
                            <div
                                className={'bg-white p-[10px] shadow-4 border-[rgba(120,120,120,0.30)] rounded-[10px]'}>
                                <div onClick={() => handleToggleTab(item?.rowId)} className={'mb-[13px]'}>
                                    <Row gutter={[10, 13]}>
                                        <Col span={14} className={'text-[12px] font-[500] text-title'}>
                                            نام فروشگاه:
                                            <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                                 {item?.shopName}
                                            </span>
                                        </Col>
                                        <Col span={10} className={'text-[12px] font-[500] text-title'}>
                                            کد ترمینال:
                                            <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                                {item?.terminalNumber}
                                            </span>
                                        </Col>

                                        <Col span={24} className={'text-[12px] font-[500] text-title'}>
                                            تاریخ راه اندازی:
                                            <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                                            {
                                                                new DateObject({
                                                                    date: new Date(item?.createDate),
                                                                    calendar: gregorian,
                                                                }).convert(persian).format(`${date[0]}:${date[1]} - YYYY/MM/DD`)
                                                            }
                                              </span>
                                        </Col>


                                        <Col xs={24} className={'text-[12px] font-[500] text-title'}>
                                            نوع ترمینال:
                                            <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                              {item?.terminalTypeDesc}
                                            </span>
                                        </Col>
                                        <Col span={24} className={'text-[12px] font-[500] text-title'}>
                                            شرکت PSP:
                                            <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                                {item?.pspName}
                                            </span>
                                        </Col>
                                    </Row>
                                </div>

                                {
                                    currentTab === item?.rowId ? <TransitionsPage coordinates={'y'} size={10}>
                                        <Row gutter={[5, 13]}
                                             className={currentTab === item?.rowId ? ' duration-1500 pb-[12px]' : 'hidden duration-1000'}>
                                            <Col span={12} className={'text-[12px] font-[500] text-title'}>
                                                شماره سریال:
                                                <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                   {item?.serialNumber}
                                </span>
                                            </Col>
                                            <Col span={12} className={'text-[12px] font-[500] text-title'}>
                                                مدل سخت افزار:
                                                <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                    {item?.hardwareModel}
                                </span>
                                            </Col>
                                            <Col span={12} className={'text-[12px] font-[500] text-title'}>
                                                پورت دسترسی:
                                                <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                   {item?.accessPort}
                                </span>
                                            </Col>
                                            <Col span={12} className={'text-[12px] font-[500] text-title'}>
                                                آدرس دسترسی:
                                                <span className={'text-[12px] font-[400] text-[#4D4D4D] mr-2'}>
                                    {item?.accessAddress}
                                </span>
                                            </Col>
                                        </Row>
                                    </TransitionsPage> : ''
                                }


                                <div onClick={() => handleToggleTab(item?.rowId)}
                                     className={'w-full items-center text-center'}>
                                    <img src={Arrow} className={!currentTab ? 'inline' : 'inline rotate-180 '}/>
                                </div>
                            </div>
                        </Col>

                    })
                }


            </Row>

            <Modal
                open={terminalMobileModal}
                onCancel={() => setTerminalMobileModal(false)}
                header={false}
                closable={false}
                onFinish={handleDepositReport}
                bodyStyle={{
                    padding: 0,
                    backgroundColor: 'white',
                }}
                size={{
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 40,
                    xl: 40,
                    xxl: 30,
                }}
                style={{
                    top: '20vh',
                }}

            >
                <div className={'pb-[24px]'}>
                    <div className={'--modal text-[12px] text-[#4D4D4D]'}>
                        <Space className={'px-[24px] pt-[16px]'}>
                            <img src={filter}/>
                            فیلترها
                        </Space>
                    </div>
                    <Divider className={'!m-2'}/>
                    <div className={'px-[22px]'}>
                        <Form
                            form={terminalMobileFormRef}
                            autoComplete="off"
                            scrollToFirstError
                            labelCol={{
                                span: 24,
                            }}
                            wrapperCol={{
                                span: 24,
                            }}
                            onFinish={handleFilter}
                        >
                            <Row gutter={[10, 10]}>

                                <Col span={24}>
                                    <SelectBox
                                        name={'terminalType'}
                                        label={'نوع ترمینال '}
                                        placeholder={'همه'}

                                    >
                                        <Select.Option value={'all'}> همه</Select.Option>,

                                        {
                                            terminalTypeRes.map((item) =>
                                                <Select.Option
                                                    value={item.rowId}>{item.terminalTypeDesc}</Select.Option>,
                                            )
                                        }

                                    </SelectBox>
                                </Col>

                                <Col span={24}>
                                    <Input
                                        name={'terminalNumber'}
                                        placeholder={' شماره ترمینال'}
                                        formRef={terminalMobileFormRef}
                                        focus
                                        suffix={<img src={search}/>}
                                    />
                                </Col>
                                <Col sm={10} xs={24}
                                     className={'items-center text-center mt-[47px] mb-[30px] mx-auto'}>
                                    <Button
                                        className={'!rounded-[5px] text-[12px] font-[400] w-full'}
                                        htmlType={'submit'}
                                        type={'secondary'}
                                        radius={50}
                                    >
                                        اعمال فیلتر
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    </div>
                </div>
            </Modal>
        </TransitionsPage>
    );
};

export default TerminalMobile;
