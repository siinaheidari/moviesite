import { PlusOutlined } from '@ant-design/icons';
import { Col, Form, Row, Select, Space, Spin } from 'antd';
import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import SvgIcon from 'templates/components/SvgIcon';
import { Button, Modal, SelectBox, Table } from 'templates/Ui';

// components
import RequestPaperRoll from 'pages/profile/merchantProfile/terminals/components/RequestPaperRoll';
import RequestChangeTerminal from 'pages/profile/merchantProfile/terminals/components/RequestChangeTerminal';
import RequestCloseTerminal from 'pages/profile/merchantProfile/terminals/components/RequestCloseTerminal';
import { DateObject } from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import { useRequest } from '../../../../../utils/useRequest';
import { useAuth } from '../../../../../contexts/auth/AuthContext';

const TerminalsContainer = styled(Row)`
  position: relative;

  .--newTerminalBtn {
    text-align: end;
    position: absolute;
    z-index: 1;
    top: -38px;
    left: 38px;

    a {
      .ant-space-item {
        font-weight: 500;

        svg {
          width: 12px;
          height: 12px;
        }
      }
    }
  }
`;

const TerminalDesktop = () => {

    const terminalsTableRef = useRef(null);
    const [ filterFormRef ] = Form.useForm();
    const [ requestPaperRollModalVisible, setRequestPaperRollModalVisible ] = useState(false);
    const [ terminalType, setTerminalType ] = useState();
    const [ requestChangeTerminalModalVisible, setRequestChangeTerminalModalVisible ] = useState(false);

    const [ requestCloseTerminalModalVisible, setRequestCloseTerminalModalVisible ] = useState(false);

    const actionMenu = {
        IPG: [
            {
                label: <div>درخواست تغییر IP درگاه پرداخت</div>,
                key: 'change-terminal-ip',
            },
            {
                label: <div>درخواست پشتیبانی</div>,
                key: 'support',
            },
        ],
        POS: [
            {
                label: <div onClick={ () => setRequestPaperRollModalVisible(true) }>درخواست رول کاغذی</div>,
                key: 'paper-roll',
            },
            {
                label: <div onClick={ () => setRequestChangeTerminalModalVisible(true) }>درخواست تعویض پایانه</div>,
                key: 'change-terminal',
            },
            {
                label: <div onClick={ () => setRequestCloseTerminalModalVisible(true) }>درخواست جمع آوری پایانه</div>,
                key: 'close-terminal',
            },
            {
                label: <div>تغییر آدرس پایانه</div>,
                key: 'change-terminal-address',
            },
            {
                label: <div>درخواست پشتیبانی</div>,
                key: 'support',
            },
        ],
    };


    const { auth } = useAuth();
    console.log(auth);
    const {
        isLoading: merchantListTerminalIsLoading,
        data: merchantListTerminalData,
    } = useRequest({
        path: '/merchant/terminal-list',
        params: {
            rowPage: 100,
            pageNumber: 1,
            personId: auth?.userId,
            terminalType: terminalType === 'all' ? null : terminalType,
        },
        key: [ 'terminal-list', terminalType ],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });


    const merchantListTerminalRes = merchantListTerminalData || [];

    const handleFilter = () => {
        const values = filterFormRef?.getFieldsValue(true);
        console.log(values);
        setTerminalType(values?.terminalType);
    };

    const tableColumns = [
        {
            title: 'کد پذیرنده',
            dataIndex: 'personId',
            key: 'personId',
            align: 'center',
        },
        {
            title: 'نام فروشگاه',
            dataIndex: 'shopName',
            key: 'shopName',
            align: 'center',
        },
        {
            title: 'کد ترمینال',
            dataIndex: 'terminalNumber',
            key: 'terminalNumber',
            align: 'center',
        },
        {
            title: 'نوع ترمینال',
            dataIndex: 'terminalTypeDesc',
            key: 'terminalTypeDesc',
            align: 'center',
        },
        {
            title: 'شرکت PSP',
            dataIndex: 'pspName',
            key: 'pspName',
            align: 'center',
        },

        {
            title: 'تاریخ راه اندازی',
            dataIndex: 'createDate',
            key: 'createDate',
            align: 'center',
            render: (_, row) => {
                const hour = row?.createDate?.split('T')[1]?.split(':');
                const date = new DateObject({
                    date: new Date(row?.createDate),
                    calendar: gregorian,
                });
                return date.add(7, 'hour').convert(persian).format(`${ hour[0] }:${ hour[1] } - YYYY/MM/DD`);
            },
        },

        {
            title: 'شماره سریال',
            dataIndex: 'serialNumber',
            key: 'serialNumber',
            align: 'center',
        },
        {
            title: 'مدل سخت افزار',
            dataIndex: 'hardwareModel',
            key: 'hardwareModel',
            align: 'center',
        },
        {
            title: 'پورت دسترسی',
            dataIndex: 'accessPort',
            key: 'accessPort',
            align: 'center',
        },
        {
            title: 'آدرس دسترسی',
            dataIndex: 'accessAddress',
            key: 'accessAddress',
            align: 'center',
        },
        // {
        //     title: 'عملیات',
        //     dataIndex: 'action',
        //     key: 'action',
        //     align: 'center',
        //     render: (_, { terminalType }) => {
        //         terminalType = terminalType === 'POS' ? 'POS' : 'IPG';
        //         return (
        //             <div className='__action'>
        //                 <DropdownV2
        //                     menu={ actionMenu[ terminalType ] }
        //                     title={ 'بیشتر' }
        //                 />
        //             </div>
        //         );
        //     }
        // }
    ];


    const {
        isLoading: terminalTypeLoading,
        data: terminalTypeData,
    } = useRequest({
        path: '/setting/list-terminal-type',
        key: [ 'terminalType-desktop' ],
        apiType: 'club',
    });


    const terminalTypeRes = terminalTypeData || [];


    return (
        <Spin spinning={ merchantListTerminalIsLoading }>
            <TerminalsContainer>
                <Form
                    form={ filterFormRef }
                    name="indexFrom"
                    autoComplete="off"
                    scrollToFirstError
                    labelCol={ {
                        span: 24,
                    } }
                    wrapperCol={ {
                        span: 24,
                    } }
                    onFinish={ handleFilter }
                >
                    <Row gutter={ 16 } justify={ 'end' }>
                        <Col xs={ 24 } lg={ 6 } >
                            <SelectBox
                                name="terminalType"
                                placeholder={ 'نوع ترمینال' }
                                showSearch={ false }
                                rules={ [
                                    {
                                        required: true,
                                        message: 'نوع ترمینال را انتخاب نمایید',
                                    },
                                ] }
                                allowClear={ false }
                                loading={ terminalTypeLoading }

                            >
                                <Select.Option value={ "all" }> همه</Select.Option>,

                                {
                                    terminalTypeRes.map((item) =>
                                        <Select.Option value={ item.rowId }>{ item.terminalTypeDesc }</Select.Option>,
                                    )
                                }
                            </SelectBox>
                        </Col>
                        <Col span={ 4 } className={"ml-[20px]"}>
                            <Button
                                htmlType={ 'submit' }
                                type={ 'secondary' }
                                className={ '!bg-purple  !text-white w-full mx-auto' }>اعمال فیلتر
                            </Button>
                        </Col>
                        <Col span={ 24 } className="--table" ref={ terminalsTableRef }>
                            <Table
                                columns={ tableColumns }
                                dataSource={ merchantListTerminalRes }
                                bordered
                                tableLayout={ 'fixed' }
                                pagination={ {
                                    hideOnSinglePage: true,
                                    defaultPageSize: 10,
                                    total: merchantListTerminalRes?.length,
                                    showSizeChanger: false,
                                    responsive: true,
                                    position: [ 'bottomLeft' ],
                                    nextIcon: <SvgIcon icon={ 'leftCircle' } width={ 20 } height={ 20 }
                                                       color={ '#999999' }
                                                       style={ { margin: '6px auto' } }/>,
                                    prevIcon: <SvgIcon icon={ 'rightCircle' } width={ 20 } height={ 20 }
                                                       color={ '#999999' }
                                                       style={ { margin: '6px auto' } }/>,
                                    onChange: () => terminalsTableRef?.current.scrollIntoView({ behavior: 'smooth' }),
                                } }
                            />
                        </Col>
                    </Row>


                    <Col span={ 24 } className=" relative top-[70px] text-end">
                        <Link to={ '/merchantProfile/requests/posAndIPGRequest' }>
                            <Space size={ 10 }>
                                <PlusOutlined/>
                                درخواست ثبت پایانه جدید

                            </Space>
                        </Link>
                    </Col>
                    <Modal
                        open={ requestPaperRollModalVisible }
                        title={ 'درخواست رول کاغذی' }
                        onCancel={ () => setRequestPaperRollModalVisible(false) }
                        size={ {
                            xxl: 70,
                        } }
                    >
                        <RequestPaperRoll onCloseModal={ () => setRequestPaperRollModalVisible(false) }/>
                    </Modal>

                    <Modal
                        open={ requestChangeTerminalModalVisible }
                        title={ 'درخواست تعویض پایانه' }
                        onCancel={ () => setRequestChangeTerminalModalVisible(false) }
                        size={ {
                            xxl: 70,
                        } }
                    >
                        <RequestChangeTerminal onCloseModal={ () => setRequestChangeTerminalModalVisible(false) }/>
                    </Modal>

                    <Modal
                        open={ requestCloseTerminalModalVisible }
                        title={ 'درخواست جمع آوری پایانه' }
                        onCancel={ () => setRequestCloseTerminalModalVisible(false) }
                        size={ {
                            xxl: 70,
                        } }
                    >
                        <RequestCloseTerminal onCloseModal={ () => setRequestCloseTerminalModalVisible(false) }/>
                    </Modal>
                </Form>
            </TerminalsContainer>
        </Spin>
    );
};

export default TerminalDesktop;
