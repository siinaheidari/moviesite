import React, {useRef, useState} from 'react';
import {Col, Form, Row, Select, Spin} from 'antd';
import {useRequest} from '../../../../utils/useRequest';
import {Button, Input, Table} from '../../../../templates/Ui';
import {DateObject} from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import SvgIcon from '../../../../templates/components/SvgIcon';

const TerminalsList = () => {
    const [filterFormRef] = Form.useForm();
    const [terminalNo, setTerminalNo] = useState(1);
    const transactionTableRef = useRef(null);
    const [page, setPage] = useState(10);
    const [ticketModal, setTicketModal] = useState({});
    const [pageSize, setPageSize] = useState(10);
    const [requestTypeId, setRequestTypeId] = useState(51);
    const [personId, setPersonId] = useState();
    const {Option} = Select;
    const [ticketFormRef] = Form.useForm();

    // const handleOpenTicketModal = (ticketModal) => {
    //     setTicketModal(ticketModal);
    // };
    //


    const {
        isLoading: merchantListTerminalIsLoading,
        data: merchantListTerminalData,
    } = useRequest({
        path: '/merchant/terminal-list',
        params: {
            rowPage: 100,
            pageNumber: 1,
            personId: personId ? personId : null,
        },
        key: ['terminal-list-admin', personId],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const merchantListTerminalRes = merchantListTerminalData;

    const handleFilter = () => {
        const values = filterFormRef?.getFieldsValue(true);
        console.log(values);
        setPersonId(values?.personId);
    };


    const tableColumns = [
        {
            title: 'کد پذیرنده',
            dataIndex: 'personId',
            key: 'personId',
            align: 'center',
        },
        {
            title: 'نام فروشگاه',
            dataIndex: 'shopName',
            key: 'shopName',
            align: 'center',
        },
        {
            title: 'کد ترمینال',
            dataIndex: 'terminalNumber',
            key: 'terminalNumber',
            align: 'center',
        },
        {
            title: 'نوع ترمینال',
            dataIndex: 'terminalTypeDesc',
            key: 'terminalTypeDesc',
            align: 'center',
        },
        {
            title: 'شرکت PSP',
            dataIndex: 'pspName',
            key: 'pspName',
            align: 'center',
        },

        {
            title: 'تاریخ راه اندازی',
            dataIndex: 'createDate',
            key: 'createDate',
            align: 'center',
            render: (_, row) => {
                const hour = row?.createDate?.split('T')[1]?.split(':');
                const date = new DateObject({
                    date: new Date(row?.createDate),
                    calendar: gregorian,
                });
                return date.add(7, 'hour').convert(persian).format(`${hour[0]}:${hour[1]} - YYYY/MM/DD`);
            },
        },

        {
            title: 'شماره سریال',
            dataIndex: 'serialNumber',
            key: 'serialNumber',
            align: 'center',
        },
        {
            title: 'مدل سخت افزار',
            dataIndex: 'hardwareModel',
            key: 'hardwareModel',
            align: 'center',
        },
        {
            title: 'پورت دسترسی',
            dataIndex: 'accessPort',
            key: 'accessPort',
            align: 'center',
        },
        {
            title: 'آدرس دسترسی',
            dataIndex: 'accessAddress',
            key: 'accessAddress',
            align: 'center',
        },
        // {
        //     title: 'عملیات',
        //     dataIndex: 'action',
        //     key: 'action',
        //     align: 'center',
        //     render: (_, { terminalType }) => {
        //         terminalType = terminalType === 'POS' ? 'POS' : 'IPG';
        //         return (
        //             <div className='__action'>
        //                 <DropdownV2
        //                     menu={ actionMenu[ terminalType ] }
        //                     title={ 'بیشتر' }
        //                 />
        //             </div>
        //         );
        //     }
        // }
    ];


    return (
        <Row>
            <Spin spinning={merchantListTerminalIsLoading}>
                <Col span={24} className={'bg-white p-5 shadow-6 rounded-[10px]'}>
                    <div>
                        لیست ترمینال ها
                    </div>
                    <Form
                        form={filterFormRef}
                        name="indexFrom"
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={{
                            span: 24,
                        }}
                        wrapperCol={{
                            span: 24,
                        }}
                        onFinish={handleFilter}
                    >


                        <Row gutter={16} justify={'end'}>
                            <Col span={6}>
                                <Input
                                    name={'personId'}
                                    placeholder={'شماره پذیرنده'}
                                    bordered
                                    allowClear
                                />
                            </Col>
                            <Col span={4}>
                                <Button
                                    htmlType={'submit'}
                                    type={'secondary'}
                                    className={'!bg-purple !text-white w-full mx-auto'}>اعمال فیلتر
                                </Button>
                            </Col>

                            <Table
                                rowClassName={'cursor-pointer'}
                                columns={tableColumns}
                                className="my-form"
                                dataSource={merchantListTerminalRes}
                                onChange={({current, pageSize,}) => {
                                    setPage(current);
                                    setPageSize(pageSize);
                                }}
                                bordered
                                tableLayout={'fixed'}
                                pagination={{
                                    hideOnSinglePage: true,
                                    defaultPageSize: 10,
                                    total: 200,
                                    showSizeChanger: true,
                                    responsive: true,
                                    position: ['bottomLeft'],
                                    nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                                       color={'#999999'}
                                                       style={{margin: '6px auto'}}/>,
                                    prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                                       color={'#999999'}
                                                       style={{margin: '6px auto'}}/>,
                                    // onChange: () => tableRef?.current.scrollIntoView({ behavior: 'smooth' }),
                                }}
                            />
                        </Row>
                    </Form>
                </Col>
            </Spin>
        </Row>
    );
};

export default TerminalsList;
