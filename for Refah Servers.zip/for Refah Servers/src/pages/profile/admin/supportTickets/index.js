import React, {useRef, useState} from 'react';
import { Col, ConfigProvider, Form, Radio, Row, Select, Spin } from 'antd';

import {
  Button,
  Input,
  Modal,
  RadioButton,
  RadioFormItem,
  RadioGroup,
  SelectBox,
  Table,
} from '../../../../templates/Ui';

import TicketDetails from "./components/TicketDetails";
import OldRequests from "./components/OldRequests";
import {AnimatePresence, motion} from "framer-motion";
import SvgIcon from '../../../../templates/components/SvgIcon';
import { useRequest } from '../../../../utils/useRequest';
import { DateObject } from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';


const SupportTickets = () => {

  const [filterFormRef] = Form.useForm();
  const transactionTableRef = useRef(null);
  const [ticketModal, setTicketModal] = useState(false)
  const [currentInfo, setCurrentInfo] = useState("details")
  const [ value3, setValue3 ] = useState(1);
  const [ personId, setPersonId ] = useState();
  const [ page, setPage ] = useState(10);

  const handleOpenTicketModal = (ticketModal) => {
    setTicketModal(ticketModal);
  };

  const handleCloseTicketModal = () => {
    setTicketModal(false);
  }

  
  const onChange3 = ({ target: { value } }) => {
    console.log('radio3 checked', value);
    setValue3(value);
  };


  const {
    isLoading,
    data,
    refetch,
  } = useRequest({
    path: '/merchant/request-list',
    params: {
      requestTypeId: 55 ,
      personId: personId,
    },
    options: {
      retry: false,
    },
    apiType: 'club',
    key: [ 'request-list', page, personId ],
  });


  const response = data || [];
  console.log('ffffffffffff', response);

  const handleChangeFilter = () => {

    const values = filterFormRef?.getFieldsValue(true);
    setPersonId(values?.personId);

  };
  
  
  const options = [
    {
      label: 'امروز',
      value: 1,
    },
    {
      label: 'هفته',
      value: 7,
    },
    {
      label: 'ماه',
      value: 30,
    },
    {
      label: 'سال',
      value: 365,
    },
  ];

  const tableColumns = [

    {
      title: 'کد پذیرنده',
      dataIndex: 'merchentCode',
      key: 'merchentCode',
      align: 'center',

    },
    {
      title: 'عنوان',
      dataIndex: 'requestTypeDesc',
      key: 'requestTypeDesc',
      align: 'center',

    },
    {
      title: 'توضیحات',
      dataIndex: 'description',
      key: 'description',
      align: 'center',
      render: (_, row) => {
        return row?.description?.slice(0, 15);
      },

    },
    {
      title: 'شماره ترمینال',
      dataIndex: 'terminalNumber',
      key: 'terminalNumber',
      align: 'center',

    },
    {
      title: 'نام پذیرنده',
      dataIndex: 'personName',
      key: 'personName',
      align: 'center',

    },

    {
      title: 'تاریخ',
      dataIndex: 'totalResponseTime',
      key: 'totalResponseTime',
      align: 'center',
      render: (_, row) => {
        const hour = row?.modifyDate?.split('T')[1]?.split(':');
        const date = new DateObject({
          date: new Date(row?.modifyDate),
          calendar: gregorian,
        });
        return date.add(7, 'hour').convert(persian).format(`${ hour[0] }:${ hour[1] } - YYYY/MM/DD`);
      },
    },

    {
      title: 'جزئیات',
      dataIndex: 'action',
      key: 'action',
      align: 'center',
      render: (_, row) => <p onClick={ () => handleOpenTicketModal(row) }
                             className={ 'text-blue-500 underline cursor-pointer' }>جزئیات</p>,
    },

  ];



  const info = [
    {
      key: "details",
      title: "جزئیات",
      component: <TicketDetails/>
    },
    {
      key: "oldRequests",
      title: "درخواست‌های قبلی",
      component: <OldRequests/>
    },
  ]

  const activeInfo = info?.find(item => item.key === currentInfo)


  return (
    <Spin spinning={false}>
      <div className={"py-[25px] bg-white rounded-lg"}>
        <Form
          form={filterFormRef}
          name='indexFrom'
          autoComplete='off'
          scrollToFirstError
          labelCol={{
            span: 24
          }}
          wrapperCol={{
            span: 24
          }}
          onFinish={handleChangeFilter}
        >
          
          <div className={ 'flex justify-between gap-3 items-center pb-[25px]' }>
            <div className={"w-1/4 pr-[36px]"}>
              لیست پشتیبانی و تیکت ها
            </div>
            <div className={ 'pl-[34px] w-3/4 flex justify-end  gap-[16px] items-center' }>
              <Row gutter={16}>
                <Col span={16 }>
                  <Input
                      name={ 'personId' }
                      placeholder={ 'شماره پذیرنده' }
                      bordered
                      allowClear

                  />
                </Col>
                <Col span={ 8 }>
                  <Button
                      htmlType={ 'submit' }
                      type={ 'secondary' }
                      className={ '!bg-purple !text-white w-full mx-auto' }>اعمال فیلتر
                  </Button>
                </Col>
              </Row>
            </div>
          
          </div>


          <Col span={24} className='--table' ref={transactionTableRef}>
            <Table
              columns={tableColumns}
              dataSource={response}
              bordered
              tableLayout={'fixed'}
              pagination={{
                hideOnSinglePage: true,
                defaultPageSize: 10,
                total: 30,
                showSizeChanger: false,
                responsive: true,
                position: ['bottomLeft'],
                nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20} color={'#999999'}
                                   style={{margin: '6px auto'}}/>,
                prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20} color={'#999999'}
                                   style={{margin: '6px auto'}}/>,
                // onChange: () => transactionTableRef?.current.scrollIntoView({behavior: 'smooth'})
              }}
            />
          </Col>
        </Form>
        <Modal
          open={ticketModal}
          onCancel={handleCloseTicketModal}
          size={{
            sm: 55,
            xs: 55,
            md: 55,
            lg: 55,
            xl: 55,
            xxl: 55
          }}
          bodyStyle={{
            padding: 0,
          }}
          style={{
            top: '10vh'
          }}
        >

          <div className={"flex gap-5 items-center px-8 text-[14px] border-b"}>
            {info.map((item) =>
              <p onClick={() => setCurrentInfo(item.key)} className={"cursor-pointer relative py-5 "}>{item.title}
                {
                  item.key === currentInfo ? (
                    <motion.div className={"underline bg-purple h-[5px] rounded-t-[10px] absolute bottom-0 w-full"}
                                layoutId={"underline"}/>
                  ) : null
                }
              </p>
            )}
          </div>
          <AnimatePresence mode={"wait"}>
            <motion.div
              key={currentInfo || 'initialPage'}
              initial={{
                x: 20,
                opacity: 0,
              }}
              animate={{
                x: 0,
                opacity: 1,
              }}
              exit={{
                x: -20,
                opacity: 0
              }}
              transition={{
                duration: 0.3
              }}
            >
              <div>
                {activeInfo?.component}
              </div>

            </motion.div>

          </AnimatePresence>

        </Modal>

      </div>
    </Spin>
  )
    ;
};

export default SupportTickets;