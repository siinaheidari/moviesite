import React, {useRef, useState} from 'react';

import {DownOutlined} from "@ant-design/icons";


const OldRequests = () => {

  const [currentInfo, setCurrentInfo] = useState()

  const info = [
    {
      key: 1,
      title: "جزئیات",
      component: "fghjhgjgh"
    },

  ]

  const activeInfo = info?.find(item => item.key === currentInfo)


  return (
    <div>
      <div className={"flex justify-between gap-3 items-center text-center px-[52px] py-5"}>
        <p className={"font-[400]"}>موضوع: <span className={"text-textcolor font-[400]"}>فوری</span></p>
        <p className={"font-[400]"}>درجه اهمیت: <span className={"text-red-600"}>فوری</span></p>
        <p className={"font-[400]"}>تاریخ: <span>۱۴۰۲/۰۳/۲۲</span></p>
        <p className={"font-[400]"}>ساعت: <span>۱۲:۳۰</span></p>
        <p className={"font-[400]"}>پاسخ داده شده</p>
        {info.map((item) =>
          <p onClick={() => setCurrentInfo(item.key)} className={"cursor-pointer text-blue-400 "}>بیشتر<span><DownOutlined/></span>
          </p>
        )}
      </div>
      {activeInfo?.component}
    </div>
  );
};

export default OldRequests;