import React from 'react';
import {Button, TextArea} from "../../../../../templates/Ui";
import {Form} from "antd";

const TicketDetails = () => {

  const [ticketFormRef]=Form.useForm()

  const handleSendTicket=(value)=>[
    console.log(value)
  ]

  return (
    <div className={"mt-2 py-10 px-[76px]"}>
      <div className={"border rounded-lg py-8"}>

      <p className={"bg-[#dc3545] text-white w-[70px] px-2 rounded-l-lg leading-8"}>فوری</p>
     <div className={"px-7"}>
      <div className={"text-textcolor text-[14px] flex justify-between gap-5 my-7 "}>
        <p className={"font-[400]"}>{"کد عضویت: 534354354"}</p>
        <p className={"font-[400]"}>{"تاریخ: ۱۴۰۱/۱۰/۲۴"}</p>
        <p className={"font-[400]"}>{"ساعت: ۹:22"}</p>
      </div>
      <div className={"text-textcolor text-[14px] my-4"}>
        <p className={"pb-3 font-[400]"}>موضوع:</p>
        <p className={"border rounded-lg w-1/3 py-2 px-3 font-[400]"}>اختلال</p>
      </div>
       <div className={"my-6 font-[400]"}>
         <p className={"pb-5 font-[400]"}>
           توضیحات:
         </p>
         <p className={"bg-[#f5f5f5] px-3 rounded-lg text-[#7a7a7a] leading-[22px] text-justify text-[13px] py-4 font-[400]"}>
           Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ad adipisci amet aperiam autem blanditiis consectetur corporis culpa cum debitis dignissimos dolore dolorem doloremque error excepturi illo inventore itaque iure iusto laborum libero minus necessitatibus non nostrum, officia perferendis possimus quae quaerat quibusdam quidem recusandae repellat saepe similique tempore temporibus!
         </p>
       </div>
       <Form
       name={"ticket"}
       form={ticketFormRef}
       autoComplete='off'
       labelCol={{
         span: 24
       }}
       wrapperCol={{
         span: 24
       }}
       onFinish={handleSendTicket}
       >
      <div>
        <p className={"pb-4 font-[400] text-textcolor"}>پاسخ دهی:</p>
        <TextArea name={"textArea"} rules={[{required:true,message:"فیلد مورد نظر را پر کنید."}]} ref={ticketFormRef} />
      </div>
       <div className={"items-end text-end font-[400]"}>
         <button onClick={handleSendTicket} className={"bg-purple text-white w-1/4 py-2 rounded-lg"}>ارسال</button>
       </div>
       </Form>
    </div>
      </div>
    </div>
  );
};

export default TicketDetails;