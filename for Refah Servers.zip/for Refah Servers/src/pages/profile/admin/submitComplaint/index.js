import React, {useRef, useState} from 'react';
import {Col, Form, Row, Spin} from 'antd';

import {Modal, Table} from '../../../../templates/Ui';
import SvgIcon from '../../../../templates/components/SvgIcon';
import ProtestsTicketDetails from './components/ProtestsTicketDetails';
import ProtestsOldRequests from './components/ProtestsOldRequests';
import {AnimatePresence, motion} from 'framer-motion';
import {useRequest} from '../../../../utils/useRequest';
import {DateObject} from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import {useAuth} from '../../../../contexts/auth/AuthContext';
import styled from "styled-components";


const SubmitContainer = styled(Row)`


  .ant-table-row {
    &.--active {
      .ant-table-cell:first-child {
        border-right: 7px solid #1cc500 !important;
      }
    }

    &.--deActive {
      .ant-table-cell:first-child {
        border-right: 7px solid #fe2301 !important;
      }
    }
  }

`;


const SubmitComplaint = () => {
    const {auth} = useAuth();
    const [filterFormRef] = Form.useForm();
    const transactionTableRef = useRef(null);
    const [ticketModal, setTicketModal] = useState({});
    const [currentInfo, setCurrentInfo] = useState('details');
    const [value3, setValue3] = useState(1);
    const [page, setPage] = useState(10);

    const handleOpenTicketModal = (ticketModal) => {
        setTicketModal(ticketModal);
    };


    const handleChangeFilter = formData => {
        // console.log(formData);
    };


    const {
        isLoading: adminComplaintLoading,
        data: adminComplaintData,
        refetch: refetchComplaint,
    } = useRequest({
        path: '/suggestion/list',
        key: ['question', page],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const adminComplaintDataRes = adminComplaintData;


    const tableColumns = [
        {
            title: 'کد عضویت',
            dataIndex: 'personId',
            key: 'personId',
            align: 'center',
            width: 110,
        },
        {
            title: 'نام پذیرنده',
            dataIndex: 'personName',
            key: 'personId',
            align: 'center',
        },
        {
            title: 'موضوع',
            dataIndex: 'suggestionsDesc',
            key: 'suggestionsDesc',
            align: 'center',
            render: (_, row) => {
                return `${row?.suggestionsDesc.slice(0, 20)}...`;

            },
            width: 150,
        },
        {
            title: 'جواب',
            dataIndex: 'answer',
            key: 'answer',
            align: 'center',
            render: (_, row) => {
                return row?.answer ?<div className={"text-lime-500"}>{row.answer.slice(0, 20)} ... </div>  :
                    <div className={row?.answer ? "text-lime-500" : "text-red-500"}>پاسخی داده نشده</div>
            },
        },
        {
            title: 'تاریخ و ساعت',
            dataIndex: 'createDate',
            key: 'createDate',
            align: 'center',
            render: (_, row) => {
                const hour = row?.createDate?.split('T')[1]?.split(':');
                const date = new DateObject({
                    date: new Date(row?.createDate),
                    calendar: gregorian,
                });
                return date.add(7, 'hour').convert(persian).format(`${hour[0]}:${hour[1]} - YYYY/MM/DD`);
            },
        },
        {
            title: 'نوع پشتیبانی',
            dataIndex: 'date',
            key: 'date',
            align: 'center',
        },
        {
            title: 'درجه اهمیت',
            dataIndex: 'time',
            key: 'time',
            align: 'center',
        },
        {
            title: 'جزئیات',
            dataIndex: 'action',
            key: 'action',
            align: 'center',
            render: (_, row) => <p onClick={() => handleOpenTicketModal(row)}
                                   className={'text-blue-500 underline cursor-pointer'}>جزئیات</p>,
        },
    ];


    const info = [
        {
            key: 'details',
            title: 'جزئیات',
            component: <ProtestsTicketDetails  refetchComplaint={refetchComplaint}
                                              ticketModal={ticketModal} setTicketModal={setTicketModal}/>,
        },
        {
            key: 'oldRequests',
            title: 'درخواست‌های قبلی',
            component: <ProtestsOldRequests  refetchComplaint={refetchComplaint} ticketModal={ticketModal} setTicketModal={setTicketModal}/>,
        },
    ];

    const activeInfo = info?.find(item => item.key === currentInfo);

    const onChange3 = ({target: {value}}) => {
        console.log('radio3 checked', value);
        setValue3(value);
    };


    const options = [
        {
            label: 'امروز',
            value: 1,
        },
        {
            label: 'هفته',
            value: 7,
        },
        {
            label: 'ماه',
            value: 30,
        },
        {
            label: 'سال',
            value: 365,
        },
    ];


    return (
        <Spin spinning={false}>
            <SubmitContainer className={'py-[25px]  rounded-[5px]'}>
                <Form
                    form={filterFormRef}
                    name="indexFrom"
                    autoComplete="off"
                    scrollToFirstError
                    labelCol={{
                        span: 24,
                    }}
                    wrapperCol={{
                        span: 24,
                    }}
                    onFinish={handleChangeFilter}
                >

                    <Col span={24} className="">
                        <div className={'flex bg-white shadow-6 rounded-[10px] justify-between gap-3 items-center py-[25px]'}>
                            <div className={'w-1/4 pr-[36px]'}>
                                لیست پشتیبانی و تیکت ها
                            </div>
                            <div className={'pl-[34px] w-3/4 flex justify-end gap-[16px] items-center bg-white'}>
                                <div>
                                    <div className={'w-full'}>
                                        {/*<ConfigProvider*/}
                                        {/*    theme={ {*/}
                                        {/*        components: {*/}
                                        {/*            Radio: {*/}
                                        {/*                colorPrimary: '#7258d8',*/}
                                        {/*                colorPrimaryActive: '#7258d8',*/}
                                        {/*                colorPrimaryHover: '#7258d8',*/}
                                        {/*                colorBorder: 'red',*/}
                                        {/*            },*/}
                                        {/*        },*/}
                                        {/*    } }>*/}
                                        {/*    <Radio.Group*/}
                                        {/*        options={ options }*/}
                                        {/*        onChange={ onChange3 }*/}
                                        {/*        defaultValue={ 2 }*/}
                                        {/*        value={ value3 }*/}
                                        {/*        optionType="button"*/}
                                        {/*        buttonStyle="solid"*/}
                                        {/*        className={ 'border !rounded-[5px] [&>label]:py-[1.27rem] [&>label]:leading-[0px] [&>label]:!border-0 [&>label]:cursor-pointer' }*/}
                                        {/*    />*/}
                                        {/*</ConfigProvider>*/}
                                    </div>

                                </div>
                                {/*<div className={ 'w-1/5' }>*/}
                                {/*    <SelectBox*/}
                                {/*        name={ 'bulldog' }*/}
                                {/*        placeholder={ 'همه' }*/}
                                {/*        initialValue={ 1 }*/}
                                {/*        withoutForm*/}
                                {/*        className={ '!w-full' }*/}
                                {/*    >*/}
                                {/*        <Select.Option value={ 1 }>همه</Select.Option>*/}
                                {/*        <Select.Option value={ 2 }>2</Select.Option>*/}
                                {/*    </SelectBox>*/}
                                {/*</div>*/}
                                {/*<Col className={ '!w-1/5' }>*/}
                                {/*    <SelectBox*/}
                                {/*        name={ 'branch' }*/}
                                {/*        placeholder={ 'شعبه' }*/}
                                {/*        initialValue={ 1 }*/}
                                {/*        withoutForm={ true }*/}
                                {/*        className={ '!w-full' }*/}
                                {/*    >*/}
                                {/*        <Select.Option value={ 1 }>همه</Select.Option>*/}
                                {/*        <Select.Option value={ 2 }>شعبه 2</Select.Option>*/}
                                {/*    </SelectBox>*/}
                                {/*</Col>*/}

                            </div>

                        </div>
                    </Col>


                    <Col span={24} className="--table bg-white shadow-6 mt-[30px]" ref={transactionTableRef}>
                        <Table
                            columns={tableColumns}
                            dataSource={adminComplaintData}
                            bordered
                            tableLayout={'fixed'}
                            rowClassName={response => {
                                if (response?.answer ) {
                                    return '--active'
                                }

                                return '--deActive'
                            }}
                            // rowClassName={response => {
                            //     if (response?.status!==1) {
                            //         return '--statusTrue';
                            //     }
                            //     return '--statusFalse';
                            // }}
                            pagination={{
                                hideOnSinglePage: true,
                                defaultPageSize: page,
                                total: 100,
                                showSizeChanger: false,
                                responsive: true,
                                position: ['bottomLeft'],

                                nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                                   color={'#999999'}
                                                   style={{margin: '6px auto'}}/>,
                                prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                                   color={'#999999'}
                                                   style={{margin: '6px auto'}}/>,

                                // onChange: () => transactionTableRef?.current.scrollIntoView({ behavior: 'smooth' }),
                            }}
                        />
                    </Col>
                </Form>
                <Modal
                    open={ticketModal?.rowId}
                    onCancel={() => setTicketModal({})}
                    size={{
                        sm: 55,
                        xs: 55,
                        md: 80,
                        lg: 80,
                        xl: 80,
                        xxl: 80,
                    }}
                    bodyStyle={{
                        padding: 0,
                    }}
                    style={{
                        top: '10vh',
                    }}
                >

                    <div
                        className={'flex gap-5 items-center px-8 text-[14px]'}>
                        {info.map((item) =>
                            <p onClick={() => setCurrentInfo(item.key)}
                               className={'cursor-pointer relative py-5 '}>{item.title}
                                {
                                    item.key === currentInfo ? (
                                        <motion.div
                                            className={'underline bg-purple h-[5px] rounded-t-[10px] absolute bottom-0 w-full'}
                                            layoutId={'underline'}/>
                                    ) : null
                                }
                            </p>,
                        )}
                    </div>
                    <AnimatePresence mode={'wait'}>
                        <motion.div
                            key={currentInfo || 'initialPage'}
                            initial={{
                                x: 20,
                                opacity: 0,
                            }}
                            animate={{
                                x: 0,
                                opacity: 1,
                            }}
                            exit={{
                                x: -20,
                                opacity: 0,
                            }}
                            transition={{
                                duration: 0.3,
                            }}
                        >
                            <div>
                                {activeInfo?.component}
                            </div>

                        </motion.div>

                    </AnimatePresence>

                </Modal>

            </SubmitContainer>
        </Spin>
    )
        ;
};

export default SubmitComplaint;