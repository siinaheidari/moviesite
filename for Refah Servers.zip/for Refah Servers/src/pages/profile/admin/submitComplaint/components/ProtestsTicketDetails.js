import React from 'react';
import {Button, TextArea} from '../../../../../templates/Ui';
import {Form} from 'antd';
import {useRequest} from '../../../../../utils/useRequest';
import persianCalendar from 'react-date-object/calendars/persian';
import {DateObject} from 'react-multi-date-picker';
import gregorian_en from 'react-date-object/locales/gregorian_en';
import gregorian from 'react-date-object/calendars/gregorian';


const ProtestsTicketDetails = ({ticketModal, setTicketModal}) => {

    const [ticketFormRef] = Form.useForm();


    const {
        isLoading: answerIsLoading,
        mutateAsync: answerRequest,
    } = useRequest({
        path: '/suggestion/update',
        mutationMethod: 'patch',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: 'درخواست شما با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleOffers = async () => {
        const values = ticketFormRef.getFieldsValue(['answer']);
        try {
            await answerRequest({
                rowId: ticketModal?.rowId,
                answer: `"${values?.answer}"`,
                status: ticketFormRef?.status,
            });
            await ticketFormRef.resetFields();
            await setTicketModal({});
        } catch (err) {
            console.log(err);
        }
    };

    const date = ticketModal?.createDate?.split('T')[1]?.split(':');

    return (
        <div className={'mt-2 py-3 px-[30px]'}>
            <div className={'border rounded-lg mb-6 px-8'}>

                <div className={'text-textcolor text-[14px] flex justify-between gap-5 my-7 '}>
                    <p className={'font-[400]'}> کد عضویت: {ticketModal?.personId} </p>
                    <p className={'font-[400]'}> نام پذیرنده: {ticketModal?.personName} </p>
                    <div className={'flex justify-between gap-2'}>
                        <div>
                            تاریخ و ساعت:
                        </div>

                        <div className={'text-[14px] font-[400] text-[#4D4D4D] '}>
                            {

                                new DateObject({
                                    date: new Date(ticketModal?.createDate),
                                    calendar: gregorian,
                                }).convert(persianCalendar, gregorian_en).format(`${date[0]}:${date[1]} - YYYY/MM/DD`)
                            }
                        </div>
                    </div>

                </div>
                <div className={'flex justify-between my-4 gap-8 w-3/4'}>
                    <div className={'text-textcolor text-[14px] w-full'}>
                        <p className={'pb-3 font-[400]'}>عنوان:</p>
                        <p className={'border rounded-lg py-2 px-3 font-[400]'}>شکایات</p>
                    </div>
                    <div className={'text-textcolor text-[14px] w-full'}>
                        <p className={'pb-3 font-[400]'}>موضوع:</p>
                        <p className={'border rounded-lg py-2 px-3 font-[400]'}>اختلال</p>
                    </div>
                </div>
                <div className={'my-6 font-[400]'}>
                    <p className={'pb-5 font-[400]'}>
                        توضیحات:
                    </p>
                    <p className={' bg-[#f5f5f5] px-3 rounded-lg text-[#7a7a7a] leading-[22px] text-justify text-[13px] py-4 font-[400] '}>
                        {ticketModal?.suggestionsDesc}
                    </p>

                    <Form
                        name={'ticket'}
                        form={ticketFormRef}
                        autoComplete="off"
                        labelCol={{
                            span: 24,
                        }}
                        wrapperCol={{
                            span: 24,
                        }}
                        onFinish={handleOffers}
                        className={'mt-[20px]'}
                    >
                        <div>
                            <TextArea
                                name={'answer'}
                                label={'پاسخ دهی:'}
                                placeholder={'پاسخ دهی:'}
                                initialValue={ticketModal?.answer}
                                rules={[{
                                    required: true,
                                    message: 'لطفا پاسخ خود را ثبت نام کنید.',
                                }]}
                                ref={ticketFormRef}
                            />
                        </div>
                        <div className={'items-end text-end mt-[50px] font-[400]'}>
                            <Button htmlType={'submit'} type={'secondary'}
                                    className={'!bg-purple !text-white w-1/4  py-2 rounded-lg'}>ارسال
                            </Button>
                        </div>
                    </Form>
                </div>


            </div>
        </div>
    );
};

export default ProtestsTicketDetails;