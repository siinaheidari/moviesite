import React from 'react';
import {Col, Collapse, Empty, Space} from 'antd';
import {useRequest} from 'utils/useRequest';
import styled from 'styled-components';
import question from 'assets/icons/question.svg';

const CollapseContainer = styled(Collapse)`

  .ant-collapse {
    border: 0 !important;

    border-radius: 50px !important;

    .ant-collapse-item {
      margin-bottom: 18px !important;
      border-radius: 10px !important;
      box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.09);
      
    }


  }

  :where(.css-dev-only-do-not-override-yp8pcc).ant-collapse {
    border: 0px solid white !important;
  }


  .ant-collapse-content-box {
    background-color: #F9F9F9 !important;
  }

  .ant-collapse-content-box {
    padding-top: 20px !important;
    color: #4d4d4d;
    font-size: 12px !important;
    border-radius: 20px;
  }

  //
  //.ant-collapse-expand-icon {
  //  display: none !important;
  //}
`;


const ProtestsOldRequests = ({ticketModal, refetchComplaint}) => {

    const {Panel} = Collapse;

    const {
        isLoading: protestsOldLoading,
        data: protestsOldData,

    } = useRequest({
        path: '/suggestion/list',
        params: {
            personId: ticketModal?.personId
        },
        key: ['protests-old'],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const protestsOldDataRes = protestsOldData;

    const onChange = (key) => {
        console.log(key);
    };

    const date = protestsOldDataRes?.createDate?.split('T')[1]?.split(':');

    return (
        <div>
            <CollapseContainer xs={24} lg={24} className={'px-[30px] my-[30px]'}>
                <Collapse defaultActiveKey={['1']} expandIconPosition={'end'} onChange={onChange} accordion
                          className={'!border-0 '}
                          bordered={false}>
                    {!!protestsOldDataRes ?
                        protestsOldDataRes?.map(item =>
                            <Panel
                                header={<div className={'flex gap-2 justify-between'}>
                                    <Space size={14}>
                                        <img src={question}/>{item?.suggestionsDesc}
                                    </Space>
                                </div>}
                                key={item?.rowId}
                                className={'bg-white'}>
                                <div className={''}> {item?.answer}</div>
                            </Panel>,
                        )
                        : <Col span={24} className="text-center">
                            <Empty description={'چیزی یافت نشد'}/>
                        </Col>
                    }

                </Collapse>
            </CollapseContainer>
        </div>
    );
};

export default ProtestsOldRequests;