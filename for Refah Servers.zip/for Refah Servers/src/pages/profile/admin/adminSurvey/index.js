import React, {useRef, useState} from 'react';
import {Col, Form, Select, Spin} from 'antd';
import {Button, Input, Modal, SelectBox, Table} from '../../../../templates/Ui';
import {inputRule} from '../../../../utils/helper';
import SvgIcon from '../../../../templates/components/SvgIcon';
import {useRequest} from '../../../../utils/useRequest';
import {useAuth} from '../../../../contexts/auth/AuthContext';
import {DateObject} from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';

const AdminSurvey = () => {
    const {auth} = useAuth();
    const [surveyForm] = Form.useForm();
    const [openModal, setOpenModal] = useState(false);
    const tableRef = useRef();

    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);


    const handleOpenModal = (type) => {
        setOpenModal(type);
    };

    const {
        isLoading: pollTypeIsLoading,
        data: pollTypeData,
    } = useRequest({
        path: '/poll/list-poll-type',
        key: ['poll-type'],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const pollTypeDataRes = pollTypeData;


    const {
        isLoading: toolsListLoading,
        data: toolsListData,
        refetch: refetchToolsList,
    } = useRequest({
        path: '/poll/tools-list-poll',
        key: ['tools-list'],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const toolsListRes = toolsListData;
    console.log('fsfdssdf', toolsListRes);

    const {
        isLoading: surveyIsLoading,
        mutateAsync: surveyRequest,
    } = useRequest({
        path: '/poll/tools-insert-poll',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: ' نظرسنجی ها با موفقیت ایجاد شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleSurveyRequest = async () => {
        const values = surveyForm.getFieldsValue(['pollDesc', 'pollTypeId']);
        try {
            await surveyRequest({
                pollDesc: `'${values?.pollDesc}'`,
                pollTypeId: values?.pollTypeId,
            });
            await refetchToolsList();
            surveyForm.resetFields();
        } catch (err) {
            console.log(err);
        }
    };


    const {
        isLoading: pollAnswerIsLoading,
        data: pollAnswerData,
    } = useRequest({
        path: '/poll/list-poll-answer',
        key: ['list-poll-answer'],
        params: {
            pollId: openModal,
            // personId:auth?.userId
        },
        apiType: 'club',
        options: {
            enabled: !!openModal,
            cacheTime: 0,
        },
    });

    const pollAnswerDataRes = pollAnswerData;


    const tableColumns = [
        {
            title: 'عنوان',
            dataIndex: 'pollDesc',
            key: 'pollDesc',
            align: 'center',

        },
        {
            title: 'تاریخ',
            dataIndex: 'totalResponseTime',
            key: 'totalResponseTime',
            align: 'center',
            render: (_, row) => {
                const hour = row?.createDate?.split('T')[1]?.split(':');
                const date = new DateObject({
                    date: new Date(row?.createDate),
                    calendar: gregorian,
                });
                return date.add(7, 'hour').convert(persian).format(`${hour[0]}:${hour[1]} - YYYY/MM/DD`);
            },
        },
        {
            title: 'نوع نظرسنجی',
            dataIndex: 'pollTypeId',
            key: 'pollTypeId',
            align: 'center',
            render: (_, row) => <div className={''}>
                {
                    row.pollTypeId === 1 ? 'کمی' : 'کیفی'
                }
            </div>,
        },
        {
            title: '',
            dataIndex: 'pollTypeId',
            key: 'pollTypeId',
            align: 'center',
            render: (_, row) => <div onClick={() => handleOpenModal(row?.rowId)}
                                     className={'text-blue-400 underline'}>
                مشاهده امتیازات
            </div>
            ,
        },
    ];


    const tableAnswerColumns = [
        {
            title: 'کد پذیرنده',
            dataIndex: 'personId',
            key: 'personId',
            align: 'center',
        },
        {
            title: 'نام و خانوادگی',
            dataIndex: 'personName',
            key: 'personName',
            align: 'center',
        },
        {
            title: 'نوع نظرسنجی',
            dataIndex: 'pollScore',
            key: 'pollScore',
            align: 'center',
            render: (_, row) =>
                row?.pollScore >= 4 ?
                    <div className={'text-lime-400 text-[14px]'}>{row?.pollScore}</div> : row?.pollScore === 3 ?
                        <div className={'text-orange-300 text-[14px]'}>{row?.pollScore}</div> : row?.pollScore <= 2 ?
                            <div className={'text-red-500 text-[14px]'}>{row?.pollScore}</div> : ""


        },
        {
            title: 'تاریخ',
            dataIndex: 'totalResponseTime',
            key: 'totalResponseTime',
            align: 'center',
            render: (_, row) => {
                const hour = row?.createDate?.split('T')[1]?.split(':');
                const date = new DateObject({
                    date: new Date(row?.createDate),
                    calendar: gregorian,
                });
                return date.add(7, 'hour').convert(persian).format(`${hour[0]}:${hour[1]} - YYYY/MM/DD`);
            },
        },
    ];


    return (
        <Spin spinning={surveyIsLoading || pollTypeIsLoading || toolsListLoading}>
            <Form
                form={surveyForm}
                name="suveyFrom"
                autoComplete="off"
                onFinish={handleSurveyRequest}
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
            >
                {/*<div className={"flex justify-between items-center gap-5"}>*/}
                {/*  <div className={"w-full max-w-[350px] mt-3"}>*/}
                {/*    <Input*/}
                {/*      name={'search'}*/}
                {/*      placeholder={"جستجو"}*/}
                {/*      formRef={filterFormRef}*/}
                {/*      suffix=<SearchOutlined style={{color: "#7258d8", fontSize: "16px"}}/>*/}
                {/*    />*/}
                {/*  </div>*/}

                {/*  <div className={"flex gap-3 items-center"}>*/}
                {/*    <div className={"text-center"}>*/}
                {/*      <p>سینا حیدری</p>*/}
                {/*      <p className={"text-[#b6b6b6]"}>مشخصات ادمین</p>*/}
                {/*    </div>*/}
                {/*    <img src={"/images/adminIcon.svg"} width={"60px"}/>*/}
                {/*  </div>*/}
                {/*</div>*/}


            </Form>
            <div className={''}>
                <p className={'font-[500]'}>مدیریت نظرسنجی ها</p>
                <div className={'bg-white p-[23px] leading-[22px] text-textcolor rounded-lg mt-5 '}>
                    <p className={'font-[400] '}> از طریق این بخش می توانید یک نظر سنجی روی سایت فعال کنید.</p>
                    {/*<p className={"font-[400]"}>توجه داشته باشید در صورتی که لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت*/}
                    {/*  چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و*/}
                    {/*  برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.</p>*/}
                </div>
            </div>
            <div>
                <Form
                    form={surveyForm}
                    autoComplete="off"
                    labelCol={{
                        span: 24,
                    }}
                    wrapperCol={{
                        span: 24,
                    }}
                    onFinish={handleSurveyRequest}
                >
                    <div className={'items-center  bg-white rounded-lg p-5 py-10 mt-5'}>
                        <div className={'w-full mt-3'}>

                            <SelectBox
                                name="pollTypeId"
                                label={'نوع نظرسنجی'}
                                placeholder={'نوع نظرسنجی'}
                                showSearch={false}
                                loading={surveyIsLoading}
                                rules={[
                                    {
                                        required: true,
                                        message: 'نوع نظرسنجی را انتخاب نمایید',
                                    },
                                ]}
                                allowClear={false}
                            >
                                {
                                    pollTypeDataRes?.map(item =>
                                        <Select.Option value={item?.rowId}>{item?.pollTypeDesc}</Select.Option>,
                                    )
                                }

                            </SelectBox>

                        </div>
                        {/*<div className={"w-full mt-3"}>*/}
                        {/*  <Input*/}
                        {/*    name={'questions'}*/}
                        {/*    label={"شماره سوال"}*/}
                        {/*    noPlaceHolder*/}
                        {/*    formRef={surveyForm}*/}
                        {/*    rules={[*/}
                        {/*      {*/}
                        {/*        required: true,*/}
                        {/*        message: inputRule('required input', {inputName: 'شماره سوال'})*/}
                        {/*      }*/}
                        {/*    ]}*/}
                        {/*  />*/}
                        {/*</div>*/}
                        <div className={'w-full mt-3'}>
                            <Input
                                name={'pollDesc'}
                                label={'سوال و توضیحات نظرسنجی'}

                                formRef={surveyForm}
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'سوال و توضیحات نظرسنجی'}),
                                    },
                                ]}
                            />
                        </div>
                        <Col span={7} className={'mx-auto mt-[5rem] mb-[1rem]'}>
                            <Button
                                htmlType={'submit'}
                                type={'secondary'}
                                className={'!bg-purple !text-white w-full mt-8 mx-auto'}>درج
                                نظرسنجی
                            </Button>
                        </Col>

                    </div>

                    <Col span={24} className={"pt-[40px] text-[15px] text-center text-textblue"}>
                        لیست نظرسنجی ها
                    </Col>

                    <Col span={24} className="mt-6 mb-14 bg-white rounded-lg" ref={tableRef}>
                        <Table
                            rowClassName={'cursor-pointer'}
                            columns={tableColumns}
                            className="my-form"
                            dataSource={toolsListRes}
                            onChange={({current, pageSize,}) => {
                                setPage(current);
                                setPageSize(pageSize);
                            }}
                            bordered
                            tableLayout={'fixed'}
                            pagination={{
                                hideOnSinglePage: true,
                                defaultPageSize: 10,
                                total: 200,
                                showSizeChanger: true,
                                responsive: true,
                                position: ['bottomLeft'],
                                nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                                   color={'#999999'}
                                                   style={{margin: '6px auto'}}/>,
                                prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                                   color={'#999999'}
                                                   style={{margin: '6px auto'}}/>,
                                // onChange: () => tableRef?.current.scrollIntoView({ behavior: 'smooth' }),
                            }}
                        />
                    </Col>
                </Form>

            </div>


            <Modal
                open={openModal}
                title={''}
                onCancel={() => setOpenModal('')}
                header={false}
                closable={false}
                bodyStyle={{
                    padding: 0,

                }}
                size={{
                    xs: 90,
                    sm: 90,
                    md: 90,
                    lg: 60,
                    xl: 60,
                    xxl: 60,
                }}
                style={{
                    top: '23vh',
                }}>
                <Col span={24} className={"pt-[29px] text-[15px] text-center text-textblue"}>
                    لیست امتیازات
                </Col>
                <Col span={24} className="mt-8 mb-6 bg-white rounded-lg" ref={tableRef}>
                    <Table
                        rowClassName={'cursor-pointer'}
                        columns={tableAnswerColumns}
                        className="my-form"
                        dataSource={pollAnswerDataRes}
                        onChange={({current, pageSize,}) => {
                            setPage(current);
                            setPageSize(pageSize);
                        }}
                        bordered
                        tableLayout={'fixed'}
                        pagination={{
                            hideOnSinglePage: true,
                            defaultPageSize: 10,
                            total: 200,
                            showSizeChanger: true,
                            responsive: true,
                            position: ['bottomLeft'],
                            nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                               color={'#999999'}
                                               style={{margin: '6px auto'}}/>,
                            prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                               color={'#999999'}
                                               style={{margin: '6px auto'}}/>,
                            // onChange: () => tableRef?.current.scrollIntoView({ behavior: 'smooth' }),
                        }}
                    />
                </Col>
            </Modal>

        </Spin>
    );
};

export default AdminSurvey;