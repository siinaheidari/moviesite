import React, { useState } from 'react';
import { Button, Col, ConfigProvider, Form, Radio, Row, Space } from 'antd';
import merchantNumber from '../../../../../assets/images/adminhome/merchantNumber.svg';
import allTransactions from '../../../../../assets/images/adminhome/allTransactions.svg';
import happyMerchant from '../../../../../assets/images/adminhome/happyMerchant.svg';
import sadMerchant from '../../../../../assets/images/adminhome/sadMerchant.svg';
import num1 from '../../../../../assets/icons/adminhomeIcon/1.svg';
import num2 from '../../../../../assets/icons/adminhomeIcon/2.svg';
import num3 from '../../../../../assets/icons/adminhomeIcon/3.svg';
import num4 from '../../../../../assets/icons/adminhomeIcon/4.svg';
import num5 from '../../../../../assets/icons/adminhomeIcon/5.svg';
import num6 from '../../../../../assets/icons/adminhomeIcon/6.svg';
import num7 from '../../../../../assets/icons/adminhomeIcon/7.svg';
import num8 from '../../../../../assets/icons/adminhomeIcon/8.svg';
import num9 from '../../../../../assets/icons/adminhomeIcon/9.svg';
import { DatePicker } from '../../../../../templates/Ui';
import { DateObject } from 'react-multi-date-picker';
import persian from 'react-date-object/calendars/persian';
import gregorian from 'react-date-object/calendars/gregorian';
import { inputRule } from '../../../../../utils/helper';

const TopSection = () => {
  
  const [ filterFormRef ] = Form.useForm();
  
  const [ value3, setValue3 ] = useState(1);
  
  const currentData = new DateObject({ calendar: persian });
  const currentData2 = new DateObject({ calendar: persian });
  
  const lastDayDate = new DateObject({ calendar: persian });
  const lastDayDate2 = new DateObject({ calendar: persian });
  
  const [ startDate, setStartDate ] = useState(lastDayDate2?.subtract(1, 'day')
    ?.convert(gregorian)
    ?.format('YYYY-MM-DD'));
  const [ endDate, setEndDate ] = useState(currentData2?.convert(gregorian)
    ?.format('YYYY-MM-DD'));
  
  const items = [
    
    {
      title: 'تعداد شرکت در نظرسنجی',
      value: 54321,
      icon: num1,
    },
    {
      title: 'تعداد شرکت کنندگان مسابقه',
      value: 4321,
      icon: num2,
    },
    {
      title: 'تعداد طرح هاو کمپین های جاری',
      value: 4321,
      icon: num3,
    },
    {
      title: 'کاربران فعال',
      value: 54321,
      icon: num4,
    },
    {
      title: 'کاربران غیرفعال',
      value: 321,
      icon: num5,
    },
    {
      title: 'موجودی کیف پول پذیرندگان',
      value: 4321,
      icon: num6,
    },
    {
      title: 'درخواست اتصال به شرکای تجاری',
      value: 54321,
      icon: num7,
    },
    {
      title: 'تعداد کل شعبات',
      value: 4321,
      icon: num8,
    },
    {
      title: 'تعداد شکایات',
      value: 4321,
      icon: num9,
    },
  
  ];
  
  
  const options = [
    {
      label: 'امروز',
      value: 1,
    },
    {
      label: 'هفته',
      value: 7,
    },
    {
      label: 'ماه',
      value: 30,
    },
    {
      label: 'سال',
      value: 365,
    },
  ];
  
  
  const onChange3 = ({ target: { value } }) => {
    console.log('radio3 checked', value);
    setValue3(value);
  };
  
  
  const handleFilter = values => {
    setStartDate(() => {
      return new DateObject({
        date: values?.startDate,
        calendar: persian,
      })?.convert(gregorian)
        .format('YYYY-MM-DD');
    });
    
    setEndDate(() => {
      return new DateObject({
        date: values?.endDate,
        calendar: persian,
      })?.convert(gregorian)
        .format('YYYY-MM-DD');
    });
  };
  
  
  return (
    <Row>
      
      <Col span={ 24 }>
        <Row gutter={ 20 }>
          <Col span={ 6 }>
            <div
              className={ 'bg-[#D1E7DD] border border-[#BADBCC] rounded-[5px] py-[16px] px-[23px] text-textcolor font-[500] text-[14px]' }>
              <Space align={ 'center' }>
                <div
                  className={ 'w-[40px] h-[40px] bg-[#198754] items-center text-center flex justify-center rounded-[5px] ml-[14px]' }>
                  <img src={ merchantNumber } className={ '' }/>
                </div>
                
                <div>
                  تعداد پذیرندگان
                  <div className={ 'mt-[4px]' }>654321</div>
                </div>
              </Space>
            </div>
          </Col>
          <Col span={ 6 }>
            <div
              className={ 'bg-[#F8D7DA] border border-[#F5C2C7] rounded-[5px] py-[16px] px-[23px] text-textcolor font-[500] text-[14px]' }>
              <Space align={ 'center' }>
                <div
                  className={ 'w-[40px] h-[40px] bg-[#DC3545] items-center text-center flex justify-center rounded-[5px] ml-[14px]' }>
                  <img src={ allTransactions }/>
                </div>
                
                <div>
                  میزان کل تراکنش ها
                  <div className={ 'mt-[4px]' }>$987654321</div>
                </div>
              </Space>
            </div>
          </Col>
          <Col span={ 6 }>
            <div
              className={ 'bg-[#FFF3CD] border border-[#FFECB5] rounded-[5px] py-[16px] px-[23px] text-textcolor font-[500] text-[14px]' }>
              <Space align={ 'center' }>
                <div
                  className={ 'w-[40px] h-[40px] bg-[#FFC107] items-center text-center flex justify-center rounded-[5px] ml-[14px]' }>
                  <img src={ happyMerchant }/>
                </div>
                
                <div>
                  مشتریان راضی
                  <div className={ 'mt-[4px]' }>654321</div>
                </div>
              </Space>
            </div>
          </Col>
          <Col span={ 6 }>
            <div
              className={ 'bg-[#CFF4FC] border border-[#B6EFFB] rounded-[5px] py-[16px] px-[23px] text-textcolor font-[500] text-[14px]' }>
              <Space align={ 'center' }>
                <div
                  className={ 'w-[40px] h-[40px] bg-[#0DCAF0] items-center text-center flex justify-center rounded-[5px] ml-[14px]' }>
                  <img src={ sadMerchant }/>
                </div>
                
                <div>
                  مشتریان ناراضی
                  <div className={ 'mt-[4px]' }>654321</div>
                </div>
              </Space>
            </div>
          </Col>
        </Row>
      </Col>
      <Col span={ 24 } className={ 'mt-[26px]' }>
        <Row gutter={ 10 } justify={ 'space-between' }>
          <Col xs={24} md={10}>
            <ConfigProvider
              theme={ {
                components: {
                  Radio: {
                    colorPrimary: '#7258d8',
                    colorPrimaryActive: '#7258d8',
                    colorPrimaryHover: '#7258d8',
                  },
                },
              } }>
              <Radio.Group
                options={ options }
                onChange={ onChange3 }
                defaultValue={2}
                value={ value3 }
                optionType="button"
                buttonStyle="solid"
                className={ 'border !rounded-[5px] [&>label]:py-[1.27rem] [&>label]:leading-[0px] [&>label]:!border-0 [&>label]:cursor-pointer' }
              />
            </ConfigProvider>
          </Col>
          <Col xs={24} md={14}>
            <Form
              form={ filterFormRef }
              name="indexFrom"
              autoComplete="off"
              scrollToFirstError
              labelCol={ {
                span: 24,
              } }
              wrapperCol={ {
                span: 24,
              } }
              onFinish={ handleFilter }
            >
              <Row gutter={ 16 } justify={ 'end' }>
                <Col span={ 6 }>
                  <DatePicker
                    name={ 'startDate' }
                    placeholder={ 'از تاریخ' }
                    hiddenLabel
                    initialValue={ lastDayDate?.subtract(1, 'day')
                      .format('YYYY-MM-DD') }
                    rules={ [
                      {
                        required: true,
                        message: inputRule('required selectBox', { inputName: 'تاریخ ' }),
                      },
                    ] }
                    rtl
                  />
                </Col>
                <Col span={ 6 }>
                  <DatePicker
                    name={ 'endDate' }
                    placeholder={ 'تا تاریخ' }
                    hiddenLabel
                    initialValue={ currentData.format('YYYY-MM-DD') }
                    
                    rules={ [
                      {
                        required: true,
                        message: inputRule('required selectBox', { inputName: 'تاریخ ' }),
                      },
                    ] }
                    rtl
                  />
                </Col>
                
                <Col span={ 4 } className="text-end pb-6">
                  <Button onClick={ handleFilter } className={ 'bg-purple h-[42px] text-white rounded-lg !w-full' }>
                    اعمال
                  </Button>
                </Col>
              </Row>
            </Form>
          
          </Col>
        </Row>
      
      </Col>
      <Col span={ 24 } className={ 'mt-[10px]' }>
        <Row gutter={ [ 19, 16 ] } align={ 'stretch' } >
          {
            items.map((item) => (
              <Col span={ 8 }>
                <div
                  className={ 'bg-white border border-[#F0F0F0] rounded-[5px] py-[16px] pr-[37px] text-textcolor font-[500] text-[14px]' }>
                  <div className={ 'flex justify-between gap-2 items-center' }>
                    <div>
                      <div>{ item.title }</div>
                      <div className={ 'mt-[4px] font-[400]' }>{ item.value }</div>
                    </div>
                    <div
                      className={ 'w-[40px] h-[40px]  items-center text-center flex justify-between rounded-[5px] ml-[14px]' }>
                      <img src={ item.icon }/>
                    </div>
                  </div>
                </div>
              
              </Col>
            ))
          }
        </Row>
      </Col>
    </Row>
  
  );
};

export default TopSection;
