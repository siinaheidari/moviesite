import React, { useRef } from 'react';
import { Col, Row, Select } from 'antd';
import { Input, SelectBox, Table } from '../../../../../templates/Ui';
import { inputRule } from '../../../../../utils/helper';
import { Link } from 'react-router-dom';
import SvgIcon from '../../../../../templates/components/SvgIcon';

const BottomSection = () => {
  
  const tableRef = useRef();
  
  const tableColumns = [
    {
      title: 'نام',
      dataIndex: 'firstName',
      key: 'firstName',
      align: 'center'
    },
    {
      title: 'نام خانوادگی',
      dataIndex: 'lastName',
      key: 'lastName',
      align: 'center'
    },
    {
      title: 'شماره ترمینال',
      dataIndex: 'memberNumber',
      key: 'memberNumber',
      align: 'center'
    },
    {
      title: 'نوع پایانه درخواستی',
      dataIndex: 'terminalType',
      key: 'terminalType',
      align: 'center'
    },
    {
      title: 'شعبه',
      dataIndex: 'branch',
      key: 'branch',
      align: 'center'
    },
    {
      title: 'کد شعبه',
      dataIndex: 'branchCode',
      key: 'branchCode',
      align: 'center'
    },
    {
      title: 'تاریخ',
      dataIndex: 'date',
      key: 'date',
      align: 'center'
    },
    {
      title: 'ساعت',
      dataIndex: 'time',
      key: 'time',
      align: 'center'
    },
    {
      title: '...',
      dataIndex: 'action',
      key: 'action',
      align: 'center',
      render: (_, {merchantNumber}) => <Link to={""} className={"underline !text-[#407BFF]"}>جزئیات</Link>
    }
  ];
  
    const Mock = [
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      },
      {
        id: 1,
        terminal: 215465,
        terminalType: 'پایانه های بی سیم',
        memberNumber: '0258569',
        firstName: 'نجمه',
        lastName: 'علوی',
        date: '1401-08-02',
        time: '16:21',
        branch: 'ونک',
        branchCode: '035'
      }
    ];

  
  return (
    <Row>
      <Col span={ 24 } className={ 'bg-white pt-[33px] pb-[69] rounded-[5px] border-b'}>
        <Row gutter={ 20 } justify={ 'space-between' } align={ 'middle' } className={ 'px-[34px]' }>
          <Col  className={ 'text-16px' }>
            گزارش پذیرندگان اخیر
          </Col>
          <Col span={ 18 }>
            <Row gutter={14} justify={"end"}>
              <Col xl={ 4 } md={ 6 }>
                <SelectBox
                  name="branch"
                  placeholder="انتخاب شعبه"
                  rules={ [
                    {
                      required: true,
                      message: 'شعبه را انتخاب نمایید',
                    },
                  ] }
                  allowClear={ false }
                >
                  <Select.Option value={ 'all' }>همه</Select.Option>
                  <Select.Option value={ 1 }>شعبه 1</Select.Option>
                  <Select.Option value={ 2 }>شعبه 2</Select.Option>
                </SelectBox>
              </Col>
              <Col xl={ 4 } md={ 6 }>
                <SelectBox
                  name="branch"
                  placeholder="انتخاب شعبه"
                  rules={ [
                    {
                      required: true,
                      message: 'شعبه را انتخاب نمایید',
                    },
                  ] }
                  allowClear={ false }
                >
                  <Select.Option value={ 'all' }>همه</Select.Option>
                  <Select.Option value={ 1 }>شعبه 1</Select.Option>
                  <Select.Option value={ 2 }>شعبه 2</Select.Option>
                </SelectBox>
              </Col>
              <Col xl={ 4 } md={ 6 }>
                <SelectBox
                  name="branch"
                  placeholder="انتخاب شعبه"
                  rules={ [
                    {
                      required: true,
                      message: 'شعبه را انتخاب نمایید',
                    },
                  ] }
                  allowClear={ false }
                >
                  <Select.Option value={ 'all' }>همه</Select.Option>
                  <Select.Option value={ 1 }>شعبه 1</Select.Option>
                  <Select.Option value={ 2 }>شعبه 2</Select.Option>
                </SelectBox>
              </Col>
            </Row>
          </Col>
        </Row>
      </Col>
      <Col span={24} className={'px-[32px] pt-[32px] mb-[20px]'}>
        <Row justify={"end"} gutter={14}>
          <Col span={5}>
            <Input
              name={ 'nationalCode' }
              placeholder={"جستجو شماره ترمینال"}
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'کد ملی' })
                }
              ]}
              maxLength={ 10 }
              justNumber
              // formRef={ formRef }
              rtl
              focus
            />
          </Col>
          <Col span={3} className='text-end pb-6'>
            <button className={"bg-purple text-white h-[41px] rounded-lg w-full shadow-shadow"}>
              جستجو
            </button>
          </Col>
        </Row>
      </Col>
      <Col span={ 24 } ref={ tableRef }>
        <Table
          columns={ tableColumns }
          // loading={isLoading}
          dataSource={ Mock }
          // onChange={({current}) => setPage(current)}
          bordered
          tableLayout={ 'fixed' }
          pagination={ {
            hideOnSinglePage: true,
            defaultPageSize: 20,
            total: 200,
            showSizeChanger: false,
            responsive: true,
            position: ['bottomLeft'],
            nextIcon: <SvgIcon icon={ 'leftCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                               style={ { margin: '6px auto' } }/>,
            prevIcon: <SvgIcon icon={ 'rightCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                               style={ { margin: '6px auto' } }/>,
            onChange: () => tableRef?.current.scrollIntoView({ behavior: 'smooth' })
          } }
        />
      </Col>
    </Row>
  );
};

export default BottomSection;
