import React from 'react';
import { Col, Row, Select } from 'antd';
import { SelectBox } from '../../../../../templates/Ui';

const MiddleSection = () => {
  
  
  const branches=[
    
    {
      name:"تعداد کل تراکنش ها",
      value:54321,
    },  {
      name:"تعداد پذیرنده فعال",
      value:54321,
    },  {
      name:"تعداد پذیرنده غیرفعال",
      value:5664,
    },  {
      name:"تعداد پایانه های جدیدا متصل شده",
      value:54321,
    },  {
      name:"منابع متصل به پوز",
      value:54321,
    },  {
      name:"تعداد پایانه فعال",
      value:54321,
    },  {
      name:"تعداد پایانه غیر فعال",
      value:54321,
    },  {
      name:"مبلغ کل تراکنش ها",
      value:54321,
    },
  ]
  
  return (
    <Row>
      <Col span={24} className={"bg-white pt-[33px] pb-[69] rounded-[5px]"}>
        <Row gutter={20} justify={"space-between"} align={"middle"} className={"px-[34px]"}>
          <Col span={4} className={"text-[16px]"}>
            گزارش شعبه ها
          </Col>
          <Col xl={4} md={6}>
            <SelectBox
              name="branch"
              placeholder="انتخاب شعبه"
              rules={[
                {
                  required: true,
                  message: 'شعبه را انتخاب نمایید'
                },
              ]}
              allowClear={false}
            >
              <Select.Option value={"all"}>همه</Select.Option>
              <Select.Option value={1}>شعبه 1</Select.Option>
              <Select.Option value={2}>شعبه 2</Select.Option>
            </SelectBox>
          </Col>
        </Row>
      </Col>
      
      <Col span={24} className={"px-[50px] pt-[14px] pb-[69px]"}>
        <Row gutter={[20,20]}>
          {
            branches.map((item)=>
              <Col span={8}>
                <div className={"bg-[#F9F9F9] border border-[#DEDEDE] rounded-[5px] font-[500] text-[14px] text-[#7A7A7A] px-[21px] py-[15px]"}>
                  {item.name}
                  <div className={"font-[400] text-[#4D4D4D] mt-[22px]"}>
                    {item.value}
                  </div>
                </div>
              </Col>
          )
          }
        </Row>
      </Col>
    </Row>
  );
};

export default MiddleSection;
