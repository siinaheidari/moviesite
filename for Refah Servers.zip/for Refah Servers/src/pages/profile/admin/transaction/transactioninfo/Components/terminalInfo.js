import React, {useRef} from 'react';
import {Col, Divider, Form, Row, Select, Spin} from "antd";
import {
  RadioButton,
  RadioFormItem,
  RadioGroup, SelectBox,
  Table
} from "../../../../../../templates/Ui";
import SvgIcon from "../../../../../../templates/components/SvgIcon";
import {formatNumber} from "../../../../../../utils/helper";

const TerminalInfo = () => {

  const [TerminalFormRef] = Form.useForm();
  const transactionTableRef = useRef(null);

  const handleChangeFilter = formData => {
    console.log(formData);
  };

  const tableColumns = [
    {
      title: 'کد ترمینال',
      dataIndex: 'terminal',
      key: 'terminal',
      align: 'center'
    },
    {
      title: 'نوع ترمینال',
      dataIndex: 'portType',
      key: 'portType',
      align: 'center'
    },
    {
      title: 'شرکت PSP',
      dataIndex: 'PSPInc',
      key: 'PSPInc',
      align: 'center'
    },
    {
      title: 'تاریخ راه اندازی',
      dataIndex: 'transactionNumber',
      key: 'transactionNumber',
      align: 'center'
    },
    {
      title: ' شماره سریال',
      dataIndex: 'date',
      key: 'date',
      align: 'center'
    },
    {
      title: 'مدل سخت‌افزار',
      dataIndex: 'time',
      key: 'time',
      align: 'center'
    },
    {
      title: 'پورت دسترسی',
      dataIndex: 'trackingCode',
      key: 'trackingCode',
      align: 'center'
    },
    {
      title: 'آدرس دسترسی',
      dataIndex: 'cardNumber',
      key: 'cardNumber',
      align: 'center'
    },
    {
      title: 'جزئیات',
      dataIndex: 'cardNumber',
      key: 'cardNumber',
      align: 'center'
    },
  ];

  const transactions = [
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: "جزئیات",
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    }
  ];


  return (
    <Spin spinning={false}>
      <div className={"pt-6 "}>
        <Form
          form={TerminalFormRef}
          name='indexFrom'
          autoComplete='off'
          scrollToFirstError
          labelCol={{
            span: 24
          }}
          wrapperCol={{
            span: 24
          }}
          onFinish={handleChangeFilter}
        >
          <Row gutter={[0, 30]}>
            <Col span={24} className='--filters'>
              <Col span={24}>
                <Row gutter={16} justify={'space-between'}>
                  <Col span={6}>
                    <p className={"text-textcolor"}>امتیاز کسب شده پذیرنده از این قسمت:</p>
                  </Col>
                </Row>
              </Col>
              <Divider/>

              <Col span={24}>
                <Row gutter={16} justify={'space-between'}>

                    <Col span={10}>
                      <p> شماره مشتری:<span> 456845456345</span></p>
                    </Col>

                    <Col span={5}>
                      <SelectBox
                        name="status"
                        placeholder="وضعیت تراکنش"
                        rules={[
                          {
                            required: true,
                            message: 'وضعیت تراکنش را انتخاب نمایید'
                          },
                        ]}
                        allowClear={false}
                      >
                        <Select.Option value={"all"}>همه</Select.Option>
                        <Select.Option value={'true'}>درگاه پرداخت</Select.Option>
                        <Select.Option value={'false'}>POS</Select.Option>
                      </SelectBox>
                    </Col>
                  </Row>
              </Col>

            </Col>

            <Col span={24} className='--table' ref={transactionTableRef}>
              <Table
                columns={tableColumns}
                dataSource={transactions}
                bordered
                tableLayout={'fixed'}
                pagination={{
                  hideOnSinglePage: true,
                  defaultPageSize: 10,
                  total: 30,
                  showSizeChanger: false,
                  responsive: true,
                  position: ['bottomLeft'],
                  nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20} color={'#999999'}
                                     style={{margin: '6px auto'}}/>,
                  prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20} color={'#999999'}
                                     style={{margin: '6px auto'}}/>,
                  onChange: () => transactionTableRef?.current.scrollIntoView({behavior: 'smooth'})
                }}
              />
            </Col>
          </Row>
        </Form>
      </div>
    </Spin>
  );
};

export default TerminalInfo;