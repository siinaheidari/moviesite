import React, {useRef} from 'react';
import {Col, Divider, Form, Row, Select, Spin} from "antd";
import {
  RadioButton,
  RadioFormItem,
  RadioGroup,
  Table
} from "../../../../../../templates/Ui";
import SvgIcon from "../../../../../../templates/components/SvgIcon";
import {formatNumber} from "../../../../../../utils/helper";

const BankInfo = () => {

  const [bankInfoFormRef] = Form.useForm();
  const transactionTableRef = useRef(null);

  const handleChangeFilter = formData => {
    console.log(formData);
  };

  const tableColumns = [
    {
      title: 'ردیف',
      dataIndex: 'terminal',
      key: 'terminal',
      align: 'center'
    },
    {
      title: 'نوع حساب',
      dataIndex: 'portType',
      key: 'portType',
      align: 'center'
    },
    {
      title: 'شماره حساب',
      dataIndex: 'PSPInc',
      key: 'PSPInc',
      align: 'center'
    },
    {
      title: 'شماره شبا',
      dataIndex: 'transactionNumber',
      key: 'transactionNumber',
      align: 'center'
    },
    {
      title: ' موجودی حساب (ریال)',
      dataIndex: 'date',
      key: 'date',
      align: 'center',
      render: (_, {transactionAmount}) => formatNumber(transactionAmount)
    },
    {
      title: 'ترمینال متصل',
      dataIndex: 'time',
      key: 'time',
      align: 'center'
    },
    {
      title: 'تاریخ راه اندازی',
      dataIndex: 'trackingCode',
      key: 'trackingCode',
      align: 'center'
    },
    {
      title: 'تاریخ جمع‌آوری',
      dataIndex: 'cardNumber',
      key: 'cardNumber',
      align: 'center'
    },
  ];

  const transactions = [
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 1,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 2,
      terminal: 45345346,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234434589012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 54784547478781025,
      transactionAmount: 802000,
      score: 50,
      status: true
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 5,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 6,
      terminal: 215465,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 7,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 8,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 9,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 3,
      terminal: 21675,
      portType: 'POS',
      PSPInc: 'ایران کیش',
      transactionNumber: 1234435789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498345456,
      cardNumber: 5478513454781025,
      transactionAmount: 100000,
      score: 100,
      status: true
    },
    {
      id: 4,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: true
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    },
    {
      id: 10,
      terminal: 215465,
      portType: 'درگاه پرداخت',
      PSPInc: 'ایران کیش',
      transactionNumber: 123456789012,
      date: '1401-08-02',
      time: '16:21',
      trackingCode: 5498789456,
      cardNumber: 5478512654781025,
      transactionAmount: 500000,
      score: 100,
      status: false
    }
  ];

  return (
    <Spin spinning={false}>
      <div className={"pt-6 "}>
        <Form
          form={bankInfoFormRef}
          name='indexFrom'
          autoComplete='off'
          scrollToFirstError
          labelCol={{
            span: 24
          }}
          wrapperCol={{
            span: 24
          }}
          onFinish={handleChangeFilter}
        >
          <Row gutter={[0, 30]}>
            <Col span={24} className='--filters'>
              <Col span={24}>
                <Row gutter={16} justify={'space-between'}>
                  <Col span={6}>
                    <p className={"text-textcolor"}>امتیاز کسب شده پذیرنده از این قسمت:</p>
                  </Col>
                </Row>
              </Col>
              <Divider/>

              <Col span={24}>
                <Row gutter={16} justify={'space-between'}>
                  <p> شماره مشتری:<span> 456845456345</span></p>
                  <Col span={6}>
                    <RadioFormItem
                      name={'input1'}
                    >
                      <RadioGroup defaultValue={'test'} block>
                        <RadioButton value={'test'}>
                          همه
                        </RadioButton>

                        <RadioButton value={'test1'}>
                          درگاه پرداخت
                        </RadioButton>

                        <RadioButton value={'test2'}>
                          POS
                        </RadioButton>
                      </RadioGroup>
                    </RadioFormItem>
                  </Col>
                </Row>
              </Col>

            </Col>

            <Col span={24} className='--table' ref={transactionTableRef}>
              <Table
                columns={tableColumns}
                dataSource={transactions}
                bordered
                tableLayout={'fixed'}
                pagination={{
                  hideOnSinglePage: true,
                  defaultPageSize: 10,
                  total: 30,
                  showSizeChanger: false,
                  responsive: true,
                  position: ['bottomLeft'],
                  nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20} color={'#999999'}
                                     style={{margin: '6px auto'}}/>,
                  prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20} color={'#999999'}
                                     style={{margin: '6px auto'}}/>,
                  onChange: () => transactionTableRef?.current.scrollIntoView({behavior: 'smooth'})
                }}
              />
            </Col>
          </Row>
        </Form>
      </div>
    </Spin>
  );
};

export default BankInfo;