import React, {useState} from 'react';
import {Divider} from "antd";
import {toast} from "react-toastify";

const InviteFriends = () => {
  const text = " http://localhost:3002/admin/managements/merchants"

const handleCopy=()=>{
  navigator.clipboard.writeText(text)
    .then(()=>{
      toast.success("کپی شد")
    })
}




  return (
    <div className={"px-3 mt-[20px] min-h-[624px] text-textcolor text-[14px]"}>
      <p className={"text-textcolor py-2"}>امتیاز کسب شده پذیرنده از این قسمت: ۵ امتیاز</p>
      <Divider/>
      <div className={"py-8"}>
        <p>لینک ویژه پذیرنده برای ارسال به دوستان:</p>
        <div className={"flex items-center py-8"}>
          <p className={"border rounded-r-lg p-2 h-12 leading-8"}>{text}</p>
          <button onClick={handleCopy} className={"bg-gray-800 text-white h-12 w-[7rem] rounded-l-md hover:bg-purple"}>کپی لینک
          </button>
        </div>
      </div>
      <p>گزارش فعالیت‌ها</p>
      <Divider/>
    </div>
  );
};

export default InviteFriends;