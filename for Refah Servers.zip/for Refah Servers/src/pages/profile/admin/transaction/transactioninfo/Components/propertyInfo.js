import React from 'react';
import {Button, Col, Divider, Form, Row, Select} from "antd";
import {DatePicker, Input, SelectBox} from "../../../../../../templates/Ui";
import {inputRule} from "../../../../../../utils/helper";
import {useRequest} from "../../../../../../utils/useRequest";

const PropertyInfo = () => {
  const [propertyInfoForm]=Form.useForm()
  const countryWatch = Form.useWatch("country", propertyInfoForm)
  const stateWatch = Form.useWatch("state", propertyInfoForm)
  const cityWatch = Form.useWatch("city", propertyInfoForm)
  const ownershipType = Form.useWatch("ownershipType", propertyInfoForm)

  console.log(ownershipType?.toString() === '0')

  const {isLoading: ownershipLoading, data: ownershipData} = useRequest({
    path: "/api/v1/merchant/list-ownership-type",
    key: ["ownership"],
    apiType: "admin"
  })
  const ownershipRes = ownershipData?.output || []

  const {isLoading: countryLoading, data: countryData} = useRequest({
    path: "/api/v1/setting/location-list-country",
    key: ["country"],
    apiType: "admin"
  })
  const countryRes = countryData?.output || []

  const {isLoading: stateLoading, data: stateData} = useRequest({
    path: "/api/v1/setting/location-list-state?rowPage=100&pageNumber=1",
    params: {
      StateCode: propertyInfoForm.getFieldValue("country")
    },
    key: ["state", countryWatch],
    apiType: "admin",
    options:{
      enabled:!!countryWatch,
      retry:false
    }
  })

  const stateDataRes = stateData?.output || []

  const {isLoading: cityLoading, data: cityData} = useRequest({
    path: "/api/v1/setting/location-list-city?rowPage=100&pageNumber=1",
    params: {
      StateCode: propertyInfoForm.getFieldValue("state")
    },
    key: ["city", stateWatch],
    apiType: 'admin',
    options: {
      enabled: !!stateWatch,
      retry: false
    }
  })
  const cityDataRes = cityData?.output || []

  const {isLoading: areaLoading, data: areaData} = useRequest({
    path: "/api/v1/setting/location-list-area?rowPage=100&pageNumber=1",
    params: {
      CityCode: propertyInfoForm.getFieldValue("city")
    },
    key: ["city", cityWatch],
    apiType: 'admin',
    options: {
      enabled: !!cityWatch,
      retry: false
    }
  })
  const areaDataRes = areaData?.output || []

  const goz=propertyInfoForm.getFieldsValue(true)
  console.log(goz)

  return (
    <div className={"px-3 mt-[20px] min-h-[624px] relative"}>
      <Form
        form={propertyInfoForm}
        name='shopInfo'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
      >
        <Col span={6}>
          <p className={"text-textcolor"}>امتیاز کسب شده پذیرنده از این قسمت: ۵ امتیاز</p>
        </Col>
        <Divider/>
        <Row gutter={[50, 10]} className={"relative"}>
          <Col xs={24} md={6} lg={6}>
            <SelectBox
              name={'ownershipType'}
              label={'نوع ملک'}
              loading={ownershipLoading}
              rules={[
                {
                  required: true,
                  message: inputRule('required selectBox', {inputName: 'نوع ملک'})
                }
              ]}
              onChange={val => {
                if (val === 0) {
                  propertyInfoForm.setFields([
                    {
                      name: 'rentalExpiryDate',
                      value: null,
                      errors: []
                    }
                  ])
                }
              }}
            >
              {
                ownershipRes.map((item) =>
                  <Select.Option value={item.ownershipTypeID}>{item.ownershipTypeDesc}</Select.Option>
                )
              }
            </SelectBox>
          </Col>

          <Col xs={24} md={6} lg={6}>
            <DatePicker
              name={'rentalExpiryDate'}
              label={'تاریخ پایان قرارداد اجاره'}
              minDate
              rules={[
                {
                  required: ownershipType?.toString() === '0' ? false : true,
                  message: inputRule('required input', {inputName: 'تاریخ پایان قرارداد اجاره'})
                }
              ]}
              formRef={propertyInfoForm}
              ltr
              disabled={ownershipType === 0 ? true : false}
            />
          </Col>
          <Col xs={24} md={6} lg={6}>
            <Input
              name={'taxCode'}
              label={'کد مالیاتی'}
              rules={[
                {
                  required: true,
                  message: inputRule('required input', {inputName: 'کد مالیاتی'})
                }
              ]}
              formRef={propertyInfoForm}
              justNumber
              maxLength={12}
              ltr
            />
          </Col>

          <Col xs={24} md={6} lg={6}>
            <Input
              name={'branchCode'}
              label={'کد شبعه'}
              rules={[
                {
                  required: true,
                  message: inputRule('required input', {inputName: 'کد شبعه'})
                }
              ]}
              formRef={propertyInfoForm}
              justNumber
              maxLength={12}
              ltr
            />
          </Col>

          <Col xs={24} md={8} lg={6}>
            <SelectBox
              name={'country'}
              label={'کشور'}
              loading={countryLoading}
              rules={[
                {
                  required: true,
                  message: inputRule('required selectBox', {inputName: 'کشور'})
                }
              ]}
            >
              {
                countryRes.map((item) =>
                  <Select.Option value={item.CountryCode}>{item.CountryName}</Select.Option>
                )
              }
            </SelectBox>
          </Col>

          <Col xs={24} md={8} lg={6}>
            <SelectBox
              name={'state'}
              label={'استان'}
              loading={stateLoading}
              rules={[
                {
                  required: true,
                  message: inputRule('required selectBox', {inputName: 'استان'})
                }
              ]}
            >
              {
                stateDataRes.map((item) =>
                  <Select.Option value={item.StateCode}>{item.StateName}</Select.Option>
                )
              }

            </SelectBox>
          </Col>

          <Col xs={24} md={8} lg={6}>
            <SelectBox
              name={'city'}
              label={'شهر'}
              loading={cityLoading}
              rules={[
                {
                  required: true,
                  message: inputRule('required selectBox', {inputName: 'شهر'})
                }
              ]}
            >
              {
                cityDataRes.map((item) =>
                  <Select.Option value={item.CityCode}>{item.CityName}</Select.Option>
                )
              }
            </SelectBox>
          </Col>

          <Col xs={24} md={8} lg={6}>
            <SelectBox
              name={'area'}
              label={'شهرستان'}
              loading={areaLoading}
              rules={[
                {
                  required: true,
                  message: inputRule('required selectBox', {inputName: 'شهر'})
                }
              ]}
            >
              {
                areaDataRes.map((item) =>
                  <Select.Option value={item.AreaNumber}>{item.AreaName}</Select.Option>
                )
              }
            </SelectBox>
          </Col>

          <Col xs={24} md={12} lg={8}>
            <Input
              name={'postalCode'}
              label={'کد پستی'}
              rules={[
                {
                  required: true,
                  message: inputRule('required input', {inputName: 'کد پستی'})
                }
              ]}
              formRef={propertyInfoForm}
              ltr
            />
          </Col>
          <Col xs={24} md={12} lg={16}>
            <Input
              name={'address'}
              label={'آدرس'}
              rules={[
                {
                  required: true,
                  message: inputRule('required input', {inputName: 'آدرس'})
                }
              ]}
              formRef={propertyInfoForm}
              // onPressEnter={}
            />
          </Col>
        </Row>
        <Form.Item className={"w-full text-end items-end pt-5 absolute bottom-3 left-4"}>
          <Button className={" w-1/4 h-[42px] text-purple-400 border border-purple-400"} htmlType="submit">
            ویرایش
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default PropertyInfo;