import React from 'react';
import {Button, Divider} from "antd";

const RequestsList = () => {
  return (
    <div className={"px-3 mt-[20px] min-h-[624px] text-textcolor text-[14px] relative"}>
      <p className={"text-textcolor py-2"}>امتیاز کسب شده پذیرنده از این قسمت: ۵ امتیاز</p>
      <Divider/>
      <div className={"absolute bottom-0 left-5 w-full text-end items-end"}>
        <Button className={" w-1/4 h-[42px] text-purple-400 border border-purple-400"} htmlType="submit">
          ویرایش
        </Button>
      </div>

    </div>
  );
};

export default RequestsList;