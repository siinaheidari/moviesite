import React, {useState} from 'react';
import IncreaseMoneyAdmin from "./merchantWallet/IncreaseMoneyAdmin";
import TransportMoneyAdmin from "./merchantWallet/transportMoneyAdmin";
import cashOutAdmin from "./merchantWallet/useMoneyAdmin";
import SvgIcon from "../../../../../../templates/components/SvgIcon";
import CashFlowAdmin from "./merchantWallet/cashFlowAdmin";
import {ReactComponent as IncreaseMoneyIcon} from "../../../../../../assets/icons/increaseMoney.svg";
import {formatNumber} from "../../../../../../utils/helper";
import {TransitionsPage} from "../../../../../../templates/Ui";
import {motion} from "framer-motion";

const MerchantWallet = () => {

  const [currentTab, setCurrentTab] = useState(5);

  const tabs = [
    {
      key: 5,
      component: <IncreaseMoneyAdmin/>,
      icon: <IncreaseMoneyIcon/>,
      title: 'افزایش موجودی'
    },
    // {
    //   key: 6,
    //   component: <cashOutAdmin/>,
    //   icon: 'dollarIcon',
    //   title: 'کاهش موجودی'
    // },
    // {
    //   key: 7,
    //   component: <TransportMoneyAdmin />,
    //   icon: 'dollarIcon',
    //   title: 'انتقال موجودی'
    // },
    {
      key: 4,
      component: <CashFlowAdmin/>,
      icon: 'fileText',
      title: 'مشاهده گردش کیف پول'
    },
  ];

  const activeTab = tabs.find(item => item?.key === currentTab);


  return (
    <div className={"flex text-textcolor mt-[30px] min-h-[624px]"}>
      <div className={"w-1/3"}>
        <div className={"backwallet"}>
          <div className={" text-center text-white item-center "}>
            <div className={"flex gap-5 items-start"}>
              <img src={"/images/walleticon.png"} alt={""}/>
              <div>
                <p className={""}>موجودی کیف پول پذیرنده</p>
                {/*<h1 className={"text-white pt-2"}>{`${formatNumber(auth?.walletDetails?.balance || 0)} ریال`}</h1>*/}
              <p className={"pt-4"}>345643432545 ریال</p>
              </div>
            </div>
          </div>
        </div>
        {tabs.map((item) =>
          <div onClick={() => setCurrentTab(item.key)} className={currentTab===item.key?"bg-purple text-white w-full focus:bg-cashback focus:text-textblue my-[11px] flex gap-3 items-center justify-center px-2 h-[42px] border border-borderblue rounded-md":"bg-white w-full focus:bg-cashback focus:text-textblue my-[11px] flex gap-3 items-center justify-center px-2 h-[42px] border border-borderblue rounded-md"}>{item.title}
          </div>
        )}
      </div>




      <div className={currentTab !== 0 ? "w-2/3 pr-6 " : ""}>
        <TransitionsPage id={currentTab} coordinates={'x'} size={-30}>
          <div className={currentTab !== 0 ? "bg-white border rounded-md shadow-shadow" : "hidden"}>
            <div className={"flex gap-2 items-center  text-center w-full border-b-2 py-4 px-[22px] "}>
              {typeof activeTab?.icon === 'string' ?
                <SvgIcon icon={activeTab?.icon} width={19} height={19} color={'#21409A'}/> :
                activeTab?.icon
              }
              <h1 className={"m-0 text-textblue"}>{activeTab?.title}</h1>
            </div>
            {activeTab?.component}
          </div>
        </TransitionsPage>
      </div>
    </div>
  );
};

export default MerchantWallet;