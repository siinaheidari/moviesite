import React from 'react';
import {Col, Divider, Form, Row,Button} from "antd";
import {inputRule} from "../../../../../../utils/helper";
import { Input} from "../../../../../../templates/Ui";

const ShopInfo = () => {

  const [ShopInfoFormRef]=Form.useForm()

  return (
    <div className={"px-3 mt-[20px] min-h-[624px] relative"}>
      <Form
        form={ShopInfoFormRef}
        name='shopInfo'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
      >
        <Col span={24}>
          <Col span={6}>
            <p className={"text-textcolor"}>امتیاز کسب شده پذیرنده از این قسمت: ۵ امتیاز</p>
          </Col>
          <Divider/>
          <Row gutter={[50,10]}>
            <Col md={8} lg={8} xs={24}>
              <Input
                name={'email'}
                label={'ایمیل'}
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'ایمیل'})
                  },
                ]}
                formRef={ShopInfoFormRef}
                ltr
                focus
              />
            </Col>
            <Col md={8} lg={8} xs={24}>
              <Input
                name={'name'}
                label={'نشانی وب‌سایت'}
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'نشانی وب‌سایت'})
                  },
                ]}
                formRef={ShopInfoFormRef}
                ltr
                focus
              />
            </Col>
            <Col md={8} lg={8} xs={24}>
              <Input
                name={'logo'}
                label={'بارگذاری تصویر لوگو'}
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'بارگذاری تصویر لوگو'})
                  },
                ]}
                formRef={ShopInfoFormRef}
                ltr
                focus
              />
            </Col>
          </Row>
        </Col>
        <Form.Item className={"w-full text-end items-end absolute bottom-0 left-4"}>
          <Button className={" w-1/4 h-[42px] text-purple-400 border border-purple-400"} htmlType="submit">
            ویرایش
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default ShopInfo;