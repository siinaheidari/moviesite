import { LoadingOutlined, UploadOutlined } from '@ant-design/icons';
import {Col, Divider, Form, message, Row, Select, Upload} from 'antd';
import React, { useState } from 'react';
import styled from 'styled-components';
import { Input, SelectBox } from 'templates/Ui';
import { inputRule } from 'utils/helper';
import {useRequest} from "../../../../../../utils/useRequest";

const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
};

const beforeUpload = (file) => {
  const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
  if (!isJpgOrPng) {
    message.error('You can only upload JPG/PNG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJpgOrPng && isLt2M;
};

const BankAccountInformationContainer = styled(Row)`
  .--imageUpload {
    .ant-form-item {
      .ant-upload-select {
        border: 1px solid #C6D4FF !important;
        border-radius: 5px !important;
        background-color: #FFFFFF !important;
        height: 142px !important;
        width: 100% !important;
        margin: 0 !important;

        .ant-upload {
          display: block !important;

          .--uploadContent {
            height: 100%;

            .__topSection {
              align-self: center;
              height: calc(100% - 40px);

              .anticon {
                font-size: 2rem;
                margin-top: 30px;
                color: #725bdb;

                &.anticon-upload {
                  font-size: 2.2rem;

                }
              }

              .--img {
                height: 100%;
                width: auto;
              }
            }

            .__bottomSection {
              background-color: #725bdb;
              line-height: 40px;
              align-self: flex-end;
              color: #FFFFFF;
              font-size: .875rem;
              font-weight: 400;
            }
          }
        }
      }

      &.ant-form-item-has-error {
        .ant-upload-select {
          border-color: #ff4d4f !important;
        }
      }
    }
  }
`;

const MerchantDocuments = ({ formRef }) => {
  const [uploadIsLoading, setUploadIsLoading] = useState({
    shenasnameh: false,
    frontNationalCard: false,
    backNationalCard: false,
    iban: false,
    contractSigned: false,
    leaseOrDocument: false,
    businessLicense: false,
    statute: false,
    newspaper: false
  });

  const [uploadImages, setUploadImages] = useState({});

  const handleChangeShenasnamehImage = (info, imageName) => {
    if (info.file.status === 'uploading') {
      setUploadIsLoading(current => ( { ...current, [ imageName ]: true } ));
      return;
    }

    if (info.file.status === 'done') {
      // Get this url from response in real world.
      getBase64(info.file.originFileObj, (url) => {
        setUploadIsLoading(current => ( { ...current, [ imageName ]: false } ));
        setUploadImages(current => ( { ...current, [ imageName ]: url } ));
      });
    }

    getBase64(info.file.originFileObj, (url) => {
      setUploadIsLoading(current => ( { ...current, [ imageName ]: false } ));
      setUploadImages(current => ( { ...current, [ imageName ]: url } ));
    });
  };

  const UploadButton = ({ text, imageName }) => {
    return (
      <Row className='--uploadContent'>
        <Col span={ 24 } className='__topSection'>
          { uploadImages[ imageName ] ? (
            <img src={ uploadImages[ imageName ] } className='--img'/>
          ) : (
            uploadIsLoading[ imageName ] ? <LoadingOutlined/> : <UploadOutlined/>
          ) }
        </Col>

        <Col span={ 24 } className='__bottomSection'>
          { text }
        </Col>
      </Row>
    );
  };


  const {isLoading: terminalTypeLoading, data: terminalTypeData} = useRequest({
    path: "/api/v1/setting/list-terminal-type",
    key: ["terminalType"],
    apiType: "admin"
  })

  const terminalTypeRes=terminalTypeData?.output||[]

  return (
    <div className={"px-3 mt-[20px] min-h-[624px]"}>
    <BankAccountInformationContainer gutter={ [16, 5] }>
      <Col span={6}>
        <p className={"text-textcolor"}>امتیاز کسب شده پذیرنده از این قسمت: ۵ امتیاز</p>
      </Col>
      <Divider/>
      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'shenasnameh'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر شناسنامه' })
            }
          ] }
        >
          <Upload
            name='shenasnameh'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'shenasnameh') }
          >
            <UploadButton text={ 'تصویر شناسنامه' } imageName={ 'shenasnameh' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'frontNationalCard'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر روی کارت ملی' })
            }
          ] }
        >
          <Upload
            name='frontNationalCard'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'frontNationalCard') }
          >
            <UploadButton text={ 'تصویر روی کارت ملی' } imageName={ 'frontNationalCard' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'backNationalCard'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر پشت کارت ملی' })
            }
          ] }
        >
          <Upload
            name='backNationalCard'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'backNationalCard') }
          >
            <UploadButton text={ 'تصویر پشت کارت ملی' } imageName={ 'backNationalCard' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'iban'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر مهر شده تاییدیه شبا' })
            }
          ] }
        >
          <Upload
            name='iban'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'iban') }
          >
            <UploadButton text={ 'تصویر مهر شده تاییدیه شبا' } imageName={ 'iban' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'contractSigned'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر قرارداد امضا شده توسط پذیرنده' })
            }
          ] }
        >
          <Upload
            name='contractSigned'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'contractSigned') }
          >
            <UploadButton text={ 'تصویر قرارداد امضا شده توسط پذیرنده' } imageName={ 'contractSigned' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'leaseOrDocument'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر اجاره نامه یا سند' })
            }
          ] }
        >
          <Upload
            name='leaseOrDocument'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'leaseOrDocument') }
          >
            <UploadButton text={ 'تصویر اجاره نامه یا سند' } imageName={ 'leaseOrDocument' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'businessLicense'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر جواز کسب' })
            }
          ] }
        >
          <Upload
            name='businessLicense'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'businessLicense') }
          >
            <UploadButton text={ 'تصویر جواز کسب' } imageName={ 'businessLicense' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'statute'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر اساس نامه' })
            }
          ] }
        >
          <Upload
            name='statute'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'statute') }
          >
            <UploadButton text={ 'تصویر اساس نامه' } imageName={ 'statute' }/>
          </Upload>
        </Form.Item>
      </Col>

      <Col xs={ 24 } md={ 12 } lg={ 8 } className='--imageUpload'>
        <Form.Item
          name={ ['images', 'newspaper'] }
          rules={ [
            {
              required: true,
              message: inputRule('required upload', { inputName: 'تصویر روزنامه رسمی' })
            }
          ] }
        >
          <Upload
            name='newspaper'
            listType='picture-card'
            showUploadList={ false }
            action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
            beforeUpload={ beforeUpload }
            onChange={ info => handleChangeShenasnamehImage(info, 'newspaper') }
          >
            <UploadButton text={ 'تصویر روزنامه رسمی' } imageName={ 'newspaper' }/>
          </Upload>
        </Form.Item>
      </Col>
    </BankAccountInformationContainer>
    </div>
  );
};

export default MerchantDocuments;
