import React, {useEffect, useRef, useState} from 'react';
import "../../../../../../../index.scss"
import {SelectBox, Modal, Table, DatePicker} from "../../../../../../../templates/Ui";
import {Button, Col, Form, Row, Select, Spin} from "antd";
import {useRequest} from "../../../../../../../utils/useRequest";
import SvgIcon from "../../../../../../../templates/components/SvgIcon";
import {convertDatePicker, inputRule} from "../../../../../../../utils/helper";
import {DateObject} from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import * as PropTypes from "prop-types";
import gregorian from "react-date-object/calendars/gregorian";
import {ShareAltOutlined} from "@ant-design/icons";
import {useAuth} from "../../../../../../../contexts/auth/AuthContext";

function TransactionsListContainer(props) {
  return null;
}

TransactionsListContainer.propTypes = {
  gutter: PropTypes.arrayOf(PropTypes.number),
  children: PropTypes.node
};
const CashFlowAdmin = () => {

  const {auth, handleChangeUserData} = useAuth();

  const [transactionDetailModal, setTransactionDetailModal] = useState(false);

  const [selectedTransaction, setSelectedTransaction] = useState({});

  const handleOpenModal = transactionDetail => {
    setSelectedTransaction(transactionDetail);
    setTransactionDetailModal(true);
  }

  const handleCloseModal = () => {
    setSelectedTransaction({});
    setTransactionDetailModal(false);
  }

  const [filterFormRef] = Form.useForm();

  const tableRef = useRef();

  const [page, setPage] = useState(1);

  const [pageSize, setPageSize] = useState(10)

  const currentData = new DateObject({calendar: persian});

  const [startDate, setStartDate] = useState(currentData?.format('YYYY-MM-DD'))

  const [endDate, setEndDate] = useState(currentData?.format('YYYY-MM-DD'));

  const [transactionType, setTransactionType] = useState('all')

  const [status, setStatus] = useState('all')


  const {isLoading, data, dataUpdatedAt} = useRequest({
    path: '/api/core/wallet/transaction-report',
    params: {
      pageNumber: page,
      pageIndex: pageSize,
      eDate: endDate,
      sDate: startDate,
      transactionType: transactionType !== 'all' ? transactionType : null,
      status: status !== 'all' ? status : null
    },
    options: {
      retry: false
    },
    key: ['cashFlow', page, startDate, endDate, pageSize, transactionType, status],
  });

  const {refetch: refetchUserWalletData} = useRequest({
    path: '/api/core/wallet/info',
    key: ['userWalletInfo'],
    options: {
      enabled: false,
      cacheTime: 0,
    }
  });

  useEffect(() => {
    refetchUserWalletData()
      .then(res => {
        const userWalletData = res?.data?.output;
        if (Object.keys(userWalletData)?.length) {
          let draftUserInfo = auth;
          draftUserInfo.walletDetails = userWalletData;
          handleChangeUserData(draftUserInfo);
        }
      })
  }, [dataUpdatedAt])

  const response = data?.output || [];

  const handleFilter = values => {
    setStartDate(values?.startDate);
    setEndDate(values?.endDate);
    setTransactionType(values?.transactionType)
    setStatus(values?.status)
  }


  const tableColumns = [
    {
      title: 'transactionType',
      dataIndex: 'transactionType',
      key: 'transactionType',
      align: 'center',
      render: (_, row) => {
        let desc;
        if (row?.transactionType === 1) desc = 'شارژ کیف پول';
        else if (row?.transactionType === 2) desc = 'برداشت از کیف پول';
        else if (row?.transactionType === 3) desc = 'انتقال از کیف پول';
        else if (row?.transactionType === 4) desc = 'پرداخت بابت خرید';
        else if (row?.transactionType === 5) desc = 'دریافت از کیف پول دیگر';
        else if (row?.transactionType === 6) desc = 'دریافت بابت فروش';
        else desc = '';

        return <span>{desc}</span>
      }
    },

    {
      title: 'transactionDate ',
      dataIndex: 'transactionDate',
      key: 'transactionDate',
      align: 'center',
      render: (_, row) => {
        const date = new DateObject({date: row?.createDate, calendar: gregorian});
        return `${date.convert(persian).format('HH:mm')} - ${date.convert(persian).format('YYYY/MM/DD')}`
      }
    },

    {
      title: 'transactionPrice',
      dataIndex: 'transactionPrice',
      key: 'transactionPrice',
      align: 'center',
      render: (_, row) => (row?.transactionType === 3 || row?.status === 0|| row?.transactionType === 2) ?
        <span style={{color: 'red'}}>{row?.transactionPrice}</span> :
        <span style={{color: '#1CC500'}}>{row?.transactionPrice}</span>
    },
    {
      title: 'rial',
      dataIndex: 'rial',
      key: 'rial',
      align: 'center',
      render: () => 'ریال'
    },
    {
      title: 'transactionStatus ',
      dataIndex: 'transactionStatus',
      key: 'transactionStatus',
      align: 'center',
      render: (_, row) => (row?.status === 1) ?
        <span style={{color: '#1CC500'}}>تراکنش موفق</span>
        : <span style={{color: 'red'}}>تراکنش ناموفق</span>
    },
  ];

  const showDesc = typeId => {
    let desc;
    if (typeId === 1) desc = 'شارژ کیف پول';
    else if (typeId === 2) desc = 'برداشت از کیف پول';
    else if (typeId === 3) desc = 'انتقال از کیف پول';
    else if (typeId === 4) desc = 'پرداخت بابت خرید';
    else if (typeId === 5) desc = 'دریافت از کیف پول دیگر';
    else if (typeId === 6) desc = 'دریافت بابت فروش';
    else if (typeId === 7) desc = 'پرداخت قبض';
    else desc = '';

    return desc
  }

  return (

    <div className={"cashback"}>
      <Form
        form={filterFormRef}
        name='indexFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleFilter}
      >
        <Row className='px-3 pt-3'>
          <Col span={24} className='__filterSection'>
            <Row gutter={20} align={'middle'} justify={'space-between'}>
              <Col span={20}>
                <Row gutter={20}>
                  <Col span={6}>
                    <DatePicker
                      name={'startDate'}
                      placeholder={'از تاریخ'}
                      hiddenLabel
                      initialValue={startDate}
                      dateFormat={'YYYY-MM-DD'}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required selectBox', {inputName: 'تاریخ '})
                        }
                      ]}
                    />
                  </Col>
                  <Col span={6}>
                    <DatePicker
                      name={'endDate'}
                      placeholder={'تا تاریخ'}
                      hiddenLabel
                      initialValue={endDate}
                      dateFormat={'YYYY-MM-DD'}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required selectBox', {inputName: 'تاریخ '})
                        }
                      ]}
                    />
                  </Col>
                  <Col span={7}>
                    <SelectBox
                      name="transactionType"
                      placeholder="لیست تراکنش ها"
                      initialValue={transactionType}
                      rules={[
                        {
                          required: true,
                          message: 'نوع تراکنش را انتخاب نمایید'
                        },
                      ]}
                      allowClear={false}
                    >
                      <Select.Option value={"all"}>همه</Select.Option>
                      <Select.Option value={1}>شارژ کیف پول</Select.Option>
                      <Select.Option value={2}>برداشت از کیف پول</Select.Option>
                      <Select.Option value={3}>انتقال از کیف پول</Select.Option>
                      <Select.Option value={4}>پرداخت بابت خرید</Select.Option>
                      <Select.Option value={5}>دریافت از کیف پول دیگر</Select.Option>
                      <Select.Option value={6}>دریافت بابت فروش</Select.Option>
                      <Select.Option value={7}>پرداخت قبض</Select.Option>
                    </SelectBox>
                  </Col>
                  <Col span={5}>
                    <SelectBox
                      name="status"
                      placeholder="وضعیت تراکنش"
                      initialValue={status}

                      rules={[
                        {
                          required: true,
                          message: 'وضعیت تراکنش را انتخاب نمایید'
                        },
                      ]}
                      allowClear={false}
                    >
                      <Select.Option value={"all"}>همه</Select.Option>
                      <Select.Option value={'true'}>موفق</Select.Option>
                      <Select.Option value={'false'}>ناموفق</Select.Option>
                    </SelectBox>
                  </Col>
                </Row>
              </Col>

              <Col span={2.5} className='text-end pb-7'>
                <Button htmlType={'submit'} type={'default'}>
                  اعمال
                </Button>
              </Col>
            </Row>
          </Col>

          <Col span={24} className='__table' ref={tableRef}>
            <Table
              rowClassName={"cursor-pointer"}
              showHeader={false}
              onRow={record => ({
                onClick: () => handleOpenModal(record)
              })}
              columns={tableColumns}
              className='my-form'
              dataSource={response}
              loading={isLoading}
              onChange={({current, pageSize}) => {
                setPage(current)
                setPageSize(pageSize)
              }}
              bordered
              tableLayout={'fixed'}
              pagination={{
                hideOnSinglePage: true,
                defaultPageSize: 10,
                total: 200,
                showSizeChanger: true,
                responsive: true,
                position: ['bottomLeft'],
                nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                   color={'#999999'}
                                   style={{margin: '6px auto'}}/>,
                prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                   color={'#999999'}
                                   style={{margin: '6px auto'}}/>,
                onChange: () => tableRef?.current.scrollIntoView({behavior: 'smooth'})
              }}
            />
          </Col>
        </Row>
      </Form>


      <Modal
        open={transactionDetailModal}
        onCancel={handleCloseModal}
        size={{
          sm: 95,
          xs: 95,
          md: 90,
          lg: 90,
          xl: 80,
          xxl: 70
        }}
        bodyStyle={{
          padding: 0,
        }}
        style={{
          top: '30vh'
        }}
      >
        <div className={""}>
          <div className={" text-center items-center gap-5 text-textcolor"}>
            <div className={'w-full border-b-2 px-[12px] py-[16px]'}>
              <div className={'flex gap-3'}>
                <div className={'w-1/4 '}>
                  <h2 className={"font-[400]"}>شماره پیگیری</h2>
                </div>

                {!!selectedTransaction?.toWalletId &&
                  <div className={'w-1/4 bg-blue-400'}>
                    <h2 className={"font-[400]"}>شماره شناسه کیف پول مقصد</h2>
                  </div>
                }

                <div className={'w-1/4 '}>
                  <h2 className={"font-[400]"}>تاریخ و ساعت</h2>
                </div>

                <div className={'w-1/4 '}>
                  <h2 className={"font-[400]"}>مبلغ </h2>
                </div>

                <div className={'w-1/4 '}>
                  <h2 className={"font-[400]"}>توضیحات</h2>
                </div>

                <div className={'w-1/4 '}>
                  <h2 className={"font-[400]"}>عملیات</h2>
                </div>
              </div>
            </div>

            <div className={'w-full px-[12px] py-[16px]'} style={{color: '#787878'}}>
              <div className={'flex'}>
                <div className={'w-1/4'}>
                  <h2 className={"font-[400]"}>{selectedTransaction?.referenceNumber}</h2>
                </div>

                {!!selectedTransaction?.toWalletId &&
                  <div className={'w-1/4'}>
                    <h2>{selectedTransaction?.toWalletId}</h2>
                  </div>
                }

                <div className={'w-1/4'}>
                  <h2 className={"font-[400]"}>{new DateObject({
                    date: selectedTransaction?.createDate,
                    calendar: gregorian
                  }).convert(persian).format('HH:mm - YYYY/MM/DD')}</h2>
                </div>

                <div className={'w-1/4'}>
                  <h2
                    className={selectedTransaction.transactionType === 3 || selectedTransaction.status===0 || selectedTransaction.transactionType === 2 ? "text-red-600 font-[400]" : "text-green-500 font-[400]"}>{selectedTransaction.transactionPrice} ریال </h2>
                </div>

                <div className={'w-1/4'}>
                  <h2 className={"font-[400]"}>
                    {showDesc(selectedTransaction?.transactionType)}
                  </h2>
                </div>

                <div className={'w-1/4 flex items-center gap-1 text-center justify-center'}>
                  <h2><ShareAltOutlined/></h2>
                  <h2 className={"font-[400]"}>اشتراک گذاری</h2>
                </div>
              </div>
            </div>

          </div>

        </div>
      </Modal>
    </div>

  );
};

export default CashFlowAdmin;