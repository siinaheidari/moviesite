import React, {useState} from 'react';
import "../../../../../index.scss"
import {Badge} from "antd";
import personalTransactionInfo from "./Components/personalTransactionInfo";
import PersonalTransactionInfo from "./Components/personalTransactionInfo";
import MerchantInfo from "./Components/merchantInfo";
import ShopInfo from "./Components/shopInfo";
import PropertyInfo from "./Components/propertyInfo";
import MerchantWallet from "./Components/merchantWallet";
import MerchantDocuments from "./Components/merchantDocuments";
import TerminalInfo from "./Components/terminalInfo";
import BankInfo from "./Components/bankInfo";
import InviteFriends from "./Components/inviteFriends";
import RequestsList from "./Components/requestsList";
import {motion, AnimatePresence} from "framer-motion";
import {LeftOutlined} from "@ant-design/icons";
import {Link, useNavigate} from "react-router-dom";
import {formatNumber} from "../../../../../utils/helper";

const TransactionInfo = () => {

  const [currentInfo, setCurrentInfo] = useState("personalTransactionInfo")
  const navigate = useNavigate()
  const [currentStep, setCurrentStep] = useState(0);

  const info = [
    {
      key: "personalTransactionInfo",
      title: "ریز تراکنش",
      component: <PersonalTransactionInfo/>
    },
    {
      key: "merchantInfo",
      title: "اطلاعات فردی پذیرنده",
      component: <MerchantInfo/>
    },
    {
      key: "shopInfo",
      title: "اطلاعات فروشگاه",
      component: <ShopInfo/>
    },
    {
      key: "propertyInfo",
      title: "اطلاعات ملک",
      component: <PropertyInfo/>
    },
    {
      key: "bankInfo",
      title: "اطلاعات حساب بانکی",
      component: <BankInfo/>
    },
    {
      key: "merchantDocuments",
      title: "مدارک پذیرنده",
      component: <MerchantDocuments/>
    },
    {
      key: "terminalInfo",
      title: "اطلاعات ترمینال",
      component: <TerminalInfo/>
    },
    {
      key: "merchantWallet",
      title: "کیف پول پذیرنده",
      component: <MerchantWallet/>
    },
    {
      key: "inviteFriends",
      title: "دعوت دوستان",
      component: <InviteFriends/>
    },
    {
      key: "RequestList",
      title: "گزارش درخواست ها",
      component: <RequestsList/>
    },
  ]

  const activeInfo = info?.find(item => item.key === currentInfo)


  return (
    <div className={"text-textcolor text-[14px] pb-10"}>
      <div className={"bg-white mb-5 rounded-[12px] shadow-shadow w-full p-[25px] flex justify-between"}>
        <div className={"flex gap-3"}>
          <p> مدیریت پذیرندگان </p>
          <LeftOutlined/>
          <p
            className={"text-purple"}>{currentInfo === "personalTransactionInfo" ? "ریز تراکنش" : currentInfo === "merchantInfo" ? "اطلاعات فردی پذیرنده" : currentInfo === "shopInfo" ? "اطلاعات فروشگاه" : currentInfo === "propertyInfo" ? "اطلاعات ملک " : currentInfo === "bankInfo" ? "اطلاعات حساب بانکی" : currentInfo === "merchantDocuments" ? "مدارک پذیرنده" : currentInfo === "terminalInfo" ? "اطلاعات ترمینال" : currentInfo === "merchantWallet" ? "کیف پول پذیرنده" : currentInfo === "inviteFriends" ? "دعوت دوستان" : currentInfo === "RequestList" ? "گزارش درخواست ها" : ""}</p>
        </div>
        <Link to={"/admin/managements/merchants"}><p>بازگشت</p></Link>

      </div>
      <div className={"bg-white p-[25px] rounded-[12px]"}>
        <div className={"flex gap-3 px-[45px] py-[25px] text-[14px] font-[500] rounded-[12px] shadow-shadow"}>
          <div className={"w-1/5"}>
            <Badge count={"75%"} style={{marginTop: "10px", marginLeft: "20px", backgroundColor: ""}}>
              <img className={"border-[0.8rem] rounded-full border-green-500 border-solid"}
                   src={"/images/adminIcon.svg"}/>
            </Badge>
          </div>
          <div className={"w-4/5"}>
            <div className={"flex justify-between"}>
              <h1 className={"text-[16px mb-[25px]"}>سینا حیدری<span
                className={"text-red-500 mr-4"}> مسدود کردن پذیرنده</span></h1>
              <h1 className={"text-blue-500 underline"}>تغییر رمز عبور کاربر</h1>
            </div>
            <div className={"flex justify-between"}>
              <div className={"text-start "}>
                <h1 className={"mb-[25px]"}>نوع کاربری: <span>پذیرنده</span></h1>
                <h1 className={"py-2"}>تلفن همراه: <span>091245678965</span></h1>
                <h1 className={"mt-[25px]"}>وضعیت: <span
                  className={"bg-green px-2 rounded-[10px] text-green-700"}>فعال</span></h1>
              </div>
              <div>
                <h1 className={"mb-[25px]"}>سطح کاربری پذیرنده: <span>vip </span></h1>
                <h1 className={"py-2 mb-[25px]"}>امتیاز پذیرنده: <span>۱۲۰۰</span></h1>
                <h1 className={"mt-2 mb-[25px]"}> موجودی کیف پول: <span>{formatNumber(2000000)} ریال</span></h1>
              </div>
              <div className={"w-1/4 text-end"}>
                <button
                  className={"text-white py-2.5 w-full max-w-[200px] rounded-[10px] bg-adminBtn mt-[5.5rem] px-2 "}>ورود
                  به پروفایل
                  کاربر
                </button>
              </div>
            </div>
          </div>
        </div>
        <div
          className={"flex justify-between gap-2 items-center px-3 mt-[20px] shadow-shadow bg-gray-100 rounded-lg text-textcolor text-[12px]"}>
          {info.map((item) =>
            <p onClick={() => setCurrentInfo(item.key)} className={"cursor-pointer relative py-5 "}>{item.title}
              {
                item.key === currentInfo ? (
                  <motion.div className={"underline bg-purple h-[5px] rounded-t-[10px] absolute bottom-0 w-full"}
                              layoutId={"underline"}/>
                ) : null
              }
            </p>
          )}
        </div>

        <div>
          <AnimatePresence mode={"wait"}>
            <motion.div
              key={currentInfo || 'initialPage'}
              initial={{
                x: 20,
                opacity: 0,
              }}
              animate={{
                x: 0,
                opacity: 1,
              }}
              exit={{
                x: -20,
                opacity: 0
              }}
              transition={{
                duration: 0.3
              }}
            >
              {activeInfo?.component}
            </motion.div>

          </AnimatePresence>

        </div>
      </div>
    </div>
  );
};

export default TransactionInfo;