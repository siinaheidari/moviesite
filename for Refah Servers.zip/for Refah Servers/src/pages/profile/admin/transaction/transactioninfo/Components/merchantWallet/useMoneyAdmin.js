// import React, {useEffect, useState} from 'react';
// import {LeftOutlined, LoadingOutlined, ShareAltOutlined, WarningOutlined} from '@ant-design/icons';
// import {Col, Divider, Form, Radio, Row, Select, Spin, Statistic} from 'antd';
//
// import styled from 'styled-components';
// import {Button, Input, Modal, SelectBox} from 'templates/Ui';
// import {Else, If, Then} from 'utils/Condition';
// import {convertDatePicker, fn_deadline, formatNumber, inputRule, toEnDigit} from 'utils/helper';
// import {useRequest} from 'utils/useRequest';
// import {useAuth} from "../../../../../../../contexts/auth/AuthContext";
// import {toast} from "react-toastify";
// import starkString from "starkstring";
// import {errorMessages} from "../../../../../../../utils/axios/errorMessages";
//
//
// const ForgetPasswordContainer = styled(Row)`
//   .--title {
//     margin-bottom: 50px;
//     text-align: center;
//     font-size: 1rem;
//   }
//
//   .--otpStatus {
//     &,
//     .ant-statistic-content {
//       color: #557EFF;
//       font-size: .875rem;
//     }
//
//     .__resend {
//       display: inline-block;
//       cursor: pointer;
//
//       &:hover {
//         color: #3264ff;
//       }
//
//       &.--disable {
//         pointer-events: none;
//       }
//     }
//   }
//
//   .--btn {
//     margin-top: 30px;
//   }
//
//   .--goToSignIn {
//     margin-top: 35px;
//   }
// `;
//
//
// const cashOutAdmin = ({goToWalletPage,goToAddCartBank}) => {
//   const {auth, handleChangeUserData} = useAuth();
//   const {Countdown} = Statistic;
//   const [cashOutFormRef] = Form.useForm();
//   const userMobile = cashOutFormRef?.getFieldValue('mobile');
//   const mobileWatch = Form.useWatch('mobile', cashOutFormRef);
//   const otpInputWatch = Form.useWatch('inputCode', cashOutFormRef);
//   const [cashOutStep, setcashOutStep] = useState(0);
//   const [resendCode, setResendCode] = useState(false);
//   const [submitVisible, setSubmitVisible] = useState(false);
//   const [resendCodeDeadline, setResendCodeDeadline] = useState(0);
//   const amountWatch = Form.useWatch('amount', cashOutFormRef);
//   const [errorModal, setErrorModal] = useState(false)
//
//
//   const handleCloseModal = () => {
//     setErrorModal(false);
//   }
//
//   const {mutateAsync: sendOtpRequest2, isLoading: sendOtpIsLoading} = useRequest({
//     path: '/api/core/otp',
//     isMutation: true
//   });
//
//   const handleSendOtpCode = () => {
//     cashOutFormRef.validateFields()
//       .then(() => {
//         sendOtpRequest2({})
//           .then(() => {
//             setcashOutStep(1);
//           })
//           .catch(() => {
//             toast.error("کد ارسال نشد لطفا مجددا تلاش فرمایید")
//           })
//       })
//   };
//
//
//   const {isLoading: cartTypeDataIsLoading, data: cartTypeData} = useRequest({
//     path: '/api/core/wallet/iban-pan',
//     params: {},
//     key: ['cartType'],
//     options: {
//       retry: false
//     }
//   });
//
//   const cartType = cartTypeData?.output || [];
//
//   const {mutateAsync: cashOutRequest, isLoading: cashOutRequestLoading, error: cashOutError} = useRequest({
//     path: '/api/core/wallet/withdrawal',
//     isMutation: true,
//   })
//
//   const handlecashOut = () => {
//     const formData = cashOutFormRef?.getFieldsValue(true);
//     const draftFormData = structuredClone(formData);
//     cashOutRequest({
//       id: draftFormData?.buyChargeSelectbox,
//       amount: +(draftFormData?.amount?.replace(/,/g, '')),
//       otp: +(draftFormData?.inputCode),
//     })
//       .then(() => {
//         toast.success("مبلغ مورد نظر با موفقیت برداشت شد")
//         setcashOutStep(2);
//       }).catch((err) => {
//       const errorMessage = errorMessages[err?.output];
//       toast.error(errorMessage || 'برداشت انجام نشد، لطفا اطلاعات ورودی را چک نمایید');
//       if (err?.output !== 'Invalid Otp') {
//         cashOutFormRef.resetFields();
//         setcashOutStep(0)
//       } else {
//         cashOutFormRef.setFields([
//           {
//             name: 'inputCode',
//             value: '',
//             errors: ['کد وارد شده اشتباه است'],
//           }
//         ])
//       }
//     })
//   };
//
//
//   useEffect(() => {
//     if (!sendOtpIsLoading) {
//       setResendCodeDeadline(fn_deadline('02.01'));
//       setResendCode(false);
//     }
//   }, [sendOtpIsLoading]);
//
//
//   useEffect(() => setSubmitVisible(!!!(otpInputWatch && otpInputWatch?.length === 6)), [otpInputWatch]);
//
//   const {isLoading: userWalletsIsLoading, data: userWalletsData, isFetched, dataUpdatedAt} = useRequest({
//     path: '/api/core/wallet/info',
//     key: ['userWalletInfo'],
//     options: {
//       enabled: (cashOutStep === 2),
//       cacheTime: 0,
//     }
//   });
//
//
//   useEffect(() => {
//     if (cashOutStep === 2 && isFetched) {
//       let draftUserInfo = auth;
//       if (userWalletsData?.output) {
//         draftUserInfo.walletDetails = userWalletsData?.output;
//       }
//       handleChangeUserData(draftUserInfo)
//     }
//   }, [cashOutStep, isFetched, dataUpdatedAt])
//
//
//   const handleAmountButtons = amount => {
//     cashOutFormRef.setFields([{
//       name: "amount",
//       value: formatNumber(starkString(amount).parseNumber().englishNumber().toString()),
//     }])
//   }
//
//
//   return (
//     <Spin spinning={!!(sendOtpIsLoading || cashOutRequestLoading)}>
//       <Form
//         form={cashOutFormRef}
//         name='cashOut'
//         autoComplete='off'
//         scrollToFirstError
//         labelCol={{
//           span: 24
//         }}
//         wrapperCol={{
//           span: 24
//         }}
//         onFinish={handlecashOut}
//         className={"px-8 pb-10 pt-4"}
//       >
//         <ForgetPasswordContainer>
//           {cashOutStep === 0 &&
//             <div className={"items-center w-full h-[367px] "}>
//               <div className={"w-full"}>
//                 <p className={"!mb-3"}>مبلغ پیش فرض</p>
//                 <div className={"mb-2"}>
//                   <div className={"flex gap-4 items-center text-center "}>
//                     <div onClick={() => handleAmountButtons(1000000)}
//                          className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
//                       <p className={"leading-[38px]"}>۱,۰۰۰,۰۰۰ ریال</p>
//                     </div>
//                     <div onClick={() => handleAmountButtons(2000000)}
//                          className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
//                       <p className={"leading-[38px]"}>۲,۰۰۰,۰۰۰ ریال</p>
//                     </div>
//                     <div onClick={() => handleAmountButtons(5000000)}
//                          className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
//                       <p className={"leading-[38px]"}>۵,۰۰۰,۰۰۰ ریال</p>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div className={"flex gap-3 justify-start"}>
//                 <div className={"max-w-[310px]"}>
//                   <Input
//                     name='amount'
//                     label={'مبلغ'}
//                     noPlaceHolder
//                     maxLength={100000000}
//                     placeholderAlign={'right'}
//                     rules={[
//                       {
//                         required: true,
//                         message: inputRule('required input', {inputName: 'مبلغ'})
//                       },
//                       {
//                         validator: (_, value) => {
//                           if (value?.length && +(value?.replace(/,/g, '')) < 10000) {
//                             return Promise.reject(new Error(inputRule("minLength amount", {
//                               inputName: "مبلغ",
//                               length: "10,000 ریال"
//                             })))
//                           }
//
//                           return Promise.resolve();
//                         }
//                       },
//                       {
//                         validator: (_, value) => {
//                           if (value?.length && +(value?.replace(/,/g, '')) > 100000000) {
//                             return Promise.reject(new Error(inputRule("maxLength amount", {
//                               inputName: "مبلغ",
//                               length: "100,000,000 ریال"
//                             })))
//                           }
//
//                           return Promise.resolve();
//                         }
//                       },
//                     ]}
//                     rtl
//                     justNumber
//                     formRef={cashOutFormRef}
//                     maxLength={11}
//                     suffix={"ریال"}
//                     onChange={e => {
//                       cashOutFormRef.setFields([
//                         {
//                           name: 'amount',
//                           value: e?.target?.value ? formatNumber(starkString(e?.target?.value).parseNumber().englishNumber().toString()) : null,
//                           errors: []
//                         },
//                       ])
//                     }}
//                   />
//                 </div>
//
//                 <div className={"w-full max-w-[300px]"}>
//                   <SelectBox
//                     name="buyChargeSelectbox"
//                     label="انتخاب کارت"
//                     placeholder=""
//                     onPressEnter={handleSendOtpCode}
//                     rules={[
//                       {
//                         required: true,
//                         message: inputRule('required selectBox', {inputName: 'کارت'})
//                       },
//                     ]}
//                     allowClear
//                     dropdownRender={menu => {
//                       return(
//                         <>
//                           <div onClick={goToAddCartBank} className={"flex gap-2 items-center px-2.5 py-[2px] cursor-pointer"}>
//                             <p className={"text-[18px] text-blue-400"}>+</p>
//                             <div className={" text-blue-400"}>اضافه کردن کارت بانکی
//                             </div>
//                           </div>
//                           <Divider style={{margin: '8px 0'}}/>
//                           {menu}
//                         </>
//                       )
//                     }}
//                   >
//                     {cartType?.map(item => (
//                       <Select.Option value={item?.rowId}>{item?.BankName}-{item?.pan}</Select.Option>
//                     ))}
//                   </SelectBox>
//                 </div>
//               </div>
//
//               <div className={"mt-[9rem] m-auto text-center items-center"}>
//                 <Button
//                   style={{margin: 'auto', padding: "0 20px"}}
//                   type={'secondary'}
//                   onClick={handleSendOtpCode}
//                   icon={<LeftOutlined/>}
//                   iconAlign={'end'}
//                 >
//                   ادامه
//                 </Button>
//               </div>
//             </div>
//           }
//           {cashOutStep === 1 &&
//             <div className={"w-full items-center"}>
//               <div className={"w-full max-w-[310px]"}>
//                 <Input
//                   name={'inputCode'}
//                   noPlaceHolder
//                   label={('کد ارسال شده را وارد نمایید')?.replaceAll('{{mobileNumber}}', userMobile)}
//                   maxLength={6}
//                   rules={[
//                     {
//                       required: true,
//                       message: inputRule('required input', {inputName: 'کد تایید'})
//                     }
//                   ]}
//                 />
//               </div>
//               <div className={"w-[310px]"}>
//                 <div className='--otpStatus'>
//                   <Row justify='space-between' gutter={17}>
//                     <If condition={!resendCode}>
//                       <Then>
//                         <Col>
//                           <WarningOutlined/> {'اعتبار باقیمانده کد ارسال شده'}
//                         </Col>
//                         <Col>
//                           <Countdown value={resendCodeDeadline} onFinish={() => setResendCode(true)} format='mm:ss'/>
//                         </Col>
//                       </Then>
//
//                     </If>
//                   </Row>
//                 </div>
//               </div>
//
//               <div className={"mt-[12rem] m-auto text-center items-center w-full max-w-[230px]"}>
//                 <Button className={"bg-backbtn text-white "}
//                         type={'submit'}
//                         block
//                         onClick={handlecashOut}
//                         icon={<LeftOutlined/>}
//                         iconAlign={'end'}
//
//                 >
//                   انتقال
//                 </Button>
//               </div>
//             </div>
//           }
//           {
//             cashOutStep === 2 &&
//             <div className={"mx-auto  text-textcolor !text-center !items-center text-[14px] pb-8 w-2/3"}>
//               <div className={"m-auto text-center items-center mt-8"}>
//                 <img className={"inline text-tick pb-5"} src={"/images/Tick Square.svg"}/>
//                 <h1 className={"text-tick text-[16px]"}>
//                   برداشت موفقیت آمیز بود
//                 </h1>
//                 <div className={"flex justify-between items-center pt-8 pb-[43px] "}>
//
//                 </div>
//               </div>
//               <button
//                 className={"border border-blue-700 text-tickettext rounded-md px-2 py-2.5"}
//                 onClick={goToWalletPage}
//               >
//                 بازگشت به صفحه کیف پول
//               </button>
//             </div>
//           }
//           <Modal
//             onCancel={handleCloseModal}
//             size={{
//               sm: 55,
//               xs: 55,
//               md: 55,
//               lg: 55,
//               xl: 55,
//               xxl: 30
//             }}
//             bodyStyle={{
//               padding: 0,
//             }}
//             style={{
//               top: '30vh'
//             }}
//           >
//
//             <div className={"mx-auto text-textcolor !text-center !items-center text-[14px] pb-10 w-2/3"}>
//               <div className={" items-center text-center pt-8 pb-[43px]"}>
//                 <img className={"inline text-tick pb-5"} src={"/images/Close Square.svg"}/>
//                 <h1 className={"text-error text-[16px]"}>
//                   برداشت ناموفق
//                 </h1>
//               </div>
//               <div className={"flex justify-center items-center pb-[27px] mx-auto"}>
//                 <h1>{errorMessages[cashOutError?.output] || '--'}</h1>
//               </div>
//               <button
//                 className={"border border-blue-700 text-tickettext rounded-md px-2 py-2.5"}
//                 onClick={goToWalletPage}
//               >
//                 بازگشت به صفحه کیف پول
//               </button>
//             </div>
//
//           </Modal>
//
//         </ForgetPasswordContainer>
//       </Form>
//     </Spin>
//   );
// };
//
// export default cashOutAdmin;
//
