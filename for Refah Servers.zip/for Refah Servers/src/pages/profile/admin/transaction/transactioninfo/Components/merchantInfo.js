import React, {useState} from 'react';
import {Button, Col, Divider, Form, Row, Select} from "antd";
import {inputRule} from "../../../../../../utils/helper";
import {DatePicker, Input, SelectBox} from "../../../../../../templates/Ui";

const MerchantInfo = () => {

  const [merchantInfoFormRef] = Form.useForm()
  const {Option} = Select;
  // const [currentStep, setCurrentStep] = useState(0);

  const handleFinish = (value) => {
    console.log(value)
  }

  // const handleNextStep = () => {
  //   setCurrentStep(currentStep + 1)
  // }

  return (
    <div className={"px-3 mt-[20px]"}>
      <Form
        form={merchantInfoFormRef}
        onFinish={handleFinish}
        name='merchantInfo'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
      >
        <Col span={24}>
          <Col span={6}>
            <p className={"text-textcolor"}>امتیاز کسب شده پذیرنده از این قسمت: ۵ امتیاز</p>
          </Col>
          <Divider/>
          <Row gutter={[50, 10]}>
            <Col md={8} lg={8} xs={24}>
              <Input
                name={'name'}
                label={'نام'}
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'نام'})
                  },
                ]}
                formRef={merchantInfoFormRef}
                ltr
                focus
              />
            </Col>
            <Col md={8} lg={8} xs={24}>
              <SelectBox
                name={'education'}
                label={'تحصیلات'}
                rules={[
                  {
                    required: true,
                    message: inputRule('required selectBox', {inputName: 'تحصیلات'})
                  }
                ]}
                formRef={merchantInfoFormRef}
              >
                <Option value={0}>فوق لیسانس</Option>
                <Option value={1}>لیسانس</Option>
                <Option value={1}>دیپلم</Option>
              </SelectBox>
            </Col>
            <Col md={8} lg={8} xs={24}>
              <Input
                name={'mobile'}
                label={'شماره موبایل'}
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'شماره موبایل'})
                  },
                  {
                    min: 11,
                    message: inputRule('minLength input', {inputName: 'شماره موبایل', length: 11})
                  }

                ]}
                maxLength={11}
                justNumber
                formRef={merchantInfoFormRef}
                ltr
                focus
              />
            </Col>
            <Col md={8} lg={8} xs={24}>
              <Input
                name={'lastName'}
                label={'نام خانوادگی'}
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'نام خانوادگی'})
                  },
                ]}
                formRef={merchantInfoFormRef}
                ltr
                focus
              />
            </Col>
            <Col md={8} lg={8} xs={24}>
              <SelectBox
                name={""}
                label={'رشته تحصیلی'}
                rules={[
                  {
                    required: true,
                    message: inputRule('required selectBox', {inputName: 'رشته تحصیلی'})
                  }
                ]}
                formRef={merchantInfoFormRef}
              >
                <Option value={0}>عمران</Option>
                <Option value={1}>فناوری اطلاعات</Option>
              </SelectBox>
            </Col>
            <Col md={8} lg={8} xs={24}>
              <Input
                name={'email'}
                label={'ایمیل'}
                noPlaceHolder
                rules={[
                  {
                    required: true,
                    message: inputRule('required input', {inputName: 'ایمیل'})
                  },
                ]}
                formRef={merchantInfoFormRef}
                ltr
                focus
              />
            </Col>
            <Col span={24}>
              <Row gutter={50}>
                <Col md={8} lg={8} xs={24}>
                  <SelectBox
                    name={"gender"}
                    label={'جنسیت'}
                    rules={[
                      {
                        required: true,
                        message: inputRule('required selectBox', {inputName: 'جنسیت'})
                      }
                    ]}
                    formRef={merchantInfoFormRef}
                  >
                    <Option value={0}>عمران</Option>
                    <Option value={1}>فناوری اطلاعات</Option>
                  </SelectBox>
                </Col>
                <Col md={8} lg={8} xs={24}>
                  <SelectBox
                    name={'bigCity'}
                    label={'استان'}
                    rules={[
                      {
                        required: true,
                        message: inputRule('required selectBox', {inputName: 'استان'})
                      }
                    ]}
                  >
                    <Option value={0}>تهران</Option>
                  </SelectBox>
                </Col>
              </Row>
            </Col>
            <Col span={24}>
              <Row gutter={50}>
                <Col md={8} lg={8} xs={24}>
                  <SelectBox
                    name={"married"}
                    label={'تاهل'}
                    rules={[
                      {
                        required: true,
                        message: inputRule('required selectBox', {inputName: 'تاهل'})
                      }
                    ]}
                    formRef={merchantInfoFormRef}
                  >
                    <Option value={0}>مرد</Option>
                    <Option value={1}>زن</Option>
                  </SelectBox>
                </Col>
                <Col md={8} lg={8} xs={24}>
                  <SelectBox
                    name={'city'}
                    label={'شهر'}
                    rules={[
                      {
                        required: true,
                        message: inputRule('required selectBox', {inputName: 'شهر'})
                      }
                    ]}
                  >
                    <Option value={0}>تهران</Option>
                  </SelectBox>
                </Col>
              </Row>
            </Col>
            <Col span={24}>
              <Row gutter={50}>
                <Col md={8} lg={8} xs={24}>
                  <DatePicker
                    name='birthDate'
                    label='تاریخ تولد'
                    noPlaceHolder
                    rules={[
                      {
                        required: true,
                        message: inputRule('required selectBox', {inputName: 'تاریخ تولد'})
                      }
                    ]}
                    maxDate={true}
                    formRef={merchantInfoFormRef}
                    ltr
                  />
                </Col>
                <Col md={8} lg={8} xs={24}>
                  <Input
                    name={'address'}
                    label={"نشانی"}
                    noPlaceHolder
                    rules={[
                      {
                        required: true,
                        message: inputRule('required input', {inputName: 'نشانی'})
                      },
                    ]}
                    formRef={merchantInfoFormRef}
                    ltr
                    focus
                  />
                </Col>
              </Row>
            </Col>
          </Row>
          <Form.Item className={"w-full text-end items-end pt-5"}>
            <Button className={" w-1/4 h-[42px] text-purple-400 border border-purple-400"} htmlType="submit">
              ویرایش
            </Button>
          </Form.Item>
        </Col>
      </Form>
    </div>
  );
};

export default MerchantInfo;