import React, {useEffect, useState} from 'react';
import {Button, Form, Input, Radio, Spin} from "antd";
import {formatNumber, inputRule, toEnDigit} from "../../../../../../../utils/helper";
import starkString from "starkstring";
import {useRequest} from "../../../../../../../utils/useRequest";
import {useAuth} from "../../../../../../../contexts/auth/AuthContext";
import {errorMessages} from "../../../../../../../utils/axios/errorMessages";
import {toast} from "react-toastify";

const layout = {
  labelCol: {
    span: 24,
  },
  wrapperCol: {
    span: 24,
  },
};
const IncreaseMoneyAdmin = () => {

  const {auth} = useAuth();
  const [increaseMoneyForm] = Form.useForm();
  const increaseWalletWatch = Form.useWatch('amount', increaseMoneyForm);


  const handleAmountButtons = amount => {
    increaseMoneyForm.setFields([{
      name:"amount",
      value: amount
    }])
  }


  const {mutateAsync: increaseMoneyRequest, isLoading: increaseMoneyRequestLoading} = useRequest({
    path: '/api/core/wallet/charge',
    isMutation: true,
  })

  const handleIncreaseMoneyForm = (values) => {
    values.amount = +(values?.amount?.replace(/,/g, ''))
    values.provider = 'ENB';
    values.id = +(auth?.walletDetails?.rowId);
    increaseMoneyRequest(values)
      .then(res => {
        window.location.href = res?.output?.paymentLink
      }).catch((err) => {
      const errorMessage = errorMessages[err?.output];
      toast.error(errorMessage || 'افزایش موجودی انجام نشد، لطفا اطلاعات را چک نمایید')
    })

  };


  useEffect(() => {
    increaseMoneyForm.setFields([

      {
        name: 'amount',
        value: increaseWalletWatch ? formatNumber(starkString(increaseWalletWatch).parseNumber().englishNumber().toString()) : null,
        errors: []
      },
    ])
  }, [increaseWalletWatch]);


  return (
    <div className={"px-8 pb-4 pt-4"}>
      <Spin spinning={increaseMoneyRequestLoading}>
        <Form
          {...layout}
          form={increaseMoneyForm}
          name="increaseMoneyForm"
          onFinish={handleIncreaseMoneyForm}
        >
          <div className={" w-full "}>
            <p className={"!mb-3"}>مبلغ پیش فرض</p>
            <div className={"mb-2"}>
              <div className={"flex gap-4 items-center text-center "}>
                <div onClick={()=> handleAmountButtons(1000000)} className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
                  <p className={"leading-[38px]"}>۱,۰۰۰,۰۰۰ ریال</p>
                </div>
                <div onClick={()=> handleAmountButtons(2000000)} className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
                  <p className={"leading-[38px]"}>۲,۰۰۰,۰۰۰ ریال</p>
                </div>
                <div onClick={()=> handleAmountButtons(5000000)} className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
                  <p className={"leading-[38px]"}>۵,۰۰۰,۰۰۰ ریال</p>
                </div>
              </div>
            </div>
          </div>
          <div className={"w-full flex gap-3 max-w-[310px]"}>
            <Form.Item
              name="amount"
              label="مبلغ مورد نظر خود را به ریال وارد نمایید"
              validateFirst
              rules={[
                {
                  required: true,
                  message: inputRule('required input', {inputName: 'مبلغ'})
                },
                {
                  validator: (_, value) => {
                    if (value?.length && +(value?.replace(/,/g, '')) < 10000) {
                      return Promise.reject(new Error(inputRule("minLength amount", {
                        inputName: "مبلغ",
                        length: "10,000 ریال"
                      })))
                    }

                    return Promise.resolve();
                  }
                },
                {
                  validator: (_, value) => {
                    if (value?.length && +(value?.replace(/,/g, '')) > 100000000) {
                      return Promise.reject(new Error(inputRule("maxLength amount", {
                        inputName: "مبلغ",
                        length: "100,000,000 ریال"
                      })))
                    }

                    return Promise.resolve();
                  }
                },
              ]}
            >
              <Input
                rootClassName={"h-[42px] border border-borderblue ltr"}
                suffix={"ریال"}
                maxLength={11}
              />
            </Form.Item>

          </div>

          <div className={"mt-[9.5rem] m-auto"}>
            <Form.Item rootClassName={"text-center"}>
              <Button className={"bg-chargblue m-auto w-full max-w-[235px] h-[38px] !text-white"} htmlType="submit">
                پرداخت آنلاین
              </Button>
            </Form.Item>
          </div>

        </Form>
      </Spin>
    </div>
  );
};

export default IncreaseMoneyAdmin;