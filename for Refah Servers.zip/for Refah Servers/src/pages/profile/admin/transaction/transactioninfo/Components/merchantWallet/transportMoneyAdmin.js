import React, {useEffect, useState} from 'react';
import {LeftOutlined, LoadingOutlined, ShareAltOutlined, WarningOutlined} from '@ant-design/icons';
import {Col, Form, Radio, Row, Spin, Statistic} from 'antd';

import styled from 'styled-components';
import {Button, Input, Modal} from 'templates/Ui';
import {Else, If, Then} from 'utils/Condition';
import {fn_deadline, formatNumber, inputRule} from 'utils/helper';
import {useRequest} from 'utils/useRequest';
import {useAuth} from "../../../../../../../contexts/auth/AuthContext";
import {toast} from "react-toastify";
import starkString from "starkstring";
import {errorMessages} from "../../../../../../../utils/axios/errorMessages";

const ForgetPasswordContainer = styled(Row)`
  .--title {
    margin-bottom: 50px;
    text-align: center;
    font-size: 1rem;
  }

  .--otpStatus {
    &,
    .ant-statistic-content {
      color: #557EFF;
      font-size: .875rem;
    }

    .__resend {
      display: inline-block;
      cursor: pointer;

      &:hover {
        color: #3264ff;
      }

      &.--disable {
        pointer-events: none;
      }
    }
  }

  .--btn {
    margin-top: 30px;
  }

  .--goToSignIn {
    margin-top: 35px;
  }
`;

const layout = {
  labelCol: {
    span: 24,
  },
  wrapperCol: {
    span: 24,
  },
};

const TransportMoneyAdmin = ({goToWalletPage}) => {
  const {auth, handleChangeUserData} = useAuth();
  const {Countdown} = Statistic;
  const [transportFormRef] = Form.useForm();
  const userMobile = transportFormRef?.getFieldValue('mobile');
  const increaseWalletWatch = Form.useWatch('amount', transportFormRef);
  const mobileWatch = Form.useWatch('mobile', transportFormRef);
  const otpInputWatch = Form.useWatch('inputCode', transportFormRef);
  const [transportStep, setTransportStep] = useState(0);
  const [resendCode, setResendCode] = useState(false);
  const [submitVisible, setSubmitVisible] = useState(false);
  const [resendCodeDeadline, setResendCodeDeadline] = useState(0);
  const [transactionDetailModal, setTransactionDetailModal] = useState(false);
  const mobile = Form.useWatch('mobile', transportFormRef);


  const {isLoading: personIdentityIsLoading, data: personIdentity, refetch} = useRequest({
    path: '/api/core/wallet/person-identity',
    params: {
      mobile
    },
    key: ['person-identity'],
    options: {
      enabled: false,
      retry: false,
      cacheTime: 0,
    }
  });

  const response = personIdentity?.output || [];

  const handleOpenModal = () => {
    transportFormRef.validateFields()
      .then(() => {
        refetch()
          .then((res) => {
            if (res?.error?.output) {
              const errorMessage = errorMessages[res?.error?.output];
              toast.warning(errorMessage, {toastId: mobile+ '_'+ errorMessage});
            }
            else {
              setTransactionDetailModal(true)
            }
          })
      });
  }
  const handleCloseModal = () => {
    setTransactionDetailModal(false);
  }


  const {mutateAsync: sendOtpRequest2, isLoading: sendOtpIsLoading} = useRequest({
    path: '/api/core/otp',
    isMutation: true
  });

  const handleSendOtpCode = () => {
    sendOtpRequest2({})
      .then(() => {
        setTransportStep(1); // go to next step
      })
      .catch(() => {
        toast.error("کد ارسال نشد لطفا مجددا تلاش فرمایید")
      })
  };

  const {mutateAsync: transportMoneyRequest, isLoading: transportMoneyLoading, data: transportMoneyData, error: transportMoneyError} = useRequest({
    path: '/api/core/wallet/transfer',
    isMutation: true,
  });

  const transportMoneyResponse = transportMoneyData?.output || {};

  const {isLoading: userWalletsIsLoading, data: userWalletsData, isFetched, dataUpdatedAt} = useRequest({
    path: '/api/core/wallet/info',
    key: ['userWalletInfo'],
    options: {
      enabled: (transportStep === 2),
      cacheTime: 0,
    }
  });


  useEffect(() => {
    if (transportStep === 2 && isFetched) {
      let draftUserInfo = auth;

      if (userWalletsData?.output) {
        draftUserInfo.walletDetails = userWalletsData?.output;
      }
      handleChangeUserData(draftUserInfo)
    }
  }, [transportStep, isFetched, dataUpdatedAt])

  const handleTransport = () => {
    const formData = transportFormRef?.getFieldsValue(true);
    const draftFormData = structuredClone(formData);
    transportMoneyRequest({
      amount: +(draftFormData?.amount?.replace(/,/g, '')),
      destWalletSerial: response?.personWalletInfo?.walletSerial,
      otp: draftFormData?.inputCode,
      sourceWalletSerial: +(auth?.walletDetails?.walletSerial),
    }).then(() => {
      toast.success("مبلغ مورد نظر با موفقیت انتقال پیدا کرد")
      setTransportStep(2);
    }).catch((err) => {
      const errorMessage = errorMessages[err?.output];
      toast.error(errorMessage || 'برداشت انجام نشد، لطفا اطلاعات ورودی را چک نمایید');
      if (err?.output !== 'Invalid Otp') {
        transportFormRef.resetFields();
        setTransportStep(0)
        setTransactionDetailModal(false)
      } else {
        transportFormRef.setFields([
          {
            name: 'inputCode',
            value: '',
            errors: ['کد وارد شده اشتباه است'],
          }
        ])
      }
    })
  };


  useEffect(() => {
    if (!sendOtpIsLoading) {
      setResendCodeDeadline(fn_deadline('02.01'));
      setResendCode(false);
    }
  }, [sendOtpIsLoading]);


  useEffect(() => setSubmitVisible(!!!(otpInputWatch && otpInputWatch?.length === 6)), [otpInputWatch]);

  const handleAmountButtons = amount => {
    transportFormRef.setFields([{
      name:"amount",
      value: formatNumber(starkString(amount).parseNumber().englishNumber().toString()),
    }])
  }


  return (
    <Spin spinning={sendOtpIsLoading || transportMoneyLoading || userWalletsIsLoading || personIdentityIsLoading}>
      <Form
        form={transportFormRef}
        {...layout}
        name='forgetPasswordFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleTransport}
      >
        <ForgetPasswordContainer className='px-8 pb-10 pt-4'>
          {transportStep === 0 &&
            <div className={"items-center w-full"}>
              <div className={" w-full"}>
                <p className={"!mb-3"}>مبلغ پیش فرض</p>
                <div className={"mb-2"}>
                  <div className={"flex gap-4 items-center text-center "}>
                    <div onClick={()=> handleAmountButtons(1000000)} className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
                      <p className={"leading-[38px]"}>۱,۰۰۰,۰۰۰ ریال</p>
                    </div>
                    <div onClick={()=> handleAmountButtons(2000000)} className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
                      <p className={"leading-[38px]"}>۲,۰۰۰,۰۰۰ ریال</p>
                    </div>
                    <div onClick={()=> handleAmountButtons(5000000)} className={"shadow-shadow !items-center !text-center h-[42px] !border rounded-md w-1/4 cursor-pointer"}>
                      <p className={"leading-[38px]"}>۵,۰۰۰,۰۰۰ ریال</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className={"w-full max-w-[310px]"}>
                <Input
                  name={'mobile'}
                  label={'شماره موبایل'}
                  noPlaceHolder
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'شماره موبایل مقصد'})
                    },
                    {
                      pattern: new RegExp(/^[0-9]+$/),
                      message: inputRule('must be number input', {inputName: 'شماره موبایل مقصد'})
                    },
                    {
                      min: 11,
                      message: inputRule('minLength input', {inputName: 'شماره موبایل مقصد', length: 11}),
                      validateTrigger: 'onBlur'
                    },
                    {
                      max: 11,
                      message: inputRule('maxLength input', {inputName: 'شماره موبایل مقصد', length: 11})
                    }
                  ]}
                  maxLength={11}
                  justNumber
                  formRef={transportFormRef}
                  ltr
                  focus
                />
              </div>
              <div/>
              <div className={"w-full max-w-[310px]"}>
                <Input
                  name='amount'
                  label={'مبلغ'}
                  noPlaceHolder
                  placeholderAlign={'right'}
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'مبلغ'})
                    },
                    {
                      validator: (_, value) => {
                        if (value?.length && +(value?.replace(/,/g, '')) < 50000) {
                          return Promise.reject(new Error(inputRule("minLength amount", {
                            inputName: "مبلغ",
                            length: "50000 ریال"
                          })))
                        }

                        return Promise.resolve();
                      }
                    },
                  ]}
                  ltr
                  justNumber
                  formRef={transportFormRef}
                  maxLength={11}
                  onChange={e => {
                    transportFormRef.setFields([
                      {
                        name: 'amount',
                        value: e?.target?.value ? formatNumber(starkString(e?.target?.value).parseNumber().englishNumber().toString()) : null,
                        errors: []
                      },
                    ])
                  }}
                />
              </div>
              <div className={"mt-[6rem] m-auto text-center items-center"}>
                <Button
                  style={{margin: 'auto', padding: "0 20px"}}
                  type={'secondary'}
                  onClick={handleOpenModal}
                  icon={<LeftOutlined/>}
                  iconAlign={'end'}
                >
                  ادامه
                </Button>
              </div>
              <Modal
                open={transactionDetailModal}
                onCancel={handleCloseModal}
                size={{
                  sm: 55,
                  xs: 55,
                  md: 55,
                  lg: 55,
                  xl: 55,
                  xxl: 30
                }}
                bodyStyle={{
                  padding: 0,
                }}
                style={{
                  top: '30vh'
                }}
              >
                <div className={"p-10 items-center text-center m-auto"}>
                  <div className={" text-center items-center text-textcolor"}>
                    <h1 className={"pb-5 text-textblue text-[16px]"}>اطلاعات مقصد</h1>
                    <div className={"flex justify-center gap-2 mx-auto pb-5 "}>
                      <h1>نام:</h1>
                      <h1>{response?.personInfo?.firstname}</h1>
                    </div>
                    <div className={"flex justify-center gap-2 mx-auto pb-5"}>
                      <h1>نام خانوادگی:</h1>
                      <h1>{response?.personInfo?.lastname}</h1>
                    </div>
                    <div className={"flex justify-center gap-2 mx-auto pb-8"}>
                      <h1>شناسه کیف پول:</h1>
                      <h1>{response?.personWalletInfo
                        ?.walletSerial}</h1>
                    </div>
                  </div>

                  <button onClick={handleSendOtpCode} className={"bg-textblue text-white rounded-md px-3 py-2"}>
                    تایید و ارسال کد یکبار مصرف
                  </button>
                </div>
              </Modal>
            </div>
          }
          {transportStep === 1 &&
            <div className={"w-full items-center"}>
              <div className={"w-full max-w-[310px]"}>
                <Input
                  name={'inputCode'}
                  noPlaceHolder
                  maxLength={6}
                  label={('کد ارسال شده را وارد نمایید')?.replaceAll('{{mobileNumber}}', userMobile)}
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'کد تایید'})
                    }
                  ]}
                />
              </div>
              <div className={"w-[310px]"}>
                <div className='--otpStatus'>
                  <Row justify='space-between' gutter={17}>
                    <If condition={!resendCode}>
                      <Then>
                        <Col>
                          <WarningOutlined/> {'اعتبار باقیمانده کد ارسال شده'}
                        </Col>

                        <Col>
                          <Countdown value={resendCodeDeadline} onFinish={() => setResendCode(true)} format='mm:ss'/>
                        </Col>
                      </Then>

                    </If>
                  </Row>
                </div>
              </div>

              <div className={"mt-[12rem] m-auto text-center items-center w-full max-w-[230px]"}>
                <Button className={"bg-backbtn text-white "}
                        type={'submit'}
                        block
                        onClick={handleTransport}
                        icon={<LeftOutlined/>}
                        iconAlign={'end'}
                >
                  انتقال
                </Button>
              </div>
            </div>
          }
        </ForgetPasswordContainer>
      </Form>
      {
        transportStep === 2 &&
        <div className={"bg-white text-center items-center w-full max-w-[500px] m-auto px-8 pb-10 "}>
          <div className={"text-textcolor text-[14px]"}>
            <div className={"m-auto text-center items-center pb-8"}>
              <img className={"inline text-tick pb-5"} src={"/images/Tick Square.svg"}/>

              <h1 className={"text-tick text-[16px]"}>
                انتقال با موفقیت انجام شد
              </h1>

            </div>
            <div className={"flex justify-between items-center  pb-[27px]"}>
              <h1>مبلغ: (ریال)</h1>
              <h1>{transportMoneyResponse?.transactionPrice}</h1>
            </div>
            <div className={"flex justify-between items-center  pb-[27px]"}>
              <h1>شماره ترمینال:</h1>
              <div className={"flex gap-1"}>
                <h1>{response?.personInfo?.firstname}</h1>
                <h1>{response?.personInfo?.lastname}</h1>
              </div>
            </div>

            <div className={"flex justify-between items-center pb-[27px]"}>
              <h1>کد رهگیری:</h1>
              <h1>{transportMoneyResponse?.referenceNumber}</h1>
            </div>

            <div className={"flex justify-between items-center pb-[43px]"}>
              <h1>تاریخ و ساعت:</h1>
              <h1>{transportMoneyResponse?.transactionDate}</h1>
            </div>

            <button className={"border border-blue-700 text-tickettext rounded-md px-2 py-2.5"}
                    onClick={goToWalletPage}>
              بازگشت به صفحه کیف پول
            </button>

          </div>
        </div>
      }
      {
        transportStep === 3 &&
        <div className={"bg-white !text-center !items-center w-full max-w-[650px] m-auto px-8 pb-10 "}>
          <div className={"text-textcolor text-[14px] "}>
            <div className={"m-auto !text-center !items-center pb-8 "}>
              <img className={"inline text-tick pb-5"} src={"/images/Close Square.svg"}/>
              <h1 className={"text-error text-[16px]"}>
                انتقال ناموفق
              </h1>
            </div>
            <div className={"flex justify-between items-center  pb-[27px]"}>
              <h1>توضیحات:</h1>
              <h1>{errorMessages[transportMoneyError?.output] || '--'}</h1>
            </div>
            <button
              className={"border border-blue-700 text-tickettext rounded-md px-2 py-2.5"}
              onClick={goToWalletPage}
            >
              بازگشت به صفحه کیف پول
            </button>
          </div>
        </div>
      }
    </Spin>
  );
};

export default TransportMoneyAdmin;

