import React, {useRef, useState} from 'react';
import {useRequest} from "../../../../utils/useRequest";
import { Button, Col, Form, Row, Select } from 'antd';
import { DatePicker, SelectBox, Table} from "../../../../templates/Ui";
import SvgIcon from "../../../../templates/components/SvgIcon";
import styled from "styled-components";
import {convertColor, convertDatePicker} from "../../../../utils/helper";
import {useParams} from "react-router-dom";
import {DateObject} from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";


const TransactionsListContainer = styled(Row)`
  background-color: #FFFFFF;
  border: 1px solid #F0F0F0;
  border-radius: 10px;
  padding: 41px 0 17px;

  .--topSection {
    border-bottom: 1px solid #F0F0F0;
    padding: 0 44px 20px;
  }

  .--bottomSection {
    .__filterSection {
      padding: 0 44px;
    }

    .__table {
      .--details {
        cursor: pointer;
        color: #407BFF;
        text-decoration-line: underline;
        font-size: .875rem;
        font-weight: 400;

        :hover {
          color: ${convertColor('#407BFF', -40)};
        }
      }
    }
  }
`;


const TransactionsList = () => {

    const [filterFormRef] = Form.useForm();

    const currentData = new DateObject({ calendar: persian });

    const [startDate, setStartDate] = useState(currentData?.format('YYYY/MM/DD'))

    const [endDate, setEndDate] = useState(currentData?.format('YYYY/MM/DD'))

    const {terminalNumber} = useParams();

    const tableRef = useRef();

    const [page, setPage] = useState(1);

    const [deviceType, setDeviceType] = useState("all");

    const {isLoading, data} = useRequest({
        path: '/api/v1/transaction/list',
        params: {
            pageNumber: '1',
            transactionsDate: `'${convertDatePicker(startDate)}'`,
            transactioneDate: `'${convertDatePicker(endDate)}'`,
            terminalNumber,
            rowPage: 20,
            deviceType: deviceType === 'all' ? null : deviceType
        },
        key: ['tractionsList', page, deviceType, startDate, endDate, terminalNumber],
        options: {
            retry: false
        },
        apiType: 'admin'
    });

    const response = data?.output || [];

    const tableColumns = [

        {
            title: 'شماره ترمینال',
            dataIndex: 'terminalNumber',
            key: 'terminalNumber',
            align: 'center'
        },
        {
            title: 'شماره مشتری',
            dataIndex: 'merchantNumber',
            key: 'merchantNumber',
            align: 'center'
        },
        {
            title: 'تاریخ',
            dataIndex: 'sTransactionDate',
            key: 'sTransactionDate',
            align: 'center'
        },
        {
            title: 'ساعت',
            dataIndex: 'sTransactionTime',
            key: 'sTransactionTime',
            align: 'center'
        },
        {
            title: 'کد رهگیری',
            dataIndex: 'traceNo',
            key: 'traceNo',
            align: 'center'
        },
        {
            title: 'شماره مرجع',
            dataIndex: 'referenceNumber',
            key: 'referenceNumber',
            align: 'center'
        },
        {
            title: 'نوع دستگاه',
            dataIndex: 'deviceType',
            key: 'deviceType',
            align: 'center'
        },

        {
            title: 'شمازه پرداخت',
            dataIndex: 'paymentNumber',
            key: 'paymentNumber',
            align: 'center'
        },
        {
            title: 'شناسه معامله',
            dataIndex: 'transactionNumber',
            key: 'transactionNumber',
            align: 'center'
        },
        {
            title: 'مبلغ',
            dataIndex: 'orginalPrice',
            key: 'orginalPrice',
            align: 'center'
        },

        {
            title: 'روز پرداخت',
            dataIndex: 'settlementDate',
            key: 'settlementDate',
            align: 'center'
        },
        {
            title: 'شناسه پرداخت',
            dataIndex: 'paymentCode',
            key: 'paymentCode',
            align: 'center'
        },

        {
            title: 'تاریخ تسویه',
            dataIndex: 'execSettlementDate',
            key: 'execSettlementDate',
            align: 'center'
        },
        {
            title: 'نوع پول ',
            dataIndex: 'currencyType',
            key: 'currencyType',
            align: 'center'
        },

        {
            title: 'تاریخ تراکنش میلادی',
            dataIndex: 'mTransactionDate',
            key: 'mTransactionDate',
            align: 'center'
        },
        {
            title: 'ساعت تراکنش میلادی',
            dataIndex: 'mTransactionTime',
            key: 'mTransactionTime',
            align: 'center'
        },
        {
            title: 'شماره شبا',
            dataIndex: 'shaba',
            key: 'shaba',
            align: 'center'
        },
    ];

    const handleFilter = values => {
        setDeviceType(values.deviceType);
        setStartDate(values.startDate);
        setEndDate(values.endDate);
    }


    return (
        <Form
            form={filterFormRef}
            name='indexFrom'
            autoComplete='off'
            scrollToFirstError
            labelCol={{
                span: 24
            }}
            wrapperCol={{
                span: 24
            }}
            onFinish={handleFilter}
        >
            <TransactionsListContainer gutter={[0, 23]}>
                <Col span={24} className='--topSection'>
                    <Row gutter={16} align={'middle'} justify={'space-between'}>
                        <Col>
                            لیست تراکنش ها
                        </Col>
                    </Row>
                </Col>

                <Col span={24} className='--bottomSection'>
                    <Row gutter={[0, 23]}>
                        <Col span={24} className='__filterSection'>
                            <Row gutter={16} align={'middle'} justify={'space-between'}>
                                <Col span={6}>

                                    <SelectBox
                                        name={"deviceType"}
                                        label={"نوع دستگاه"}
                                        initialValue={'all'}
                                    >
                                        <Select.Option value={"all"}>همه</Select.Option>
                                        <Select.Option value={"POS"}>POS</Select.Option>
                                        <Select.Option value={"IPG"}>IPG</Select.Option>
                                    </SelectBox>
                                </Col>

                                <Col span={10}>
                                    <Row gutter={16}>
                                        <Col span={12}>
                                            <DatePicker
                                                name={'startDate'}
                                                placeholder={'از تاریخ'}
                                                label={<span></span>}
                                                initialValue={currentData?.format('YYYY/MM/DD')}
                                            />
                                        </Col>

                                        <Col span={12}>
                                            <DatePicker
                                                name={'endDate'}
                                                placeholder={'تا تاریخ'}
                                                label={<span></span>}
                                                initialValue={currentData?.format('YYYY/MM/DD')}
                                            />
                                        </Col>
                                    </Row>
                                </Col>

                            
                                    <Col span={ 4 } className="text-end mt-2">
                                        <Button htmlType={"submit"} className={ '!bg-purple h-[42px] text-white rounded-lg !w-full' }>
                                            اعمال
                                        </Button>
                             
                                </Col>


                            </Row>
                        </Col>

                        <Col span={24} className='__table' ref={tableRef}>
                            <Table
                                scroll={{x:"1600px"}}
                                columns={tableColumns}
                                loading={isLoading}
                                dataSource={response}
                                onChange={({current}) => setPage(current)}
                                bordered
                                tableLayout={'fixed'}
                                pagination={{
                                    hideOnSinglePage: true,
                                    defaultPageSize: 20,
                                    total: 200,
                                    showSizeChanger: false,
                                    responsive: true,
                                    position: ['bottomLeft'],
                                    nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20} color={'#999999'}
                                                       style={{margin: '6px auto'}}/>,
                                    prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20} color={'#999999'}
                                                       style={{margin: '6px auto'}}/>,
                                    onChange: () => tableRef?.current.scrollIntoView({behavior: 'smooth'})
                                }}
                            />
                        </Col>
                    </Row>
                </Col>
            </TransactionsListContainer>
        </Form>
    );
};

export default TransactionsList;