import React, {useRef, useState} from 'react';
import {Col, Form, Row, Select, Spin} from 'antd';
import {useRequest} from '../../../../utils/useRequest';
import {Button, Input, Modal, SelectBox, Table, TextArea} from '../../../../templates/Ui';
import {DateObject} from 'react-multi-date-picker';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import SvgIcon from '../../../../templates/components/SvgIcon';
import styled from "styled-components";


const RequestAccountsContainer = styled(Row)`


  .ant-table-row {
    &.--active {
      .ant-table-cell:first-child {
        border-right: 7px solid #1cc500 !important;
      }
    }

    &.--deActive {
      .ant-table-cell:first-child {
        border-right: 7px solid #fe2301 !important;
      }
    }
  }

`;


const RequestsList = () => {
    const [filterFormRef] = Form.useForm();
    const [terminalNo, setTerminalNo] = useState(1);
    const transactionTableRef = useRef(null);
    const [page, setPage] = useState(10);
    const [ticketModal, setTicketModal] = useState({});

    const [requestTypeId, setRequestTypeId] = useState(51);
    const [personId, setPersonId] = useState();
    const {Option} = Select;
    const [ticketFormRef] = Form.useForm();

    const handleOpenTicketModal = (ticketModal) => {
        setTicketModal(ticketModal);
    };


    const {
        isLoading: requestsListIsLoading,
        data: requestsList,

    } = useRequest({
        path: '/setting/list-request-type',

        options: {
            retry: false,
        },
        apiType: 'club',
        key: ['request-type-list'],
    });


    const requestsListResponse = requestsList || [];


    const handleFilter = () => {
        const values = filterFormRef?.getFieldsValue(true);
        setPersonId(values?.personId);
        setRequestTypeId(values?.requestTypeId);
    };


    const {
        isLoading,
        data,
        refetch,
    } = useRequest({
        path: '/merchant/request-list',
        params: {
            requestTypeId: requestTypeId,
            personId: personId,
        },
        options: {
            retry: false,
        },
        apiType: 'club',
        key: ['request-list', page, personId, requestTypeId],
    });


    const response = data || [];
    console.log('ffffffffffff', response);


    const tableColumns = [

        {
            title: 'کد پذیرنده',
            dataIndex: 'merchentCode',
            key: 'merchentCode',
            align: 'center',

        },
        {
            title: 'عنوان',
            dataIndex: 'requestTypeDesc',
            key: 'requestTypeDesc',
            align: 'center',

        },
        {
            title: 'توضیحات',
            dataIndex: 'description',
            key: 'description',
            align: 'center',
            render: (_, row) => {
                return `${row?.description?.slice(0, 20)} ...`;
            },

        },
        {
            title: 'جواب',
            dataIndex: 'answered',
            key: 'answered',
            align: 'center',
            render: (_, row) => {
                return row?.answered ?
                    <div className={"text-lime-500"}>{row.answered.slice(0, 20)} ... </div> :
                    <div className={row?.answered ? "text-lime-500" : "text-red-500"}>پاسخی داده نشده</div>
            },

        },
        {
            title: 'شماره ترمینال',
            dataIndex: 'terminalNumber',
            key: 'terminalNumber',
            align: 'center',

        },
        {
            title: 'نام پذیرنده',
            dataIndex: 'personName',
            key: 'personName',
            align: 'center',

        },

        {
            title: 'تاریخ',
            dataIndex: 'totalResponseTime',
            key: 'totalResponseTime',
            align: 'center',
            render: (_, row) => {
                const hour = row?.modifyDate?.split('T')[1]?.split(':');
                const date = new DateObject({
                    date: new Date(row?.modifyDate),
                    calendar: gregorian,
                });
                return date.add(7, 'hour').convert(persian).format(`${hour[0]}:${hour[1]} - YYYY/MM/DD`);
            },
        },

        {
            title: 'جزئیات',
            dataIndex: 'action',
            key: 'action',
            align: 'center',
            render: (_, row) => <p onClick={() => handleOpenTicketModal(row)}
                                   className={'text-blue-500 underline cursor-pointer'}>جزئیات</p>,
        },

    ];


    const {
        isLoading: answerIsLoading,
        mutateAsync: answerRequest,
    } = useRequest({
        path: '/merchant/update-request',
        mutationMethod: 'patch',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: 'درخواست شما با موفقیت ارسال شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleOffers = async () => {
        const values = ticketFormRef.getFieldsValue(['answer']);
        try {
            await answerRequest({
                trakingNumber: ticketModal?.trakingNumber,
                answered: values?.answer,
                status: 2,
            });
            await ticketFormRef.resetFields();
            await refetch();
            await setTicketModal({});
        } catch (err) {
            console.log(err);
        }
    };

    return (
        <RequestAccountsContainer>
            <Spin spinning={answerIsLoading || isLoading || requestsListIsLoading}>
                <Col span={24} className={'bg-white p-5 shadow-6 rounded-[10px]'}>
                    <div>
                        لیست درخواست ها
                    </div>
                    <Form
                        form={filterFormRef}
                        name="indexFrom"
                        autoComplete="off"
                        scrollToFirstError
                        labelCol={{
                            span: 24,
                        }}
                        wrapperCol={{
                            span: 24,
                        }}
                        onFinish={handleFilter}
                    >


                        <Row gutter={16} justify={'end'}>
                            <Col span={6}>
                                <SelectBox
                                    name={'requestTypeId'}
                                    placeholder={'نوع درخواست'}
                                    initialValue={51}
                                >

                                    {
                                        requestsListResponse?.map(item =>
                                            <Select.Option
                                                value={item?.rowId}>{item?.requestTypeDesc}</Select.Option>,
                                        )
                                    }
                                </SelectBox>
                            </Col>
                            <Col span={6}>
                                <Input
                                    name={'personId'}
                                    placeholder={'شماره پذیرنده'}
                                    bordered
                                    allowClear

                                />
                            </Col>
                            <Col span={4}>
                                <Button
                                    htmlType={'submit'}
                                    type={'secondary'}
                                    className={'!bg-purple !text-white w-full mx-auto'}>اعمال فیلتر
                                </Button>
                            </Col>


                            <Table
                                columns={tableColumns}
                                dataSource={response}

                                bordered
                                tableLayout={'fixed'}
                                rowClassName={response => {
                                    if (response?.answer) {
                                        return '--active'
                                    }

                                    return '--deActive'
                                }}
                                // rowClassName={response => {
                                //     if (response?.status!==1) {
                                //         return '--statusTrue';
                                //     }
                                //     return '--statusFalse';
                                // }}
                                pagination={{
                                    hideOnSinglePage: true,
                                    defaultPageSize: page,
                                    total: 100,
                                    showSizeChanger: false,
                                    responsive: true,
                                    position: ['bottomLeft'],

                                    nextIcon: <SvgIcon icon={'leftCircle'} width={20} height={20}
                                                       color={'#999999'}
                                                       style={{margin: '6px auto'}}/>,
                                    prevIcon: <SvgIcon icon={'rightCircle'} width={20} height={20}
                                                       color={'#999999'}
                                                       style={{margin: '6px auto'}}/>,

                                    // onChange: () => transactionTableRef?.current.scrollIntoView({ behavior: 'smooth' }),
                                }}
                            />
                        </Row>
                    </Form>
                </Col>
                <Modal
                    open={ticketModal?.rowId}
                    onCancel={() => setTicketModal({})}
                    size={{
                        sm: 55,
                        xs: 55,
                        md: 80,
                        lg: 80,
                        xl: 80,
                        xxl: 80,
                    }}
                    bodyStyle={{
                        padding: 0,
                    }}
                    style={{
                        top: '10vh',
                    }}
                >
                    <Form
                        name={'ticket'}
                        form={ticketFormRef}
                        autoComplete="off"
                        labelCol={{
                            span: 24,
                        }}
                        wrapperCol={{
                            span: 24,
                        }}
                        onFinish={handleOffers}
                        className={'mt-[20px]'}
                    >



                        <div className={'py-5 px-10'}>
                            <div className={'pb-5 font-[500] text-textblue '}>
                                {ticketModal?.requestTypeDesc}
                            </div>
                            <div className={'pb-3 font-[400]'}>
                                توضیحات:
                            </div>
                            <div
                                className={' bg-[#f5f5f5] px-3  rounded-lg text-[#7a7a7a] leading-[22px] text-justify text-[13px] py-4 mb-2 font-[400] '}>
                                {ticketModal?.description ? ticketModal?.description : 'پاسخی ثبت نشده است'}
                            </div>

                            <div>
                                <TextArea
                                    name={'answer'}
                                    label={'پاسخ دهی:'}
                                    placeholder={'پاسخ دهی:'}
                                    initialValue={ticketModal?.answered}
                                    rules={[{
                                        required: true,
                                        message: 'لطفا پاسخ خود را ثبت نام کنید.',
                                    }]}
                                    ref={ticketFormRef}
                                />
                            </div>
                            <div className={'py-5 font-[400] items-center text-center'}>
                                <Button htmlType={'submit'} type={'secondary'} onClick={handleOffers}
                                        className={'!bg-purple !text-white w-1/4 py-2 rounded-lg'}>ارسال
                                </Button>
                            </div>
                        </div>

                    </Form>
                </Modal>
            </Spin>
        </RequestAccountsContainer>
    );
};

export default RequestsList;
