import React, {useState} from 'react';
import {Button, Col, Form, Row} from "antd";
import {DatePicker} from "../../../../../templates/Ui";
import {formatNumber, inputRule} from "../../../../../utils/helper";

import {DateObject} from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import "../../../../../index.scss"
import {Pie} from '@ant-design/plots';

const Index = () => {

  const [filterFormRef] = Form.useForm();
  const currentData = new DateObject({calendar: persian});
  const [startDate, setStartDate] = useState(currentData?.format('YYYY-MM-DD'))
  const [endDate, setEndDate] = useState(currentData?.format('YYYY-MM-DD'));


  const handleFilter = values => {
    setStartDate(values?.startDate);
    setEndDate(values?.endDate);
  }


  const sina = "4645684643"
  const DemoPie = () => {
    const data = [
      {
        type: 'شارژ کیف پول',
        value: 250000,
      },
      {
        type: 'برداشت کیف پول',
        value: 10000,
      },
      {
        type: 'انتقال از کیف پول',
        value: 600000,
      },
      {
        type: 'پرداخت بابت خرید',
        value: 250000,
      },
      {
        type: 'دریافت از کیف پول دیگر',
        value: 600000,
      },
      {
        type: 'دریافت بابت فروش',
        value: 1500000
      },
      {
        type: 'پرداخت بابت قبض',
        value: 750000
      }
    ];
    const config = {
      height:250,
      width:250,
      color: ['#FF4600', '#FF006F', '#FF00FA', '#1447A0', '#5CB0FF', '#C4A700', '#1CC500'],
      appendPadding: 0,
      data,
      angleField: 'value',
      colorField: 'type',
      radius: 120,
      innerRadius: 0.7,
      label: null,

      interactions: [
        {
          type: 'element-selected',
        },
        {
          type: 'element-active',
        },
      ],
      statistic: {
        title: {
          content: 'موجودی کل کیف پول'
        },
        content: {
          content: formatNumber(200000),
        },
      },
      legend: false
    };
    return <Pie meta={null} {...config} />;
  };

  return (
    <div className={"bg-white p-5 rounded-lg"}>
      <Form
        form={filterFormRef}
        name='indexFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleFilter}
      >
        <div className={"flex justify-between gap-3"}>
          <p className={"py-2"}>گزارش کیف پول</p>
          <div className={"flex gap-5"}>
            <DatePicker
              name={'startDate'}
              placeholder={'از تاریخ'}
              hiddenLabel
              initialValue={startDate}
              dateFormat={'YYYY-MM-DD'}
              rules={[
                {
                  required: true,
                  message: inputRule('required selectBox', {inputName: 'تاریخ '})
                }
              ]}
            />
            <DatePicker
              name={'endDate'}
              placeholder={'تا تاریخ'}
              hiddenLabel
              initialValue={endDate}
              dateFormat={'YYYY-MM-DD'}
              rules={[
                {
                  required: true,
                  message: inputRule('required selectBox', {inputName: 'تاریخ '})
                }
              ]}
            />
            <button className={"bg-purple px-1 py-2.5 h-10 leading-5 w-full max-w-[190px] text-white rounded-lg shadow-shadow"}>
              جستجو
            </button>
          </div>
        </div>
      </Form>
      <div className={"flex gap-10 items-center !py-0 justify-between mx-auto w-full max-w-[1200px]"}>
        <div className={" test"}>
          <DemoPie/>
        </div>
        <div className={" text-center items-center"}>
          <div className={"flex gap-5"}>
            <p className={"bg-orange-600 w-4 h-4"}></p>
            <p>شارژ کیف پول:</p>
            <p> {sina}</p>
          </div>
          <div className={"flex gap-5 py-10 items-center"}>
            <p className={"bg-red-500 w-4 h-4"}></p>
            <p>برداشت کیف پول:</p>
            <p> {sina}</p>
          </div>
          <div className={"flex gap-5 items-center"}>
            <p className={"bg-pink-500 w-4 h-4"}></p>
            <p>انتقال از کیف پول:</p>
            <p> {sina}</p>
          </div>
          <div className={"flex gap-5 pt-10 items-center"}>
            <p className={"bg-backbtn w-4 h-4"}></p>
            <p>پرداخت بابت خرید:</p>
            <p> {sina}</p>
          </div>
        </div>
        <div className={" "}>
          <div className={"flex gap-5 items-center"}>
            <p className={"bg-blue-400 w-4 h-4"}></p>
            <p>دریافت از کیف پول دیگر:</p>
            <p> {sina}</p>
          </div>
          <div className={"flex gap-5 py-10 items-center"}>
            <p className={"bg-yellow-500 w-4 h-4"}></p>
            <p>دریافت بابت فروش:</p>
            <p> {sina}</p>
          </div>
          <div className={"flex gap-5 items-center"}>
            <p className={"bg-emerald-500 w-4 h-4"}></p>
            <p>پرداخت بابت قبض:</p>
            <p> {sina}</p>
          </div>
          <div className={"flex gap-5 pt-10 items-center"}>
            <p className={"w-4 h-4"}>*</p>
            <p>مبالغ به ریال می‌باشد</p>
          </div>
        </div>
      </div>


    </div>
  );
};

export default Index;