import React, {useState} from 'react';
import {Col, Collapse, Form, Space, Spin} from 'antd';
import {useRequest} from '../../../../utils/useRequest';
import {Button, Input, Modal} from '../../../../templates/Ui';
import {inputRule} from '../../../../utils/helper';
import styled from 'styled-components';
import question from 'assets/icons/question.svg';

const CollapseContainer = styled(Collapse)`

  .ant-collapse {
    border: 0 !important;
    background-color: #F5F5F5 !important;
    border-radius: 50px !important;

    .ant-collapse-item {
      margin-bottom: 18px !important;
      border-radius: 10px !important;
      box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.09);
    }


  }

  :where(.css-dev-only-do-not-override-yp8pcc).ant-collapse {
    border: 0px solid white !important;
  }


  .ant-collapse-content-box {
    background-color: #F9F9F9 !important;
  }

  .ant-collapse-content-box {
    padding-top: 20px !important;
    color: #4d4d4d;
    font-size: 12px !important;
    border-radius: 20px;
  }

  //
  //.ant-collapse-expand-icon {
  //  display: none !important;
  //}
`;

const AdminFaq = () => {

    const [adminFaqForm] = Form.useForm();
    const [adminEditFaqForm] = Form.useForm();
    const {Panel} = Collapse;
    const [editModal, setEditModal] = useState({});


    const handleOpenModal = (editModal) => {
        setEditModal(editModal);
    };

    console.log('fdssssssss', editModal);

    const {
        isLoading: adminFaqIsLoading,
        data: adminFaqData,
        refetch: refetchFaq,
    } = useRequest({
        path: '/question/list',
        key: ['question'],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const FaqDataRes = adminFaqData;


    const {
        isLoading: FaqIsLoading,
        mutateAsync: FaqRequest,
    } = useRequest({
        path: '/question/insert',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: ' سوال متداول با موفقیت ایجاد شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleSurveyRequest = async () => {
        const values = adminFaqForm.getFieldsValue(true);
        try {
            await FaqRequest({
                question: `'${values?.question}'`,
                answer: `'${values?.answer}'`,
            });
            await refetchFaq();
            adminFaqForm.resetFields();
        } catch (err) {
            console.log(err);
        }
    };


    const {
        isLoading: changeFaqIsLoading,
        mutateAsync: changeFaqRequest,
    } = useRequest({
        path: '/question/update',
        mutationMethod: 'patch',
        isMutation: true,
        apiType: 'club',
        customSuccessMessage: ' سوال متداول با موفقیت ویرایش شد',
        customErrorMessage: 'خطا در ارسال درخواست لطفا مجددا تلاش فرمایید',
    });


    const handleChangeFaq = async () => {
        const values = adminEditFaqForm.getFieldsValue(true);
        try {
            await changeFaqRequest({
                question: editModal?.question,
                rowId: editModal?.rowId,
                answer: `'${values?.answer}'`,
            });
            await refetchFaq();
            adminFaqForm.resetFields();
        } catch (err) {
            console.log(err);
        }
    };


    const onChange = (key) => {
        console.log(key);
    };

    return (
        <Spin spinning={changeFaqIsLoading || FaqIsLoading || adminFaqIsLoading}>
            <div className={''}>
                <p className={'font-[500]'}>سوالات متداول</p>
                <div className={'bg-white p-[23px] leading-[22px] text-textcolor rounded-lg mt-5 '}>
                    <p className={'font-[400] '}> از طریق این بخش می توانید یک سوال متداول روی سایت فعال کنید.</p>
                    {/*<p className={"font-[400]"}>توجه داشته باشید در صورتی که لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت*/}
                    {/*  چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و*/}
                    {/*  برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.</p>*/}
                </div>
            </div>
            <Form
                form={adminFaqForm}
                name="suveyFrom"
                autoComplete="off"
                onFinish={handleSurveyRequest}
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
            >
                <div className={'bg-white p-[25px] mt-[20px] rounded-[10px] shadow-6'}>
                    <div className={'w-full mt-3'}>
                        <Input
                            name={'question'}
                            label={'سوال و توضیحات '}

                            formRef={adminFaqForm}
                            rules={[
                                {
                                    required: true,
                                    message: inputRule('required input', {inputName: 'سوال و توضیحات  '}),
                                },
                            ]}
                        />
                    </div>
                    <div className={'w-full mt-3'}>
                        <Input
                            name={'answer'}
                            label={'جواب سوال'}

                            formRef={adminFaqForm}
                            rules={[
                                {
                                    required: true,
                                    message: inputRule('required input', {inputName: 'جواب و سوال'}),
                                },
                            ]}
                        />
                    </div>
                    <Col span={7} className={'mx-auto mt-[5rem] mb-[1rem]'}>
                        <Button
                            htmlType={'submit'}
                            type={'secondary'}
                            className={'!bg-purple !text-white w-full mt-8 mx-auto'}>درج
                            سوال
                        </Button>
                    </Col>
                </div>
            </Form>
            <CollapseContainer xs={24} lg={24} className={'mt-[40px]'}>
                <Col span={24} className={"pb-[20px] text-[15px] text-center text-textblue"}>
                    لیست سوالات متداول
                </Col>
                <Collapse defaultActiveKey={['1']} expandIconPosition={'end'} onChange={onChange} accordion
                          className={'!border-0'}
                          bordered={false}>
                    {
                        FaqDataRes?.map(item =>
                            <Panel
                                header={<div className={'flex gap-2 justify-between'}>
                                    <Space size={14}>
                                        <img src={question}/>{item?.question}
                                    </Space>
                                </div>}
                                key={item?.rowId}
                                className={'bg-white'}>
                                <div className={''}>
                                    <div className={'flex justify-between'}>
                                        {item?.answer}
                                        <div>
                                            <Button
                                                type={'secondary'}
                                                onClick={() => handleOpenModal(item)}
                                                className={'!bg-purple !text-white w-full mt-8 mx-auto'}
                                            >
                                                ویرایش
                                            </Button>
                                        </div>

                                    </div>


                                </div>
                            </Panel>,
                        )
                    }

                </Collapse>
            </CollapseContainer>


            <Modal
                open={editModal?.rowId}
                onCancel={() => setEditModal({})}
                size={{
                    sm: 55,
                    xs: 55,
                    md: 80,
                    lg: 60,
                    xl: 60,
                    xxl: 60,
                }}
                bodyStyle={{
                    padding: 0,
                }}
                style={{
                    top: '15vh',
                }}
            >

                <Form
                    form={adminEditFaqForm}
                    name="indexFrom"
                    autoComplete="off"
                    scrollToFirstError
                    labelCol={{
                        span: 24,
                    }}
                    wrapperCol={{
                        span: 24,
                    }}
                    onFinish={handleChangeFaq}
                >
                    <div className={'py-5 px-10'}>

                        <div className={'w-full text-center text-purple text-[15px] font-[500]'}>
                            ویرایش سوال یا جواب
                        </div>

                        <div className={'w-full mt-3'}>
                            <Input
                                name={'question'}
                                label={'سوال و توضیحات '}
                                placeholder={editModal?.question}
                                disabled
                                formRef={adminFaqForm}
                                // rules={ [
                                //     {
                                //         required: true,
                                //         message: inputRule('required input', { inputName: 'سوال و توضیحات  ' }),
                                //     },
                                // ] }
                            />
                        </div>
                        <div className={'w-full mt-3'}>
                            <Input
                                name={'answer'}
                                label={'جواب سوال'}
                                initialValue={editModal?.answer}
                                formRef={adminFaqForm}
                                // rules={ [
                                //     {
                                //         required: true,
                                //         message: inputRule('required input', { inputName: 'جواب و سوال' }),
                                //     },
                                // ] }
                            />
                        </div>
                        <Col span={24} className={'items-center text-center py-8'}>
                            <Button
                                type={'secondary'}
                                htmlType={'submit'}
                                className={'!bg-purple !text-white w-1/2  mx-auto '}
                            >
                                ویرایش
                            </Button>
                        </Col>
                    </div>
                </Form>
            </Modal>

        </Spin>
    );
};

export default AdminFaq;
