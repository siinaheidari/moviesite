import { Col, Form, Row, Select, Space, Spin } from 'antd';
import { ReactComponent as SearchIcon } from 'assets/icons/searchAdmin.svg';
import { useRef, useState } from 'react';
import styled from 'styled-components';
import SvgIcon from 'templates/components/SvgIcon';
import {Button, Input, RadioButton, RadioFormItem, RadioGroup, SelectBox, Table} from 'templates/Ui';
import { convertColor } from 'utils/helper';
import {useRequest} from "../../../../utils/useRequest";
import {Link} from "react-router-dom";

const MerchantsManagementContainer = styled(Row)`
  background-color: #FFFFFF;
  border: 1px solid #F0F0F0;
  border-radius: 10px;
  padding: 41px 0 17px;

  .--topSection {
    border-bottom: 1px solid #F0F0F0;
    padding: 0 44px 20px;
  }

  .--bottomSection {
    .__filterSection {
      padding: 0 44px;
    }

    .__table {
      .--details {
        cursor: pointer;
        color: #407BFF;
        text-decoration-line: underline;
        font-size: .875rem;
        font-weight: 400;

        :hover {
          color: ${ convertColor('#407BFF', -40) };
        }
      }
    }
  }
`;

const MerchantsManagement = () => {


  const [filterFormRef] = Form.useForm();
  
  const tableRef = useRef();

  const [page, setPage] = useState(1);

  const [deviceType,setDeviceType]=useState(null);


  const {isLoading, data} = useRequest({
    path: '/merchant/merchant-list',
    params: {
      pageNumber: page,
      rowPage: 20,
      deviceType: deviceType
    },
    key: ['merchantList', page, deviceType],
    apiType: 'admin',
    options: {
      retry: false
    },
    /*options: {
      enabled: !!deviceType
    }*/
  });

  const response = data?.output || [];
  console.log(response)

  const {isLoading: deviceTypeIsLoading, data: deviceTypeData} = useRequest({
    path: '/merchant/device-type',
    params: {
    },
    key: ['deviceType1'],
    options: {
      retry: false
    },
    apiType: 'admin'
  });


  const deviceTypes = deviceTypeData?.output || [];

  const tableColumns = [
    {
      title: 'نام',
      dataIndex: 'firstName',
      key: 'firstName',
      align: 'center'
    },
    {
      title: 'نام خانوادگی',
      dataIndex: 'lastName',
      key: 'lastName',
      align: 'center'
    },
    {
      title: 'شماره ترمینال',
      dataIndex: 'terminalNumber',
      key: 'terminalNumber',
      align: 'center'
    },
    {
      title: 'نوع پایانه درخواستی',
      dataIndex: 'deviceType',
      key: 'deviceType',
      align: 'center'
    },
    {
      title: 'شعبه',
      dataIndex: 'branchName',
      key: 'branchName',
      align: 'center'
    },
    {
      title: 'کد شعبه',
      dataIndex: 'branchCode',
      key: 'branchCode',
      align: 'center'
    },
    {
      title: 'تاریخ',
      dataIndex: 'createDate',
      key: 'createDate',
      align: 'center'
    },
    {
      title: 'ساعت',
      dataIndex: 'createTime',
      key: 'createTime',
      align: 'center'
    },
    {
      title: '...',
      dataIndex: 'action',
      key: 'action',
      align: 'center',
      render: (_, {merchantNumber}) => <Link to={`/admin/managements/merchants/${merchantNumber}`}>جزئیات</Link>
    }
  ];
  

  console.log(deviceTypeData)

  return (
      <Form
          form={ filterFormRef }
          name='indexFrom'
          autoComplete='off'
          scrollToFirstError
          labelCol={ {
            span: 24
          } }
          wrapperCol={ {
            span: 24
          } }
      >
        <MerchantsManagementContainer gutter={ [0, 23] }>
          <Col span={ 24 } className='--topSection'>
            <Row gutter={ 16 } align={ 'middle' } justify={ 'space-between' }>
              <Col>
                لیست پذیرندگان
              </Col>
            </Row>
          </Col>

          <Col span={ 24 } className='--bottomSection'>
            <Row gutter={ [0, 23] }>
              <Col span={ 24 } className='__filterSection'>
                <Row gutter={ 16 } align={ 'middle' } justify={ 'space-between' }>
                  <Col span={ 8 }>
                    <SelectBox
                      name={"deviceType"}
                      label={"نوع دستگاه"}
                      loading={deviceTypeIsLoading}
                      initialValue={null}
                      onChange={val => setDeviceType(val)}
                    >
                      <Select.Option value={null}>همه</Select.Option>
                      {deviceTypes?.map(item => (
                        <Select.Option key={item?.rowId} value={item?.shortWord}>{item.terminalTypeDesc}</Select.Option>
                      ))}
                    </SelectBox>
                  </Col>

                  {/*<Col span={ 5 }>
                    <Input
                        name={ 'q' }
                        placeholder={ 'جستجو کنید...' }
                        addonAfter={ <SearchIcon/> }
                        allowClear={ false }
                    />
                  </Col>*/}
                </Row>
              </Col>

              <Col span={ 24 } className='__table' ref={ tableRef }>
                <Table
                    columns={ tableColumns }
                    loading={isLoading}
                    dataSource={ response }
                    onChange={({current}) => setPage(current)}
                    bordered
                    tableLayout={ 'fixed' }
                    pagination={ {
                      hideOnSinglePage: true,
                      defaultPageSize: 20,
                      total: 200,
                      showSizeChanger: false,
                      responsive: true,
                      position: ['bottomLeft'],
                      nextIcon: <SvgIcon icon={ 'leftCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                                         style={ { margin: '6px auto' } }/>,
                      prevIcon: <SvgIcon icon={ 'rightCircle' } width={ 20 } height={ 20 } color={ '#999999' }
                                         style={ { margin: '6px auto' } }/>,
                      onChange: () => tableRef?.current.scrollIntoView({ behavior: 'smooth' })
                    } }
                />
              </Col>
            </Row>
          </Col>
        </MerchantsManagementContainer>
      </Form>
  );
};

export default MerchantsManagement;
