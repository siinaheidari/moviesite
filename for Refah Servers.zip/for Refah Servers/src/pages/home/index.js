import { Col, Row } from 'antd';
import { ReactComponent as CustomerSystemFirstImg } from 'assets/images/home/customerSystemFirstImg.svg';
import { ReactComponent as CustomerSystemSecondImage } from 'assets/images/home/customerSystemSecondImage.svg';
import { ReactComponent as CustomerSystemThirdImage } from 'assets/images/home/customerSystemThirdImage.svg';

// images
import homeBg from 'assets/images/home/homeBg.svg';
import { ReactComponent as HomeImageBank } from 'assets/images/home/homeImageBank.svg';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { useAuth } from '../../contexts/auth/AuthContext';
import tw from 'twin.macro';
import borderBg from 'assets/images/borderBg.png';

const HomeContainer = styled(Row)`
  min-height: 100vh;
  margin: 0 -8vw;
  padding: 5vh 8vw;
  position: relative;
  margin-bottom: 0 !important;

  ${ tw`max-md:!h-[100vh]` }
  .--bg1,
  .--bg2,
  .--bg3 {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }

  .--bg1 {
    background-image: url(${ homeBg });
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }

  .--bg2 {
    background-color: rgba(43, 43, 43, 0.2);
  }

  .--bg3 {
    background-color: rgba(255, 255, 255, 0.2);
  }

  .--homeImageBank {
    text-align: center;
    min-height: 40vh;
    height: 350px;

    svg {
      height: 100%;
    }
  }
`;

const CustomerSystemBoxContainer = styled(Row)`
  //background: linear-gradient(110.72deg, rgba(255, 255, 255, 0.36) 1.21%, rgba(196, 196, 196, 0.06) 100%);
  //background-color: transparent;
  //backdrop-filter: blur(15px);
  height: 100%;


  .--image,
  .--link {
    text-align: center;
  }

  .--image {
    svg {
      max-height: 112px;
      -webkit-transition: ease all .5s;
      -moz-transition: ease all .5s;
      -o-transition: ease all .5s;
      transition: ease all .5s;
      -webkit-transform: scale(1);
      -moz-transform: scale(1);
      -o-transform: scale(1);
      transform: scale(1);
      display: inline;
    }
  }

  .--link {
    color: #000000;
    position: unset;

    &,
    span {
      font-weight: 400;
    }

    a {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
    }
  }

  :hover {
    .--image {
      svg {
        -webkit-transform: scale(1.15);
        -moz-transform: scale(1.15);
        -ms-transform: scale(1.15);
        -o-transform: scale(1.15);
        transform: scale(1.15);
      }
    }
  }
`;

const Home = () => {



    return (
        <HomeContainer gutter={ [ 0, 20 ] }>
            <div className="--bg3"/>
            <div className="--bg2"/>
            <div className="--bg1"/>

            <Col span={ 24 } className="--customerSystem">
                <Row gutter={ [ 21, 21 ] } justify={ 'center' }>
                    <Col xs={ 24 } md={ 6 }>
                        <div className={ 'relative' }>
                            <img src={ borderBg } className={ 'max-w-[300px] mx-auto' }/>
                            <CustomerSystemBox

                                image={ CustomerSystemThirdImage }
                                className={ '!w-[300px] mx-auto !hiddenُ' }
                                link={ {
                                    link: '/merchantProfile',
                                    text: 'سامانه',
                                    gradientText: 'باشگاه پذیرندگان',
                                } }
                            />
                        </div>
                    </Col>

                    <Col xs={ 24 } md={ 6 }>
                        <div className={ 'relative' }>
                            <img src={ borderBg } className={ 'max-w-[300px] mx-auto' }/>
                            <CustomerSystemBox
                                className={ '!w-[300px] mx-auto' }
                                image={ CustomerSystemFirstImg }
                                link={ {
                                    link: '/',
                                    text: 'سامانه هوشمند',
                                    gradientText: 'مشتریان اختصاصی',
                                } }
                            />
                        </div>

                    </Col>

                    <Col xs={ 24 } md={ 6 }>
                        <div className={ 'relative' }>
                            <img src={ borderBg } className={ 'max-w-[300px] mx-auto' }/>
                            <CustomerSystemBox
                                image={ CustomerSystemSecondImage }
                                className={ '!w-[300px] mx-auto' }
                                link={ {
                                    link: '/',
                                    text: 'سامانه',
                                    gradientText: 'باشگاه مشتریان بانک',
                                } }
                            />
                        </div>
                    </Col>

                </Row>
            </Col>

            <Col span={ 24 } className="--homeImageBank max-md:!hidden">
                <HomeImageBank style={ { display: 'inline' } }/>
            </Col>
        </HomeContainer>
    );
};

const CustomerSystemBox = ({
                               link,
                               image: Image,
                           }) => {
    return (
        <CustomerSystemBoxContainer gutter={ [ 0, 15 ] } className={ 'absolute inset-0 py-[10px]' } align={ 'middle' }>
            <Col span={ 24 } className="--image">
                <Image className="max-lg:!h-[110px] max-lg:!w-[110px] lg:!h-[122px]"/>
            </Col>

            <Col span={ 24 }
                 className="--link text-[.9rem] sm:text-[1rem] md:text-[.75rem] lg:text-[.9rem] xl:text-[1rem]">
                { link?.text }
                <span className="--gradientTextReverse"> { link?.gradientText }</span>

                <Link to={ link?.link }/>
            </Col>
        </CustomerSystemBoxContainer>
    );
};

export default Home;
