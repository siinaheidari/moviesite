import React from 'react';
import { Col, Collapse, Empty, Row, Space } from 'antd';
import { useRequest } from '../../../utils/useRequest';
import styled from 'styled-components';
import question from '../../../assets/icons/question.svg';
import news from "assets/images/news.svg"
import left from "assets/icons/Arrow - Left 2.svg"

const CollapseContainer = styled(Collapse)`

  .ant-collapse {
    border: 0 !important;
    background-color: white !important;
    border-radius: 50px !important;

    .ant-collapse-item {
      margin-bottom: 18px !important;
      border-radius: 10px !important;
      box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.09);
    }


  }

  :where(.css-dev-only-do-not-override-yp8pcc).ant-collapse {
    border: 0px solid white !important;
  }


  .ant-collapse-content-box {
    background-color: #F9F9F9 !important;

  }

  .ant-collapse-content-box {
    padding-top: 20px !important;
    color: #4d4d4d;
    font-size: 12px !important;
    border-radius: 20px;
  }

  //
  //.ant-collapse-expand-icon {
  //  display: none !important;
  //}
`;


const Index = () => {

    const { Panel } = Collapse;

    const {
        isLoading: merchantIsLoading,
        data: merchantFaqData,
        refetch: refetchFaq,
    } = useRequest({
        path: '/question/list',
        key: [ 'question' ],
        apiType: 'club',
        options: {
            cacheTime: 0,
        },
    });

    const FaqDataRes = merchantFaqData;


    const onChange = (key) => {
        console.log(key);
    };

    return (
        <Row justify={ '' }>
            <Col span={ 24 } className={ 'mt-[57px] mx-auto' }>
                <Row gutter={ [ 16, 20 ] }>
                    <Col span={ 18 }>
                        <div
                            className={ 'text-textblue rounded-[10px] shadow-6 text-[14px] font-[500] bg-white px-[35px] py-[46px]' }>
                            <div className={ 'mb-[20px]' }>
                                راهنمایی سامانه باشگاه پذیرندگان بانک رفاه
                            </div>

                            <div
                                className={ 'text-[14px] max-lg:text-[12px] font-[400] text-[#4D4D4D] leading-[27px]' }>
                                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک
                                است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط
                                فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد،
                                کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می
                                طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و
                                فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری
                                موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل حروفچینی
                                دستاوردهای اصلی، و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار
                                گیرد.لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان
                                گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای
                                شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد،
                                کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می
                                طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و
                                فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری
                                موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل حروفچینی
                                دستاوردهای اصلی، و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار
                                گیرد.لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان
                                گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای
                                شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد،
                                کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می
                                طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و
                                فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری
                                موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل حروفچینی
                                دستاوردهای اصلی، و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار
                                گیرد.
                            </div>
                        </div>

                    </Col>
                    <Col span={ 6 }>
                        <div className={ 'text-textblue rounded-[10px] shadow-6 text-[14px] font-[500] bg-white p-[10px]' }>
                            <Space align={"start"}>
                                <img src={news} className={"w-full"}/>
                                <div className={"text-[12px] font-[400] text-[#4D4D4D] leading-normal"}>
                                    آزمون های استخدامی بانک های رفاه و سرمایه برگزار شد
                                </div>
                            </Space>
                            <Col span={24} className={"text-end !px-0"}>
                                <Space>
                                    <div className={"text-[12px] font-[400]"}>
                                        ادامه
                                    </div>
                                    <img src={left} className={"w-full"}/>
                                </Space>
                            </Col>
                        </div>
                    </Col>
                    <Col span={ 18 }>
                        <div
                            className={ 'text-textblue rounded-[10px] shadow-6 text-[14px] font-[500] bg-white px-[35px] py-[46px]' }>
                            <div className={ 'mb-[20px]' }>
                                سوالات متداول
                            </div>

                            <div className={ 'text-[14px] max-lg:text-[12px] font-[400] text-[#4D4D4D] leading-[27px]' }>
                                <CollapseContainer xs={ 24 } lg={ 24 } className={ 'my-[20px]' }>
                                    <Collapse  expandIconPosition={ 'end' } onChange={ onChange } accordion
                                              className={ '!border-0' }
                                              bordered={ false }>
                                        {!!FaqDataRes?
                                            FaqDataRes?.map(item =>
                                                <Panel
                                                    header={ <div className={ 'flex gap-2 justify-between' }>
                                                        <Space size={ 14 }>
                                                            <img src={ question }/>{ item?.question }
                                                        </Space>
                                                    </div> }
                                                    key={ item?.rowId }
                                                    className={ 'bg-white' }>
                                                    <div className={ '' }> { item?.answer }</div>
                                                </Panel>,
                                            )
                                        :
                                            <Col span={24} className="text-center">
                                                <Empty description={'سوالی یافت نشد'}/>
                                            </Col>
                                        }
                                    </Collapse>
                                </CollapseContainer>
                            </div>
                        </div>
                    </Col>
                </Row>

            </Col>
        </Row>
    );
};

export default Index;
