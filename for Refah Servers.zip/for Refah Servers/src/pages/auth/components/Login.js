import {Col, Form, Row, Spin} from 'antd';
import {Link, Navigate, useNavigate} from 'react-router-dom';
import styled from 'styled-components';
import {Button, Input, InputPassword, Radio, RadioFormItem, RadioGroup} from 'templates/Ui';
import {inputRule} from 'utils/helper';
import {useRequest} from "../../../utils/useRequest";
import {useAuth} from "../../../contexts/auth/AuthContext";
import {DateObject} from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import gregorian from "react-date-object/calendars/gregorian";
import {useEffect, useState} from "react";

import { LeftOutlined, LoadingOutlined, WarningOutlined } from '@ant-design/icons';




const LoginContainer = styled(Row)`
  .--forgetPassword {
    margin-top: 18px;

    a {
      font-size: .75rem;
      font-weight: 400;
    }
  }

  .--loginBtn {
    margin-top: 60px;
  }
`;

const Login = () => {
  const {handleChangeUserData, userData} = useAuth();

  const {  NODE_ENV } = process.env;

  const navigate = useNavigate();

  const [loginFormRef] = Form.useForm();

  const [userInfo, setUserInfo] = useState({});
  const [walletCreated, setWalletCreated] = useState(false);
  const userTypeWatch = Form.useWatch('userType', loginFormRef);
  const [forgetPasswordStep, setForgetPasswordStep] = useState(0);


  const {mutateAsync: loginRequest, isLoading: loginRequestIsLoading} = useRequest({
    path: '/auth/login',
    isMutation: true,
    method: 'post',
    apiType: 'auth',
  });

  const {isLoading: getWalletKeyIsLoading, refetch: getWalletKeyRequest} = useRequest({
    path: '/wallet/key',
    key: [ 'wallet', 'key' ],
    options: {
      cacheTime: 0,
      retry: 0,
      enabled: false,
    },
  });

  // create wallet for user
  const {
    isLoading: createWalletIsLoading,
    mutateAsync: createWalletRequest,
  } = useRequest({
    path: '/wallet/create',
    isMutation: true,
    showMessage: false,
  });


  const handleLogin = async () => {
    try {
      const formData = await loginFormRef?.getFieldsValue(true);

      const res = await loginRequest(formData);

      const {tokenInfo, userInfo} = await res?.response;

      await localStorage.setItem("accessToken", tokenInfo?.accessToken);
      await localStorage.setItem("refreshToken", tokenInfo?.refreshToken);

      await setUserInfo(userInfo);
    }

    catch (error) {

    }
  }


  useEffect(() => {
    if (!!Object.keys(userInfo)?.length) {

      getWalletKeyRequest()
          .then(res => {
            console.log(res);
            const walletIdentifier = res?.data?.[0]?.walletIdentifier;

            if (walletIdentifier) {
              userInfo.walletIdentifier = walletIdentifier;

              handleChangeUserData(userInfo);
            } else {
              createWalletRequest({amount: 500000})
                  .then(async res => {
                    const walletIdentifier = res?.response[ 0 ]?.walletIdentifier;
                    await handleChangeUserData({
                      ...userInfo,
                      walletIdentifier,
                    });
                  })
            }
          })
    }
  }, [userInfo])

  return (
    <Spin spinning={ loginRequestIsLoading || getWalletKeyIsLoading || createWalletIsLoading }>
      <Form
        form={loginFormRef}
        name='loginFrom'
        className='--form'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleLogin}
      >
        <LoginContainer>
          
          {forgetPasswordStep===0&&
            <>
              <Col span={24} >
                <RadioFormItem
                  name={'userType'}
                  initialValue='1'
                >
                  <RadioGroup block>
                    <Radio value='1' >افراد حقیقی</Radio>
                    
                    <Radio value='2' disabled>اتباع خارجی</Radio>
                    
                    <Radio value='3' disabled>افراد حقوقی</Radio>
                  </RadioGroup>
                </RadioFormItem>
              </Col>
              
              
              {userTypeWatch === "1" && forgetPasswordStep === 0 &&
                <>
                  <Col span={24}>
                    <Input
                      name={'userName'}
                      label={'کد ملی'}
                      noPlaceHolder
                      justNumber
                      formRef={loginFormRef}
                      ltr
                      focus
                      maxLength={10}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required input', {inputName: 'کد ملی'})
                        },
                      ]}
                    />
                  
                  </Col>
                  <Col span={24}>
                    <InputPassword
                      name={'password'}
                      label={'رمز عبور'}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required input', {inputName: 'رمز عبور'})
                        },
                        {
                          min: 5,
                          message: inputRule('minLength input', {inputName: 'رمز عبور', length: 5})
                        }
                      ]}
                      noPlaceHolder
                      rtl
                    />
                  </Col>
                  <Col span={24} className='!text-textblue cursor-pointer pb-[68px]'>
                    <Link to={'/auth/forgetPassword'} className={"!text-textblue"}>
                      رمز عبور خود را فراموش کردید؟
                    </Link>
                  </Col>
                  <Col span={24} className='--btn max-lg:mb-[25px]' >
                    <Button
                      type={'secondary'}
                      block
                 htmlType={"submit"}
                      icon={<LeftOutlined/>}
                      iconAlign={'end'}
                    >
                      ورود
                    </Button>
                  </Col>
                </>
              }
              {userTypeWatch === "2" && forgetPasswordStep === 0 &&
                <>
                  <Col span={24}>
                    <Input
                      name={ 'fidaCode' }
                      label={ 'کد فیدا' }
                      noPlaceHolder
                      rules={ [
                        {
                          required: true,
                          message: inputRule('required input', { inputName: 'کد فیدا' })
                        },
                        {
                          pattern: new RegExp(/^[0-9]+$/),
                          message: inputRule('must be number input', { inputName: 'کد فیدا' })
                        }
                      ] }
                      justNumber
                      formRef={ loginFormRef }
                      ltr
                      focus
                    />
                  </Col>
                  <Col span={24}>
                    <InputPassword
                      name={'password'}
                      label={'رمز عبور'}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required input', {inputName: 'رمز عبور'})
                        },
                        {
                          min: 5,
                          message: inputRule('minLength input', {inputName: 'رمز عبور', length: 5})
                        }
                      ]}
                      noPlaceHolder
                      rtl
                    />
                  </Col>
                  <Col span={24} className='--forgetPassword !text-textblue pb-[68px]'>
                    <Link to={'/auth/forgetPassword'} className={"!text-textblue"}>
                      رمز عبور خود را فراموش کردید؟
                    </Link>
                  </Col>
                  
                  <Col span={24} className='--btn  max-lg:mb-[25px]'>
                    <Button
                      type={'secondary'}
                      block
                     htmlType={"submit"}
                      icon={<LeftOutlined/>}
                      iconAlign={'end'}
                    >
                      ورود
                    </Button>
                  </Col>
                </>
              }
              
              {userTypeWatch === "3" && forgetPasswordStep === 0 &&
                <>
                  <Col span={24}>
                    <Input
                      name={ 'CEONationalCode' }
                      label={ 'کد ملی مدیرعامل' }
                      noPlaceHolder
                      rules={ [
                        {
                          required: true,
                          message: inputRule('required input', { inputName: 'کد ملی مدیرعامل' })
                        },
                        {
                          pattern: new RegExp(/^[0-9]+$/),
                          message: inputRule('must be number input', { inputName: 'کد ملی مدیرعامل' })
                        },
                        {
                          min: 10,
                          message: inputRule('minLength input', { inputName: 'کد ملی مدیرعامل', length: 10 }),
                          validateTrigger: 'onBlur'
                        },
                        {
                          max: 10,
                          message: inputRule('maxLength input', { inputName: 'کد ملی مدیرعامل', length: 10 })
                        }
                      ] }
                      justNumber
                      formRef={ loginFormRef }
                      ltr
                      focus
                    />
                  </Col>
                  
                  <Col span={24}>
                    <InputPassword
                      name={'password'}
                      label={'رمز عبور'}
                      rules={[
                        {
                          required: true,
                          message: inputRule('required input', {inputName: 'رمز عبور'})
                        },
                        {
                          min: 5,
                          message: inputRule('minLength input', {inputName: 'رمز عبور', length: 5})
                        }
                      ]}
                      noPlaceHolder
                      rtl
                    />
                  </Col>
                  
                  <Col span={24} className='--forgetPassword !text-textblue pb-[68px]'>
                    <Link to={'/auth/forgetPassword'} className={"!text-textblue"}>
                      رمز عبور خود را فراموش کردید؟
                    </Link>
                  </Col>
                  
                  <Col span={24} className='--btn  max-lg:mb-[25px]'>
                    <Button
                      type={'secondary'}
                      block
                   htmlType={"submit"}
                      icon={<LeftOutlined/>}
                      iconAlign={'end'}
                    >
                      ورود
                    </Button>
                  </Col>
                </>
              }
            </>
          }
        </LoginContainer>
      </Form>
    </Spin>
  );
};

export default Login;
