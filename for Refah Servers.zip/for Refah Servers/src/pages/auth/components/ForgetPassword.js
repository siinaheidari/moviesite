import {useEffect, useState} from 'react';
import {LeftOutlined, LoadingOutlined, WarningOutlined} from '@ant-design/icons';
import {Col, Form, Row, Spin, Statistic} from 'antd';
import {Link} from 'react-router-dom';
import styled from 'styled-components';
import {Button, Input, InputPassword, Radio, RadioFormItem, RadioGroup} from 'templates/Ui';
import {Else, If, Then} from 'utils/Condition';
import {fn_deadline, inputRule} from 'utils/helper';
import {useRequest} from 'utils/useRequest';
import { toast } from 'react-toastify';
import { errorMessages } from '../../../utils/axios/errorMessages';
import { requestMessages } from '../../../utils/axios/requestMessages';

const ForgetPasswordContainer = styled(Row)`
  .--title {
    margin-bottom: 30px;
    text-align: center;
    font-size: 1rem;
    
  }

  .--otpStatus {
    &,
    .ant-statistic-content {
      color: #557EFF;
      font-size: .875rem;
    }

    .__resend {
      display: inline-block;
      cursor: pointer;

      &:hover {
        color: #3264ff;
      }

      &.--disable {
        pointer-events: none;
      }
    }
  }

  .--btn {
    margin-top: 50px;
  }

  .--goToSignIn {
    margin-top: 35px;
  }
`;

const {NODE_ENV} = process.env;

const ForgetPassword = () => {
  const {Countdown} = Statistic;

  const [forgetPasswordFormRef] = Form.useForm();

  const userMobile = forgetPasswordFormRef?.getFieldValue('mobileNumber'); // get user mobile
  const userTypeWatch = Form.useWatch('userType', forgetPasswordFormRef);
  const mobileWatch = Form.useWatch('mobile', forgetPasswordFormRef);
  const otpInputWatch = Form.useWatch('inputCode', forgetPasswordFormRef); // watch otp value
  const passwordWatch = Form?.useWatch('newPassword', forgetPasswordFormRef);
  const repeatedPasswordWatch = Form?.useWatch('repeatedPassword', forgetPasswordFormRef);

  const [forgetPasswordStep, setForgetPasswordStep] = useState(0);

  // state for show btn To resend the verification code:
  const [resendCode, setResendCode] = useState(false);

  const [submitVisible, setSubmitVisible] = useState(false);

  // state for show countdown for resend code (after: 2 Minute):
  const [resendCodeDeadline, setResendCodeDeadline] = useState(0);

  // for show min and max error (mobile)
  const handleOnBlurMobile = () => {
    if (mobileWatch?.length < 11) {
      forgetPasswordFormRef?.setFields([
        {
          name: 'mobile',
          errors: [inputRule('minLength input', {inputName: 'شماره موبایل', length: 11})]
        }
      ]);
    }
  };

  const handleMinPasswordValidate = () => {
    if (passwordWatch?.length && passwordWatch?.length < 8) {
      forgetPasswordFormRef?.setFields([
        {
          name: 'newPassword',
          errors: [inputRule('minLength input', {inputName: 'رمز عبور جدید', length: 8})]
        }
      ]);
    }
  };

  const validateRepeatedPassword = (rule, value, callback) => {
    if (value && value !== passwordWatch) {
      callback('رمز های عبور باهم مطابقت ندارند');
    } else {
      callback();
    }
  };

  const handleOnBlurRepeatedPassword = () => {
    if (passwordWatch !== repeatedPasswordWatch) {
      forgetPasswordFormRef?.setFields([
        {
          name: 'repeatedPassword',
          errors: ['رمز های عبور باهم مطابقت ندارند']

        }
      ]);
    }
  };

  const handleNextStep = () => {

    setTimeout(() => {
      forgetPasswordFormRef.validateFields()
        .then(() => {
          setForgetPasswordStep(2);
        });
    }, 500);
  };

  const {mutateAsync: sendOtpRequest2, isLoading: sendOtpIsLoading} = useRequest({
    path: '/auth/otp',
    isMutation: true,

  });

  const {mutateAsync: sendForgetPass, isLoading: sendForgetPassLoading} = useRequest({
    path: '/auth/forget-password',
    isMutation: true,
    mutationMethod:"patch",

  });


  const handleSendOtpCode = () => {
    forgetPasswordFormRef.validateFields().then(()=>{
      const formData = forgetPasswordFormRef?.getFieldsValue(true);
      let body;
      if (formData?.userType === "1") {
        body = {
          mobileNumber: formData?.mobileNumber,
          nationalCode: formData?.nationalCode,
          action:"forget-password",
          userType:formData?.userType
        }
      } else if (formData?.userType === "2") {
        body = {
          mobile: formData?.mobileNumber,
          fidaCode: formData?.fidaCode,
        }
      } else if (formData?.userType === "3") {
        body = {
          mobile: formData?.mobileNumber
        }
      }
      
      sendOtpRequest2(
        body
      )
        .then(() => {
          setForgetPasswordStep(1);// go to next step

          // toast.success("رمز یکبار مصرف با موفقیت ارسال شد")

        })
        .catch((err) => {
          // const Messages = requestMessages[err?.message];
          // toast.error(Messages || 'لطفا اطلاعات ورودی را چک نمایید');
        });
    }).catch((err)=>{
    
    })
  };


  const handleForgetPassword = () => {
    const formData = forgetPasswordFormRef?.getFieldsValue(true);
    
    sendForgetPass({
      mobileNumber : formData?.mobileNumber,
      otp : formData?.inputCode,
      newPassword:formData?.newPassword
    }).then(()=>{
      toast.success('تغییر رمز عبور با موفقیت تغییر کرد');
    }).catch((err)=>{
      const Message = requestMessages[err?.output];
      toast.error(Message || 'لطفا اطلاعات ورودی را چک نمایید');
    })

  };


  // handle for set resend code: show resend time
  useEffect(() => {
    if (!sendOtpIsLoading) {
      setResendCodeDeadline(fn_deadline('02.01'));
      setResendCode(false);
    }
  }, [sendOtpIsLoading]);


  // handle disable/enable next btn: if empty or not otp length is true disable btn else enable and user can submit form
  useEffect(() => setSubmitVisible(!!!(otpInputWatch && otpInputWatch?.length === 6)), [otpInputWatch]);


  return (
    <Spin spinning={ !!( sendOtpIsLoading || sendForgetPassLoading ) }>
      <Form
        form={forgetPasswordFormRef}
        name='forgetPasswordFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        onFinish={handleForgetPassword}
      >
        <ForgetPasswordContainer>
          <Col span={24} className='--title --gradientText'>
            فراموشی رمز عبور
          </Col>

          {forgetPasswordStep===0&&
          <>
            <Col span={24}>
              <RadioFormItem
                name={'userType'}
                initialValue='1'
              >
                <RadioGroup block>
                  <Radio value='1'>افراد حقیقی</Radio>

                  <Radio value='2' disabled>اتباع خارجی</Radio>

                  <Radio value='3' disabled>افراد حقوقی</Radio>
                </RadioGroup>
              </RadioFormItem>
            </Col>


            {userTypeWatch === "1" && forgetPasswordStep === 0 &&
              <>
                <Col span={24}>
                  <Input
                    name='mobileNumber'
                    label={'شماره موبایل'}
                    placeholder={'09123456789'}
                    placeholderAlign={'right'}
                    focus
                    rules={[
                      {
                        required: true,
                        message: inputRule('required input', {inputName: 'شماره موبایل'})
                      },
                      {
                        pattern: new RegExp(/^[0-9]+$/),
                        message: inputRule('must be number input', {inputName: 'شماره موبایل'})
                      },
                      {
                        min: 11,
                        message: inputRule('minLength input', {inputName: 'شماره موبایل', length: 11}),
                        validateTrigger: 'onBlur'
                      },
                      {
                        max: 11,
                        message: inputRule('maxLength input', {inputName: 'شماره موبایل', length: 11})
                      }
                    ]}
                    onBlur={handleOnBlurMobile}
                    ltr
                    justNumber
                    formRef={forgetPasswordFormRef}
                    maxLength={11}
                  />
                </Col>

                <Col span={24} className='--btn !text-13px' >
                  <Button
                    type={'secondary'}
                    block
                    onClick={handleSendOtpCode}
                    icon={<LeftOutlined/>}
                    iconAlign={'end'}
                  >
                    ارسال کد یک بار مصرف
                  </Button>
                </Col>
              </>
            }
            {userTypeWatch === "2" && forgetPasswordStep === 0 &&
              <>
                <Col span={24}>
                  <Input
                    name={ 'fidaCode' }
                    label={ 'کد فیدا' }
                    noPlaceHolder
                    rules={ [
                      {
                        required: true,
                        message: inputRule('required input', { inputName: 'کد فیدا' })
                      },
                      {
                        pattern: new RegExp(/^[0-9]+$/),
                        message: inputRule('must be number input', { inputName: 'کد فیدا' })
                      }
                    ] }
                    justNumber
                    formRef={ forgetPasswordFormRef }
                    ltr
                    focus
                  />
                </Col>
                <Col span={24}>
                  <Input
                    name='mobile'
                    label={'شماره موبایل'}
                    placeholder={'مثال 09123456789'}
                    placeholderAlign={'right'}
                    rules={[
                      {
                        required: true,
                        message: inputRule('required input', {inputName: 'شماره موبایل'})
                      },
                      {
                        pattern: new RegExp(/^[0-9]+$/),
                        message: inputRule('must be number input', {inputName: 'شماره موبایل'})
                      },
                      {
                        min: 11,
                        message: inputRule('minLength input', {inputName: 'شماره موبایل', length: 11}),
                        validateTrigger: 'onBlur'
                      },
                      {
                        max: 11,
                        message: inputRule('maxLength input', {inputName: 'شماره موبایل', length: 11})
                      }
                    ]}
                    onBlur={handleOnBlurMobile}
                    ltr
                    justNumber
                    formRef={forgetPasswordFormRef}
                    maxLength={11}
                  />
                </Col>

                <Col span={24} className='--btn'>
                  <Button
                    type={'secondary'}
                    block
                    onClick={handleSendOtpCode}
                    icon={<LeftOutlined/>}
                    iconAlign={'end'}
                  >
                    ارسال کد یک بار مصرف
                  </Button>
                </Col>
              </>
            }

            {userTypeWatch === "3" && forgetPasswordStep === 0 &&
              <>
                <Col span={24}>
                  <Input
                    name={ 'CEONationalCode' }
                    label={ 'کد ملی مدیرعامل' }
                    noPlaceHolder
                    rules={ [
                      {
                        required: true,
                        message: inputRule('required input', { inputName: 'کد ملی مدیرعامل' })
                      },
                      {
                        pattern: new RegExp(/^[0-9]+$/),
                        message: inputRule('must be number input', { inputName: 'کد ملی مدیرعامل' })
                      },
                      {
                        min: 10,
                        message: inputRule('minLength input', { inputName: 'کد ملی مدیرعامل', length: 10 }),
                        validateTrigger: 'onBlur'
                      },
                      {
                        max: 10,
                        message: inputRule('maxLength input', { inputName: 'کد ملی مدیرعامل', length: 10 })
                      }
                    ] }
                    justNumber
                    formRef={ forgetPasswordFormRef }
                    ltr
                    focus
                  />
                </Col>
                <Col span={24}>
                  <Input
                    name='mobile'
                    label={'شماره موبایل'}
                    placeholder={'مثال 09123456789'}
                    placeholderAlign={'right'}
                    rules={[
                      {
                        required: true,
                        message: inputRule('required input', {inputName: 'شماره موبایل'})
                      },
                      {
                        pattern: new RegExp(/^[0-9]+$/),
                        message: inputRule('must be number input', {inputName: 'شماره موبایل'})
                      },
                      {
                        min: 11,
                        message: inputRule('minLength input', {inputName: 'شماره موبایل', length: 11}),
                        validateTrigger: 'onBlur'
                      },
                      {
                        max: 11,
                        message: inputRule('maxLength input', {inputName: 'شماره موبایل', length: 11})
                      }
                    ]}
                    onBlur={handleOnBlurMobile}
                    ltr
                    justNumber
                    formRef={forgetPasswordFormRef}
                    maxLength={11}
                  />
                </Col>

                <Col span={24} className='--btn'>
                  <Button
                    type={'secondary'}
                    block
                    onClick={handleSendOtpCode}
                    icon={<LeftOutlined/>}
                    iconAlign={'end'}
                  >
                    ارسال کد یک بار مصرف
                  </Button>
                </Col>
              </>
            }
          </>
          }


          {forgetPasswordStep === 1 &&
            <>
              <Col span={24}>
                <Input
                  name={'inputCode'}
                  noPlaceHolder
                  label={('کد ارسال شده به شماره {{mobileNumber}} را وارد نمایید')?.replaceAll('{{mobileNumber}}', userMobile)}
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'کد تایید'})
                    }
                  ]}
                />
              </Col>

              <Col span={24} className='--otpStatus'>
                <Row justify='space-between' gutter={17}>
                  <If condition={!resendCode}>
                    <Then>
                      <Col className={"max-lg:text-[12px]"}>
                        <WarningOutlined/> {'اعتبار باقیمانده کد ارسال شده'}
                      </Col>

                      <Col>
                        <Countdown value={resendCodeDeadline} onFinish={() => setResendCode(true)} format='mm:ss'/>
                      </Col>
                    </Then>

                    <Else>
                      <Col>
                        <div
                          onClick={!sendOtpIsLoading ? handleSendOtpCode : null}
                          className={`__resend ${sendOtpIsLoading && '--disable'}`}
                        >
                          {sendOtpIsLoading && <LoadingOutlined/>} {'ارسال مجدد کد'}
                        </div>
                      </Col>
                    </Else>
                  </If>
                </Row>
              </Col>

              <Col span={24} className='--btn'>
                <Button
                  type={'secondary'}
                  block
                  icon={<LeftOutlined/>}
                  iconAlign={'end'}
                  onClick={handleNextStep}
                  disabled={submitVisible}
                >
                  تغییر رمز
                </Button>
              </Col>
            </>
          }

          {forgetPasswordStep === 2 &&
            <>
              <Col span={24}>
                <InputPassword
                  name={'newPassword'}
                  label={'رمز عبور جدید'}
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'رمز عبور جدید'})
                    },
                    {
                      min: 8,
                      message: inputRule('minLength input', {inputName: 'رمز عبور جدید', length: 8}),
                      validateTrigger: 'onBlur'
                    },
                    {
                      validator: (rule, value, callback) => {
                        if (value?.length && !value.match(/[A-Z]/)) {
                          return Promise.reject(new Error("رمز عبور باید حداقل شامل یک حرف بزرگ انگلیسی باشد"));
                        }
                        return Promise.resolve();
                      },
                      validateTrigger: 'onBlur'
                    },
                  ]}
                  onBlur={handleMinPasswordValidate}
                  noPlaceHolder
                  ltr
                />
              </Col>

              <Col span={24}>
                <InputPassword
                  name={'repeatedPassword'}
                  label={'تکرار رمز عبور'}
                  dependencies={['newPassword']}
                  rules={[
                    {
                      required: true,
                      message: inputRule('required input', {inputName: 'تکرار رمز عبور'})
                    },
                    {validator: validateRepeatedPassword, validateTrigger: 'onBlur'}
                  ]}
                  onBlur={handleOnBlurRepeatedPassword}
                  noPlaceHolder
                  ltr
                />
              </Col>

              <Col span={24} className='--btn'>
                <Button
                  htmlType={'submit'}
                  type={'secondary'}
                  block
                  icon={<LeftOutlined/>}
                  iconAlign={'end'}
                >
                  تغییر رمز
                </Button>
              </Col>
            </>
          }

          <Col span={24} className='--goToSignIn text-textblue'>
            <Link to={'/auth/login'} className={"!text-textblue"}>
              ورود به سایت
            </Link>
          </Col>
        </ForgetPasswordContainer>
      </Form>
    </Spin>
  );
};

export default ForgetPassword;

