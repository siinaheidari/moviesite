import { Image } from 'antd';

// sliders image
import sliderImageOne from 'assets/images/auth/sliderImageOne.png';
import sliderImageThree from 'assets/images/auth/sliderImageThree.png';
import sliderImageTwo from 'assets/images/auth/sliderImageTwo.png';
import styled from 'styled-components';

// import Swiper core and required modules
import SwiperCore, { Autoplay, Pagination } from 'swiper';
import 'swiper/css';

// Import Swiper styles
import 'swiper/css/bundle';
import 'swiper/css/pagination';

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// install Swiper modules
SwiperCore.use([Autoplay, Pagination]);

const SliderContainer = styled(Swiper)`
  border-radius: 10px;
  overflow: hidden;

  .swiper-scrollbar {
    display: none;
  }

  .swiper-pagination {
    bottom: 22px !important;

    .swiper-pagination-bullet {
      width: 10px;
      height: 10px;
      background-color: #fff;
      opacity: 1;
      box-shadow: 0 4px 4px rgba(0, 0, 0, 0.05);
      margin: 0 6px !important;

      &.swiper-pagination-bullet-active {
        background-color: #21409A;
      }
    }
  }
`;

const SwiperSlideContent = styled(SwiperSlide)`
  .ant-image {
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    border-radius: 10px;
  }
`;

const Slider = () => {
  
  const swiperProps = {
    dir: 'rtl',
    slidesPerView: 1,
    spaceBetween: 13,
    scrollbar: {
      hide: true
    },
    direction: 'horizontal',
    loop: true,
    autoplay: {
      delay: 4000,
      disableOnInteraction: false,
      pauseOnMouseEnter: true
    },
    pagination: {
      'clickable': true
    }
  };
  
  return (
    <SliderContainer { ...swiperProps }>
      <SwiperSlideContent dir={ 'rtl' } className='--sliderOne'>
        <div>
          <Image src={ sliderImageOne } width={ '100%' } height={ '100%' } preview={ false }/>
        </div>
      </SwiperSlideContent>
      
      <SwiperSlideContent dir={ 'rtl' } className='--sliderTow'>
        <div>
          <div>
            <Image src={ sliderImageTwo } width={ '100%' } height={ '100%' } preview={ false }/>
          </div>
        </div>
      </SwiperSlideContent>
      
      <SwiperSlideContent dir={ 'rtl' } className='--sliderTow'>
        <div>
          <div>
            <Image src={ sliderImageThree } width={ '100%' } height={ '100%' } preview={ false }/>
          </div>
        </div>
      </SwiperSlideContent>
    </SliderContainer>
  );
};

export default Slider;
