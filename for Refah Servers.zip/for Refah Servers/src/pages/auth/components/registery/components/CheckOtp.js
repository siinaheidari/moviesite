import { LoadingOutlined, WarningOutlined } from '@ant-design/icons';
import { Col, Form, Row, Statistic } from 'antd';
import { useEffect, useState } from 'react';
import styled from 'styled-components';
import { Button, Input } from 'templates/Ui';
import { Else, If, Then } from 'utils/Condition';
import { fn_deadline, inputRule } from 'utils/helper';

const CheckOtpContainer = styled(Row)`
  .--otpStatus {
    &,
    .ant-statistic-content {
      color: #557EFF;
      font-size: .875rem;
      
    }

    .__resend {
      display: inline-block;
      cursor: pointer;

      &:hover {
        color: #3264ff;
      }

      &.--disable {
        pointer-events: none;
      }
    }
  }

  .--editMobileBtn {
    margin-top: 35px;
    cursor: pointer;
    color: #557EFF;
    font-size: .875rem;

    &:hover {
      color: #3264ff;
    }
  }

  .--updateMobile {
    .__input {
      .ant-input-affix-wrapper {
        border-end-start-radius: 0;
        border-start-start-radius: 0;
        border-inline-start: 0;
      }
    }

    .__btn {
      margin-bottom: 24px;

      .ant-btn {
        border-start-start-radius: 0;
        border-end-start-radius: 0;
      }
    }
  }
`;

const CheckOtp = ({
  changeMobileAndResendCode,
  setChangeMobileAndResendCode,
  isLoading,
  onClickResendCode,
  setSubmitVisible,
  isEditMobile,
  setIsEditMobile
}) => {
  
  const { Countdown } = Statistic;

  const formRef = Form.useFormInstance()
  
  const userMobile = formRef?.getFieldValue('mobileNumber'); // get user mobile

  console.log(formRef?.getFieldsValue(true))
  
  const mobileWatch = Form.useWatch('mobile', formRef); // watch user mobile
  const otpInputWatch = Form.useWatch('otp', formRef); // watch otp value
  
  // state for show btn To resend the verification code:
  const [resendCode, setResendCode] = useState(false);
  
  // state for show countdown for resend code (after: 2 Minute):
  const [resendCodeDeadline, setResendCodeDeadline] = useState(0);
  
  // for show min and max error (mobile)
  const handleOnBlurMobile = () => {
    if (mobileWatch?.length < 11) {
      formRef?.setFields([
        {
          name: 'mobile',
          errors: [inputRule('minLength input', { inputName: 'شماره موبایل', length: 11 })]
        }
      ]);
    }
  };
  
  const handleChangeOtpValue = () => {
    formRef.validateFields()
      .then(() => {
        setChangeMobileAndResendCode(true);
        
        onClickResendCode(); // send new code
      }).catch(() => {});
  };
  
  // handle for set resend code: show resend time
  useEffect(() => {
    if (!isLoading) {
      setResendCodeDeadline(fn_deadline('02.01'));
      setResendCode(false);
    }
  }, [isLoading]);
  
  useEffect(() => {
    if (!changeMobileAndResendCode) {
      setIsEditMobile(false);
    }
  }, [changeMobileAndResendCode]);
  
  // handle disable/enable next btn: if empty or not otp length is true disable btn else enable and user can submit form
  useEffect(() => setSubmitVisible(!!!( otpInputWatch && otpInputWatch?.length === 6 )), [otpInputWatch]);
  
  return (
    <CheckOtpContainer gutter={ [16, 16] }>
      { !isEditMobile ?
        <>
          <Col span={ 24 }>
            <Input
              name={ 'otp' }
              noPlaceHolder
              label={ ( 'کد ارسال شده به شماره {{userMobile}} را وارد نمایید' )?.replaceAll('{{userMobile}}', userMobile) }
              rules={ [
                {
                  required: true,
                  message: inputRule('required input', { inputName: 'کد تایید' })
                }
              ] }
              maxLength={ 6 }
            />
          </Col>
          
          <Col span={ 24 } className='--otpStatus'>
            <Row justify='space-between' gutter={ 17 }>
              <If condition={ !resendCode }>
                <Then>
                  <Col className={"!text-[12px]"}>
                    <WarningOutlined/> { 'اعتبار باقیمانده کد ارسال شده' }
                  </Col>
                  
                  <Col>
                    <Countdown value={ resendCodeDeadline } onFinish={ () => setResendCode(true) } format='mm:ss'/>
                  </Col>
                </Then>
                
                <Else>
                  <Col>
                    <div
                      onClick={ !isLoading ? onClickResendCode : () => {} }
                      className={ `__resend ${ isLoading && '--disable' }` }
                    >
                      { isLoading && <LoadingOutlined/> } { 'ارسال مجدد کد' }
                    </div>
                  </Col>
                </Else>
              </If>
            </Row>
          </Col>
          
          <Col span={ 24 } className='--editMobileBtn !text-[12px]'>
            <div onClick={ () => setIsEditMobile(true) }>
              ویرایش شماره موبایل
            </div>
          </Col>
        </> :
        <>
          <Col span={ 24 } className='--updateMobile'>
            <Row align={ 'bottom' }>
              <Col flex={ '1 1' } className='__input'>
                <Input
                  name='mobile'
                  label={ 'شماره موبایل' }
                  noPlaceHolder
                  rules={ [
                    {
                      required: true,
                      message: inputRule('required input', { inputName: 'شماره موبایل' })
                    },
                    {
                      pattern: new RegExp(/^[0-9]+$/),
                      message: inputRule('must be number input', { inputName: 'شماره موبایل' })
                    },
                    {
                      min: 11,
                      message: inputRule('minLength input', { inputName: 'شماره موبایل', length: 11 }),
                      validateTrigger: 'onBlur'
                    },
                    {
                      max: 11,
                      message: inputRule('maxLength input', { inputName: 'شماره موبایل', length: 11 })
                    }
                  ] }
                  onBlur={ handleOnBlurMobile }
                  ltr
                  justNumber
                  formRef={ formRef }
                  maxLength={ 11 }
                />
              </Col>
              
              {/*<Col flex={ '130px' } className='__btn'>*/}
              {/*  <Button*/}
              {/*    type={ 'secondary' }*/}
              {/*    height={ 46 }*/}
              {/*    width={ '130px' }*/}
              {/*    onClick={ handleChangeOtpValue }*/}
              {/*    loading={ isLoading }*/}
              {/*  >*/}
              {/*    ویرایش*/}
              {/*  </Button>*/}
              {/*</Col>*/}
            </Row>
          </Col>
        </>
      }
    </CheckOtpContainer>
  );
};

export default CheckOtp;
