import {Col, Form, Row} from 'antd';
import {useEffect} from 'react';
import {DatePicker, Input, InputPassword, Radio, RadioFormItem, RadioGroup} from 'templates/Ui';
import {inputRule} from 'utils/helper';
import {useSearchParams} from "react-router-dom";

const General = ({formRef}) => {

    const userTypeWatch = Form.useWatch('userType2', formRef);
    const nationalCodeWatch = Form.useWatch('nationalCode', formRef);
    const mobileWatch = Form.useWatch('mobile', formRef);
    const passwordWatch = Form?.useWatch('password', formRef);
    const repeatedPasswordWatch = Form?.useWatch('repeatedPassword', formRef);
    const [searchParams] = useSearchParams();

    // for show min and max error
    const handleOnBlurNationalCode = () => {
        if (nationalCodeWatch?.length < 10 && Number(nationalCodeWatch)) {
            formRef?.setFields([
                {
                    name: 'nationalCode',
                    errors: [inputRule('minLength input', {inputName: 'کد ملی', length: 10})]
                }
            ]);
        }
    };

    // for show min and max error (mobile)
    const handleOnBlurMobile = () => {
        if (mobileWatch?.length < 11) {
            formRef?.setFields([
                {
                    name: 'mobile',
                    errors: [inputRule('minLength input', {inputName: 'شماره موبایل', length: 11})]
                }
            ]);
        }
    };

    const handleMinPasswordValidate = () => {
        if (passwordWatch?.length && passwordWatch?.length < 8) {
            formRef?.setFields([
                {
                    name: 'password',
                    errors: [inputRule('minLength input', {inputName: 'رمز عبور', length: 8})]
                }
            ]);
        }
    };

    const validateRepeatedPassword = (rule, value, callback) => {
        if (value && value !== passwordWatch) {
            callback('رمز های عبور باهم مطابقت ندارند');
        } else {
            callback();
        }
    };

    const handleOnBlurRepeatedPassword = () => {
        if (passwordWatch !== repeatedPasswordWatch) {
            formRef?.setFields([
                {
                    name: 'repeatedPassword',
                    errors: ['رمز های عبور باهم مطابقت ندارند']

                }
            ]);
        }
    };


    useEffect(() => {
        // by change user type reset form
        if (userTypeWatch) {
            formRef?.resetFields(['nationalCode', 'fidaCode', 'CEONationalCode', 'companyNationalId', 'mobile', 'birthDate']);
        }
    }, [userTypeWatch]);

    return (
        <Row>
            <Col span={24}>
                <RadioFormItem
                    name={'userType2'}
                    initialValue='1'
                >
                    <RadioGroup block>
                        <Radio value='1'>افراد حقیقی</Radio>

                        <Radio value='2' disabled>اتباع خارجی</Radio>

                        <Radio value='3' disabled>افراد حقوقی</Radio>
                    </RadioGroup>
                </RadioFormItem>
            </Col>

            {userTypeWatch === '1' &&
                <Col span={24}>
                    <Row gutter={16}>
                        <Col xs={24} xl={12}>
                            <Input
                                name={'nationalCode'}
                                label={'کد ملی'}
                                noPlaceHolder
                                justNumber
                                formRef={formRef}
                                ltr
                                focus
                                maxLength={10}
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'کد ملی'})
                                    },
                                ]}
                            />
                        </Col>

                        <Col xs={24} xl={12}>
                            <Input
                                name='mobileNumber'
                                label={'شماره موبایل'}
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'شماره موبایل'})
                                    },
                                    {
                                        pattern: new RegExp(/^[0-9]+$/),
                                        message: inputRule('must be number input', {inputName: 'شماره موبایل'})
                                    },
                                    {
                                        min: 11,
                                        message: inputRule('minLength input', {inputName: 'شماره موبایل', length: 11}),
                                        validateTrigger: 'onBlur'
                                    },
                                    {
                                        max: 11,
                                        message: inputRule('maxLength input', {inputName: 'شماره موبایل', length: 11})
                                    }
                                ]}
                                onBlur={handleOnBlurMobile}
                                ltr
                                justNumber
                                formRef={formRef}
                                maxLength={11}
                            />
                        </Col>

                        <Col xs={24} xl={12}>
                            <DatePicker
                                name='birthDate'
                                label='تاریخ تولد'
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required selectBox', {inputName: 'تاریخ تولد'})
                                    }
                                ]}

                                formRef={formRef}
                            />
                        </Col>
                        <Col xs={24} xl={12}>
                            <Input
                                name={'inviteCode'}
                                label={'کد معرف (اختیاری)'}
                                initialValue={searchParams.get("code")}
                                noPlaceHolder
                                onBlur={handleOnBlurNationalCode}
                                formRef={formRef}
                                ltr
                            />
                        </Col>
                    </Row>
                </Col>
            }

            {userTypeWatch === '2' &&
                <>
                    <Col span={24}>
                        <Row gutter={16}>
                            <Col xs={24} xl={12}>
                                <Input
                                    name={'fidaCode'}
                                    label={'کد فیدا'}
                                    noPlaceHolder
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'کد فیدا'})
                                        },
                                        {
                                            pattern: new RegExp(/^[0-9]+$/),
                                            message: inputRule('must be number input', {inputName: 'کد فیدا'})
                                        }
                                    ]}
                                    justNumber
                                    formRef={formRef}
                                    ltr

                                />
                            </Col>

                            <Col xs={24} xl={12}>
                                <Input
                                    name='mobile'
                                    label={'شماره موبایل'}
                                    noPlaceHolder
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required input', {inputName: 'شماره موبایل'})
                                        },
                                        {
                                            pattern: new RegExp(/^[0-9]+$/),
                                            message: inputRule('must be number input', {inputName: 'شماره موبایل'})
                                        },
                                        {
                                            min: 11,
                                            message: inputRule('minLength input', {
                                                inputName: 'شماره موبایل',
                                                length: 11
                                            }),
                                            validateTrigger: 'onBlur'
                                        },
                                        {
                                            max: 11,
                                            message: inputRule('maxLength input', {
                                                inputName: 'شماره موبایل',
                                                length: 11
                                            })
                                        }
                                    ]}
                                    onBlur={handleOnBlurMobile}
                                    ltr
                                    justNumber
                                    formRef={formRef}
                                    maxLength={11}
                                />
                            </Col>
                            <Col xs={24} xl={12}>
                                <DatePicker
                                    name='birthDate'
                                    label='تاریخ تولد'
                                    noPlaceHolder
                                    rules={[
                                        {
                                            required: true,
                                            message: inputRule('required selectBox', {inputName: 'تاریخ تولد'})
                                        }
                                    ]}
                                    maxDate={true}
                                    formRef={formRef}

                                />
                            </Col>
                            <Col xs={24} xl={12}>
                                <Input
                                    name={'inviteCode'}
                                    label={'کد معرف (اختیاری)'}
                                    initialValue={searchParams.get("code")}
                                    noPlaceHolder
                                    onBlur={handleOnBlurNationalCode}
                                    formRef={formRef}
                                    ltr

                                />
                            </Col>
                        </Row>
                    </Col>
                </>
            }

            {userTypeWatch === '3' &&
                <Col span={24}>
                    <Row gutter={16}>
                        <Col xs={24}>
                            <Input
                                name={'CEONationalCode'}
                                label={'کد ملی مدیرعامل'}
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'کد ملی مدیرعامل'})
                                    },
                                    {
                                        pattern: new RegExp(/^[0-9]+$/),
                                        message: inputRule('must be number input', {inputName: 'کد ملی مدیرعامل'})
                                    },
                                    {
                                        min: 10,
                                        message: inputRule('minLength input', {
                                            inputName: 'کد ملی مدیرعامل',
                                            length: 10
                                        }),
                                        validateTrigger: 'onBlur'
                                    },
                                    {
                                        max: 10,
                                        message: inputRule('maxLength input', {
                                            inputName: 'کد ملی مدیرعامل',
                                            length: 10
                                        })
                                    }
                                ]}
                                justNumber
                                formRef={formRef}
                                ltr

                            />
                        </Col>

                        <Col xs={24} xl={12}>
                            <Input
                                name={'companyNationalId'}
                                label={'شناسه ملی شرکت'}
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'شناسه ملی شرکت'})
                                    },
                                    {
                                        pattern: new RegExp(/^[0-9]+$/),
                                        message: inputRule('must be number input', {inputName: 'شناسه ملی شرکت'})
                                    }
                                ]}
                                justNumber
                                formRef={formRef}
                                ltr

                            />
                        </Col>

                        <Col xs={24} xl={12}>
                            <Input
                                name='mobile'
                                label={'شماره موبایل'}
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required input', {inputName: 'شماره موبایل'})
                                    },
                                    {
                                        pattern: new RegExp(/^[0-9]+$/),
                                        message: inputRule('must be number input', {inputName: 'شماره موبایل'})
                                    },
                                    {
                                        min: 11,
                                        message: inputRule('minLength input', {inputName: 'شماره موبایل', length: 11}),
                                        validateTrigger: 'onBlur'
                                    },
                                    {
                                        max: 11,
                                        message: inputRule('maxLength input', {inputName: 'شماره موبایل', length: 11})
                                    }
                                ]}
                                onBlur={handleOnBlurMobile}
                                ltr
                                justNumber
                                formRef={formRef}
                                maxLength={11}
                            />
                        </Col>


                        <Col xs={24} xl={12}>
                            <DatePicker
                                name='birthDate'
                                label='تاریخ تولد'
                                noPlaceHolder
                                rules={[
                                    {
                                        required: true,
                                        message: inputRule('required selectBox', {inputName: 'تاریخ تولد'})
                                    }
                                ]}
                                maxDate={true}
                                formRef={formRef}
                                rtl
                            />
                        </Col>
                        <Col xs={24} xl={12}>
                            <Input
                                name={'inviteCode'}
                                label={'کد معرف (اختیاری)'}
                                initialValue={searchParams.get("code")}
                                noPlaceHolder
                                onBlur={handleOnBlurNationalCode}
                                formRef={formRef}
                                ltr

                            />
                        </Col>
                    </Row>
                </Col>
            }
            <Col span={24}>
                <Row gutter={16}>
                    <Col span={userTypeWatch === '3' ? 12 : 24}>
                        <InputPassword
                            name={'password'}
                            label={'رمز عبور'}
                            rules={[
                                {
                                    required: true,
                                    message: inputRule('required input', {inputName: 'رمز عبور'})
                                },
                                {
                                    min: 8,
                                    message: inputRule('minLength input', {inputName: 'رمز عبور', length: 8}),

                                    validateTrigger: 'onBlur'
                                },
                                {
                                    validator: (rule, value, callback) => {
                                        if (value?.length && !value.match(/[A-Z]/)) {
                                            return Promise.reject(new Error("رمز عبور باید حداقل شامل یک حرف بزرگ انگلیسی باشد"));
                                        }
                                        return Promise.resolve();
                                    },
                                    validateTrigger: 'onBlur'
                                },
                            ]}
                            onBlur={handleMinPasswordValidate}
                            noPlaceHolder
                            rtl
                        />
                    </Col>

                    <Col span={userTypeWatch === '3' ? 12 : 24}>
                        <InputPassword
                            name={'repeatedPassword'}
                            label={'تکرار رمز عبور'}
                            dependencies={['password']}
                            rules={[
                                {
                                    required: true,
                                    message: inputRule('required input', {inputName: 'تکرار رمز عبور'})
                                },
                                {validator: validateRepeatedPassword, validateTrigger: 'onBlur'}
                            ]}
                            onBlur={handleOnBlurRepeatedPassword}
                            noPlaceHolder
                            rtl
                        />
                    </Col>
                </Row>
            </Col>
        </Row>
    );
};

export default General;
