import {LeftOutlined} from '@ant-design/icons';
import {Col, Form, Row, Spin} from 'antd';
import CheckOtp from 'pages/auth/components/registery/components/CheckOtp';
import {useEffect, useState} from 'react';
import styled from 'styled-components';
import {Button, Checkbox, Modal} from 'templates/Ui';
import {useRequest} from 'utils/useRequest';

// form components
import General from './components/General';
import {DateObject} from "react-multi-date-picker";
import gregorian from "react-date-object/calendars/gregorian";
import persian from "react-date-object/calendars/persian";
import {toast} from "react-toastify";
import {useNavigate, useSearchParams} from "react-router-dom";
import {errorMessages} from "../../../../utils/axios/errorMessages";

const RegisterContainer = styled(Row)`
  .--formAction {
    margin-top: 20px;
    padding-bottom: 20px;
    margin-bottom: 10px;
    
  }
`;

const {NODE_ENV} = process.env;

const Register = () => {

  const [formRef] = Form.useForm();

  const navigate = useNavigate();

  const [accessToken, setAccessToken] = useState('');

  const [currentStep, setCurrentStep] = useState(0);

  const [changeMobileAndResendCode, setChangeMobileAndResendCode] = useState(false); // for check if change and resend code otp

  const [submitVisible, setSubmitVisible] = useState(false);

  const [isEditMobile, setIsEditMobile] = useState(false);

  const [checkboxModal,setCheckboxModal]=useState(false)

  const [searchParams] = useSearchParams();


  const {
    isLoading: sendOtpIsLoading,
    mutateAsync: sendOtpRequest,
  } = useRequest({
    path: '/auth/otp',
    isMutation: true,
    apiType: 'auth'
  });

  const {
    isLoading: registerIsLoading,
    mutateAsync: registerRequest,
  } = useRequest({
    path: '/auth/register',
    isMutation: true,
    apiType: 'auth'
  });


  const handleNextStep = async () => {
    try {
      await formRef?.validateFields();

      const formData = formRef.getFieldsValue(true);

      if (currentStep === 0) {
        const sendOtpBody = {
          mobileNumber: formData?.mobileNumber,
          nationalCode: formData?.nationalCode,
          userType: formData?.userType,
          action: 'register',
        };

        await sendOtpRequest(sendOtpBody);

        await setCurrentStep(current => current + 1); // go to next step

        setChangeMobileAndResendCode(false); // resend code success and close edit mobile
      }
    }
    catch (error) {
      if (NODE_ENV === 'development') {
        //setCurrentStep(1); // if in develop mode go to next step
        console.log('error in handleNextStep >>>>', error);
        setChangeMobileAndResendCode(false); // if in develop mode resend code success and close edit mobile
      }

      const errorMessage = errorMessages[error?.response?.message];
      toast.error(errorMessage || 'کد ارسال نشد لطفا مجددا تلاش فرمایید')
    }
  }

  const handleRegister = async () => {
    try {
      const formData = await formRef?.getFieldsValue(true);

      console.log(formData);
      await registerRequest({
        ...formData,

      });

      await navigate('/auth/login');
    }
    catch (error) {
      if (NODE_ENV === 'development') {
        console.log('error in register >>>>>>', error);
      }
    }
  };

  const steps = [
    {
      step: 'general',
      content: <General formRef={formRef}/>
    },
    {
      step: 'checkOTP',
      content: <CheckOtp
        formRef={formRef}
        isEditMobile={isEditMobile}
        setIsEditMobile={setIsEditMobile}
        onClickResendCode={sendOtpRequest}
        isLoading={sendOtpIsLoading}
        changeMobileAndResendCode={changeMobileAndResendCode}
        setChangeMobileAndResendCode={setChangeMobileAndResendCode}
        setSubmitVisible={setSubmitVisible}
      />
    }
  ];

  const handleOpenCheckBox = (e) => {
    e.preventDefault()
    setCheckboxModal(true)
  }

  const handleCloseCheckBox = () => {
    setCheckboxModal(false);
  }

  return (
    <Spin spinning={sendOtpIsLoading || registerIsLoading }>
      <Form
        form={formRef}
        name='registerFrom'
        autoComplete='off'
        scrollToFirstError
        labelCol={{
          span: 24
        }}
        wrapperCol={{
          span: 24
        }}
        initialValues={ {
          userType: '1',
        } }
        onFinish={handleRegister}
      >
        <RegisterContainer>
          <Col span={24} className='--formContent'>
            {steps[currentStep]?.content}
          </Col>

          <Col span={24} className='--formAction'>
            {currentStep === 0 &&
              <>
                <Checkbox name={"checkBox"}
                          rules={[{required: true, message: "لطفا با قوانین و مقررات سایت موافقت کنید"}]}><span
                  className={"text-pink-500 underline max-lg:text-[12px] mb-10"} onClick={handleOpenCheckBox}>قوانین و مقررات</span> سایت مورد
                  پذیرش من است.
                </Checkbox>
                <Modal
                  open={checkboxModal}
                  onCancel={handleCloseCheckBox}
                  size={{
                    sm:85,
                    xs: 85,
                    md: 85,
                    lg: 70,
                    xl: 70,
                    xxl: 70
                  }}
                  
                  title={
                    <div>
                      <div className={"flex items-center gap-3"}>
                        <img src={"/images/smallRules.svg"}/>
                        <p className={"text-pink-500 underline text-[16px] font-[500]"}>قوانین و مقررات</p>
                      </div>
                      <div className={" max-lg:px-0 max-lg:pt-[15px] max-lg:pb-[20px] pt-[45px] lg:pb-[170px] max-lg:text-[12px] relative text-justify"}>
                        <img src={"/images/bigRulls.svg"} className={"absolute left-0 max-lg:left-[40%] bottom-[1%] max-lg:hidden"} />
                        <div className={"text-[#414042] text-[14px] leading-5 font-[500] max-lg:text-[12px]"}>
                          لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
                        </div>
                      </div>
                    </div>
                    
                  }
                  
                  bodyStyle={{
                    padding: 0,
                  }}
                  className={"top-[25vh] max-lg:top-[20vh]"}
                >

                </Modal>
                
                <Button
                  
                  onClick={handleNextStep}
                  type={'secondary'}
                  icon={<LeftOutlined/>}
                  className='!mt-[35px] max-lg:!mt-[25px]'
                  block
                  iconAlign={'end'}
                >
                  ارسال کد یکبار مصرف
                </Button>
              </>
            }

            {(currentStep === 1 && !isEditMobile) &&
              <Button
                htmlType={'submit'}
                type={'secondary'}
                icon={<LeftOutlined/>}
                className='--next'
                block
                iconAlign={'end'}
                disabled={submitVisible}
              >
                ثبت نام
              </Button>
            }
          </Col>
        </RegisterContainer>
      </Form>
    </Spin>
  );
};

export default Register;

