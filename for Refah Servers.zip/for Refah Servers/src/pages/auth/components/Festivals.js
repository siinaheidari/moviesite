import { Col, Row } from 'antd';
import styled from 'styled-components';
import ListCircle from 'templates/components/ListCircle';

const FestivalsContainer = styled(Row)`
  background: #FFFFFF;
  box-shadow: 0 4px 10px rgba(120, 120, 120, 0.05);
  border-radius: 10px;
  padding: 70px 28px;
  overflow: hidden;

  .--title {
    --textGradientFirstPercent: 0%;
    --textGradientSecoundtPercent: 100%;
    font-size: 1rem;
  }

  .--list {
    margin-top: 30px;
    line-height: 2.1;

    > .ant-row {
      :not(:last-child) {
        margin-bottom: 13px;
      }

      .__description {
        color: #000000;
        font-weight: 400;
        font-size: .875rem;
        text-align: justify;
      }
    }
  }
`;

const Festivals = () => {
  return (
    <FestivalsContainer >
      <Col span={ 24 } className='--title --gradientText'>
        طرح ها و جشنواره فصلی باشگاه پذیرندگان
      </Col>
      
      <Col span={ 24 } className='--list'>
        <ListItem>
          جشنواره های فصلی باشگاه پذیرندگان، در پایان هرفصل با جوایز مختلف و متنوع برگزار میگردد
        </ListItem>
        
        <ListItem>
          برای شرکت در جشنواره می بایست به تعداد ستاره های کسب شده خود و هدایا گزینه حضور در قرعه کشی را انتخاب کنند.
        </ListItem>
        
        <ListItem>
          با توجه به ستاره های کسب شده پذیرنده، امکان انتخاب حضور در قرعه کشی هر جایزه مشخص شده است.
        </ListItem>
        
        <ListItem>
          پس از پایان هر فصل ، پذیرندگان تا پایان روز هفتم ماه فرصت دارند تا نسبت به انتخاب حضور در قرعه کشی جایزه مورد
          نظر خوداقدام نموده و قرعه کشی نیز در بازه دهم تا پانزدهم همان ماه برگزار خواهد شد.
        </ListItem>
      </Col>
    </FestivalsContainer>
  );
};

const ListItem = ({ children }) => {
  return (
    <Row gutter={ 16 } align={ 'stretch' }>
      <Col flex={ '8px' }>
        <ListCircle space={ 0 }/>
      </Col>
      
      <Col flex={ '1 1' } className='__description'>
        { children }
      </Col>
    </Row>
  );
};

export default Festivals;
