import { Col, Row, Segmented } from 'antd';
import { AnimatePresence, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { If, Then } from 'utils/Condition';
import Festivals from './components/Festivals';
import ForgetPassword from './components/ForgetPassword';
import Login from './components/Login';

// auth component
import Register from 'pages/auth/components/registery';
import Slider from './components/Slider';
import tw from 'twin.macro';

const AuthContainer = styled(Row)`
  margin: 28px 0;
  ${tw`max-lg:mt-[20px]`};
`;

const StartSection = styled(Col)`
  > .ant-row {
    background: #FFFFFF;
    box-shadow: 0 4px 10px rgba(120, 120, 120, 0.05);
    border-radius: 10px;
    padding: 45px 20% 20px;
    ${tw`max-lg:!px-[24px] max-lg:!pt-[26px] max-lg:!pb-[20px]`};
    ${tw`max-xl:!px-[24px]`};
    height: 100%;
  }

  .--tab {
    .ant-segmented {
      padding: 0;
      background: #F9F9F9;
      border: 1px solid #DEE4EF;
      border-radius: 5px;

      .ant-segmented-item {
        .ant-segmented-item-label {
          color: #21409A;
          font-size: .875rem;
          line-height: 40px;
          ${tw`max-lg:text-[12px]`};
        }

        &:first-child {
          &.ant-segmented-item-selected {
            border-start-end-radius: 0;
            border-end-end-radius: 0;
          }
        }

        &:last-child {
          &.ant-segmented-item-selected {
            border-start-start-radius: 0;
            border-end-start-radius: 0;
          }
        }

        &.ant-segmented-item-selected {
          background: linear-gradient(90deg, #F61982 0%, #1447A0 100%);

          .ant-segmented-item-label {
            color: #FFFFFF;
          }
        }
      }

      .ant-segmented-thumb {
        background: linear-gradient(90deg, #F61982 0%, #1447A0 100%);
      }
    }
  }
`;

const EndSection = styled(Col)``;

const Auth = ({ authType }) => {
  
  const navigate = useNavigate();
  
  const authItems = [
    {
      label: <div className='--item'>ورود</div>,
      value: 'login'
    },
    {
      label: <div className='--item'>ثبت نام</div>,
      value: 'register'
    },
  ];
  
  const handleOnChaneAuthTab = type => {
    if (type !== authType) {
      navigate(`/auth/${ type }`); // redirect to auth type (register or login).
    }
  };
  
  const authComponents = {
    login: {
      component: <Login/>
    },
    register: {
      component: <Register/>
    },
    forgetPassword: {
      component: <ForgetPassword/>
    }
  };
  
  return (
    <AuthContainer gutter={ 16 } align={ 'stretch' }>
      <StartSection xs={24} lg={12}>
        <Row align={ 'top' }>
          <Col span={ 24 }>
            <Row gutter={ [0, { xs: 32, md: 50 }] }>
              <If condition={ ( authType === 'register' || authType === 'login' ) }>
                <Then>
                  <Col span={ 24 } className='--tab'>
                    <Segmented options={ authItems } value={ authType } onChange={ handleOnChaneAuthTab } block/>
                  </Col>
                </Then>
              </If>
              
              <Col span={ 24 } className='--tabContent'>
                <AnimatePresence mode={ 'wait' }>
                  <motion.div
                    key={ authType || 'empty' }
                    initial={ { x: 40, opacity: 0 } }
                    animate={ { x: 0, opacity: 1 } }
                    exit={ { x: -40, opacity: 0 } }
                    transition={ { duration: 0.2 } }
                  >
                    { authComponents[ authType ]?.component }
                  </motion.div>
                </AnimatePresence>
              </Col>
            </Row>
          </Col>
        </Row>
      </StartSection>
      
      <EndSection span={ 12 } className={"max-lg:hidden"}>
        <Row gutter={ [0, 18] }>
          <Col span={ 24 }>
            <Slider/>
          </Col>
          
          <Col span={ 24 }>
            <Festivals/>
          </Col>
        </Row>
      </EndSection>
    </AuthContainer>
  );
};

export default Auth;
