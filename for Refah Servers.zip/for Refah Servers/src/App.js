import { lazy, Suspense } from 'react';
// react-router-dom
import { createBrowserRouter, createRoutesFromElements, Navigate, Route, RouterProvider } from 'react-router-dom';

///////////////////////////// check logged in //////////////////////////////
///////////////////// layouts /////////////////////////
import MainLayout from './templates/layouts/MainLayout';
import AuthLayout from './templates/layouts/AuthLayout';
import ProfileLayout from './templates/layouts/merchantProfile';
import AdminLayout from './templates/layouts/admin';

///////////////////// Pages skeleton /////////////////////////
import ProfileSkeleton from 'templates/components/skeletons/ProfileSkeleton';
import AuthSkeleton from 'templates/components/skeletons/AuthSkeleton';
import Support from './pages/profile/merchantProfile/Support';
import TransactionsList from './pages/profile/admin/transaction';
import TransactionInfo from './pages/profile/admin/transaction/transactioninfo';
import VerifyWallet from './pages/profile/merchantProfile/wallet/components/verifyWallet';
import Index from './pages/profile/admin/home';
import WalletDetail from './pages/profile/admin/report/walletDetail';
import { useWindowSize } from './utils/helper';
import WalletMobileParent from './pages/profile/merchantProfile/wallet/WalletMobileParent';


///////////////////// pages ////////////////////////////
const Home = lazy(() => import('./pages/home'));
const Auth = lazy(() => import('./pages/auth'));
const Faq = lazy(() => import('./pages/home/FAQ/index'));

// Merchant profile
const Profile = lazy(() => import('./pages/profile/merchantProfile/home'));
const DepositReport = lazy(() => import('./pages/profile/merchantProfile/depositReport'));
const EditProfile = lazy(() => import ('./pages/profile/merchantProfile/editProfile'));
const Terminals = lazy(() => import ('./pages/profile/merchantProfile/terminals'));
const PursueRequests = lazy(() => import ('./pages/profile/merchantProfile/requests/pursueRequests'));
const PosAndIPGRequest = lazy(() => import ('./pages/profile/merchantProfile/posAndIPGRequest'));
const DiscountCodes = lazy(() => import ('./pages/profile/merchantProfile/discountCodes'));
const BusinessPartners = lazy(() => import ('./pages/profile/merchantProfile/businessPartners'));
const PlansAndCampaigns = lazy(() => import ('./pages/profile/merchantProfile/plansAndCampaigns'));
const MyBankAccounts = lazy(() => import ('./pages/profile/merchantProfile/myBankAccounts'));
const FacilitiesGrants = lazy(() => import ('./pages/profile/merchantProfile/facilitiesGrants'));
const Tournament = lazy(() => import ('./pages/profile/merchantProfile/tournament'));
const Survey = lazy(() => import ('./pages/profile/merchantProfile/survey'));
const Wallet = lazy(() => import('./pages/profile/merchantProfile/wallet'));
const PaperRoll = lazy(() => import('./pages/profile/merchantProfile/requests/submitRequest/PaperRoll'));
const ChangeTerminal = lazy(() => import('./pages/profile/merchantProfile/requests/submitRequest/ChangeTerminal'));
const ChangeTerminalAddress = lazy(() => import('./pages/profile/merchantProfile/requests/submitRequest/ChangeTerminalAddress'));
const DisposeTerminal = lazy(() => import('./pages/profile/merchantProfile/requests/submitRequest/deposeTerminal/index'));
const OffersComplain = lazy(() => import('./pages/profile/merchantProfile/Support/offersComplain/OffersComplain'));
const MobileSubMenu = lazy(() => import('./templates/components/MobileSubMenu'));

//wallet
const IncreaseMoney = lazy(() => import('./pages/profile/merchantProfile/wallet/components/increaseMoney'));
const CashOut = lazy(() => import('./pages/profile/merchantProfile/wallet/components/usemoney'));
const TransportMoney = lazy(() => import('./pages/profile/merchantProfile/wallet/components/transportMoney'));
const BuyFromMerchant = lazy(() => import('./pages/profile/merchantProfile/wallet/components/buyFromMerchant'));
const CashFlow = lazy(() => import('./pages/profile/merchantProfile/wallet/components/cashFlow/cashFlow'));
const AddCartBank = lazy(() => import('./pages/profile/merchantProfile/wallet/components/addCardBank'));
const PayBill = lazy(() => import('./pages/profile/merchantProfile/wallet/components/paybill'));
const BuyNet = lazy(() => import('./pages/profile/merchantProfile/wallet/components/buynet'));
const BuyCharge = lazy(() => import('./pages/profile/merchantProfile/wallet/components/buycharge'));
const LostTerminal = lazy(() => import('./pages/profile/merchantProfile/requests/submitRequest/LostTerminal'));


const Lottery = lazy(() => import('./pages/profile/merchantProfile/lottery/lottery'));

// admin
const MerchantsManagement = lazy(() => import ('./pages/profile/admin/merchants'));
const AdminSurvey = lazy(() => import ('./pages/profile/admin/adminSurvey/index'));
const SupportTickets = lazy(() => import ('./pages/profile/admin/supportTickets/index'));
const SubmitComplaint = lazy(() => import ('./pages/profile/admin/submitComplaint/index'));
const AdminFaq = lazy(() => import ('./pages/profile/admin/FAQ/index'));
const RequestsList = lazy(() => import ('./pages/profile/admin/requestsList/index'));
const TerminalsList = lazy(() => import ('./pages/profile/admin/listTerminal/TerminalsList'));


const App = () => {
    const { width } = useWindowSize();

    const router = createBrowserRouter(
        createRoutesFromElements(
            <>
                <Route path={ '/' } element={ <MainLayout/> }>
                    <Route index element={ <Suspense fallback={ null }><Home/></Suspense> }/>
                    <Route path={ 'FAQ' }
                           element={ <Suspense fallback={ <ProfileSkeleton/> }><Faq/></Suspense> }/>
                    <Route path={ 'verifyWallet' }
                           element={ <Suspense fallback={ <ProfileSkeleton/> }><VerifyWallet/></Suspense> }/>
                    <Route path={ '/merchantProfile' } element={ <ProfileLayout/> }>
                        <Route index element={ <Suspense fallback={ <ProfileSkeleton/> }><Profile/></Suspense> }/>

                        <Route path={ 'editProfile' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><EditProfile/></Suspense> }/>

                        <Route path={ 'lottery' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><Lottery/></Suspense> }/>

                        <Route path={ 'terminals' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><Terminals/></Suspense> }/>

                        <Route path={ 'requests' }>
                            <Route path={ 'posAndIPGRequest' }
                                   element={ <Suspense
                                       fallback={ <ProfileSkeleton/> }><PosAndIPGRequest/></Suspense> }/>

                            <Route path={ 'RequestPaperRoll' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><PaperRoll/></Suspense> }/>

                            <Route path={ 'changeTerminal' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><ChangeTerminal/></Suspense> }/>

                            <Route path={ 'disposeTerminal' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><DisposeTerminal/></Suspense> }/>
                            <Route path={ 'lostTerminal' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><LostTerminal/></Suspense> }/>

                            <Route path={ 'changeTerminalAddress' }
                                   element={ <Suspense
                                       fallback={ <ProfileSkeleton/> }><ChangeTerminalAddress/></Suspense> }/>
                        </Route>

                        <Route path={ 'pursueRequests' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><PursueRequests/></Suspense> }/>

                        <Route path={ 'depositReport' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><DepositReport/></Suspense> }/>

                        <Route path={ 'discountCodes' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><DiscountCodes/></Suspense> }/>

                        <Route path={ 'businessPartners' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><BusinessPartners/></Suspense> }/>

                        <Route path={ 'plansAndCampaigns' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><PlansAndCampaigns/></Suspense> }/>

                        <Route path={ 'myBankAccounts' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><MyBankAccounts/></Suspense> }/>

                        <Route path={ 'facilitiesGrants' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><FacilitiesGrants/></Suspense> }/>

                        <Route path={ 'tournament' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><Tournament/></Suspense> }/>

                        <Route path={ 'survey' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><Survey/></Suspense> }/>

                        <Route path={ 'wallet' }
                               element={ width >= 992 ? <Suspense fallback={ <ProfileSkeleton/> }><Wallet/></Suspense> :
                                   <WalletMobileParent/> }>
                            <Route index element={ width >= 992 ? <Navigate to={ 'increase-money' }/> :
                                <Suspense fallback={ <ProfileSkeleton/> }><Wallet/></Suspense> }/>

                            <Route path={ 'increase-money' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><IncreaseMoney/></Suspense> }/>

                            <Route path={ 'use-money' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><CashOut/></Suspense> }/>

                            <Route path={ 'transport-money' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><TransportMoney/></Suspense> }/>

                            <Route path={ 'buy-from-merchant' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><BuyFromMerchant/></Suspense> }/>

                            <Route path={ 'cash-flow' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><CashFlow/></Suspense> }/>

                            <Route path={ 'add-cart-bank' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><AddCartBank/></Suspense> }/>

                            <Route path={ 'pay-bill' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><PayBill/></Suspense> }/>

                            <Route path={ 'buy-net' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><BuyNet/></Suspense> }/>

                            <Route path={ 'buy-charge' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><BuyCharge/></Suspense> }/>

                        </Route>


                        <Route path={ 'support' }>
                            <Route path={ 'sendTicket' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><Support/></Suspense> }/>
                            <Route path={ 'offersComplain' }
                                   element={ <Suspense fallback={ <ProfileSkeleton/> }><OffersComplain/></Suspense> }/>
                        </Route>

                        <Route path={ 'subMenu' }
                               element={ <Suspense fallback={ <ProfileSkeleton/> }><MobileSubMenu/></Suspense> }/>
                    </Route>
                </Route>

                <Route path={ '/auth' } element={ <AuthLayout/> }>
                    {/* auth redirect to login */ }
                    <Route index element={ <Navigate to="login"/> }/>

                    {/* register route */ }
                    <Route path="register"
                           element={ <Suspense fallback={ <AuthSkeleton/> }><Auth authType="register"/></Suspense> }/>

                    {/* login route */ }
                    <Route path="login"
                           element={ <Suspense fallback={ <AuthSkeleton/> }><Auth authType="login"/></Suspense> }/>

                    {/* forget password route */ }
                    <Route path="forgetPassword"
                           element={ <Suspense fallback={ <AuthSkeleton/> }><Auth
                               authType="forgetPassword"/></Suspense> }/>
                </Route>

                <Route path={ '/admin' } element={ <AdminLayout/> }>
                    <Route index element={ <Navigate to={ 'managements/merchants' }/> }/>
                    <Route path={ 'home' }>
                        <Route index element={ <Navigate to={ 'dashboard' }/> }/>
                        <Route path={ 'dashboard' } element={ <Index/> }/>
                        <Route path={ 'supportAndTickets' }
                               element={ <Suspense fallback={ null }><SupportTickets/></Suspense> }/>
                        <Route path={ 'submitComplaint' }
                               element={ <Suspense fallback={ null }><SubmitComplaint/></Suspense> }/>
                    </Route>

                    <Route path={ 'managements' }>
                        <Route index element={ <Navigate to={ 'merchants' }/> }/>
                        <Route path={ 'merchants' }
                               element={ <Suspense fallback={ null }><MerchantsManagement/></Suspense> }/>
                        <Route path={ 'merchants' }>
                            <Route path={ ':merchantNumber' }
                                   element={ <Suspense fallback={ null }><TransactionInfo/></Suspense> }/>
                        </Route>
                        <Route index element={ <Navigate to={ 'merchants' }/> }/>
                        <Route path={ 'transactions' }>
                            <Route index element={ <Suspense fallback={ null }><TransactionsList/></Suspense> }/>
                        </Route>
                        <Route path={ 'terminalsList' }>
                            <Route index element={ <Suspense fallback={ null }><TerminalsList/></Suspense> }/>
                        </Route>
                        <Route path={ 'survey' }>
                            <Route index element={ <Suspense fallback={ null }><AdminSurvey/></Suspense> }/>
                        </Route>
                        <Route path={ 'FAQ' }>
                            <Route index element={ <Suspense fallback={ null }><AdminFaq/></Suspense> }/>
                        </Route>
                        <Route path={ 'requests-list' }>
                            <Route index element={ <Suspense fallback={ null }><RequestsList/></Suspense> }/>
                        </Route>
                    </Route>
                    <Route path={ 'reports' }>
                        <Route path={ 'walletDetail' }
                               element={ <Suspense fallback={ null }><WalletDetail/></Suspense> }/>
                    </Route>


                </Route>
            </>,
        ),
    );

    return <RouterProvider router={ router }/>;
};

export default App;
