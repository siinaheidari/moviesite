import { AuthProvider } from 'contexts/auth/AuthContext';
import React from 'react';
import ReactDOM from 'react-dom/client';
import "./index.scss"

import { ConfigProvider } from 'antd';
import fa_IR from "antd/lib/locale/fa_IR";

import { MatchMediaBreakpoints } from 'react-hook-breakpoints';

// toastify
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// import root component
import App from './App';

// globalStyles
import GlobalStyles from './templates/globalStyles';

// import react query provider:
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// import react query dev tools:
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";

// context
import { SpinnerProvider } from "./contexts/spinner/SpinnerContext";
import { ThemeProvider } from './contexts/theme/ThemeContext';
import { BottomMenuProvider } from './contexts/bottomMenu/BottomMenuContext';


// initial query client:
const queryClient = new QueryClient();

const breakpoints = {
  xs: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1600,
};

const Application = () => {
  return (
    <>
      <GlobalStyles />
      <QueryClientProvider client={queryClient}>
        <SpinnerProvider>
          <AuthProvider>
            <ConfigProvider direction={"rtl"} locale={fa_IR}>
              <ThemeProvider>
                <MatchMediaBreakpoints breakpoints={breakpoints}>
                  <ToastContainer
                    position="top-center"
                    autoClose={3400}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick
                    rtl
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                    theme="colored"
                  />
                  <BottomMenuProvider>
                    <App />
                  </BottomMenuProvider>
                </MatchMediaBreakpoints>
              </ThemeProvider>
            </ConfigProvider>
            <ReactQueryDevtools />
          </AuthProvider>
        </SpinnerProvider>
      </QueryClientProvider>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('application'));
root.render(<Application />);
