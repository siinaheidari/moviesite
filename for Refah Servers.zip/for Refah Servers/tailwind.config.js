/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    screens: {
      'sm': '576px',
      'md': '768px',
      'lg': '992px',
      'xl': '1200px',
      '2xl': '1600px'
    },
    extend: {
      colors: {
        "borderblue": "#c6d4ff",
        "textcolor": "#4d4d4d",
        "placecolor": "#8c8c8c",
        "textblue": "#1447a0",
        "textLink": "#407BFF",
        "cashpink": "#f61982",
        "cashblack": "#434343",
        "ticketback": "#f9f9f9",
        "tickettext": "#1447ad",
        "tick": "#1cc500",
        "error": "#fe2301",
        "purple": "#7258d8",
        title: "#21409a",
      },
      backgroundColor: {
        "walletblue": "#c6d4ff",
        "chargblue": "#1447a0",
        "cashback": "#c6d4ff",
        "backbtn": "#21409a",
        "newnlue": "#1547a0",
        "eeeeee": "#eeeeee",
        "ffffff": "#ffffff",
        "backAdminInfo": "#fbcb5d",
        "adminBtn": "#28353D",
        "purple": "#7258d8",
        "green": "#badbcc",
        "satPayback":"#f1f5ff"
      },
      boxShadow:{
        '4': ' 0px 4px 4px 0px rgba(122, 122, 122, 0.05)',
        '6': ' 0px 0px 6px 0px rgba(0, 0, 0, 0.10)',
        '8': ' 1px 2px 6px 0px rgba(0, 0, 0, 0.10)',
        "10":" 0px 0px 6px 0px rgba(0, 0, 0, 0.05)",
        box:"0px 1.8089876174926758px 5.426962852478027px 0px rgba(0, 0, 0, 0.10);"
      },
      dropShadow:{
        icon:" 0px 5.04672908782959px 15.981307983398438px #70B5FF",
        requests:"1px 2px 6px rgba(0, 0, 0, 0.10)"
      }
    },


    boxShadow: {
      "shadow": "0px 3px 6px rgba(0,0,0,0.1) "
    }

  },
  plugins: [],
}

